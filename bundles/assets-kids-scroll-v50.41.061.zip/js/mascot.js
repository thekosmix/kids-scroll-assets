/**
 * Kids Scroll Companion Mascot ("Scroll Buddy")
 * Full-body animated companion that encourages toddlers, speaks instructions,
 * performs 5 randomized victory dances on level completion, provides gentle wrong-move
 * coaching, and triggers progressive next-step hints after 9s of inactivity.
 */

(function initMascot() {
  if (typeof window === 'undefined' || typeof document === 'undefined') return;

  const MASCOT_KEY = 'kids_scroll_mascot_enabled';

  const SUCCESS_PHRASES = [
    "Awesome! 🌟",
    "You did it! 🎉",
    "So smart! 👏",
    "Superstar! ⭐",
    "Yay, fantastic! ✨",
    "You're amazing! 🚀",
    "Bingo! Good job! 🥳"
  ];

  const MISTAKE_PHRASES = [
    "Almost! Try another one! 😊",
    "Oops, let's try again! 💫",
    "So close! You've got this! ✨",
    "Keep trying! 🌟",
    "Where does it go? Let's see! 🤔"
  ];

  const IDLE_PHRASES = [
    "You can do it! 🌟",
    "Can you find the next match? 👀",
    "Let's play together! ✨",
    "Give it a try! 🚀"
  ];

  const VICTORY_PHRASES = [
    "Yippee! You did it! 🎉",
    "Woo-hoo! Amazing! 🌟",
    "You are so smart! 🏆",
    "Superstar! Fantastic! ⭐",
    "Hooray! Great job! 🥳"
  ];

  const DANCE_ROUTINES = [
    'dance-twist',
    'dance-jump',
    'dance-shuffle',
    'dance-spin',
    'dance-cheer'
  ];

  const PLAYFUL_PHRASES = [
    { text: "Hehehe! That's giggly!", action: 'giggle' },
    { text: "I'm your best friend! 🌟", action: 'wave' },
    { text: "We'll go on an adventure! 🚀", action: 'cheer' },
    { text: "Let's jump! Boing, boing! 🦘", action: 'jump' },
    { text: "Wheee! You're so quick! ✨", action: 'giggle' },
    { text: "Tickle, tickle! Hehehe! 🎈", action: 'giggle' },
    { text: "High five, buddy! ✋", action: 'clap' }
  ];

  class ScrollBuddyMascot {
    constructor() {
      this.container = null;
      this.btn = null;
      this.actionTimeout = null;
      this.idleTimer = null;
      this.lastInstruction = null;
      this.hintSpokenForCurrentState = false;
      this.lastEncourageSpeechTime = 0;
      this.currentDanceClass = null;
      this.isInitialized = false;
      this.isEnabled = this.checkEnabled();
      this.onUserActivity = this.onUserActivity.bind(this);
    }

    checkEnabled() {
      try {
        return localStorage.getItem(MASCOT_KEY) !== 'false';
      } catch (e) {
        return true;
      }
    }

    setEnabled(enabled) {
      this.isEnabled = !!enabled;
      try {
        localStorage.setItem(MASCOT_KEY, this.isEnabled ? 'true' : 'false');
      } catch (e) {}

      if (this.isEnabled) {
        this.render();
        this.startIdleMonitoring();
      } else if (this.container) {
        this.stopIdleMonitoring();
        this.container.remove();
        this.container = null;
        this.isInitialized = false;
      }
    }

    render() {
      if (this.isInitialized || !this.isEnabled) return;
      if (document.getElementById('kids-scroll-mascot')) return;

      const markup = `
        <div id="kids-scroll-mascot" class="mascot-container mascot-idle" aria-label="Game Companion Mascot">
          <button type="button" class="mascot-btn" id="mascotBtn" aria-label="Tap companion for help" title="Tap me!">
            <svg class="mascot-svg" viewBox="0 0 160 220" width="100%" height="100%" aria-hidden="true">
              <defs>
                <linearGradient id="mascotHoodieGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#6a11cb" />
                  <stop offset="100%" stop-color="#2575fc" />
                </linearGradient>
                <linearGradient id="mascotShortsGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#2c3e50" />
                  <stop offset="100%" stop-color="#34495e" />
                </linearGradient>
              </defs>

              <!-- Ground shadow -->
              <ellipse class="mascot-ground-shadow" cx="80" cy="214" rx="44" ry="6" fill="rgba(0,0,0,0.18)" />

              <!-- Full Body Group -->
              <g class="mascot-full-body">
                <!-- Left Leg & Shoe -->
                <g class="mascot-leg leg-left">
                  <path d="M 52 148 L 50 182 L 68 182 L 70 148 Z" fill="url(#mascotShortsGrad)" stroke="#1a1a1a" stroke-width="4" stroke-linejoin="round" />
                  <path class="mascot-foot foot-left" d="M 40 184 C 40 178 50 176 68 176 C 76 176 78 184 78 195 C 78 202 74 204 60 204 C 46 204 40 196 40 184 Z" fill="#ffb300" stroke="#1a1a1a" stroke-width="4.5" stroke-linejoin="round" />
                  <path d="M 44 201 L 76 201" stroke="#ffffff" stroke-width="3.5" stroke-linecap="round" />
                </g>

                <!-- Right Leg & Shoe -->
                <g class="mascot-leg leg-right">
                  <path d="M 90 148 L 92 182 L 110 182 L 108 148 Z" fill="url(#mascotShortsGrad)" stroke="#1a1a1a" stroke-width="4" stroke-linejoin="round" />
                  <path class="mascot-foot foot-right" d="M 82 184 C 82 176 92 176 110 176 C 120 176 120 184 120 195 C 120 202 114 204 100 204 C 86 204 82 196 82 184 Z" fill="#ffb300" stroke="#1a1a1a" stroke-width="4.5" stroke-linejoin="round" />
                  <path d="M 84 201 L 116 201" stroke="#ffffff" stroke-width="3.5" stroke-linecap="round" />
                </g>

                <!-- Torso: Star Hoodie -->
                <g class="mascot-torso-group">
                  <path class="mascot-torso" d="M 44 112 C 40 144 44 158 60 158 L 100 158 C 116 158 120 144 116 112 C 104 108 92 106 80 106 C 68 106 56 108 44 112 Z" fill="url(#mascotHoodieGrad)" stroke="#1a1a1a" stroke-width="5" stroke-linejoin="round" />
                  <!-- Gold Star Badge on Chest -->
                  <path class="mascot-star-badge" d="M 80 122 L 82.5 129 L 89.5 129 L 84 133 L 86 140 L 80 136 L 74 140 L 76 133 L 70.5 129 L 77.5 129 Z" fill="#ffd700" stroke="#e67e22" stroke-width="1.2" />
                  <!-- Pocket curve -->
                  <path d="M 64 146 Q 80 152 96 146" fill="none" stroke="rgba(255,255,255,0.4)" stroke-width="3" stroke-linecap="round" />
                </g>

                <!-- Left Arm & Hand -->
                <g class="mascot-arm arm-left">
                  <path d="M 46 116 C 32 126 22 138 26 152 C 28 156 36 158 40 148 C 43 138 50 130 54 124" fill="url(#mascotHoodieGrad)" stroke="#1a1a1a" stroke-width="4.5" stroke-linejoin="round" />
                  <circle class="mascot-hand hand-left" cx="26" cy="156" r="10.5" fill="#d99c75" stroke="#1a1a1a" stroke-width="4" />
                </g>

                <!-- Right Arm & Hand -->
                <g class="mascot-arm arm-right">
                  <path d="M 114 116 C 128 126 138 138 134 152 C 132 156 124 158 120 148 C 117 138 110 130 106 124" fill="url(#mascotHoodieGrad)" stroke="#1a1a1a" stroke-width="4.5" stroke-linejoin="round" />
                  <circle class="mascot-hand hand-right" cx="134" cy="156" r="10.5" fill="#d99c75" stroke="#1a1a1a" stroke-width="4" />
                </g>

                <!-- Head & Hoodie Group (Cozy character hoodie pulled UP over head) -->
                <g class="mascot-head-group">
                  <!-- Outer Hoodie Hood (pulled up over head) -->
                  <path class="mascot-hood-outer" d="M 80 14 C 118 14 136 38 136 74 C 136 102 122 114 108 116 C 96 118 64 118 52 116 C 38 114 24 102 24 74 C 24 38 42 14 80 14 Z" fill="url(#mascotHoodieGrad)" stroke="#1a1a1a" stroke-width="5" stroke-linejoin="round" />

                  <!-- Hood Top Seam Highlight -->
                  <path d="M 46 32 C 60 20 100 20 114 32" fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="3" stroke-linecap="round" />

                  <!-- Face Opening of Hoodie (revealing child face inside) -->
                  <path class="mascot-face-opening" d="M 80 34 C 104 34 118 48 118 72 C 118 96 102 106 80 106 C 58 106 42 96 42 72 C 42 48 56 34 80 34 Z" fill="#d99c75" stroke="#1a1a1a" stroke-width="4.5" stroke-linejoin="round" />

                  <!-- Hood Fabric Edge Lining -->
                  <path d="M 80 34 C 104 34 118 48 118 72 C 118 96 102 106 80 106 C 58 106 42 96 42 72 C 42 48 56 34 80 34 Z" fill="none" stroke="#5012a8" stroke-width="3" />

                  <!-- Cute hair tuft peeking from top of hoodie opening -->
                  <path d="M 72 34 C 74 27 86 27 88 34 C 84 38 76 38 72 34 Z" fill="#caa07a" />

                  <!-- Eyebrows -->
                  <path class="mascot-eyebrow eyebrow-left" d="M 52 54 Q 62 46 72 54" fill="none" stroke="#1a1a1a" stroke-width="5" stroke-linecap="round" />
                  <path class="mascot-eyebrow eyebrow-right" d="M 88 48 Q 98 42 108 52" fill="none" stroke="#1a1a1a" stroke-width="5" stroke-linecap="round" />

                  <!-- Eyes with animated blinking -->
                  <g class="mascot-eye eye-left">
                    <ellipse cx="62" cy="66" rx="12" ry="13" fill="#ffffff" stroke="#1a1a1a" stroke-width="4" />
                    <circle class="mascot-pupil pupil-left" cx="64" cy="66" r="6" fill="#1a1a1a" />
                    <circle cx="62" cy="63" r="2.2" fill="#ffffff" />
                  </g>
                  <g class="mascot-eye eye-right">
                    <ellipse cx="98" cy="64" rx="13" ry="14" fill="#ffffff" stroke="#1a1a1a" stroke-width="4" />
                    <circle class="mascot-pupil pupil-right" cx="102" cy="65" r="6" fill="#1a1a1a" />
                    <circle cx="100" cy="62" r="2.2" fill="#ffffff" />
                  </g>

                  <!-- Mouth States -->
                  <g class="mascot-mouth-group">
                    <path class="mouth-neutral" d="M 70 89 Q 80 89 90 87" fill="none" stroke="#1a1a1a" stroke-width="4.2" stroke-linecap="round" />
                    <ellipse class="mouth-talking" cx="80" cy="90" rx="8" ry="5.5" fill="#7a1f1d" stroke="#1a1a1a" stroke-width="3.2" style="display: none;" />
                    <path class="mouth-celebrating" d="M 66 86 Q 80 102 94 86 Z" fill="#d84315" stroke="#1a1a1a" stroke-width="4" style="display: none;" />
                  </g>

                  <!-- Hoodie Collar Overlap at Neck -->
                  <path class="mascot-hoodie-collar" d="M 50 106 C 64 116 96 116 110 106 C 100 118 60 118 50 106 Z" fill="#4d10a2" stroke="#1a1a1a" stroke-width="3.5" stroke-linejoin="round" />

                  <!-- Hanging Hoodie Drawstrings with Golden Toggles -->
                  <g class="mascot-drawstrings">
                    <path class="mascot-drawstring" d="M 66 112 Q 63 126 65 138" fill="none" stroke="#ffffff" stroke-width="3" stroke-linecap="round" />
                    <circle cx="65" cy="140" r="3" fill="#ffd700" stroke="#e67e22" stroke-width="0.8" />
                    <path class="mascot-drawstring" d="M 94 112 Q 97 126 95 138" fill="none" stroke="#ffffff" stroke-width="3" stroke-linecap="round" />
                    <circle cx="95" cy="140" r="3" fill="#ffd700" stroke="#e67e22" stroke-width="0.8" />
                  </g>
                </g>
              </g>

              <span class="mascot-star-sparkle" aria-hidden="true">✨</span>
            </svg>
          </button>
        </div>
      `;

      const wrapper = document.createElement('div');
      wrapper.innerHTML = markup;
      const el = wrapper.firstElementChild;
      document.body.appendChild(el);

      this.container = el;
      this.btn = document.getElementById('mascotBtn');
      this.isInitialized = true;

      // Check for top-left placement (e.g. Build the Zoo, Build a Face)
      const path = window.location.pathname;
      const isTopLeft = (document.body && document.body.dataset.mascotPos === 'top-left') ||
                        path.includes('build-the-zoo') ||
                        path.includes('build-a-face');
      if (isTopLeft) {
        this.container.classList.add('mascot-pos-top-left');
      }

      const isPortraitTopLeft = (document.body && document.body.dataset.mascotPos === 'portrait-top-left');
      if (isPortraitTopLeft) {
        this.container.classList.add('mascot-pos-portrait-top-left');
      }

      this.btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.onTap();
      });

      this.btn.addEventListener('touchstart', () => {}, { passive: true });

      this.startIdleMonitoring();
    }

    startIdleMonitoring() {
      if (typeof window === 'undefined') return;
      ['touchstart', 'mousedown', 'pointerdown', 'keydown'].forEach(evt => {
        window.addEventListener(evt, this.onUserActivity, { passive: true, capture: true });
      });
      this.resetIdleTimer();
    }

    stopIdleMonitoring() {
      if (typeof window === 'undefined') return;
      ['touchstart', 'mousedown', 'pointerdown', 'keydown'].forEach(evt => {
        window.removeEventListener(evt, this.onUserActivity, true);
      });
      clearTimeout(this.idleTimer);
    }

    onUserActivity(e) {
      this.resetIdleTimer();
      // If user interacted with the game/page outside of tapping the mascot, reset hint state
      if (e && e.target && !e.target.closest('#kids-scroll-mascot')) {
        this.resetHintState();
      }
    }

    resetIdleTimer() {
      clearTimeout(this.idleTimer);
      if (!this.isEnabled) return;

      // 10-second inactivity delay for toddler guidance
      this.idleTimer = setTimeout(() => {
        this.onIdleTimeout();
      }, 10000);
    }

    onIdleTimeout() {
      if (!this.isEnabled || !this.container) return;
      if (window.speechSynthesis && window.speechSynthesis.speaking) return;

      this.resetHintState();

      // Mascot waves and speaks a gentle encouraging prompt
      this.wave(2000);
      const phrase = IDLE_PHRASES[Math.floor(Math.random() * IDLE_PHRASES.length)];
      this.say(phrase);

      // Trigger progressive next-hint if game supports it
      if (typeof window.showNextHint === 'function') {
        window.showNextHint();
      }

      // Reset timer to wait another interval
      this.resetIdleTimer();
    }

    resetHintState() {
      this.hintSpokenForCurrentState = false;
    }

    onTap() {
      // Gentle haptic feedback on supported mobile devices
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try { navigator.vibrate(25); } catch (e) {}
      }

      if (!this.hintSpokenForCurrentState) {
        // FIRST TAP: Speak instructional hint and show next move!
        this.hintSpokenForCurrentState = true;

        this.btn.style.transform = 'scale(1.15) rotate(-6deg)';
        setTimeout(() => {
          if (this.btn) this.btn.style.transform = '';
        }, 250);

        if (typeof window.showNextHint === 'function') {
          window.showNextHint();
        }

        if (this.lastInstruction) {
          this.say(this.lastInstruction);
        } else {
          this.say("Look! Let's find the matching one! ✨");
        }
      } else {
        // SUBSEQUENT TAPS: Friendly playful chatter & fun animations!
        const phraseObj = PLAYFUL_PHRASES[Math.floor(Math.random() * PLAYFUL_PHRASES.length)];

        if (phraseObj.action === 'jump') {
          this.btn.classList.add('mascot-tap-jump');
          setTimeout(() => { if (this.btn) this.btn.classList.remove('mascot-tap-jump'); }, 800);
        } else if (phraseObj.action === 'giggle') {
          this.btn.classList.add('mascot-tap-giggle');
          setTimeout(() => { if (this.btn) this.btn.classList.remove('mascot-tap-giggle'); }, 800);
        } else if (phraseObj.action === 'wave') {
          this.wave(1500);
        } else if (phraseObj.action === 'clap') {
          this.clap(1200);
        } else {
          this.btn.style.transform = 'scale(1.15) rotate(6deg)';
          setTimeout(() => { if (this.btn) this.btn.style.transform = ''; }, 250);
        }

        this.say(phraseObj.text);
      }
    }

    say(text, onEnd = null) {
      if (!this.isEnabled) {
        if (typeof window.speakText === 'function') {
          window.speakText(text, onEnd);
        }
        return;
      }
      this.render();
      if (!this.container) return;

      // Keep original game instruction intact if speaking playful chatter
      if (!PLAYFUL_PHRASES.some(p => p.text === text)) {
        this.lastInstruction = text;
      }
      this.setSpeaking(true);

      const finishSpeech = () => {
        this.setSpeaking(false);
        if (onEnd) onEnd();
      };

      if (typeof window.speakText === 'function') {
        window.speakText(text, finishSpeech);
      } else {
        const estDuration = Math.max(1500, text.length * 75);
        setTimeout(finishSpeech, estDuration);
      }
    }

    setSpeaking(speaking) {
      if (!this.container) return;
      if (speaking) {
        this.container.classList.add('is-speaking');
      } else {
        this.container.classList.remove('is-speaking');
      }
    }

    clap(duration = 1600) {
      if (!this.isEnabled) return;
      this.render();
      if (!this.container) return;

      clearTimeout(this.actionTimeout);
      this.clearActionClasses();
      this.container.classList.add('is-clapping');

      this.actionTimeout = setTimeout(() => {
        if (this.container) this.container.classList.remove('is-clapping');
      }, duration);
    }

    /**
     * Encourages the child on every successful move with varied lively actions and speech.
     * Rotates between clapping, joyful hopping, friendly waving, and cheer gestures.
     */
    encourage(customPhrase = null) {
      if (!this.isEnabled) return;
      this.render();
      if (!this.container) return;

      this.resetHintState();

      // Pick lively mascot action: 'clap', 'jump', 'wave', 'fist-pump'
      const actions = ['clap', 'jump', 'wave', 'fist-pump'];
      const action = actions[Math.floor(Math.random() * actions.length)];

      clearTimeout(this.actionTimeout);
      this.clearActionClasses();

      if (action === 'clap') {
        this.container.classList.add('is-clapping');
        this.actionTimeout = setTimeout(() => {
          if (this.container) this.container.classList.remove('is-clapping');
        }, 1200);
      } else if (action === 'jump') {
        this.btn.classList.add('mascot-tap-jump');
        setTimeout(() => {
          if (this.btn) this.btn.classList.remove('mascot-tap-jump');
        }, 800);
      } else if (action === 'wave') {
        this.container.classList.add('is-waving');
        this.actionTimeout = setTimeout(() => {
          if (this.container) this.container.classList.remove('is-waving');
        }, 1200);
      } else if (action === 'fist-pump') {
        this.container.classList.add('is-dancing', 'dance-cheer');
        this.actionTimeout = setTimeout(() => {
          if (this.container) {
            this.container.classList.remove('is-dancing', 'dance-cheer');
          }
        }, 1000);
      }

      // Pick upbeat preschool encouragement phrase
      const phrase = customPhrase || SUCCESS_PHRASES[Math.floor(Math.random() * SUCCESS_PHRASES.length)];

      // Throttle speech slightly (~700ms) so rapid consecutive moves don't stutter audio
      const now = Date.now();
      if (now - this.lastEncourageSpeechTime > 700) {
        this.lastEncourageSpeechTime = now;
        this.say(phrase);
      }
    }

    /**
     * Executes 1 of 5 randomized victory dance routines on level completion.
     * Pauses celebration for the specified duration (default 2500ms) before onComplete callback.
     */
    dance(duration = 2500, onComplete = null) {
      if (!this.isEnabled) {
        if (onComplete) setTimeout(onComplete, duration);
        return;
      }
      this.render();
      if (!this.container) {
        if (onComplete) setTimeout(onComplete, duration);
        return;
      }

      clearTimeout(this.actionTimeout);
      this.clearActionClasses();
      this.resetHintState();

      // Pick 1 of 5 randomized victory dance routines
      const danceClass = DANCE_ROUTINES[Math.floor(Math.random() * DANCE_ROUTINES.length)];
      this.currentDanceClass = danceClass;
      this.container.classList.add('is-dancing', danceClass);

      // Play victory phrase
      const phrase = VICTORY_PHRASES[Math.floor(Math.random() * VICTORY_PHRASES.length)];
      this.say(phrase);

      this.actionTimeout = setTimeout(() => {
        if (this.container) {
          this.container.classList.remove('is-dancing');
          if (this.currentDanceClass) {
            this.container.classList.remove(this.currentDanceClass);
            this.currentDanceClass = null;
          }
        }
        if (onComplete) onComplete();
      }, duration);
    }

    /**
     * Gentle coaching reaction on mistake/incorrect move
     */
    reactMistake(duration = 1800) {
      if (!this.isEnabled) return;
      this.render();
      if (!this.container) return;

      clearTimeout(this.actionTimeout);
      this.clearActionClasses();
      this.resetHintState();
      this.container.classList.add('is-thinking');

      const phrase = MISTAKE_PHRASES[Math.floor(Math.random() * MISTAKE_PHRASES.length)];
      this.say(phrase);

      // Show next hint to help child
      if (typeof window.showNextHint === 'function') {
        setTimeout(() => {
          window.showNextHint();
        }, 400);
      }

      this.actionTimeout = setTimeout(() => {
        if (this.container) this.container.classList.remove('is-thinking');
      }, duration);
    }

    wave(duration = 2000) {
      if (!this.isEnabled) return;
      this.render();
      if (!this.container) return;

      clearTimeout(this.actionTimeout);
      this.clearActionClasses();
      this.container.classList.add('is-waving');

      this.actionTimeout = setTimeout(() => {
        if (this.container) this.container.classList.remove('is-waving');
      }, duration);
    }

    clearActionClasses() {
      if (!this.container) return;
      this.container.classList.remove('is-clapping', 'is-dancing', 'is-waving', 'is-thinking');
      DANCE_ROUTINES.forEach(d => this.container.classList.remove(d));
    }

    init() {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => this.render());
      } else {
        this.render();
      }
    }
  }

  window.mascot = new ScrollBuddyMascot();

  // Auto-mount on load
  window.mascot.init();
})();
