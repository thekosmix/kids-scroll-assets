/**
 * Flashlight Explorer Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const overlay = document.getElementById('dark-overlay');
    const scenery = document.getElementById('scenery');
    const flashlightEmoji = document.getElementById('flashlight-emoji');

    const nightAnimals = ['🦉', '🦇', '🐭', '🦊', '🐸', '🐺'];
    let animalsToFind = 3;
    let foundCount = 0;
    let animalElements = [];
    let isDragging = false;
    let startTime;

    function initGame() {
        scenery.innerHTML = '';
        animalElements = [];
        foundCount = 0;
        
        // Pick random animals
        const shuffled = [...nightAnimals].sort(() => 0.5 - Math.random());
        const selected = shuffled.slice(0, animalsToFind);
        
        // Add some random background trees that aren't objectives
        const allItems = [...selected, '🌲', '🌳', '🌲'];
        allItems.sort(() => 0.5 - Math.random());

        allItems.forEach(item => {
            const el = document.createElement('div');
            el.className = 'hidden-animal';
            el.textContent = item;
            
            // Random positioning logic
            el.style.position = 'absolute';
            el.style.left = (Math.random() * 70 + 15) + '%';
            el.style.top = (Math.random() * 60 + 15) + '%';
            
            if(selected.includes(item)) {
                el.dataset.isObjective = 'true';
                el.dataset.name = getAnimalName(item);
                animalElements.push(el);
            }
            scenery.appendChild(el);
        });

        // Start flashlight emoji visible at startup
        const cx = window.innerWidth / 2;
        const cy = window.innerHeight * 0.65;
        if (flashlightEmoji) {
            flashlightEmoji.style.display = 'block';
            flashlightEmoji.style.left = cx + 'px';
            flashlightEmoji.style.top = cy + 'px';
        }

        // Position flashlight and light beam at start
        updateFlashlightPosition(cx, cy, true);
        startTime = Date.now();

        showStartupGuide("Drag the flashlight to explore the dark and find animals!", {
            type: 'ghost-swipe',
            startX: '50%', startY: '50%',
            endX: '50%', endY: '70%'
        });

        if(typeof saveToRecent === 'function') saveToRecent('flashlight-explorer');
    }

    function getAnimalName(emoji) {
        switch(emoji) {
            case '🦉': return 'Owl';
            case '🦇': return 'Bat';
            case '🐭': return 'Mouse';
            case '🦊': return 'Fox';
            case '🐸': return 'Frog';
            case '🐺': return 'Wolf';
            default: return 'Animal';
        }
    }

    function updateFlashlightPosition(x, y, showEmoji = true) {
        const rect = overlay.getBoundingClientRect();
        const localX = x - rect.left;
        const localY = y - rect.top;
        
        // Light beam center sits right above the flashlight head
        const beamY = localY - 30;
        
        overlay.style.background = `radial-gradient(circle 135px at ${localX}px ${beamY}px, transparent 0%, rgba(0,0,0,0.85) 45%, rgba(0,0,0,0.98) 100%)`;
        
        if (showEmoji && flashlightEmoji) {
            flashlightEmoji.style.display = 'block';
            flashlightEmoji.style.left = localX + 'px';
            flashlightEmoji.style.top = localY + 'px';
        }

        // Collision check is performed against the center of the light beam
        checkCollision(rect.left + localX, rect.top + beamY);
    }

    function checkCollision(beamScreenX, beamScreenY) {
        // Distance check between light beam center and each objective
        animalElements.forEach(el => {
            if(el.classList.contains('found')) return;
            
            const rect = el.getBoundingClientRect();
            const cx = rect.left + rect.width / 2;
            const cy = rect.top + rect.height / 2;
            
            const dx = cx - beamScreenX;
            const dy = cy - beamScreenY;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            // Flashlight radius is 135px
            if(dist < 120) {
                el.classList.add('found');
                foundCount++;
                if (typeof playAnimalSound === 'function' && typeof ANIMAL_SOUNDS !== 'undefined' && ANIMAL_SOUNDS[el.textContent]) {
                    playAnimalSound(el.textContent);
                }
                speakText("You found the " + el.dataset.name + "!");
                if(typeof vibrateSuccess === 'function') vibrateSuccess();
                
                if(foundCount >= animalsToFind) {
                    setTimeout(winGame, 1500);
                }
            }
        });
    }

    function handleStart(e) {
        isDragging = true;
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        updateFlashlightPosition(clientX, clientY);
    }

    function handleMove(e) {
        if(!isDragging) return;
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        updateFlashlightPosition(clientX, clientY);
    }

    function handleEnd() {
        isDragging = false;
    }

    document.addEventListener('touchstart', handleStart, {passive: true});
    document.addEventListener('touchmove', handleMove, {passive: true});
    document.addEventListener('touchend', handleEnd);
    document.addEventListener('touchcancel', handleEnd);
    
    document.addEventListener('mousedown', handleStart);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);

    function winGame() {
        // Illuminate entire screen
        overlay.style.background = 'transparent';
        if (flashlightEmoji) flashlightEmoji.style.display = 'none';
        
        triggerCelebration(true, 100);
        
        const duration = Math.floor((Date.now() - startTime) / 1000);
        if(typeof recordGameStats === 'function') {
            recordGameStats('flashlight-explorer', duration, { avgTime: duration/animalsToFind });
        }

        setTimeout(() => {
            overlay.style.background = 'radial-gradient(circle 120px at 50% 50%, transparent 0%, rgba(0,0,0,0.85) 40%, rgba(0,0,0,0.98) 100%)';
            initGame();
        }, 4000);
    }

    initGame();
});
