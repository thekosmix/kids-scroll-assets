/**
 * Trace the Path Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const gameContainer = document.getElementById('game-container');
    const draggable = document.getElementById('draggable-emoji');
    const target = document.getElementById('target-emoji');
    const trackPath = document.getElementById('track-path');
    const progressPath = document.getElementById('progress-path');
    
    let isDragging = false;
    let pathPoints = [];
    let currentPointIndex = 0;
    const SNAP_DISTANCE = 60;
    
    const pairs = [
        { obj: '🚗', target: '🏠' },
        { obj: '🐛', target: '🍃' },
        { obj: '🐝', target: '🌻' },
        { obj: '🐠', target: '🌊' },
        { obj: '🚂', target: '🚉' },
        { obj: '🚀', target: '🌙' },
        { obj: '🐒', target: '🍌' },
        { obj: '⛵', target: '🏝️' },
        { obj: '🐦', target: '🌳' },
        { obj: '🐸', target: '🪷' },
        { obj: '🚜', target: '🌾' },
        { obj: '🕷️', target: '🕸️' },
        { obj: '🐻', target: '🍯' },
        { obj: '🐭', target: '🧀' },
        { obj: '🐰', target: '🥕' }
    ];
    
    let startTime;

    const COLOR_THEMES = [
        { track: '#ffd54f', progress: '#ff6f00', bg: '#fffde7' }, // Sunny Gold & Orange
        { track: '#80deea', progress: '#00b0ff', bg: '#e0f7fa' }, // Sky Cyan & Electric Blue
        { track: '#f48fb1', progress: '#d81b60', bg: '#fce4ec' }, // Bubblegum Pink & Deep Rose
        { track: '#c5cae9', progress: '#651fff', bg: '#ede7f6' }, // Soft Lavender & Electric Violet
        { track: '#a5d6a7', progress: '#00c853', bg: '#e8f5e9' }, // Mint & Emerald
        { track: '#ffcc80', progress: '#ff3d00', bg: '#fff3e0' }, // Peach & Bright Coral
        { track: '#80cbc4', progress: '#00897b', bg: '#e0f2f1' }  // Teal & Turquoise
    ];

    function initGame() {
        const pair = pairs[Math.floor(Math.random() * pairs.length)];
        draggable.textContent = pair.obj;
        target.textContent = pair.target;

        const theme = COLOR_THEMES[Math.floor(Math.random() * COLOR_THEMES.length)];
        trackPath.setAttribute('stroke', theme.track);
        progressPath.setAttribute('stroke', theme.progress);
        document.body.style.backgroundColor = theme.bg;

        const rect = gameContainer.getBoundingClientRect();
        const w = rect.width || window.innerWidth;
        const h = rect.height || (window.innerHeight - 70);

        // Safe margins (accounting for 40px stroke width + 60px emoji size + padding)
        const padX = Math.max(50, w * 0.08);
        const padY = Math.max(50, h * 0.12);
        const minY = padY;
        const maxY = h - padY;
        const minX = padX;
        const maxX = w - padX;
        const isPortrait = h > w;
        const midX = (minX + maxX) / 2;
        const midY = (minY + maxY) / 2;

        // Generate vibrant geometric path shapes
        const pathType = Math.floor(Math.random() * 6);
        let pathD = '';
        let startX = minX;
        let startY = minY;
        let endX = maxX;
        let endY = maxY;

        if (pathType === 0) {
            // 1. Sinusoidal Wave (Smooth multi-crest undulation)
            if (!isPortrait) {
                const steps = 4;
                const dx = (maxX - minX) / steps;
                startX = minX;
                startY = midY;
                pathD = `M ${startX} ${startY}`;
                for (let i = 1; i <= steps; i++) {
                    const x = minX + i * dx;
                    const prevX = minX + (i - 1) * dx;
                    const peakY = i % 2 === 1 ? minY : maxY;
                    pathD += ` Q ${(prevX + x) / 2} ${peakY}, ${x} ${i === steps ? (steps % 2 === 1 ? minY : maxY) : midY}`;
                }
                endX = maxX;
                endY = steps % 2 === 1 ? minY : maxY;
            } else {
                const steps = 4;
                const dy = (maxY - minY) / steps;
                startX = midX;
                startY = minY;
                pathD = `M ${startX} ${startY}`;
                for (let i = 1; i <= steps; i++) {
                    const y = minY + i * dy;
                    const prevY = minY + (i - 1) * dy;
                    const peakX = i % 2 === 1 ? minX : maxX;
                    pathD += ` Q ${peakX} ${(prevY + y) / 2}, ${i === steps ? (steps % 2 === 1 ? minX : maxX) : midX} ${y}`;
                }
                endX = steps % 2 === 1 ? minX : maxX;
                endY = maxY;
            }
        } else if (pathType === 1) {
            // 2. Zig-Zag (Exciting sawtooth turns)
            if (!isPortrait) {
                const segments = 4;
                const dx = (maxX - minX) / segments;
                startX = minX;
                startY = maxY;
                pathD = `M ${startX} ${startY}`;
                for (let i = 1; i <= segments; i++) {
                    const x = minX + i * dx;
                    const y = i % 2 === 1 ? minY : maxY;
                    pathD += ` L ${x} ${y}`;
                }
                endX = maxX;
                endY = segments % 2 === 1 ? minY : maxY;
            } else {
                const segments = 4;
                const dy = (maxY - minY) / segments;
                startX = minX;
                startY = minY;
                pathD = `M ${startX} ${startY}`;
                for (let i = 1; i <= segments; i++) {
                    const y = minY + i * dy;
                    const x = i % 2 === 1 ? maxX : minX;
                    pathD += ` L ${x} ${y}`;
                }
                endX = segments % 2 === 1 ? maxX : minX;
                endY = maxY;
            }
        } else if (pathType === 2) {
            // 3. Mountain Peaks (Scenic jagged peaks and valleys)
            if (!isPortrait) {
                startX = minX;
                startY = maxY;
                const p1X = minX + (maxX - minX) * 0.25;
                const p2X = minX + (maxX - minX) * 0.5;
                const p3X = minX + (maxX - minX) * 0.75;
                const peak1Y = minY + (maxY - minY) * 0.15;
                const valley1Y = minY + (maxY - minY) * 0.75;
                const peak2Y = minY;
                pathD = `M ${startX} ${startY} L ${p1X} ${peak1Y} L ${p2X} ${valley1Y} L ${p3X} ${peak2Y} L ${maxX} ${maxY}`;
                endX = maxX;
                endY = maxY;
            } else {
                startX = minX;
                startY = minY;
                const p1Y = minY + (maxY - minY) * 0.25;
                const p2Y = minY + (maxY - minY) * 0.5;
                const p3Y = minY + (maxY - minY) * 0.75;
                const peak1X = minX + (maxX - minX) * 0.85;
                const valley1X = minX + (maxX - minX) * 0.25;
                const peak2X = maxX;
                pathD = `M ${startX} ${startY} L ${peak1X} ${p1Y} L ${valley1X} ${p2Y} L ${peak2X} ${p3Y} L ${minX} ${maxY}`;
                endX = minX;
                endY = maxY;
            }
        } else if (pathType === 3) {
            // 4. Stepper (Block staircase steps)
            if (!isPortrait) {
                const steps = 3;
                const dx = (maxX - minX) / steps;
                const dy = (maxY - minY) / steps;
                startX = minX;
                startY = maxY;
                pathD = `M ${startX} ${startY}`;
                for (let i = 1; i <= steps; i++) {
                    const curY = maxY - i * dy;
                    const prevX = minX + (i - 1) * dx;
                    const curX = minX + i * dx;
                    pathD += ` L ${prevX} ${curY} L ${curX} ${curY}`;
                }
                endX = maxX;
                endY = minY;
            } else {
                const steps = 3;
                const dx = (maxX - minX) / steps;
                const dy = (maxY - minY) / steps;
                startX = minX;
                startY = minY;
                pathD = `M ${startX} ${startY}`;
                for (let i = 1; i <= steps; i++) {
                    const curX = minX + i * dx;
                    const prevY = minY + (i - 1) * dy;
                    const curY = minY + i * dy;
                    pathD += ` L ${curX} ${prevY} L ${curX} ${curY}`;
                }
                endX = maxX;
                endY = maxY;
            }
        } else if (pathType === 4) {
            // 5. Multi-turn Spiral / Swirl inwards
            startX = minX;
            startY = maxY;
            endX = midX;
            endY = midY;
            const innerLeftX = minX + (maxX - minX) * 0.3;
            const innerRightX = minX + (maxX - minX) * 0.7;
            const innerTopY = minY + (maxY - minY) * 0.3;
            const innerBotY = minY + (maxY - minY) * 0.7;
            pathD = `M ${startX} ${startY} C ${minX} ${minY}, ${maxX} ${minY}, ${maxX} ${maxY} C ${maxX} ${maxY}, ${innerLeftX} ${maxY}, ${innerLeftX} ${midY} C ${innerLeftX} ${innerTopY}, ${innerRightX} ${innerTopY}, ${innerRightX} ${midY} C ${innerRightX} ${innerBotY}, ${midX} ${innerBotY}, ${midX} ${midY}`;
        } else {
            // 6. Rollercoaster Loop-the-Loop
            if (!isPortrait) {
                startX = minX;
                startY = maxY;
                const x1 = minX + (maxX - minX) * 0.3;
                const x2 = minX + (maxX - minX) * 0.7;
                const loopH = (maxY - minY) * 0.75;
                pathD = `M ${startX} ${startY} C ${x1} ${maxY}, ${x1} ${maxY - loopH}, ${midX} ${minY} C ${x2} ${maxY - loopH}, ${x1} ${minY}, ${midX} ${maxY} C ${x2} ${maxY}, ${x2} ${maxY}, ${maxX} ${minY}`;
                endX = maxX;
                endY = minY;
            } else {
                startX = minX;
                startY = minY;
                const y1 = minY + (maxY - minY) * 0.3;
                const y2 = minY + (maxY - minY) * 0.7;
                pathD = `M ${startX} ${startY} C ${maxX} ${y1}, ${minX} ${y2}, ${maxX} ${maxY}`;
                endX = maxX;
                endY = maxY;
            }
        }

        trackPath.setAttribute('d', pathD);
        
        // Setup positions
        draggable.style.left = startX + 'px';
        draggable.style.top = startY + 'px';
        target.style.left = endX + 'px';
        target.style.top = endY + 'px';

        // Pre-calculate path points for snap/progress
        const pathLength = trackPath.getTotalLength();
        const numPoints = Math.floor(pathLength / 10); // Checkpoint every 10px
        pathPoints = [];
        for(let i=0; i<=numPoints; i++) {
            const pt = trackPath.getPointAtLength(i * 10);
            pathPoints.push({x: pt.x, y: pt.y, distance: i * 10});
        }
        
        currentPointIndex = 0;
        updateProgressPath();
        startTime = Date.now();

        showStartupGuide("Follow the path to go home!", {
            type: 'ghost-trace',
            startX: `${startX}px`,
            startY: `${startY}px`,
            endX: `${endX}px`,
            endY: `${endY}px`
        });
        
        if(typeof saveToRecent === 'function') saveToRecent('trace-path');
    }

    function handleStart(e) {
        if(e.target === draggable) {
            isDragging = true;
            e.preventDefault();
        }
    }

    function handleMove(e) {
        if(!isDragging) return;
        e.preventDefault();

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        const containerRect = gameContainer.getBoundingClientRect();
        const posX = clientX - containerRect.left;
        const posY = clientY - containerRect.top;

        // Find nearest point on the path ahead
        let nearestIdx = currentPointIndex;
        let minDis = Infinity;
        
        // Only allow moving forward along the path (within a window of points)
        const windowSize = 30; // approx 300px ahead max
        const endIdx = Math.min(pathPoints.length, currentPointIndex + windowSize);
        
        for(let i = currentPointIndex; i < endIdx; i++) {
            const pt = pathPoints[i];
            const dx = pt.x - posX;
            const dy = pt.y - posY;
            const dis = Math.sqrt(dx*dx + dy*dy);
            if(dis < minDis) {
                minDis = dis;
                nearestIdx = i;
            }
        }

        // If the finger is within snap distance of the path, move the emoji
        if(minDis < SNAP_DISTANCE) {
            currentPointIndex = nearestIdx;
            const snapPt = pathPoints[currentPointIndex];
            draggable.style.left = snapPt.x + 'px';
            draggable.style.top = snapPt.y + 'px';
            updateProgressPath();

            // Check win
            if(currentPointIndex >= pathPoints.length - 2) { // Allow slight forgiveness
                isDragging = false;
                winGame();
            }
        }
    }

    function handleEnd() {
        isDragging = false;
    }

    function updateProgressPath() {
        if(currentPointIndex === 0) {
            progressPath.setAttribute('d', '');
            return;
        }
        
        // Generate partial path
        const startPt = pathPoints[0];
        let d = `M ${startPt.x} ${startPt.y}`;
        // Add a few points to make it smooth, don't need every single one but it's fine for SVG
        for(let i=1; i<=currentPointIndex; i+=5) {
            d += ` L ${pathPoints[i].x} ${pathPoints[i].y}`;
        }
        d += ` L ${pathPoints[currentPointIndex].x} ${pathPoints[currentPointIndex].y}`;
        progressPath.setAttribute('d', d);
    }

    function winGame() {
        // Snap to exact center of target
        draggable.style.left = target.style.left;
        draggable.style.top = target.style.top;
        
        triggerCelebration(true, 100);
        
        const duration = Math.floor((Date.now() - startTime) / 1000);
        if(typeof recordGameStats === 'function') {
            recordGameStats('trace-path', duration, { avgTime: duration });
        }

        setTimeout(() => {
            initGame();
        }, 3500);
    }

    document.addEventListener('touchstart', handleStart, {passive: false});
    document.addEventListener('touchmove', handleMove, {passive: false});
    document.addEventListener('touchend', handleEnd);
    document.addEventListener('touchcancel', handleEnd);
    
    document.addEventListener('mousedown', handleStart);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);

    initGame();

    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(initGame, 250);
    });
});
