/**
 * Standalone-only nav: hides the marketing footer (blog/contact/social links
 * a kid could tap out to) and adds a clockwise 3-way switcher pill:
 * Play & Learn (🎮) -> Stories & Rhymes (📖) -> Wonders & Facts (💡) -> Play & Learn (🎮)
 * only when running installed (PWA/TWA). No-op in a regular browser tab.
 */
(function () {
  if (typeof isStandaloneMode !== 'function' || !isStandaloneMode()) return;

  var path = window.location.pathname;
  var isGameMenu = path.endsWith('/game/') || path.endsWith('/game/index.html');
  var isStoryMenu = path.endsWith('/story/') || path.endsWith('/story/index.html');
  var isQuestionMenu = path.endsWith('/question/') || path.endsWith('/question/index.html');
  if (!isGameMenu && !isStoryMenu && !isQuestionMenu) return;

  var footer = document.querySelector('footer');
  if (footer) footer.style.display = 'none';

  var nextMode = isGameMenu
    ? { key: 'story', emoji: '📖', label: 'Stories & Rhymes', url: '/story/index.html' }
    : isStoryMenu
    ? { key: 'question', emoji: '💡', label: 'Wonders & Facts', url: '/question/index.html' }
    : { key: 'game', emoji: '🎮', label: 'Play & Learn', url: '/game/index.html' };

  var switcher = document.createElement('button');
  switcher.id = 'mode-switcher';
  switcher.type = 'button';
  switcher.setAttribute('aria-label', 'Switch to ' + nextMode.label);
  switcher.style.cssText = [
    'position: fixed',
    'right: 16px',
    'bottom: calc(16px + env(safe-area-inset-bottom))',
    'z-index: 9999',
    'display: flex',
    'align-items: center',
    'gap: 6px',
    'padding: 10px 16px',
    'border: none',
    'border-radius: 30px',
    'background: linear-gradient(135deg, #6a11cb, #2575fc)',
    'color: white',
    "font-family: 'Fredoka', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    'font-weight: bold',
    'font-size: 14px',
    'box-shadow: 0 4px 12px rgba(0,0,0,0.25)',
    'cursor: pointer',
    'transition: transform 0.15s ease'
  ].join(';');
  switcher.innerHTML = '<span style="font-size:18px;">' + nextMode.emoji + '</span><span>' + nextMode.label + '</span>';

  switcher.addEventListener('click', function () {
    switcher.style.transform = 'scale(0.95)';
    localStorage.setItem('kids_scroll_last_mode', nextMode.key);
    setTimeout(function() {
      window.location.href = nextMode.url;
    }, 120);
  });

  document.documentElement.appendChild(switcher);
})();
