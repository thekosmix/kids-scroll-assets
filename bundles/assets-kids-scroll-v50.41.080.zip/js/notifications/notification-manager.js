/**
 * Kids Scroll — Notification Management Engine
 * 
 * 100% Offline-first, privacy-respecting notification scheduler for bedtime routines,
 * daily wonder facts, and weekend skill games.
 * 
 * Target personas: Parents engaging with toddlers (1-3) & preschoolers (3-5).
 * Rotation:
 * - Alternate Evenings (7:30 PM): 4 nights Bedtime Stories, 3 nights Daily Wonders
 * - Weekend Mornings (10:00 AM): Skill-Building Games
 */

(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.KidsScrollNotifications = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // Storage keys
  const STORAGE_KEYS = {
    ENABLED: 'kids_scroll_notifications_enabled',
    AGE: 'kids_scroll_selected_age',
    SESSION_COUNT: 'kids_scroll_session_count',
    PROMPT_DISMISSED: 'kids_scroll_prompt_dismissed',
    PROMPT_SNOOZED_UNTIL: 'kids_scroll_prompt_snoozed_until',
    LAST_ACTIVE_TIME: 'kids_scroll_last_active_time',
    LAST_NOTIFIED_SLOT: 'kids_scroll_last_notified_slot'
  };

  // Fallback category banners (pre-cached SVG illustrations)
  const BANNERS = {
    story: '/assets/images/notifications/banner-story.svg',
    wonder: '/assets/images/notifications/banner-wonder.svg',
    game: '/assets/images/notifications/banner-game.svg',
    default: 'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/games/preview/kids-scroll.png'
  };

  const ICONS = {
    app: '/assets/icons/icon-192x192.png',
    badge: '/assets/icons/badge-silhouette.png'
  };

  // Curated Content Rotation Pools (Age-Categorized)
  const CONTENT_POOLS = {
    stories: {
      toddler: [
        {
          id: 'brush-teeth-toothpaste-train',
          title: 'The Toothpaste Train',
          emoji: '🚂',
          tagline: 'Chugga-chugga brush away the sugar bugs! Snuggle up with a 2-minute bedtime tale.',
          url: '/story/brush-teeth-toothpaste-train.html',
          image: BANNERS.story
        },
        {
          id: 'splish-splash-bubble-bath',
          title: 'Splish-Splash Bubble Bath',
          emoji: '🛁',
          tagline: 'Bath time fun with gentle soap bubbles and cozy towel cuddles before bed.',
          url: '/story/splish-splash-bubble-bath.html',
          image: BANNERS.story
        },
        {
          id: 'rabbit-story',
          title: 'The Sleepy Bunny',
          emoji: '🐰',
          tagline: 'Hop along with gentle bunny friends before resting your head for sweet dreams.',
          url: '/story/rabbit-story.html',
          image: BANNERS.story
        },
        {
          id: 'big-kid-bed-sleep-story',
          title: 'The Big Kid Bed',
          emoji: '⭐',
          tagline: 'A cozy starry night in your very own bed. Sleep tight, little dreamer!',
          url: '/story/big-kid-bed-sleep-story.html',
          image: BANNERS.story
        },
        {
          id: 'dog-story',
          title: 'The Faithful Puppy',
          emoji: '🐶',
          tagline: 'Joyful tail wags and cozy puppy paws curling up to sleep.',
          url: '/story/dog-story.html',
          image: BANNERS.story
        },
        {
          id: 'where-do-toys-sleep-cleanup',
          title: 'Where Do the Toys Sleep?',
          emoji: '🧸',
          tagline: 'Time to tuck the teddy bears and blocks into their bins for bedtime!',
          url: '/story/where-do-toys-sleep-cleanup.html',
          image: BANNERS.story
        },
        {
          id: 'listen-to-tummy-bell',
          title: 'Listen to the Tummy Bell',
          emoji: '🔔',
          tagline: 'A gentle bedtime pause when your body whispers it is time to rest.',
          url: '/story/listen-to-tummy-bell.html',
          image: BANNERS.story
        }
      ],
      preschool: [
        {
          id: 'magic-pocket-kiss-goodbye',
          title: 'The Magic Pocket Kiss',
          emoji: '💖',
          tagline: 'A cozy pocket hug that stays with you everywhere you go.',
          url: '/story/magic-pocket-kiss-goodbye.html',
          image: BANNERS.story
        },
        {
          id: 'dr-bear-stethoscope',
          title: "Dr. Bear's Stethoscope",
          emoji: '🩺',
          tagline: 'Listening to your strong, happy heartbeat with friendly Dr. Bear.',
          url: '/story/dr-bear-stethoscope.html',
          image: BANNERS.story
        },
        {
          id: 'elephant-story',
          title: 'The Gentle Elephant',
          emoji: '🐘',
          tagline: 'A kind giant who loves splashing water and helping forest friends.',
          url: '/story/elephant-story.html',
          image: BANNERS.story
        },
        {
          id: 'lion-story',
          title: 'The Brave Little Lion',
          emoji: '🦁',
          tagline: 'A warm cub learning that true courage is being gentle and patient.',
          url: '/story/lion-story.html',
          image: BANNERS.story
        },
        {
          id: 'circle-time-sunshine',
          title: 'Circle Time Sunshine',
          emoji: '☀️',
          tagline: 'Criss-cross applesauce and listening ears on with cheerful friends.',
          url: '/story/circle-time-sunshine.html',
          image: BANNERS.story
        },
        {
          id: 'the-sharing-timer',
          title: 'The Sharing Timer',
          emoji: '⏳',
          tagline: 'Taking turns with our favorite toys makes playtime twice as fun!',
          url: '/story/the-sharing-timer.html',
          image: BANNERS.story
        },
        {
          id: 'table-astronaut-manners',
          title: 'The Table Astronaut',
          emoji: '🚀',
          tagline: 'Fasten your napkin seatbelt for a delicious dinner adventure!',
          url: '/story/table-astronaut-manners.html',
          image: BANNERS.story
        }
      ]
    },
    wonders: {
      toddler: [
        {
          id: 'cat',
          topic: 'Cat',
          emoji: '🐱',
          tagline: 'Why do cats purr? Discover how our feline friends say hello and feel happy!',
          url: '/question/cat.html',
          image: BANNERS.wonder
        },
        {
          id: 'dog',
          topic: 'Dog',
          emoji: '🐶',
          tagline: 'Why do dogs wag their tails? Listen to fun puppy facts together tonight.',
          url: '/question/dog.html',
          image: BANNERS.wonder
        },
        {
          id: 'duck',
          topic: 'Duck',
          emoji: '🦆',
          tagline: 'Why do ducks love water? Discover how their waterproof feathers stay dry!',
          url: '/question/duck.html',
          image: BANNERS.wonder
        },
        {
          id: 'cow',
          topic: 'Cow',
          emoji: '🐮',
          tagline: 'Why do cows say Moo? Learn how happy cows munch sweet green grass.',
          url: '/question/cow.html',
          image: BANNERS.wonder
        },
        {
          id: 'bird',
          topic: 'Bird',
          emoji: '🐦',
          tagline: 'How do birds sing and build nests? Tap to explore gentle spoken wonders.',
          url: '/question/bird.html',
          image: BANNERS.wonder
        },
        {
          id: 'turtle',
          topic: 'Turtle',
          emoji: '🐢',
          tagline: 'Why do turtles carry their cozy shell home everywhere they go?',
          url: '/question/turtle.html',
          image: BANNERS.wonder
        }
      ],
      preschool: [
        {
          id: 'elephant',
          topic: 'Elephant',
          emoji: '🐘',
          tagline: 'How do elephants use their trunks like super straws and giant hands?',
          url: '/question/elephant.html',
          image: BANNERS.wonder
        },
        {
          id: 'lion',
          topic: 'Lion',
          emoji: '🦁',
          tagline: 'Why does a lion have a golden mane? Explore the kings of the savanna.',
          url: '/question/lion.html',
          image: BANNERS.wonder
        },
        {
          id: 'giraffe',
          topic: 'Giraffe',
          emoji: '🦒',
          tagline: 'Why do giraffes have super long necks? Nibbling tree tops together!',
          url: '/question/giraffe.html',
          image: BANNERS.wonder
        },
        {
          id: 'penguin',
          topic: 'Penguin',
          emoji: '🐧',
          tagline: 'How do penguins slide across icy snow on their tummies like sleds?',
          url: '/question/penguin.html',
          image: BANNERS.wonder
        },
        {
          id: 'bear',
          topic: 'Bear',
          emoji: '🐻',
          tagline: 'Why do bears take super-long winter naps? Explore cozy hibernation wonders.',
          url: '/question/bear.html',
          image: BANNERS.wonder
        },
        {
          id: 'kangaroo',
          topic: 'Kangaroo',
          emoji: '🦘',
          tagline: 'How do mama kangaroos carry their baby joeys in cozy pouches?',
          url: '/question/kangaroo.html',
          image: BANNERS.wonder
        }
      ]
    },
    games: {
      toddler: [
        {
          id: 'balloon-pop',
          name: 'Balloon Pop',
          emoji: '🎈',
          tagline: 'Pop colorful floating balloons to boost hand-eye reflexes and motor skills!',
          url: '/game/balloon-pop.html',
          image: BANNERS.game
        },
        {
          id: 'make-fruit-salad',
          name: 'Make Fruit Salad',
          emoji: '🍉',
          tagline: 'Slice juicy fruits and build fine motor coordination with cheerful sounds!',
          url: '/game/make-fruit-salad.html',
          image: BANNERS.game
        },
        {
          id: 'bubble-wrap-pop',
          name: 'Bubble Wrap Pop',
          emoji: '🫧',
          tagline: 'Calming sensory popping fun designed for tiny toddler fingers.',
          url: '/game/bubble-wrap-pop.html',
          image: BANNERS.game
        },
        {
          id: 'feed-animals',
          name: 'Feed the Animals',
          emoji: '🥕',
          tagline: 'Match yummy treats to hungry animal friends in a sweet sorting game!',
          url: '/game/feed-animals.html',
          image: BANNERS.game
        },
        {
          id: 'avatar-scroll',
          name: 'Avatar Scroll',
          emoji: '✨',
          tagline: 'Infinite magic scrolling with cheerful sounds and surprise stickers!',
          url: '/game/emoji-scroll.html',
          image: BANNERS.game
        }
      ],
      preschool: [
        {
          id: 'shape-sorter',
          name: 'Shape Sorter',
          emoji: '🔷',
          tagline: 'Fit geometric shapes into matching slots to build spatial logic and focus!',
          url: '/game/shape-sorter.html',
          image: BANNERS.game
        },
        {
          id: 'spot-the-pair',
          name: 'Spot the Pair',
          emoji: '🧩',
          tagline: 'Find matching emoji pairs to boost visual memory and attention span!',
          url: '/game/spot-the-pair.html',
          image: BANNERS.game
        },
        {
          id: 'learn-letters',
          name: 'Learn Letters',
          emoji: '🔤',
          tagline: 'Trace colorful alphabet letters and learn exciting new words together!',
          url: '/game/learn-letters.html',
          image: BANNERS.game
        },
        {
          id: 'pattern-maker',
          name: 'Pattern Maker',
          emoji: '🎯',
          tagline: 'Complete the colorful sequence and solve logical pattern puzzles!',
          url: '/game/pattern-maker.html',
          image: BANNERS.game
        },
        {
          id: 'shadow-match',
          name: 'Shadow Match',
          emoji: '👥',
          tagline: 'Match animals and objects to their mystery shadows in this logic game!',
          url: '/game/shadow-match.html',
          image: BANNERS.game
        }
      ]
    }
  };

  /**
   * Safe localStorage helper
   */
  const Storage = {
    get: function (key, fallback) {
      try {
        const val = localStorage.getItem(key);
        return val !== null ? val : fallback;
      } catch (e) {
        return fallback;
      }
    },
    set: function (key, value) {
      try {
        localStorage.setItem(key, value);
      } catch (e) {}
    }
  };

  /**
   * Core Notification Manager
   */
  class NotificationManager {
    constructor() {
      this.isInitialized = false;
      this.softPromptEl = null;
    }

    /**
     * Check if notifications are enabled by parent (default: true)
     */
    isEnabled() {
      return Storage.get(STORAGE_KEYS.ENABLED, 'true') !== 'false';
    }

    /**
     * Toggle or set notifications enabled state
     */
    setEnabled(enabled) {
      Storage.set(STORAGE_KEYS.ENABLED, enabled ? 'true' : 'false');
      if (enabled) {
        this.registerPeriodicSync();
      }
    }

    /**
     * Get parent's selected age group ('toddler', 'preschool', or 'all')
     */
    getSelectedAge() {
      const raw = Storage.get(STORAGE_KEYS.AGE, 'all');
      if (raw === 'toddler' || raw === 'preschool') return raw;
      return 'all';
    }

    /**
     * Get browser Notification permission state
     */
    getPermissionState() {
      if (typeof window === 'undefined' || !('Notification' in window)) {
        return 'unsupported';
      }
      return Notification.permission; // 'default', 'granted', 'denied'
    }

    /**
     * Mark current user activity (used for smart suppression)
     */
    markActive() {
      Storage.set(STORAGE_KEYS.LAST_ACTIVE_TIME, Date.now().toString());
    }

    /**
     * Check if smart suppression is active (active within last 4 hours)
     */
    isSuppressed() {
      const lastActive = parseInt(Storage.get(STORAGE_KEYS.LAST_ACTIVE_TIME, '0'), 10);
      if (!lastActive) return false;
      const fourHours = 4 * 60 * 60 * 1000;
      return (Date.now() - lastActive) < fourHours;
    }

    /**
     * Increment session count and evaluate soft prompt
     */
    trackSession() {
      const count = parseInt(Storage.get(STORAGE_KEYS.SESSION_COUNT, '0'), 10) + 1;
      Storage.set(STORAGE_KEYS.SESSION_COUNT, count.toString());
      this.markActive();

      // Show soft prompt on visit #2 onwards if not yet decided
      if (count >= 2) {
        this.checkAndShowSoftPrompt();
      }
    }

    /**
     * Evaluates whether the soft prompt banner should appear
     */
    shouldShowSoftPrompt() {
      if (typeof window === 'undefined' || !('Notification' in window)) return false;
      if (Notification.permission === 'granted' || Notification.permission === 'denied') return false;
      if (Storage.get(STORAGE_KEYS.PROMPT_DISMISSED, 'false') === 'true') return false;

      const snoozedUntil = parseInt(Storage.get(STORAGE_KEYS.PROMPT_SNOOZED_UNTIL, '0'), 10);
      if (snoozedUntil && Date.now() < snoozedUntil) return false;

      return true;
    }

    /**
     * Displays a friendly bottom sheet prompt to parents
     */
    checkAndShowSoftPrompt() {
      if (!this.shouldShowSoftPrompt()) return;
      if (document.getElementById('kids-scroll-notification-sheet')) return;

      // Inject soft prompt after slight delay so it does not interrupt immediate interaction
      setTimeout(() => {
        if (!this.shouldShowSoftPrompt()) return;
        this.renderSoftPrompt();
      }, 1500);
    }

    /**
     * Injects the modern, non-intrusive bottom sheet
     */
    renderSoftPrompt() {
      const existing = document.getElementById('kids-scroll-notification-sheet');
      if (existing) existing.remove();

      const container = document.createElement('div');
      container.id = 'kids-scroll-notification-sheet';
      container.setAttribute('role', 'dialog');
      container.setAttribute('aria-modal', 'true');
      container.setAttribute('aria-label', 'Bedtime & Routine Reminders');

      container.innerHTML = `
        <style>
          #kids-scroll-notification-sheet {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 99999;
            display: flex;
            justify-content: center;
            align-items: flex-end;
            padding: 12px;
            pointer-events: none;
            font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            animation: ksSheetSlideUp 0.35s cubic-bezier(0.16, 1, 0.3, 1) forwards;
          }
          @keyframes ksSheetSlideUp {
            from { transform: translateY(100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
          .ks-prompt-card {
            pointer-events: auto;
            background: linear-gradient(145deg, #201335 0%, #170d28 100%);
            border: 2px solid #5a32a3;
            border-radius: 24px;
            max-width: 440px;
            width: 100%;
            padding: 20px 22px;
            color: #ffffff;
            box-shadow: 0 12px 36px rgba(0, 0, 0, 0.45);
            box-sizing: border-box;
          }
          .ks-prompt-header {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 10px;
          }
          .ks-prompt-icon {
            font-size: 2.2rem;
            line-height: 1;
            filter: drop-shadow(0 4px 8px rgba(255, 215, 0, 0.3));
          }
          .ks-prompt-title {
            font-size: 1.18rem;
            font-weight: 800;
            margin: 0;
            color: #ffffff;
            letter-spacing: -0.2px;
          }
          .ks-prompt-desc {
            font-size: 0.94rem;
            line-height: 1.45;
            color: #d1c4e9;
            margin: 0 0 18px 0;
          }
          .ks-prompt-actions {
            display: flex;
            gap: 10px;
          }
          .ks-prompt-btn-primary {
            flex: 1.4;
            background: linear-gradient(135deg, #ffd700 0%, #ff9800 100%);
            color: #1a0f2e;
            border: none;
            border-radius: 16px;
            padding: 13px 16px;
            font-size: 0.98rem;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(255, 152, 0, 0.35);
            transition: transform 0.15s ease, filter 0.15s ease;
          }
          .ks-prompt-btn-primary:active {
            transform: scale(0.97);
          }
          .ks-prompt-btn-secondary {
            flex: 1;
            background: rgba(255, 255, 255, 0.1);
            color: #e2d9f3;
            border: 1px solid rgba(255, 255, 255, 0.18);
            border-radius: 16px;
            padding: 13px 14px;
            font-size: 0.92rem;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.15s ease;
          }
          .ks-prompt-btn-secondary:active {
            background: rgba(255, 255, 255, 0.18);
          }
        </style>
        <div class="ks-prompt-card">
          <div class="ks-prompt-header">
            <span class="ks-prompt-icon" aria-hidden="true">🌙</span>
            <div>
              <h3 class="ks-prompt-title">Cozy Bedtime Stories</h3>
            </div>
          </div>
          <p class="ks-prompt-desc">
            Would you like a gentle reminder at <strong>7:30 PM</strong> for cozy bedtime reading &amp; curious wonders with your little one?
          </p>
          <div class="ks-prompt-actions">
            <button type="button" class="ks-prompt-btn-primary" id="ks-btn-allow">
              Remind Me 🔔
            </button>
            <button type="button" class="ks-prompt-btn-secondary" id="ks-btn-snooze">
              Maybe Later
            </button>
          </div>
        </div>
      `;

      document.body.appendChild(container);

      const btnAllow = container.querySelector('#ks-btn-allow');
      const btnSnooze = container.querySelector('#ks-btn-snooze');

      btnAllow.addEventListener('click', async () => {
        try {
          const perm = await this.requestPermission();
          if (perm === 'granted') {
            this.setEnabled(true);
            this.showToast('Bedtime reminders set! Sweet dreams ahead 🌟');
          }
        } catch (e) {
          console.error('Permission error:', e);
        }
        this.dismissSoftPrompt();
      });

      btnSnooze.addEventListener('click', () => {
        // Snooze for 7 days
        const sevenDays = Date.now() + (7 * 24 * 60 * 60 * 1000);
        Storage.set(STORAGE_KEYS.PROMPT_SNOOZED_UNTIL, sevenDays.toString());
        this.dismissSoftPrompt();
      });
    }

    dismissSoftPrompt() {
      const el = document.getElementById('kids-scroll-notification-sheet');
      if (el) {
        el.style.transition = 'transform 0.25s ease, opacity 0.25s ease';
        el.style.transform = 'translateY(100%)';
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 260);
      }
    }

    showToast(message) {
      const toast = document.createElement('div');
      toast.style.cssText = `
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%);
        background: #2e7d32;
        color: white;
        padding: 12px 24px;
        border-radius: 30px;
        font-size: 0.95rem;
        font-weight: bold;
        box-shadow: 0 4px 16px rgba(0,0,0,0.3);
        z-index: 100000;
        font-family: system-ui, sans-serif;
        animation: ksFade 0.3s;
      `;
      toast.textContent = message;
      document.body.appendChild(toast);
      setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s';
        setTimeout(() => toast.remove(), 300);
      }, 3500);
    }

    /**
     * Request native browser notification permission
     */
    async requestPermission() {
      if (typeof window === 'undefined' || !('Notification' in window)) {
        return 'unsupported';
      }
      const perm = await Notification.requestPermission();
      if (perm === 'granted') {
        this.registerPeriodicSync();
      }
      return perm;
    }

    /**
     * Deterministic Content Resolver
     * Calculates the exact scheduled item for a given Date and slot
     */
    getScheduledItem(targetDate, slot) {
      const date = targetDate || new Date();
      const dayOfWeek = date.getDay(); // 0=Sun, 1=Mon, ..., 6=Sat
      const dayOfYear = Math.floor((date - new Date(date.getFullYear(), 0, 0)) / 1000 / 60 / 60 / 24);
      const selectedAge = this.getSelectedAge();

      // Determine category based on schedule:
      // Weekend Mornings (Sat/Sun, 10 AM) -> Games
      // Alternate Evenings (7:30 PM):
      // - Mon, Wed, Fri, Sun -> Stories (4 nights)
      // - Tue, Thu, Sat -> Wonders (3 nights)
      let category = 'story';
      if (slot === 'morning' || (dayOfWeek === 0 || dayOfWeek === 6) && date.getHours() < 14) {
        category = 'game';
      } else if (dayOfWeek === 2 || dayOfWeek === 4 || dayOfWeek === 6) {
        // Tue, Thu, Sat
        category = 'wonder';
      } else {
        // Mon, Wed, Fri, Sun
        category = 'story';
      }

      if (slot === 'game') category = 'game';
      if (slot === 'story') category = 'story';
      if (slot === 'wonder') category = 'wonder';

      // Pick pool by age
      let ageKey = selectedAge === 'all' ? (dayOfYear % 2 === 0 ? 'toddler' : 'preschool') : selectedAge;

      if (category === 'game') {
        const pool = CONTENT_POOLS.games[ageKey] || CONTENT_POOLS.games.toddler;
        const item = pool[dayOfYear % pool.length];
        const dayLabel = dayOfWeek === 6 ? 'Saturday' : 'Sunday';
        return {
          type: 'game',
          title: `🎮 ${dayLabel} Play: ${item.name}`,
          body: item.tagline,
          url: item.url,
          image: item.image || BANNERS.game,
          icon: ICONS.app,
          badge: ICONS.badge,
          tag: 'kids-scroll-weekend-game'
        };
      }

      if (category === 'wonder') {
        const pool = CONTENT_POOLS.wonders[ageKey] || CONTENT_POOLS.wonders.toddler;
        const item = pool[dayOfYear % pool.length];
        return {
          type: 'wonder',
          title: `💡 Bedtime Wonder: ${item.topic}`,
          body: item.tagline,
          url: item.url,
          image: item.image || BANNERS.wonder,
          icon: ICONS.app,
          badge: ICONS.badge,
          tag: 'kids-scroll-bedtime-wonder'
        };
      }

      // Default: Bedtime Story
      const pool = CONTENT_POOLS.stories[ageKey] || CONTENT_POOLS.stories.toddler;
      const item = pool[dayOfYear % pool.length];
      return {
        type: 'story',
        title: `🌙 Bedtime Story: ${item.title}`,
        body: item.tagline,
        url: item.url,
        image: item.image || BANNERS.story,
        icon: ICONS.app,
        badge: ICONS.badge,
        tag: 'kids-scroll-bedtime-story'
      };
    }

    /**
     * Dispatch notification through Service Worker or native Web Notification
     */
    async dispatchNotification(payload) {
      if (!this.isEnabled()) return false;
      if (this.getPermissionState() !== 'granted') return false;

      const toAbs = (u) => {
        if (!u) return u;
        try {
          return new URL(u, (typeof window !== 'undefined' ? window.location.origin : 'https://www.offlinekidsgames.com')).href;
        } catch (e) {
          return u;
        }
      };

      const title = payload.title;
      // Note: `icon` is intentionally omitted so Android does NOT render a redundant square
      // avatar on the right side; the Kids Scroll emblem is already displayed on the left side header.
      const options = {
        body: payload.body,
        badge: toAbs(payload.badge || ICONS.badge),
        image: toAbs(payload.image || BANNERS.default),
        data: {
          url: payload.url,
          type: payload.type,
          timestamp: Date.now()
        },
        vibrate: [100, 50, 100],
        tag: payload.tag || 'kids-scroll-notification',
        renotify: true
      };

      // 1. Prefer Service Worker registration (native TWA delegation and background sync support)
      if ('serviceWorker' in navigator) {
        try {
          const reg = await navigator.serviceWorker.ready;
          if (reg && reg.showNotification) {
            await reg.showNotification(title, options);
            return true;
          }
        } catch (e) {
          console.warn('Service Worker showNotification failed, trying fallback:', e);
        }
      }

      // 2. Direct Web Notification fallback
      if ('Notification' in window) {
        try {
          const n = new Notification(title, options);
          n.onclick = function (e) {
            e.preventDefault();
            window.focus();
            if (payload.url) {
              window.location.href = payload.url;
            }
          };
          return true;
        } catch (e) {
          console.error('Notification constructor error:', e);
        }
      }

      return false;
    }

    /**
     * Instant local test trigger for developers and parents
     * @param {'story' | 'wonder' | 'game' | 'next'} slot
     */
    async test(slot) {
      const type = slot || 'story';
      const item = this.getScheduledItem(new Date(), type);
      
      // If permission is not yet granted, request it first
      if (this.getPermissionState() !== 'granted') {
        const perm = await this.requestPermission();
        if (perm !== 'granted') {
          alert('Notification permission was not granted. Please enable notifications in your browser settings to test.');
          return false;
        }
      }

      return await this.dispatchNotification(item);
    }

    /**
     * Registers Periodic Background Sync where available (Chromium/Android)
     */
    async registerPeriodicSync() {
      if ('serviceWorker' in navigator) {
        try {
          const reg = await navigator.serviceWorker.ready;
          if ('periodicSync' in reg) {
            const status = await navigator.permissions.query({ name: 'periodic-background-sync' }).catch(() => null);
            if (!status || status.state === 'granted') {
              await reg.periodicSync.register('kids-scroll-routine-check', {
                minInterval: 12 * 60 * 60 * 1000 // twice daily check
              });
            }
          }
        } catch (e) {
          // PeriodicSync unsupported or not permitted; silent fallback to session checks
        }
      }
    }

    /**
     * Initialize notification hooks on page load
     */
    init() {
      if (this.isInitialized) return;
      this.isInitialized = true;

      // Track session and activity
      this.trackSession();

      // Register periodic sync if already enabled
      if (this.isEnabled() && this.getPermissionState() === 'granted') {
        this.registerPeriodicSync();
      }
    }
  }

  const instance = new NotificationManager();

  // Auto-initialize when loaded in window context
  if (typeof window !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => instance.init());
    } else {
      instance.init();
    }
  }

  return instance;
});
