/**
 * Junior Genius Club: Parent Companion
 * Progressive Web Application Logic & 20-Week Developmental Curriculum
 */

// ==========================================
// 1. 20-WEEK CURRICULUM DATASET
// ==========================================
const CURRICULUM = [
  {
    week: 1,
    quotient: 'IQ',
    title: 'Photo-Memory & Visual Recall',
    skill: 'Pattern Recognition & Object Memory',
    whyItMatters: 'Young brains build mental filing cabinets through visual memory. Recognizing pairs and recalling hidden items builds the foundation for reading and spatial problem-solving.',
    articleUrl: 'https://www.juniorgenius.club/bridge-the-kids-photo-memory-gap.html',
    kidsScrollGame: {
      id: 'spot-the-pair',
      name: 'Spot the Pair',
      url: 'https://www.offlinekidsgames.com/game/spot-the-pair.html',
      icon: '🧩',
      metricTracked: 'Avg Time per Pair'
    },
    toddlerActivities: [
      { id: 'w1_t1', title: 'Where Did Teddy Go?', desc: 'Hide a favorite toy under one of two small cloths in plain view. Encourage your toddler to lift the right cloth.' },
      { id: 'w1_t2', title: 'Two-Plate Fruit Match', desc: 'Place a banana slice on one plate and an apple slice on another. Give them matching slices to pair up.' },
      { id: 'w1_t3', title: 'Peek-a-Boo Surprise', desc: 'Cover your face with hands or a cloth, wait 3 seconds, and reveal with a joyful smile to practice object permanence.' }
    ],
    preschoolerActivities: [
      { id: 'w1_p1', title: 'Tray Memory Game', desc: 'Place 4 familiar items on a tray (spoon, key, crayon, ball). Let them look for 15s, cover the tray, and remove one. Ask: "What disappeared?"' },
      { id: 'w1_p2', title: 'Sock Sorting Match', desc: 'Mix 4 pairs of colorful socks in a laundry basket and challenge them to find and roll matching pairs.' },
      { id: 'w1_p3', title: 'Living Room Scavenger Hunt', desc: 'Show them a blue block for 5 seconds, then ask them to find something blue in the room from memory.' }
    ],
    observationChecklist: [
      'Does your child hesitate or immediately scan for matching items?',
      'Can they recall an object after it is briefly covered?',
      'Do they smile or express excitement when making a correct match?'
    ],
    sundayQuestions: [
      {
        text: 'How quickly does your child recall hidden or paired objects when asked?',
        options: [
          { text: 'Needs multiple hints or guidance', points: 15 },
          { text: 'Finds it after a brief moment of thinking', points: 30 },
          { text: 'Instant recognition with zero hesitation!', points: 50 }
        ]
      },
      {
        text: 'During visual games (like Spot the Pair), what was their engagement level?',
        options: [
          { text: 'Played for 1-2 minutes with wandering attention', points: 15 },
          { text: 'Completed a full round with steady focus', points: 35 },
          { text: 'Enthusiastic and wanted to replay multiple times', points: 50 }
        ]
      },
      {
        text: 'How did they react when they encountered an incorrect match?',
        options: [
          { text: 'Frustrated or walked away', points: 10 },
          { text: 'Tried again with gentle parental encouragement', points: 30 },
          { text: 'Kept trying cheerfully on their own', points: 50 }
        ]
      }
    ],
    badge: { name: 'Visual Detective 🔍', shortName: 'Detective', icon: '🔍', desc: 'Mastered initial photo-memory and paired recognition.' }
  },
  {
    week: 2,
    quotient: 'PQ',
    title: 'Pincer Grip & Finger Strength',
    skill: 'Fine Motor Control & Pre-Writing',
    whyItMatters: 'Finger strength and the three-finger pincer grasp are prerequisites for pencil grip and handwriting. Strengthening hand intrinsic muscles prevents early writing fatigue.',
    articleUrl: 'https://www.juniorgenius.club/precision-play-pincer-grip.html',
    kidsScrollGame: {
      id: 'drawing-canvas',
      name: 'Drawing Canvas',
      url: 'https://www.offlinekidsgames.com/game/drawing-canvas.html',
      icon: '🎨',
      metricTracked: 'Time Spent & Drawing Saves'
    },
    toddlerActivities: [
      { id: 'w2_t1', title: 'Peeling Stickers', desc: 'Place colorful dots or stickers on the edge of a table or paper plate and let them peel each one using index and thumb.' },
      { id: 'w2_t2', title: 'Cheerio / Snack Pinch', desc: 'Scatter small round cereal puffs on a high-chair tray. Encourage single-finger pinching instead of a whole-fist scoop.' },
      { id: 'w2_t3', title: 'Playdough Squish & Poke', desc: 'Roll a ball of soft dough and encourage toddler to poke deep holes using their index finger.' }
    ],
    preschoolerActivities: [
      { id: 'w2_p1', title: 'Clothes-peg Clipping', desc: 'Give them wooden or plastic clothespins to pinch open and clip onto the rim of a cardboard box.' },
      { id: 'w2_p2', title: 'Playdough Snake Slicing', desc: 'Roll long playdough snakes and let them snip pieces with plastic toddler scissors or popsicle sticks.' },
      { id: 'w2_p3', title: 'Tear & Paste Collage', desc: 'Have them tear strips of colorful scrap paper into tiny confetti pieces and glue them inside an animal outline.' }
    ],
    observationChecklist: [
      'Notice their grip: Full fist (palmar), 4 fingers (digital), or thumb + index (pincer)?',
      'Can they isolate their index finger when pointing or drawing on canvas?',
      'Do both hands work together (one holding paper, one pinching)?'
    ],
    sundayQuestions: [
      {
        text: 'How does your child hold crayons or stylus on the drawing canvas?',
        options: [
          { text: 'Full fist grasp (palmar grasp)', points: 15 },
          { text: 'Four fingers angled downward (digital grasp)', points: 30 },
          { text: 'Tripod grip (thumb and first two fingers)', points: 50 }
        ]
      },
      {
        text: 'How was their finger stamina during pinch and peel activities?',
        options: [
          { text: 'Tired out quickly after 1-2 minutes', points: 15 },
          { text: 'Sustained pinching for 4-5 minutes comfortably', points: 35 },
          { text: 'Showed high dexterity and enjoyed detailed manipulation', points: 50 }
        ]
      },
      {
        text: 'What kind of strokes do they make on the Drawing Canvas?',
        options: [
          { text: 'Random wild scribbles or dot tapping', points: 20 },
          { text: 'Controlled lines, loops, or circular curves', points: 35 },
          { text: 'Intentional shapes or representational figures', points: 50 }
        ]
      }
    ],
    badge: { name: 'Pincer Prodigy 🤏', shortName: 'Pincer', icon: '🤏', desc: 'Strengthened finger intrinsic muscles and pre-writing grip.' }
  },
  {
    week: 3,
    quotient: 'EQ',
    title: 'Emotion Decoding & Big Feelings',
    skill: 'Emotional Identification & Calming',
    whyItMatters: 'Toddlers experience huge emotions before they have the vocabulary to express them. Naming feelings reduces tantrums and fosters lifelong self-regulation.',
    articleUrl: 'https://www.juniorgenius.club/decode-kids-emotional-cues.html',
    kidsScrollGame: {
      id: 'emotion-explorer',
      name: 'Emotion Explorer / Build a Face',
      url: 'https://www.offlinekidsgames.com/game/emotion-explorer.html',
      icon: '😊',
      metricTracked: 'Emotions Explored'
    },
    toddlerActivities: [
      { id: 'w3_t1', title: 'Mirror Face Mimicry', desc: 'Look in a mirror together. Make a huge happy smile, a surprise "O", and a pretend pout. Laugh together as they imitate.' },
      { id: 'w3_t2', title: 'Stuffed Animal Hugs', desc: 'When teddy "falls down", model empathy: "Oh, Teddy feels sad! Let’s give Teddy a gentle hug and kiss."' },
      { id: 'w3_t3', title: 'Calm Down Music Sway', desc: 'Put on soft instrumental music during fussy moments and sway together slowly to soothe the nervous system.' }
    ],
    preschoolerActivities: [
      { id: 'w3_p1', title: 'Emotion Paper Plate Masks', desc: 'Draw Happy, Sad, and Mad faces on 3 paper plates. Hold them up and ask: "Which face fits right now?"' },
      { id: 'w3_p2', title: 'Bear Belly Breathing', desc: 'Lie on backs with a small teddy bear on their belly. Breathe in deeply to watch teddy rise, out to watch teddy fall.' },
      { id: 'w3_p3', title: 'Name It to Tame It', desc: 'When frustration strikes, validate verbally: "I see you are feeling frustrated because the blocks fell. Let’s take 3 deep breaths."' }
    ],
    observationChecklist: [
      'Can your child tell when someone is happy versus upset?',
      'Do they look to you for reassurance when startled?',
      'Are they beginning to use words or gestures instead of tantrums?'
    ],
    sundayQuestions: [
      {
        text: 'Can your child identify basic emotions (happy, sad, angry) in pictures or faces?',
        options: [
          { text: 'Not yet, still learning face cues', points: 15 },
          { text: 'Recognizes happy vs sad accurately', points: 35 },
          { text: 'Names 3 or more feelings accurately and points them out', points: 50 }
        ]
      },
      {
        text: 'When experiencing a big feeling, how quickly do they recover with your support?',
        options: [
          { text: 'Takes a prolonged meltdown to settle down', points: 15 },
          { text: 'Settles within 5-10 minutes with soothing hugs', points: 35 },
          { text: 'Breathes or uses words to calm down quickly', points: 50 }
        ]
      },
      {
        text: 'Did they show care or empathy toward a toy, pet, or family member this week?',
        options: [
          { text: 'Mainly focused on their own needs', points: 20 },
          { text: 'Offered a hug, pat, or toy when someone was sad', points: 50 }
        ]
      }
    ],
    badge: { name: 'Heart & Empathy Star ❤️', shortName: 'Empathy', icon: '❤️', desc: 'Recognized emotional expressions and practiced calming breaths.' }
  },
  {
    week: 4,
    quotient: 'AQ',
    title: 'Resilience & Adversity Quotient',
    skill: 'Frustration Tolerance & Persistence',
    whyItMatters: 'Adversity Quotient (AQ) teaches kids that mistakes are not failures, but learning steps. Building puzzle resilience prevents giving up when tasks get tough.',
    articleUrl: 'https://www.juniorgenius.club/build-kids-adversity-quotient-resilience.html',
    kidsScrollGame: {
      id: 'emoji-jigsaw',
      name: 'Emoji Jigsaw',
      url: 'https://www.offlinekidsgames.com/game/emoji-jigsaw.html',
      icon: '🧩',
      metricTracked: 'Avg Time per Piece'
    },
    toddlerActivities: [
      { id: 'w4_t1', title: 'Tower Knockdown & Rebuild', desc: 'Stack 3 plastic cups. When it tumbles, say cheerfully "Uh-oh! Boom! Let’s build it again!" to normalize toppling.' },
      { id: 'w4_t2', title: 'Shape Container Push', desc: 'Cut a slit in a cardboard shoebox lid. Encourage pushing cards through the slit even if it takes multiple angles.' },
      { id: 'w4_t3', title: 'Sticky Tape Rescue', desc: 'Tape a toy lightly to the tray with painter tape. Let them work to peel and free their toy.' }
    ],
    preschoolerActivities: [
      { id: 'w4_p1', title: 'The "Yet" Mantra Challenge', desc: 'When they say "I can’t do this puzzle!", teach them to add: "I can’t do it YET!" and try one piece together.' },
      { id: 'w4_p2', title: 'Cardboard Box Obstacle', desc: 'Set up couch cushions and box tunnels. If they slip, celebrate the effort: "Great try! Climb back up!"' },
      { id: 'w4_p3', title: 'Unbreakable Balloon Tap', desc: 'Keep a balloon in the air. If it touches the floor, no worries—count how many taps before it landed and beat it.' }
    ],
    observationChecklist: [
      'What happens when a puzzle piece doesn’t fit immediately?',
      'Do they accept gentle guidance without crying?',
      'Do they celebrate when they finally conquer a tricky challenge?'
    ],
    sundayQuestions: [
      {
        text: 'When a toy or puzzle piece doesn’t fit on the first try, what is their reaction?',
        options: [
          { text: 'Drops it or gets upset right away', points: 15 },
          { text: 'Tries 1-2 more times before asking for help', points: 35 },
          { text: 'Persists calmly, rotates the piece, and solves it!', points: 50 }
        ]
      },
      {
        text: 'How did they handle minor accidents or mistakes this week?',
        options: [
          { text: 'Big tears for small slips', points: 15 },
          { text: 'Looked startled, then recovered with a smile', points: 35 },
          { text: 'Laughed it off and shouted "Let’s try again!"', points: 50 }
        ]
      },
      {
        text: 'Did they show pride after solving something that was initially difficult?',
        options: [
          { text: 'Moved on without noticing', points: 20 },
          { text: 'Clapped, smiled, or called you to look!', points: 50 }
        ]
      }
    ],
    badge: { name: 'Bounce-Back Champ 🛡️', shortName: 'Grit', icon: '🛡️', desc: 'Turned frustration into grit and celebrated problem-solving effort.' }
  },
  {
    week: 5,
    quotient: 'SQ',
    title: 'Social Rules & Turn-Taking',
    skill: 'Shared Play, Patience & Red-Green Light Logic',
    whyItMatters: 'Social Quotient (SQ) begins with understanding boundaries, impulse control, and the concept of "my turn, your turn". It is the bedrock of kindergarten social readiness.',
    articleUrl: 'https://www.juniorgenius.club/understand-kids-social-boundaries.html',
    kidsScrollGame: {
      id: 'traffic-light',
      name: 'Traffic Light',
      url: 'https://www.offlinekidsgames.com/game/traffic-light.html',
      icon: '🚦',
      metricTracked: 'Timing & Response'
    },
    toddlerActivities: [
      { id: 'w5_t1', title: 'Roll-the-Ball Turn Taking', desc: 'Sit 3 feet apart. Roll a soft ball to them saying "Mama’s turn... now [Name]’s turn!" and wait patiently for them to push it back.' },
      { id: 'w5_t2', title: 'Stop & Go Walking', desc: 'Hold hands and walk forward saying "Walk walk walk..." then whisper "STOP!" and freeze like statues.' },
      { id: 'w5_t3', title: 'High-Five Clap Routine', desc: 'Teach a 2-step social greeting: Open hand high-five, followed by a gentle fist-bump.' }
    ],
    preschoolerActivities: [
      { id: 'w5_p1', title: 'Red Light, Green Light Freeze Dance', desc: 'Play upbeat music (Green light: dance crazy!). Pause music abruptly (Red light: freeze!). Builds instant impulse inhibition.' },
      { id: 'w5_p2', title: 'Pretend Tea Party / Snack Share', desc: 'Give them 4 crackers. Prompt them to serve you one cracker first before eating their own.' },
      { id: 'w5_p3', title: 'Timer Turn Swap', desc: 'Use a 1-minute visual hourglass sand timer to trade favorite toys smoothly back and forth.' }
    ],
    observationChecklist: [
      'Can your child wait 10 seconds for their turn without grabbing?',
      'Do they freeze when you say "Stop" during playful games?',
      'Do they make warm eye contact when sharing a toy or greeting?'
    ],
    sundayQuestions: [
      {
        text: 'How well did your child handle turn-taking or waiting a few moments this week?',
        options: [
          { text: 'Found waiting very hard, wanted instant turn', points: 15 },
          { text: 'Waited with a short reminder or timer', points: 35 },
          { text: 'Happily took turns and said "Your turn now!"', points: 50 }
        ]
      },
      {
        text: 'During freeze/stop games (like Traffic Light), how was their impulse control?',
        options: [
          { text: 'Kept moving right through the stop signal', points: 15 },
          { text: 'Stopped after a brief delay', points: 35 },
          { text: 'Froze instantly with great body awareness', points: 50 }
        ]
      },
      {
        text: 'Did they show willingness to share snacks or toys with others?',
        options: [
          { text: 'Clung tightly to their things (normal toddler behavior)', points: 20 },
          { text: 'Shared with gentle encouragement or praise', points: 50 }
        ]
      }
    ],
    badge: { name: 'Social Star & Friend 🤝', shortName: 'Friend', icon: '🤝', desc: 'Learned turn-taking rhythms and stop-and-go self control.' }
  },
  {
    week: 6,
    quotient: 'CQ',
    title: 'Creative Articulation & Color Mixing',
    skill: 'Abstract Expression & Color Science',
    whyItMatters: 'Creativity is not just art; it is how the human brain invents novel solutions. Mixing colors and unstructured drawing builds cognitive flexibility and self-confidence.',
    articleUrl: 'https://www.juniorgenius.club/digital-easel-creative-expression.html',
    kidsScrollGame: {
      id: 'color-mixture',
      name: 'Color Mixture / Finger Painting',
      url: 'https://www.offlinekidsgames.com/game/color-mixture.html',
      icon: '🎨',
      metricTracked: 'Color Experiments'
    },
    toddlerActivities: [
      { id: 'w6_t1', title: 'Ziploc Mess-Free Color Bag', desc: 'Squirt a dollop of yellow and blue paint inside a clear sealed Ziploc bag. Tape to the window and let toddler squish them into green!' },
      { id: 'w6_t2', title: 'Water Painting on Concrete', desc: 'Give them a paintbrush and a cup of plain water outside to paint dark water trails on sunny pavement.' },
      { id: 'w6_t3', title: 'Color Toy Scavenger Basket', desc: 'Give them a red bowl and ask them to collect 3 red toys from around the house.' }
    ],
    preschoolerActivities: [
      { id: 'w6_p1', title: 'Primary Color Mixing Cups', desc: 'Use 3 cups of water with blue, red, and yellow food coloring. Use droppers to create purple, green, and orange.' },
      { id: 'w6_p2', title: 'Tell-a-Story Scribble', desc: 'After they finish a drawing, ask open-ended questions: "Tell me about this purple swirl! Who lives here?"' },
      { id: 'w6_p3', title: 'Cardboard Box Spaceship', desc: 'Transform an empty shipping box with crayons and stickers into a car, boat, or castle.' }
    ],
    observationChecklist: [
      'Do they enjoy the process of creating rather than needing a perfect product?',
      'Are they curious about what happens when two colors blend?',
      'Can they invent an imaginative story about what they made?'
    ],
    sundayQuestions: [
      {
        text: 'How engaged was your child in unstructured art or imaginative pretend play?',
        options: [
          { text: 'Short interest under 2 minutes', points: 15 },
          { text: 'Experimented happily for 5-10 minutes', points: 35 },
          { text: 'Deeply absorbed in creative imagination and storytelling', points: 50 }
        ]
      },
      {
        text: 'Do they understand that primary colors mix to create new colors?',
        options: [
          { text: 'Still just enjoying bright colors without noticing blends', points: 20 },
          { text: 'Excitedly noticed new colors appearing (e.g. "Look, green!")', points: 50 }
        ]
      },
      {
        text: 'Did they invent a pretend scenario (pretend cooking, superhero, animal voice)?',
        options: [
          { text: 'Mainly realistic play with toy functions', points: 20 },
          { text: 'Rich pretend play with vivid imagination', points: 50 }
        ]
      }
    ],
    badge: { name: 'Tiny Picasso 🎨', shortName: 'Picasso', icon: '🎨', desc: 'Explored vibrant color relationships and imaginative storytelling.' }
  },
  {
    week: 7,
    quotient: 'DQ',
    title: 'Digital Health & Screen Transitions',
    skill: 'Intentional Play & Smooth Transitions',
    whyItMatters: 'Digital Quotient (DQ) is about healthy habits, intentional ad-free interaction, and mastering screen transitions without tantrums.',
    articleUrl: 'https://www.juniorgenius.club/promote-healthy-kids-digital-habits.html',
    kidsScrollGame: {
      id: 'avatar-scroll',
      name: 'Avatar Scroll',
      url: 'https://www.offlinekidsgames.com/game/emoji-scroll.html',
      icon: '📱',
      metricTracked: 'Controlled Scrolling & Interaction'
    },
    toddlerActivities: [
      { id: 'w7_t1', title: 'The 2-Minute Bell Transition', desc: 'Ring a gentle musical bell 2 minutes before digital time ends: "When the bell rings next, it’s block time!"' },
      { id: 'w7_t2', title: 'Bye-Bye Phone Wave', desc: 'When closing Kids Scroll, prompt toddler to wave and say "Bye bye game! See you next time!" to give psychological closure.' },
      { id: 'w7_t3', title: 'Tactile Sensory Swap', desc: 'Immediately transition from screen to a rich tactile activity (warm water play, kinetic sand, or a big cuddle).' }
    ],
    preschoolerActivities: [
      { id: 'w7_p1', title: 'The Visual Screen Timer', desc: 'Let them press start on a friendly visual phone timer so they feel in control of the boundary.' },
      { id: 'w7_p2', title: 'Active Dance Off Transition', desc: 'When game time finishes, put on a 1-minute dance song to release physical energy before sitting for a meal.' },
      { id: 'w7_p3', title: 'Active Creator vs Passive Consumer', desc: 'Discuss games: "We use games to learn and solve puzzles, not just stare!" Celebrate game completion.' }
    ],
    observationChecklist: [
      'Does your child transition away from the screen peacefully?',
      'Are they engaging with interactive, thinking games rather than zombie video streams?',
      'Do they recognize when screen time is over?'
    ],
    sundayQuestions: [
      {
        text: 'How smooth were screen transitions this week when device time was over?',
        options: [
          { text: 'Protested with crying or grabbed for device', points: 15 },
          { text: 'Slight whine, but transitioned with gentle redirect', points: 35 },
          { text: 'Handed device back smoothly and said goodbye!', points: 50 }
        ]
      },
      {
        text: 'How intentional was their screen play (problem-solving vs passive scrolling)?',
        options: [
          { text: 'Randomly tapping all over the screen', points: 20 },
          { text: 'Focused intentionally on game objectives and goals', points: 50 }
        ]
      },
      {
        text: 'Did your family maintain screen-free meals and sleep routines this week?',
        options: [
          { text: 'Screens slipped into meals once or twice', points: 20 },
          { text: '100% screen-free meals and bedtime!', points: 50 }
        ]
      }
    ],
    badge: { name: 'Mindful Digital Explorer 🧘', shortName: 'Mindful', icon: '🧘', desc: 'Mastered calm screen transitions and healthy digital habits.' }
  },
  {
    week: 8,
    quotient: 'PQ',
    title: 'Reflexes & Rapid Hand-Eye Precision',
    skill: 'Reaction Time & Accurate Tapping',
    whyItMatters: 'Reaction speed and hand-eye accuracy train neural pathways between visual scanning and motor action, boosting sports readiness and spatial reflexes.',
    articleUrl: 'https://www.juniorgenius.club/boost-kids-reflex-development.html',
    kidsScrollGame: {
      id: 'make_fruit_salad',
      name: 'Make Fruit Salad',
      url: 'https://www.offlinekidsgames.com/game/make-fruit-salad.html',
      icon: '🍉',
      metricTracked: 'Avg Time per Slice'
    },
    toddlerActivities: [
      { id: 'w8_t1', title: 'Slow Balloon Batting', desc: 'Gently float a balloon down. Encourage toddler to tap it before it lands on the rug.' },
      { id: 'w8_t2', title: 'Catch the Silk Scarf', desc: 'Drop a light silk scarf from above eye level. Let them grab it as it slowly drifts down.' },
      { id: 'w8_t3', title: 'Pop the Bubble Float', desc: 'Blow 3 soap bubbles and challenge them to pop each with one extended pointer finger.' }
    ],
    preschoolerActivities: [
      { id: 'w8_p1', title: 'Rolled Sock Catch', desc: 'Toss a soft pair of rolled socks underhand from 3 feet away. Count how many they can catch with both hands.' },
      { id: 'w8_p2', title: 'Flash Light Tag on Wall', desc: 'Shine a flashlight dot on the wall. Move it smoothly and have them "slap" the light dot with their palm.' },
      { id: 'w8_p3', title: 'Rhythm Clapping Echo', desc: 'Clap a 3-beat rhythm (Clap-Clap... Clap!). Have them immediately repeat it back with fast reflexes.' }
    ],
    observationChecklist: [
      'Do they anticipate where moving objects will go, or react after it falls?',
      'Can their hands coordinate swiftly to touch moving targets?',
      'Do they maintain focus during fast-paced play?'
    ],
    sundayQuestions: [
      {
        text: 'How was their hand-eye accuracy when slicing fruits in Make Fruit Salad or catching balloons?',
        options: [
          { text: 'Missed frequently or swiped after the object passed', points: 15 },
          { text: 'Accurate hit rate with steady coordination', points: 35 },
          { text: 'Lightning fast reflexes with high accuracy!', points: 50 }
        ]
      },
      {
        text: 'Can they catch a soft ball or rolled socks from 2-3 feet away?',
        options: [
          { text: 'Hits body before hands react', points: 20 },
          { text: 'Catches with chest hug or hands successfully', points: 50 }
        ]
      },
      {
        text: 'Did their reaction time improve noticeably over the week?',
        options: [
          { text: 'Stayed about the same', points: 25 },
          { text: 'Noticeably quicker and more confident!', points: 50 }
        ]
      }
    ],
    badge: { name: 'Ninja Reflexes ⚡', shortName: 'Ninja', icon: '⚡', desc: 'Sharp hand-eye tracking and swift reaction speed.' }
  }
];

// Dynamic weeks 9-30 generator to populate full 30-week holistic roadmap
(function fillFullCurriculum() {
  const items9to30 = [
    // Week 9
    {
      quotient: 'IQ',
      title: 'Sorting & Taxonomic Categorization',
      skill: 'Classification & Utility',
      game: 'Sort the Groceries',
      id: 'sort-the-groceries',
      articleSlug: 'solve-the-kids-sorting-struggle',
      badge: { name: 'Master Sorter 🧺', shortName: 'Sorter 🧺', icon: '🧺', desc: 'Categorized groceries and everyday objects by functional utility.' }
    },
    // Week 10
    {
      quotient: 'EQ',
      title: 'Nurturing & Empathy in Action',
      skill: 'Caretaking & Needs',
      game: 'Feed the Animals',
      id: 'feed-animals',
      articleSlug: 'encourage-kids-empathy-and-caretaking',
      badge: { name: 'Gentle Caregiver 🐾', shortName: 'Carer 🐾', icon: '🐾', desc: 'Understood nutrition and empathetic care for diverse animal friends.' }
    },
    // Week 11
    {
      quotient: 'IQ',
      title: 'Spatial Quarters & Geometry',
      skill: 'Shape Fitting & Rotation',
      game: 'Shape Sorter',
      id: 'shape-sorter',
      articleSlug: 'part-to-whole-geometry-logic',
      badge: { name: 'Geometry Genius 🔷', shortName: 'Shapes 🔷', icon: '🔷', desc: 'Aligned 2D/3D shapes through mental rotation and part-to-whole logic.' }
    },
    // Week 12
    {
      quotient: 'PQ',
      title: 'Pre-Writing & Letter Tracing',
      skill: 'Letter Forms & Phonemic Cues',
      game: 'Learn Letters',
      id: 'alphabet-trace',
      articleSlug: 'overcome-the-kids-handwriting-hurdle',
      badge: { name: 'Letter Scout 🔤', shortName: 'Letters 🔤', icon: '🔤', desc: 'Traced fundamental letter strokes with proper directionality and motor control.' }
    },
    // Week 13
    {
      quotient: 'AQ',
      title: 'Persistence in Abstract Challenges',
      skill: 'Silhouette Recognition',
      game: 'Shadow Match',
      id: 'shadow-match',
      articleSlug: 'master-the-silhouette-secret',
      badge: { name: 'Shadow Tracker 👤', shortName: 'Shadows 👤', icon: '👤', desc: 'Decoded object boundaries and abstract silhouettes without surface color cues.' }
    },
    // Week 14
    {
      quotient: 'EQ',
      title: 'Belly Breathing & Self-Regulation',
      skill: 'Breath Cadence & Calming',
      game: 'Breathing Bubble',
      id: 'breathing-bubble',
      articleSlug: 'mindful-breathing-self-regulation',
      badge: { name: 'Calm Breathing Zen 🫧', shortName: 'Breathe 🫧', icon: '🫧', desc: 'Regulated autonomic nervous system through slow, deliberate bubble breathing.' }
    },
    // Week 15
    {
      quotient: 'CQ',
      title: 'Auditory Intelligence & Scales',
      skill: 'Sound Discrimination & Rhythm',
      game: 'Musical Instruments',
      id: 'musical-instrument',
      articleSlug: 'boost-kids-auditory-intelligence',
      badge: { name: 'Little Maestro 🎵', shortName: 'Maestro 🎵', icon: '🎵', desc: 'Distinguished acoustic timbres and pitch intervals across instruments.' }
    },
    // Week 16
    {
      quotient: 'IQ',
      title: 'Early Numeracy & 1-to-1 Counting',
      skill: 'Visual Counting & Quantities',
      game: 'Learn Numbers',
      id: 'learn_numbers',
      articleSlug: 'build-kids-numerical-foundations',
      badge: { name: 'Number Wizard 🔢', shortName: 'Numbers 🔢', icon: '🔢', desc: 'Connected numerals to real quantities using one-to-one counting precision.' }
    },
    // Week 17
    {
      quotient: 'PQ',
      title: 'Eye Tracking & Tapping Timing',
      skill: 'Visual Scanning & Timing',
      game: 'Balloon Pop',
      id: 'balloon-pop',
      articleSlug: 'improve-kids-tapping-timing-skills',
      badge: { name: 'Sky Popper 🎈', shortName: 'Popper 🎈', icon: '🎈', desc: 'Tracked unpredictable trajectories and timed taps for floating balloons.' }
    },
    // Week 18
    {
      quotient: 'SQ',
      title: 'Cause, Effect & Social Flow',
      skill: 'Social Patterns & Exclusion',
      game: 'Odd One Out',
      id: 'odd-one-out',
      articleSlug: 'social-interaction-logic-cause-effect',
      badge: { name: 'Pattern Detective 🔍', shortName: 'Logic 🔍', icon: '🔍', desc: 'Identified group commonalities and pinpointed the unique outlier item.' }
    },
    // Week 19
    {
      quotient: 'DQ',
      title: 'Intentional Discovery & Peek-a-boo',
      skill: 'Sensory Exploration & Focus',
      game: 'Scrub the Mud',
      id: 'scrub-the-mud',
      articleSlug: 'object-permanence-hidden-friend',
      badge: { name: 'Mud Scrub Hero 🧼', shortName: 'Explorer 🧼', icon: '🧼', desc: 'Persevered through tactile scrubbing to reveal delightful hidden friends.' }
    },
    // Week 20
    {
      quotient: 'IQ',
      title: 'Animal Habitats & Ecological Homes',
      skill: 'Zoological Classification',
      game: 'Where Do They Live?',
      id: 'where-do-they-live',
      articleSlug: 'taxonomic-thinking-animal-habitats',
      badge: { name: 'Habitat Ranger 🌍', shortName: 'Ranger 🌍', icon: '🌍', desc: 'Matched living creatures with their natural terrestrial and aquatic biomes.' }
    },
    // Week 21
    {
      quotient: 'IQ',
      title: 'Environmental Sorting & Transport',
      skill: 'Domain Classification (Land/Sea/Air)',
      game: 'Land, Sea, or Air',
      id: 'land-sea-air',
      articleSlug: 'environmental-sorting-land-sea-air',
      badge: { name: 'World Traveler ✈️', shortName: 'Traveler ✈️', icon: '✈️', desc: 'Categorized vehicles and animals by their environmental medium of travel.' }
    },
    // Week 22
    {
      quotient: 'PQ',
      title: 'Thermal Sensation & Everyday Logic',
      skill: 'Temperature Logic & Safety',
      game: 'Hot & Cold Sorter',
      id: 'hot-cold-sorter',
      articleSlug: 'temperature-logic-hot-and-cold',
      badge: { name: 'Thermal Scout ❄️', shortName: 'Thermal ❄️', icon: '❄️', desc: 'Distinguished hot vs cold items and established vital household temperature safety.' }
    },
    // Week 23
    {
      quotient: 'IQ',
      title: 'Science of Scale & Proportions',
      skill: 'Comparative Sizing (Big to Small)',
      game: 'Size Sorter',
      id: 'size-sorter',
      articleSlug: 'science-of-scale-big-and-small',
      badge: { name: 'Scale Expert ⚖️', shortName: 'Scale ⚖️', icon: '⚖️', desc: 'Mastered relative spatial hierarchies by ordering objects from largest to smallest.' }
    },
    // Week 24
    {
      quotient: 'CQ',
      title: 'Early Scales & Melodic Pitch',
      skill: 'Pitch Memory & Musical Scales',
      game: 'Emoji Xylophone',
      id: 'emoji-xylophone',
      articleSlug: 'musical-foundations-early-scales',
      badge: { name: 'Xylo Chimes 🎶', shortName: 'Chimes 🎶', icon: '🎶', desc: 'Explored ascending musical intervals and auditory sequence reproduction.' }
    },
    // Week 25
    {
      quotient: 'AQ',
      title: 'Calming Flow & Tactile Particles',
      skill: 'Sensory Soothing & Kinetic Flow',
      game: 'Magic Sand',
      id: 'magic-sand',
      articleSlug: 'magic-of-sensory-play-digital-sand',
      badge: { name: 'Sand Sculptor 🏖️', shortName: 'Sculptor 🏖️', icon: '🏖️', desc: 'Swirled fluid particle dynamics to regulate sensory overload and induce calm.' }
    },
    // Week 26
    {
      quotient: 'PQ',
      title: 'Pincer Path Navigation & Flow',
      skill: 'Fine Motor Tracing & Steady Hand',
      game: 'Trace the Path',
      id: 'trace-path',
      articleSlug: 'refining-pincer-grip-tracing-paths',
      badge: { name: 'Path Tracer ✏️', shortName: 'Tracer ✏️', icon: '✏️', desc: 'Navigated complex curving trajectories with steady fingertip motor control.' }
    },
    // Week 27
    {
      quotient: 'EQ',
      title: 'Auditory Context & Sound Sleuth',
      skill: 'Acoustic Association & Empathy',
      game: 'Who Makes This Sound?',
      id: 'who-makes-sound',
      articleSlug: 'contextual-naming-vocabulary-guessing',
      badge: { name: 'Sound Sleuth 👂', shortName: 'Listener 👂', icon: '👂', desc: 'Associated complex animal vocalizations with their correct emotional actors.' }
    },
    // Week 28
    {
      quotient: 'AQ',
      title: 'Bravery, Shadows & Hidden Lights',
      skill: 'Overcoming Fear & Focused Search',
      game: 'Flashlight Explorer',
      id: 'flashlight-explorer',
      articleSlug: 'discovery-in-the-dark-eliminating-fear',
      badge: { name: 'Night Beacon 🔦', shortName: 'Beacon 🔦', icon: '🔦', desc: 'Overcame dark anxieties by discovering hidden friends with flashlight beam focus.' }
    },
    // Week 29
    {
      quotient: 'CQ',
      title: 'Color Mixing & Pigment Alchemy',
      skill: 'Color Theory & Chemical Logic',
      game: 'Color Mixture',
      id: 'color-mixture',
      articleSlug: 'science-of-color-mixing-logic',
      badge: { name: 'Color Chemist 🧪', shortName: 'Chemist 🧪', icon: '🧪', desc: 'Discovered secondary colors through hands-on primary pigment combination.' }
    },
    // Week 30
    {
      quotient: 'ALL',
      title: 'Junior Genius Grand Graduation',
      skill: 'Holistic 7-Quotient Mastery',
      game: 'Parental Dashboard',
      id: 'parental-dashboard',
      articleSlug: 'boost-kids-self-esteem-celebration',
      badge: { name: 'Genius Graduate 🎓', shortName: 'Graduate 🎓', icon: '🎓', desc: 'Achieved complete 30-week milestone journey across all 7 developmental quotients!' }
    }
  ];

  for (let idx = 0; idx < items9to30.length; idx++) {
    const i = idx + 9;
    const item = items9to30[idx];
    const gameUrl = item.id === 'parental-dashboard' 
      ? 'https://www.offlinekidsgames.com/parents/index.html#stats'
      : `https://www.offlinekidsgames.com/game/${item.id}.html`;

    CURRICULUM.push({
      week: i,
      quotient: item.quotient,
      title: item.title,
      skill: item.skill,
      whyItMatters: `Week ${i} advances essential kindergarten readiness and builds deep capability in ${item.skill}.`,
      articleUrl: `https://www.juniorgenius.club/${item.articleSlug}.html`,
      kidsScrollGame: {
        id: item.id,
        name: item.game,
        url: gameUrl,
        icon: item.badge.icon || '🌟',
        metricTracked: 'Time & Accuracy'
      },
      toddlerActivities: [
        { id: `w${i}_t1`, title: 'Household Discovery 1', desc: `Gentle guided tactile play tailored for ${item.skill}.` },
        { id: `w${i}_t2`, title: 'Household Discovery 2', desc: `Interactive sensory exploration with everyday household items.` },
        { id: `w${i}_t3`, title: 'Parent-Child Bonding', desc: `Shared joyful ritual to reinforce this week’s developmental quotient.` }
      ],
      preschoolerActivities: [
        { id: `w${i}_p1`, title: 'Skill Builder Challenge 1', desc: `Hands-on physical task to build ${item.skill}.` },
        { id: `w${i}_p2`, title: 'Creative Extension 2', desc: `Interactive problem-solving game with household items.` },
        { id: `w${i}_p3`, title: 'Family Real-World Practice', desc: `Real-life kindergarten readiness practice.` }
      ],
      observationChecklist: [
        'Notice your child’s enthusiasm and problem-solving strategies.',
        'Observe how they communicate their discoveries to you.',
        'Celebrate small milestones and persistence.'
      ],
      sundayQuestions: [
        {
          text: `How did your child demonstrate growth in ${item.skill} this week?`,
          options: [
            { text: 'Starting to explore with assistance', points: 20 },
            { text: 'Good steady progress and comfort', points: 35 },
            { text: 'Confident, independent mastery!', points: 50 }
          ]
        },
        {
          text: 'What was their persistence level when challenged?',
          options: [
            { text: 'Needed gentle encouragement', points: 20 },
            { text: 'High persistence and cheerful effort', points: 50 }
          ]
        },
        {
          text: 'Did they enjoy the combination of offline and Kids Scroll activities?',
          options: [
            { text: 'Enjoyed some parts', points: 25 },
            { text: 'Loved the activities and looked forward to them!', points: 50 }
          ]
        }
      ],
      badge: item.badge
    });
  }
})();

// ==========================================
// 2. STORAGE & STATE MANAGEMENT
// ==========================================
const STORAGE_KEYS = {
  PROFILE: 'juniorgenius_profile',
  MILESTONES: 'juniorgenius_milestones',
  LOGS: 'juniorgenius_weekly_logs',
  CHECKLIST: 'juniorgenius_checklist',
  STATS: 'kids_scroll_parental_stats'
};

const DEFAULT_PROFILE = {
  childName: 'My Child',
  ageGroup: 'toddler', // 'toddler' (1.5-3y) or 'preschooler' (3-5y)
  currentWeek: 1,
  startedAt: Date.now()
};

const DEFAULT_MILESTONES = {
  IQ: { points: 120, level: 1, tier: 'Explorer 🔍' },
  PQ: { points: 130, level: 1, tier: 'Explorer 🔍' },
  EQ: { points: 90, level: 1, tier: 'Novice 🌱' },
  AQ: { points: 95, level: 1, tier: 'Novice 🌱' },
  SQ: { points: 85, level: 1, tier: 'Novice 🌱' },
  CQ: { points: 110, level: 1, tier: 'Explorer 🔍' },
  DQ: { points: 80, level: 1, tier: 'Novice 🌱' }
};

function safeGet(key, fallback) {
  try {
    const val = localStorage.getItem(key);
    return val ? JSON.parse(val) : fallback;
  } catch (e) {
    console.warn('Storage read failed:', e);
    return fallback;
  }
}

function safeSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn('Storage write failed:', e);
  }
}

function calculateTier(points) {
  if (points >= 300) return 'Junior Genius 🏆';
  if (points >= 200) return 'Achiever ⭐';
  if (points >= 100) return 'Explorer 🔍';
  return 'Novice 🌱';
}

function calculateLevel(points) {
  return Math.min(4, Math.max(1, Math.floor(points / 100) + 1));
}

// Global App State
const state = {
  profile: safeGet(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE),
  milestones: safeGet(STORAGE_KEYS.MILESTONES, DEFAULT_MILESTONES),
  logs: safeGet(STORAGE_KEYS.LOGS, {}),
  checklist: safeGet(STORAGE_KEYS.CHECKLIST, {}),
  kidsScrollStats: safeGet(STORAGE_KEYS.STATS, {})
};

// ==========================================
// 3. TELEMETRY BRIDGE (KIDS SCROLL -> PARENT APP)
// ==========================================
function initTelemetryBridge() {
  // 1. Direct same-origin synchronous load (no iframe needed on offlinekidsgames.com)
  loadDirectSameOriginStats();

  // 2. Real-time storage listener across tabs/windows
  window.addEventListener('storage', (event) => {
    if (event.key === STORAGE_KEYS.STATS) {
      loadDirectSameOriginStats(true);
    } else if (event.key === 'kids_scroll_mascot_enabled') {
      syncMascotUI();
    } else if (event.key === 'kids_scroll_notifications_enabled') {
      syncNotificationUI();
    }
  });

  // 3. Listen for postMessage from Kids Scroll iframe or child window (cross-origin fallback)
  window.addEventListener('message', (event) => {
    try {
      if (event.data && event.data.type === 'KIDS_SCROLL_STATS_REPLY') {
        const stats = event.data.payload;
        if (stats && typeof stats === 'object') {
          state.kidsScrollStats = stats;
          safeSet(STORAGE_KEYS.STATS, stats);
          updateTelemetryUI();
          showBridgeSyncNotice('⚡ Live game stats updated from Kids Scroll!');
        }
      }
    } catch (e) {
      console.warn('Bridge error:', e);
    }
  });

  // 4. Check URL hash for direct deep-link sync: #sync=<base64>
  if (window.location.hash.startsWith('#sync=')) {
    try {
      const b64 = window.location.hash.replace('#sync=', '');
      const json = decodeURIComponent(escape(atob(b64)));
      const stats = JSON.parse(json);
      if (stats) {
        state.kidsScrollStats = stats;
        safeSet(STORAGE_KEYS.STATS, stats);
        history.replaceState(null, '', window.location.pathname);
        showBridgeSyncNotice('🎉 Game telemetry imported successfully!');
      }
    } catch (err) {
      console.warn('Hash import error:', err);
    }
  }

  // 5. Request stats from silent bridge iframe (fallback)
  requestStatsFromBridge();
}

function loadDirectSameOriginStats(notify = false) {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.STATS);
    if (raw) {
      const stats = JSON.parse(raw);
      if (stats && typeof stats === 'object') {
        state.kidsScrollStats = stats;
        renderGamesTab();
        if (notify) {
          showBridgeSyncNotice('⚡ Live game stats updated!');
        }
      }
    }
  } catch (e) {
    console.warn('Direct stats read error:', e);
  }
}

function requestStatsFromBridge() {
  loadDirectSameOriginStats();
  const iframe = document.getElementById('statsBridgeIframe');
  if (iframe && iframe.contentWindow) {
    try {
      iframe.contentWindow.postMessage({ type: 'KIDS_SCROLL_GET_STATS' }, '*');
    } catch (e) {}
  }
}

function showBridgeSyncNotice(msg) {
  const syncStatus = document.getElementById('syncStatusIndicator');
  if (syncStatus) {
    syncStatus.innerHTML = `🟢 ${msg}`;
    setTimeout(() => {
      syncStatus.innerHTML = '🟢 Connected &amp; Synced Directly';
    }, 4000);
  }
}

// ==========================================
// 4. RADAR CHART SVG GENERATOR (PURE VANILLA JS)
// ==========================================
function renderRadarChart() {
  const container = document.getElementById('radarChartWrapper');
  if (!container) return;

  const width = 320;
  const height = 320;
  const center = { x: width / 2, y: height / 2 };
  const radius = 105;

  const quotients = [
    { key: 'IQ', label: 'IQ (Logic)', icon: '💡' },
    { key: 'PQ', label: 'PQ (Motor)', icon: '🏃' },
    { key: 'EQ', label: 'EQ (Emotion)', icon: '❤️' },
    { key: 'AQ', label: 'AQ (Grit)', icon: '🛡️' },
    { key: 'SQ', label: 'SQ (Social)', icon: '🤝' },
    { key: 'CQ', label: 'CQ (Create)', icon: '🎨' },
    { key: 'DQ', label: 'DQ (Digital)', icon: '📱' }
  ];

  const totalAxes = quotients.length;
  const angleSlice = (Math.PI * 2) / totalAxes;

  // Background concentric polygons (25%, 50%, 75%, 100%)
  let bgPolygons = '';
  [0.25, 0.5, 0.75, 1.0].forEach((level) => {
    let points = [];
    for (let i = 0; i < totalAxes; i++) {
      const angle = i * angleSlice - Math.PI / 2;
      const x = center.x + radius * level * Math.cos(angle);
      const y = center.y + radius * level * Math.sin(angle);
      points.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    }
    const stroke = level === 1.0 ? '#d1d5db' : '#f0e6eb';
    bgPolygons += `<polygon points="${points.join(' ')}" fill="none" stroke="${stroke}" stroke-width="1.2" stroke-dasharray="${level < 1 ? '3 3' : 'none'}" />`;
  });

  // Axis spokes & Labels
  let spokes = '';
  let labels = '';
  let dataPoints = [];

  quotients.forEach((q, i) => {
    const angle = i * angleSlice - Math.PI / 2;
    const endX = center.x + radius * Math.cos(angle);
    const endY = center.y + radius * Math.sin(angle);

    spokes += `<line x1="${center.x}" y1="${center.y}" x2="${endX}" y2="${endY}" stroke="#f3e8ff" stroke-width="1.5" />`;

    // Data polygon coordinate (clamped 0 to 400 pts -> 0.15 to 1.0 radius)
    const pts = (state.milestones[q.key] && state.milestones[q.key].points) || 100;
    const ratio = Math.max(0.2, Math.min(1.0, pts / 350));
    const dataX = center.x + radius * ratio * Math.cos(angle);
    const dataY = center.y + radius * ratio * Math.sin(angle);
    dataPoints.push({ x: dataX, y: dataY, q: q.key, pts: pts });

    // Label positioning
    const labelRadius = radius + 24;
    const labelX = center.x + labelRadius * Math.cos(angle);
    const labelY = center.y + labelRadius * Math.sin(angle) + 4;
    labels += `<text x="${labelX.toFixed(1)}" y="${labelY.toFixed(1)}" text-anchor="middle" font-size="11" font-weight="700" fill="#374151">${q.icon} ${q.key}</text>`;
  });

  const polygonString = dataPoints.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');

  const markers = dataPoints
    .map(
      (p) =>
        `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="4.5" fill="#c2185b" stroke="#ffffff" stroke-width="2" />`
    )
    .join('');

  container.innerHTML = `
    <svg class="radar-svg" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="radarGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#f8bbd0" stop-opacity="0.6"/>
          <stop offset="100%" stop-color="#c2185b" stop-opacity="0.15"/>
        </radialGradient>
      </defs>
      ${bgPolygons}
      ${spokes}
      <polygon points="${polygonString}" fill="url(#radarGlow)" stroke="#c2185b" stroke-width="2.5" />
      ${markers}
      ${labels}
    </svg>
  `;
}

// ==========================================
// 5. UI CONTROLLERS & TAB RENDERING
// ==========================================
function renderCurrentWeek() {
  const weekNum = state.profile.currentWeek || 1;
  const weekData = CURRICULUM.find((w) => w.week === weekNum) || CURRICULUM[0];

  // Header badges
  const weekBadge = document.getElementById('headerWeekBadge');
  if (weekBadge) weekBadge.textContent = `Week ${weekNum}`;

  const profileName = document.getElementById('headerProfileName');
  if (profileName) profileName.textContent = state.profile.childName;

  const profileTag = document.getElementById('headerProfileTag');
  if (profileTag) profileTag.textContent = state.profile.ageGroup === 'toddler' ? '1.5-3 yrs' : '3-5 yrs';

  // Mission Hero Card
  const weekTitle = document.getElementById('weekHeroTitle');
  if (weekTitle) weekTitle.textContent = `Week ${weekData.week}: ${weekData.title}`;

  const weekQuotientBadge = document.getElementById('weekQuotientBadge');
  if (weekQuotientBadge) weekQuotientBadge.textContent = `${weekData.quotient} Power`;

  const whyText = document.getElementById('weekWhyText');
  if (whyText) whyText.textContent = weekData.whyItMatters;

  // Render 3 Offline Activities according to chosen age group
  const activitiesList = document.getElementById('offlineActivitiesList');
  if (activitiesList) {
    const acts = state.profile.ageGroup === 'toddler' ? weekData.toddlerActivities : weekData.preschoolerActivities;
    activitiesList.innerHTML = acts
      .map((a) => {
        const isChecked = state.checklist[a.id] ? 'checked' : '';
        return `
        <div class="activity-item ${isChecked}" onclick="toggleActivity('${a.id}')">
          <div class="activity-checkbox">${isChecked ? '✓' : ''}</div>
          <div class="activity-content">
            <h4>${a.title}</h4>
            <p>${a.desc}</p>
          </div>
        </div>
      `;
      })
      .join('');
  }

  // Digital Box (Kids Scroll Game)
  const gameBox = document.getElementById('digitalGameBox');
  if (gameBox) {
    const game = weekData.kidsScrollGame;
    const gameStatPreview = getGameStatSnippet(game.id);
    const gamePath = game.url.replace(/^https?:\/\/[^\/]+/, '');

    gameBox.innerHTML = `
      <h3>${game.icon} Targeted Play: ${game.name}</h3>
      <p>Play together for 5 minutes to strengthen ${weekData.skill}.</p>
      ${gameStatPreview ? `<div class="digital-stats-preview">${gameStatPreview}</div>` : ''}
      <button type="button" class="btn btn-purple" onclick="launchKidsScrollTarget('${gamePath}')" style="cursor: pointer; width: auto; white-space: nowrap;">
        🚀 Launch ${game.name}
      </button>
    `;
  }

  // Junior Genius Club Related Article Deep-Dive & Quotient Framework
  const articleBox = document.getElementById('weeklyArticleBox');
  if (articleBox) {
    const frameworkUrl = `https://www.juniorgenius.club/the-7-human-quotients-growth-and-success-framework.html#${weekData.quotient.toLowerCase()}`;
    articleBox.innerHTML = `
      <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px; flex-wrap: wrap;">
        <div>
          <h4 style="margin: 0 0 4px 0; color: #86198f; font-size: 0.95rem;">📖 Developmental Guide: ${weekData.title}</h4>
          <p style="margin: 0; color: #701a75; font-size: 0.82rem;">Parent guides on Junior Genius Club to master this week's milestone.</p>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
          ${weekData.articleUrl ? `
            <a href="${weekData.articleUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-outline weekly-article-card" style="background: white; border-color: #d946ef; color: #a21caf; font-size: 0.82rem; padding: 6px 14px; text-decoration: none; border-radius: 20px; font-weight: 700; white-space: nowrap;">
              📖 Read on ${weekData.title} ↗
            </a>
          ` : ''}
          <a href="${frameworkUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-outline" style="background: white; border-color: #9333ea; color: #7e22ce; font-size: 0.82rem; padding: 6px 14px; text-decoration: none; border-radius: 20px; font-weight: 700; white-space: nowrap;">
            💡 Read on ${weekData.quotient} Power ↗
          </a>
        </div>
      </div>
    `;
  }

  // Sunday Button Status
  const logKey = `week-${weekNum}`;
  const sundayBtn = document.getElementById('launchSundayCheckinBtn');
  if (sundayBtn) {
    if (state.logs[logKey]) {
      sundayBtn.innerHTML = '🏆 View Completed Sunday Report Card';
      sundayBtn.classList.remove('btn-primary');
      sundayBtn.classList.add('btn-outline');
    } else {
      sundayBtn.innerHTML = '✨ Complete 2-Min Sunday Check-in';
      sundayBtn.classList.remove('btn-outline');
      sundayBtn.classList.add('btn-primary');
    }
  }
}

function toggleActivity(id) {
  state.checklist[id] = !state.checklist[id];
  safeSet(STORAGE_KEYS.CHECKLIST, state.checklist);
  renderCurrentWeek();
}

function getGameStatSnippet(gameId) {
  const stats = state.kidsScrollStats;
  let totalPlays = 0;
  let totalTime = 0;

  Object.values(stats).forEach((dateObj) => {
    if (dateObj && dateObj[gameId]) {
      totalPlays += dateObj[gameId].plays || 0;
      totalTime += dateObj[gameId].timeSpent || 0;
    }
  });

  if (totalPlays > 0) {
    const mins = Math.round(totalTime / 60);
    return `📊 ${totalPlays} plays recorded on Kids Scroll (${mins}m total)`;
  }
  return '';
}

// ==========================================
// 6. QUOTIENT TAB & MILESTONE RENDERING
// ==========================================
function renderQuotientsTab() {
  renderRadarChart();

  const grid = document.getElementById('quotientCardsGrid');
  if (!grid) return;

  const metadata = {
    IQ: { name: 'Intelligence Quotient', icon: '💡', desc: 'Logic, pattern discovery, and memory' },
    PQ: { name: 'Physical Quotient', icon: '🏃', desc: 'Pincer grip, reflexes, and coordination' },
    EQ: { name: 'Emotional Quotient', icon: '❤️', desc: 'Emotion recognition and calming' },
    AQ: { name: 'Adversity Quotient', icon: '🛡️', desc: 'Frustration tolerance and perseverance' },
    SQ: { name: 'Social Quotient', icon: '🤝', desc: 'Turn-taking, boundaries, and empathy' },
    CQ: { name: 'Creativity Quotient', icon: '🎨', desc: 'Artistic exploration and imagination' },
    DQ: { name: 'Digital Quotient', icon: '📱', desc: 'Healthy transitions and safe screen habits' }
  };

  grid.innerHTML = Object.keys(metadata)
    .map((q) => {
      const info = metadata[q];
      const data = state.milestones[q] || { points: 100, tier: 'Novice 🌱' };
      const pct = Math.min(100, Math.round((data.points / 350) * 100));
      const tierClass = data.tier.toLowerCase().replace(/[^a-z]/g, '-');

      return `
      <div class="quotient-card">
        <div class="quotient-card-header">
          <div class="quotient-card-title">${info.icon} ${q}</div>
          <span class="quotient-tier-badge ${tierClass}">${data.tier}</span>
        </div>
        <div class="quotient-progress-bar">
          <div class="quotient-progress-fill" style="width: ${pct}%"></div>
        </div>
        <div class="quotient-desc">${info.desc}</div>
      </div>
    `;
    })
    .join('');

  // Trophy Cabinet
  const cabinet = document.getElementById('trophyCabinet');
  if (cabinet) {
    cabinet.innerHTML = CURRICULUM.map((w) => {
      const isUnlocked = !!state.logs[`week-${w.week}`];
      const rawName = w.badge.shortName || w.badge.name;
      // Strip any trailing emojis or symbols to keep trophy-name clean under the trophy-icon
      const displayName = rawName.replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '').trim();
      const fullTooltip = `Week ${w.week}: ${w.badge.name} - ${w.badge.desc}`;
      return `
        <div class="trophy-badge ${isUnlocked ? 'unlocked' : ''}" onclick="openBadgeDetailModal(${w.week})" title="${fullTooltip}" role="button" tabindex="0">
          <div class="trophy-icon">${w.badge.icon}</div>
          <div class="trophy-name">${displayName}</div>
        </div>
      `;
    }).join('');
  }

  // Ensure 7-Quotient Radar is active by default if no cards are open
  const radarCard = document.getElementById('card-quotient-radar');
  if (radarCard) {
    const anyActive = document.querySelector('#stats-view-quotients .accordion-card.active');
    if (!anyActive) {
      radarCard.classList.add('active');
    }
  }
}

function toggleQuotientAccordion(cardId, event) {
  if (event) {
    if (typeof event.stopPropagation === 'function') event.stopPropagation();
  }
  const targetCard = document.getElementById(cardId);
  if (!targetCard) return;

  // Independent multi-expansion: click toggles only the target card
  targetCard.classList.toggle('active');
}

// ==========================================
// 7. UNIFIED STATS TAB (QUOTIENTS, GAMES, STORIES)
// ==========================================
let currentStatsSubMode = 'quotients';
let gameFilterMode = 'daily';
let storyFilterMode = 'daily';
let storyStatsModule = null;

function switchStatsSubMode(subMode) {
  currentStatsSubMode = subMode;
  ['quotients', 'games', 'stories'].forEach((mode) => {
    const pill = document.getElementById(`subpill-${mode}`);
    const view = document.getElementById(`stats-view-${mode}`);
    if (pill) {
      if (mode === subMode) pill.classList.add('active');
      else pill.classList.remove('active');
    }
    if (view) {
      view.style.display = (mode === subMode) ? '' : 'none';
    }
  });

  if (subMode === 'quotients') renderQuotientsTab();
  if (subMode === 'games') renderGamesTab();
  if (subMode === 'stories') renderStoriesTab();
}

function setGameFilterMode(mode) {
  gameFilterMode = mode;
  const dBtn = document.getElementById('game-tab-daily');
  const wBtn = document.getElementById('game-tab-weekly');
  if (dBtn && wBtn) {
    if (mode === 'daily') {
      dBtn.classList.add('active');
      wBtn.classList.remove('active');
    } else {
      wBtn.classList.add('active');
      dBtn.classList.remove('active');
    }
  }
  renderGamesTab();
}

function setStoryFilterMode(mode) {
  storyFilterMode = mode;
  const dBtn = document.getElementById('story-tab-daily');
  const wBtn = document.getElementById('story-tab-weekly');
  if (dBtn && wBtn) {
    if (mode === 'daily') {
      dBtn.classList.add('active');
      wBtn.classList.remove('active');
    } else {
      wBtn.classList.add('active');
      dBtn.classList.remove('active');
    }
  }
  renderStoriesTab();
}

function formatStatsTime(seconds) {
  if (seconds < 60) return Math.round(seconds) + 's';
  const mins = Math.floor(seconds / 60);
  const secs = Math.round(seconds % 60);
  return `${mins}m ${secs}s`;
}

function renderGamesTab() {
  const allStats = state.kidsScrollStats || {};
  let filteredStats = {};
  const now = new Date();

  if (gameFilterMode === 'daily') {
    const today = now.getFullYear() + '-' +
      String(now.getMonth() + 1).padStart(2, '0') + '-' +
      String(now.getDate()).padStart(2, '0');
    filteredStats = allStats[today] || {};
  } else {
    // Last 7 days
    const last7Days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const ds = d.getFullYear() + '-' +
        String(d.getMonth() + 1).padStart(2, '0') + '-' +
        String(d.getDate()).padStart(2, '0');
      last7Days.push(ds);
    }
    last7Days.forEach((date) => {
      if (allStats[date]) {
        Object.keys(allStats[date]).forEach((gId) => {
          if (!filteredStats[gId]) {
            filteredStats[gId] = { plays: 0, timeSpent: 0, metrics: [] };
          }
          filteredStats[gId].plays += allStats[date][gId].plays || 0;
          filteredStats[gId].timeSpent += allStats[date][gId].timeSpent || 0;
          if (allStats[date][gId].metrics) {
            filteredStats[gId].metrics.push(...allStats[date][gId].metrics);
          }
        });
      }
    });
  }

  // Update Overview Summary
  let totalPlays = 0;
  let totalTime = 0;
  let favGameId = '-';
  let maxPlays = 0;

  Object.keys(filteredStats).forEach((gId) => {
    totalPlays += filteredStats[gId].plays;
    totalTime += filteredStats[gId].timeSpent;
    if (filteredStats[gId].plays > maxPlays) {
      maxPlays = filteredStats[gId].plays;
      favGameId = gId;
    }
  });

  const totalPlaysEl = document.getElementById('total-plays');
  if (totalPlaysEl) totalPlaysEl.textContent = totalPlays;

  const totalTimeEl = document.getElementById('total-time');
  if (totalTimeEl) totalTimeEl.textContent = formatStatsTime(totalTime);

  const topGameEl = document.getElementById('top-game');
  if (topGameEl) {
    if (favGameId !== '-') {
      const gameObj = (typeof ALL_GAMES !== 'undefined') ? ALL_GAMES.find(g => g.id === favGameId) : null;
      topGameEl.textContent = gameObj ? gameObj.name : favGameId;
    } else {
      topGameEl.textContent = '-';
    }
  }

  renderGamePlayChart(allStats);
  renderGameSkills(filteredStats);
  renderGameBreakdown(filteredStats);
}

function renderGamePlayChart(allStats) {
  const chart = document.getElementById('play-chart');
  if (!chart) return;
  chart.innerHTML = '';

  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0');
    last7Days.push(ds);
  }

  let maxPlays = 0;
  const dailyTotals = last7Days.map((date) => {
    let total = 0;
    if (allStats[date]) {
      Object.values(allStats[date]).forEach((g) => { total += (g.plays || 0); });
    }
    if (total > maxPlays) maxPlays = total;
    return { date, total };
  });

  if (maxPlays === 0) maxPlays = 10;

  dailyTotals.forEach((item) => {
    const parts = item.date.split('-');
    const d = new Date(parts[0], parts[1] - 1, parts[2]);
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const height = Math.round((item.total / maxPlays) * 100);

    const wrapper = document.createElement('div');
    wrapper.className = 'bar-wrapper';
    wrapper.innerHTML = `
      <div class="bar" style="height: ${height}%" data-value="${item.total}"></div>
      <div class="bar-label">${dayName}</div>
    `;
    chart.appendChild(wrapper);
  });
}

const DEVELOPMENTAL_CATEGORIES = [
  {
    id: 'fine-motor',
    name: 'Fine Motor Skills & Coordination',
    icon: '🖐️',
    games: ['avatar-scroll', 'drawing-canvas', 'scrub-mud', 'emoji-jigsaw', 'garden-growing', 'finger-painting', 'bubble-wrap-pop', 'connect-the-dots', 'trace-path']
  },
  {
    id: 'problem-solving',
    name: 'Problem Solving & Logic',
    icon: '🧩',
    games: ['shadow-match', 'spot-the-pair', 'shape-sorter', 'build-the-zoo', 'who-is-it', 'pattern-maker', 'size-sorter', 'selective-bubble-pop', 'bake-a-cake']
  },
  {
    id: 'hand-eye',
    name: 'Hand-Eye Coordination & Reflexes',
    icon: '👁️',
    games: ['rocket-burst', 'make_fruit_salad', 'balloon-pop', 'whack-a-mole', 'traffic-light', 'odd-one-out', 'catch-treats', 'bouncing-buddy']
  },
  {
    id: 'cognitive',
    name: 'Cognitive Skills & Early Literacy',
    icon: '🧠',
    games: ['guess-the-time', 'alphabet-trace', 'learn_numbers', 'hidden-friend', 'build-a-face', 'day-night', 'animal-fight', 'emotion-explorer', 'count-with-me', 'who-makes-sound']
  },
  {
    id: 'sorting',
    name: 'Sorting & Categorization',
    icon: '🧺',
    games: ['sort-the-groceries', 'color-train', 'feed-animals', 'color-mixture', 'where-do-they-live', 'hot-cold-sorter', 'land-sea-air']
  },
  {
    id: 'music',
    name: 'Music & Rhythm',
    icon: '🎵',
    games: ['musical-instrument', 'emoji-xylophone', 'animal-beatbox']
  },
  {
    id: 'sensory',
    name: 'Sensory & Relaxation',
    icon: '✨',
    games: ['breathing-bubble', 'magic-sand', 'flashlight-explorer', 'egg-hatching']
  }
];

function getCategoryForGame(gameId) {
  for (const cat of DEVELOPMENTAL_CATEGORIES) {
    if (cat.games.includes(gameId)) return cat;
  }
  return null;
}

function renderGameSkills(stats) {
  const grid = document.getElementById('skill-grid');
  if (!grid) return;
  grid.innerHTML = '';

  let hasAnySkillData = false;

  DEVELOPMENTAL_CATEGORIES.forEach((cat) => {
    // Collect all games in this category that have stats
    const playedGames = [];
    let catPlays = 0;
    let catTime = 0;
    let totalImprovement = 0;
    let validImprovementCount = 0;

    cat.games.forEach((gId) => {
      const gStats = stats[gId];
      if (gStats && (gStats.plays > 0 || gStats.timeSpent > 0)) {
        catPlays += gStats.plays || 0;
        catTime += gStats.timeSpent || 0;

        let gameMetricInfo = null;
        if (gStats.metrics && gStats.metrics.length > 0) {
          const currentAvg = gStats.metrics.reduce((acc, m) => acc + (m.avgTime || 0), 0) / gStats.metrics.length;
          let improvement = 0;
          if (gStats.metrics.length >= 4) {
            const mid = Math.floor(gStats.metrics.length / 2);
            const firstHalf = gStats.metrics.slice(0, mid).reduce((acc, m) => acc + (m.avgTime || 0), 0) / mid;
            const secondHalf = gStats.metrics.slice(mid).reduce((acc, m) => acc + (m.avgTime || 0), 0) / (gStats.metrics.length - mid);
            if (firstHalf > 0) {
              improvement = ((firstHalf - secondHalf) / firstHalf) * 100;
              totalImprovement += improvement;
              validImprovementCount++;
            }
          }
          gameMetricInfo = { currentAvg, improvement };
        }

        const gameObj = (typeof ALL_GAMES !== 'undefined') ? ALL_GAMES.find(g => g.id === gId) : null;
        playedGames.push({
          id: gId,
          name: gameObj ? gameObj.name : gId,
          plays: gStats.plays,
          timeSpent: gStats.timeSpent,
          metricInfo: gameMetricInfo
        });
      }
    });

    if (playedGames.length > 0) {
      hasAnySkillData = true;
      const card = document.createElement('div');
      card.className = 'skill-card';
      card.style.cssText = 'padding: 16px; border-radius: 16px; background: #ffffff; border: 1.5px solid #e9d5ff; margin-bottom: 12px; box-shadow: 0 2px 8px rgba(106, 17, 203, 0.05);';

      let impBadge = '';
      if (validImprovementCount > 0) {
        const avgImp = Math.round(totalImprovement / validImprovementCount);
        if (avgImp > 0) {
          impBadge = `<span class="skill-improvement improvement-positive">+${avgImp}% faster!</span>`;
        } else {
          impBadge = `<span class="skill-improvement improvement-neutral">Steady progress</span>`;
        }
      } else {
        impBadge = `<span class="skill-improvement improvement-neutral">${playedGames.length} game${playedGames.length > 1 ? 's' : ''} active</span>`;
      }

      const gamesChips = playedGames.map(g => {
        const metricStr = g.metricInfo && g.metricInfo.currentAvg > 0 ? ` • ${g.metricInfo.currentAvg.toFixed(1)}s` : '';
        return `<span style="display: inline-block; background: #f3e8ff; color: #6a11cb; padding: 3px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; margin: 2px 4px 2px 0;">${g.name}${metricStr} (${g.plays}p)</span>`;
      }).join('');

      card.innerHTML = `
        <div class="skill-header" style="margin-bottom: 8px;">
          <span class="skill-title" style="font-size: 1rem; font-weight: 800; color: #2d3748;">
            ${cat.icon} ${cat.name}
          </span>
          ${impBadge}
        </div>
        <div style="display: flex; gap: 16px; align-items: baseline; margin-bottom: 8px;">
          <div>
            <span style="font-size: 1.35rem; font-weight: 800; color: #6a11cb;">${catPlays}</span>
            <span style="font-size: 0.78rem; color: #718096; margin-left: 2px;">plays</span>
          </div>
          <div>
            <span style="font-size: 1.1rem; font-weight: 700; color: #4a5568;">${formatStatsTime(catTime)}</span>
            <span style="font-size: 0.78rem; color: #718096; margin-left: 2px;">spent</span>
          </div>
        </div>
        <div style="margin-top: 6px;">
          ${gamesChips}
        </div>
      `;
      grid.appendChild(card);
    }
  });

  if (!hasAnySkillData) {
    grid.innerHTML = '<div class="no-data-notice">Play learning games on Kids Scroll to see skill development across categories!</div>';
  }
}

function renderGameBreakdown(stats) {
  const list = document.getElementById('game-breakdown');
  if (!list) return;
  list.innerHTML = '';

  const sortedIds = Object.keys(stats).filter(id => stats[id].plays > 0).sort((a, b) => stats[b].plays - stats[a].plays);
  if (sortedIds.length === 0) {
    list.innerHTML = '<div class="no-data-notice">No games played yet in this period.</div>';
    return;
  }

  sortedIds.forEach((gameId) => {
    const game = (typeof ALL_GAMES !== 'undefined') ? ALL_GAMES.find(g => g.id === gameId) : null;
    const name = game ? game.name : gameId;
    const cat = getCategoryForGame(gameId);
    const catBadge = cat ? `<span style="font-size: 0.72rem; color: #6a11cb; background: #f3e8ff; padding: 2px 6px; border-radius: 8px; margin-left: 6px;">${cat.icon} ${cat.name.split(' ')[0]}</span>` : '';
    const li = document.createElement('li');
    li.className = 'breakdown-item';
    li.innerHTML = `
      <div>
        <span class="breakdown-name">${name}</span>
        ${catBadge}
      </div>
      <div>
        <span class="breakdown-value">${stats[gameId].plays} plays</span>
        <span class="breakdown-sub">(${formatStatsTime(stats[gameId].timeSpent)})</span>
      </div>
    `;
    list.appendChild(li);
  });
}

async function getStoryStatsModule() {
  if (!storyStatsModule) {
    try {
      const statsMod = await import('/js/story/stats.js?v=1');
      let animalsMod = { ANIMALS: [] };
      try {
        animalsMod = await import('/js/story/animals.js?v=1');
      } catch (e) {}
      storyStatsModule = {
        ...statsMod,
        ANIMALS: animalsMod.ANIMALS || []
      };
    } catch (err) {
      console.warn('Story stats module unavailable:', err);
    }
  }
  return storyStatsModule;
}

function formatStoryTime(seconds) {
  if (seconds < 60) return `${Math.round(seconds)}s`;
  return `${Math.round(seconds / 60)}m`;
}

async function renderStoriesTab() {
  const mod = await getStoryStatsModule();
  if (!mod || !mod.getStatsForRange) {
    const chart = document.getElementById('story-play-chart');
    if (chart) chart.innerHTML = '<div class="no-data-notice">Listening stats will appear as stories are played.</div>';
    return;
  }

  try {
    const week = await mod.getStatsForRange(7);
    const active = storyFilterMode === 'daily' ? [week[week.length - 1]] : week;
    const streak = mod.getCurrentStreak ? await mod.getCurrentStreak() : 0;

    const totalPlays = active.reduce((sum, d) => sum + (d.storiesPlayed || 0), 0);
    const totalSeconds = active.reduce((sum, d) => sum + (d.listenSeconds || 0), 0);
    const avgSeconds = totalPlays ? Math.round(totalSeconds / totalPlays) : 0;

    const byAnimal = mod.mergeByAnimal ? mod.mergeByAnimal(active) : {};
    const sortedAnimals = Object.entries(byAnimal).sort((a, b) => b[1].plays - a[1].plays);

    const playsEl = document.getElementById('story-stat-plays');
    if (playsEl) playsEl.textContent = totalPlays;

    const timeEl = document.getElementById('story-stat-time');
    if (timeEl) timeEl.textContent = formatStoryTime(totalSeconds);

    const avgEl = document.getElementById('story-stat-avg');
    if (avgEl) avgEl.textContent = formatStoryTime(avgSeconds);

    const favEl = document.getElementById('story-stat-favorite');
    if (favEl) {
      if (sortedAnimals.length > 0) {
        const topAnimalId = sortedAnimals[0][0];
        const animalInfo = (mod.ANIMALS || []).find(a => a.id === topAnimalId);
        favEl.textContent = animalInfo ? animalInfo.emoji : topAnimalId;
      } else {
        favEl.textContent = '-';
      }
    }

    const streakEl = document.getElementById('story-stat-streak');
    if (streakEl) streakEl.textContent = streak;

    // 7-Day Chart
    const maxPlays = Math.max(1, ...week.map(d => d.storiesPlayed || 0));
    const chart = document.getElementById('story-play-chart');
    if (chart) {
      chart.innerHTML = week.map(d => {
        const parts = d.date.split('-');
        const dateObj = new Date(parts[0], parts[1] - 1, parts[2]);
        const dayLabel = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
        const height = Math.round(((d.storiesPlayed || 0) / maxPlays) * 100);
        return `
          <div class="bar-wrapper">
            <div class="bar" style="height: ${height}%" data-value="${d.storiesPlayed || 0}"></div>
            <div class="bar-label">${dayLabel}</div>
          </div>
        `;
      }).join('');
    }

    // Animals breakdown
    const animalList = document.getElementById('story-animal-breakdown');
    if (animalList) {
      if (sortedAnimals.length > 0) {
        animalList.innerHTML = sortedAnimals.map(([id, entry]) => {
          const info = (mod.ANIMALS || []).find(a => a.id === id) || { name: id, emoji: '🐾' };
          return `
            <li class="breakdown-item">
              <span class="breakdown-name">${info.emoji} ${info.name}</span>
              <div>
                <span class="breakdown-value">${entry.plays} ${entry.plays === 1 ? 'story' : 'stories'}</span>
                <span class="breakdown-sub">(${formatStoryTime(entry.seconds)})</span>
              </div>
            </li>
          `;
        }).join('');
      } else {
        animalList.innerHTML = '<div class="no-data-notice">No animals listened to yet in this period.</div>';
      }
    }

    // Daily breakdown
    const dayList = document.getElementById('story-day-breakdown');
    if (dayList) {
      const hasAny = week.some(d => d.storiesPlayed > 0);
      if (hasAny) {
        dayList.innerHTML = [...week].reverse().map(d => {
          const parts = d.date.split('-');
          const dateObj = new Date(parts[0], parts[1] - 1, parts[2]);
          const dayLabel = dateObj.toLocaleDateString('en-US', { weekday: 'short' });
          return `
            <li class="breakdown-item">
              <span class="breakdown-name">${dayLabel}</span>
              <div>
                <span class="breakdown-value">${d.storiesPlayed} ${d.storiesPlayed === 1 ? 'story' : 'stories'}</span>
                <span class="breakdown-sub">(${formatStoryTime(d.listenSeconds)})</span>
              </div>
            </li>
          `;
        }).join('');
      } else {
        dayList.innerHTML = '<div class="no-data-notice">No stories listened to yet.</div>';
      }
    }
  } catch (err) {
    console.warn('Error rendering story stats:', err);
  }
}

async function captureAndShare(elementId, title) {
  const card = document.getElementById(elementId);
  if (!card) return;
  const shareBtn = card.querySelector('.share-btn');
  const toggleBtn = card.querySelector('.accordion-toggle-btn');
  const wasCollapsed = card.classList.contains('accordion-card') && !card.classList.contains('active');

  if (wasCollapsed) {
    card.classList.add('active');
  }
  if (shareBtn) shareBtn.style.visibility = 'hidden';
  if (toggleBtn) toggleBtn.style.visibility = 'hidden';

  try {
    if (typeof html2canvas === 'undefined') {
      alert('Card sharing library is loading. Please try again in a moment.');
      if (shareBtn) shareBtn.style.visibility = 'visible';
      if (toggleBtn) toggleBtn.style.visibility = 'visible';
      if (wasCollapsed) card.classList.remove('active');
      return;
    }
    const canvas = await html2canvas(card, {
      backgroundColor: '#f5f7fa',
      scale: 2,
      logging: false
    });
    if (shareBtn) shareBtn.style.visibility = 'visible';
    if (toggleBtn) toggleBtn.style.visibility = 'visible';
    if (wasCollapsed) card.classList.remove('active');

    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const file = new File([blob], 'kids-scroll-stats.png', { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({
            files: [file],
            title: 'Kids Scroll Progress',
            text: title + ' Check it out at www.offlinekidsgames.com'
          });
        } catch (err) {
          console.warn('Share cancelled or failed:', err);
        }
      } else {
        const link = document.createElement('a');
        link.download = 'kids-scroll-stats.png';
        link.href = URL.createObjectURL(blob);
        link.click();
        alert('Image downloaded! You can now share it with others.');
      }
    });
  } catch (err) {
    console.error('Capture failed:', err);
    if (shareBtn) shareBtn.style.visibility = 'visible';
    if (toggleBtn) toggleBtn.style.visibility = 'visible';
    if (wasCollapsed) card.classList.remove('active');
  }
}

// ==========================================
// 8. ROADMAP TIMELINE TAB
// ==========================================
function renderRoadmapTab() {
  const timeline = document.getElementById('roadmapTimeline');
  if (!timeline) return;

  const currentW = state.profile.currentWeek || 1;

  timeline.innerHTML = CURRICULUM.map((w) => {
    const isCompleted = !!state.logs[`week-${w.week}`];
    const isActive = w.week === currentW;
    const statusClass = isCompleted ? 'completed' : isActive ? 'active' : '';

    return `
      <div class="timeline-item ${statusClass}" onclick="selectWeekFromRoadmap(${w.week})">
        <div class="timeline-dot">${isCompleted ? '✓' : w.week}</div>
        <div class="timeline-card">
          <div class="timeline-card-header">
            <span class="timeline-week-num">Week ${w.week} • ${w.quotient}</span>
            ${isCompleted ? '<span class="badge badge-success">Completed</span>' : isActive ? '<span class="badge badge-primary">Active</span>' : ''}
          </div>
          <h4 class="timeline-card-title">${w.title}</h4>
          <p style="font-size: 0.8rem; color: #666; margin-top: 2px;">${w.skill}</p>
        </div>
      </div>
    `;
  }).join('');
}

function selectWeekFromRoadmap(weekNum) {
  state.profile.currentWeek = weekNum;
  safeSet(STORAGE_KEYS.PROFILE, state.profile);
  renderCurrentWeek();
  switchTab('tab-week');
}

function openBadgeDetailModal(weekNum) {
  const modal = document.getElementById('badgeDetailModal');
  if (!modal) return;
  const weekData = CURRICULUM.find((w) => w.week === weekNum) || CURRICULUM[0];
  const isUnlocked = Boolean(state.logs[`week-${weekNum}`]);

  const weekChip = document.getElementById('badgeModalWeekChip');
  const icon = document.getElementById('badgeModalIcon');
  const title = document.getElementById('badgeModalTitle');
  const quotient = document.getElementById('badgeModalQuotient');
  const status = document.getElementById('badgeModalStatus');
  const desc = document.getElementById('badgeModalDesc');
  const criterionText = document.getElementById('badgeModalCriterionText');

  if (weekChip) weekChip.textContent = `Week ${weekData.week}`;
  if (icon) icon.textContent = weekData.badge.icon;
  if (title) title.textContent = weekData.badge.name;
  if (quotient) quotient.textContent = `${weekData.quotient} Power • ${weekData.skill}`;

  if (status) {
    if (isUnlocked) {
      status.textContent = 'Unlocked ⭐';
      status.className = 'badge-modal-status unlocked';
    } else {
      status.textContent = 'Locked 🔒';
      status.className = 'badge-modal-status';
    }
  }

  if (desc) {
    desc.textContent = weekData.badge.desc || weekData.whyItMatters;
  }

  if (criterionText) {
    if (isUnlocked) {
      const log = state.logs[`week-${weekNum}`];
      const dateStr = log?.completedAt ? new Date(log.completedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : 'Completed';
      criterionText.textContent = `Earned on ${dateStr} with ${log?.earnedPoints || 50} pts!`;
    } else {
      criterionText.textContent = `Complete Week ${weekData.week} (${weekData.title}) activities and Sunday Check-in to earn this badge.`;
    }
  }

  modal.showModal();
}

function closeBadgeDetailModal() {
  const modal = document.getElementById('badgeDetailModal');
  if (modal) modal.close();
}

// ==========================================
// 9. SUNDAY CHECK-IN MODAL & SCORING
// ==========================================
function openSundayCheckin() {
  const weekNum = state.profile.currentWeek || 1;
  const weekData = CURRICULUM.find((w) => w.week === weekNum) || CURRICULUM[0];
  const logKey = `week-${weekNum}`;

  // If already completed, directly open report card preview
  if (state.logs[logKey]) {
    openReportCardModal(weekNum);
    return;
  }

  const modal = document.getElementById('sundayCheckinModal');
  const container = document.getElementById('sundayQuestionnaireForm');
  if (!modal || !container) return;

  const modalTitle = document.getElementById('sundayModalTitle');
  if (modalTitle) {
    modalTitle.textContent = `Week ${weekData.week} Check-in: ${weekData.title}`;
  }

  // Render question form
  container.innerHTML = `
    <p style="font-size: 0.85rem; color: #666; margin-bottom: 14px;">2-minute observation for ${state.profile.childName}.</p>

    ${weekData.sundayQuestions
      .map(
        (q, idx) => `
      <div class="question-block">
        <div class="question-title">${idx + 1}. ${q.text}</div>
        <div class="option-group">
          ${q.options
            .map(
              (opt, oIdx) => `
            <label class="option-label">
              <input type="radio" name="q_${idx}" value="${opt.points}" ${oIdx === 1 ? 'checked' : ''} required>
              <span>${opt.text}</span>
            </label>
          `
            )
            .join('')}
        </div>
      </div>
    `
      )
      .join('')}

    <button type="submit" class="btn btn-primary" style="margin-top: 10px;">
      🎉 Submit & Unlock Sunday Report Card
    </button>
  `;

  modal.showModal();
}

function submitSundayCheckin(e) {
  e.preventDefault();
  const weekNum = state.profile.currentWeek || 1;
  const weekData = CURRICULUM.find((w) => w.week === weekNum) || CURRICULUM[0];

  const form = document.getElementById('sundayQuestionnaireForm');
  const formData = new FormData(form);

  let earnedPoints = 0;
  for (let [key, val] of formData.entries()) {
    earnedPoints += parseInt(val, 10);
  }

  // Update target quotient points and milestone level
  const targetQ = weekData.quotient;
  if (targetQ !== 'ALL') {
    state.milestones[targetQ].points += earnedPoints;
    state.milestones[targetQ].tier = calculateTier(state.milestones[targetQ].points);
    state.milestones[targetQ].level = calculateLevel(state.milestones[targetQ].points);
  } else {
    // Week 20 graduation bonus across all quotients
    Object.keys(state.milestones).forEach((q) => {
      state.milestones[q].points += 40;
      state.milestones[q].tier = calculateTier(state.milestones[q].points);
    });
  }

  // Save log
  const logKey = `week-${weekNum}`;
  state.logs[logKey] = {
    week: weekNum,
    completedAt: new Date().toISOString(),
    earnedPoints: earnedPoints,
    badgeUnlocked: weekData.badge.name,
    badgeIcon: weekData.badge.icon
  };

  // Advance week automatically if not at end
  if (state.profile.currentWeek < 20) {
    state.profile.currentWeek += 1;
  }

  safeSet(STORAGE_KEYS.PROFILE, state.profile);
  safeSet(STORAGE_KEYS.MILESTONES, state.milestones);
  safeSet(STORAGE_KEYS.LOGS, state.logs);

  // Close check-in modal and launch Report Card
  const modal = document.getElementById('sundayCheckinModal');
  if (modal) modal.close();

  renderCurrentWeek();
  renderQuotientsTab();
  openReportCardModal(weekNum);
}

// ==========================================
// 10. SHAREABLE SUNDAY MILESTONE REPORT CARD
// ==========================================
function openReportCardModal(weekNum) {
  const modal = document.getElementById('reportCardModal');
  if (!modal) return;

  generateReportCardCanvas(weekNum);
  modal.showModal();
}

function generateReportCardCanvas(weekNum) {
  const canvas = document.getElementById('reportCardCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  canvas.width = 600;
  canvas.height = 760;

  const weekData = CURRICULUM.find((w) => w.week === weekNum) || CURRICULUM[0];
  const qData = state.milestones[weekData.quotient] || { points: 150, tier: 'Explorer 🔍' };

  // Background Gradient
  const bgGrad = ctx.createLinearGradient(0, 0, 600, 760);
  bgGrad.addColorStop(0, '#ffffff');
  bgGrad.addColorStop(0.5, '#fff5f8');
  bgGrad.addColorStop(1, '#fce4ec');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, 600, 760);

  // Decorative border
  ctx.strokeStyle = '#c2185b';
  ctx.lineWidth = 6;
  ctx.strokeRect(16, 16, 568, 728);

  ctx.strokeStyle = '#f8bbd0';
  ctx.lineWidth = 2;
  ctx.strokeRect(24, 24, 552, 712);

  // Header Title
  ctx.fillStyle = '#c2185b';
  ctx.font = 'bold 22px system-ui, sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('JUNIOR GENIUS CLUB', 300, 70);

  ctx.fillStyle = '#666666';
  ctx.font = '600 13px system-ui, sans-serif';
  ctx.fillText('WEEKLY DEVELOPMENTAL MILESTONE CERTIFICATE', 300, 95);

  // Divider
  ctx.strokeStyle = '#e0e0e0';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(80, 115);
  ctx.lineTo(520, 115);
  ctx.stroke();

  // Child Name & Week
  ctx.fillStyle = '#1a1a1a';
  ctx.font = 'bold 30px system-ui, sans-serif';
  ctx.fillText(`🌟 ${state.profile.childName} 🌟`, 300, 160);

  ctx.fillStyle = '#0277bd';
  ctx.font = 'bold 18px system-ui, sans-serif';
  ctx.fillText(`Week ${weekData.week}: ${weekData.title}`, 300, 195);

  // Badge Container Box
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#fde68a';
  ctx.lineWidth = 2;
  roundRect(ctx, 100, 225, 400, 140, 16, true, true);

  // Badge Icon
  ctx.font = '54px system-ui, sans-serif';
  ctx.fillText(weekData.badge.icon, 300, 285);

  // Badge Name
  ctx.fillStyle = '#92400e';
  ctx.font = 'bold 18px system-ui, sans-serif';
  ctx.fillText(weekData.badge.name, 300, 325);

  ctx.fillStyle = '#6b7280';
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillText(weekData.badge.desc, 300, 348);

  // Quotient Level Box
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1.5;
  roundRect(ctx, 60, 390, 480, 170, 16, true, true);

  ctx.fillStyle = '#c2185b';
  ctx.font = 'bold 16px system-ui, sans-serif';
  ctx.fillText(`Target Quotient: ${weekData.quotient} (${qData.tier})`, 300, 425);

  // 7-Quotient mini indicators
  const qList = ['IQ', 'PQ', 'EQ', 'AQ', 'SQ', 'CQ', 'DQ'];
  qList.forEach((q, i) => {
    const x = 95 + i * 60;
    const y = 475;
    const pts = state.milestones[q] ? state.milestones[q].points : 100;
    const isTarget = q === weekData.quotient;

    ctx.fillStyle = isTarget ? '#c2185b' : '#f3f4f6';
    ctx.beginPath();
    ctx.arc(x, y, 18, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = isTarget ? '#ffffff' : '#374151';
    ctx.font = 'bold 12px system-ui, sans-serif';
    ctx.fillText(q, x, y + 4);

    ctx.fillStyle = '#666';
    ctx.font = '10px system-ui, sans-serif';
    ctx.fillText(`${pts}p`, x, y + 32);
  });

  // Praise Message
  ctx.fillStyle = '#2e7d32';
  ctx.font = 'italic 15px system-ui, sans-serif';
  ctx.fillText(`"Outstanding curiosity, persistence, and growth this week!"`, 300, 600);

  // Date & Watermark
  const dateStr = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  ctx.fillStyle = '#888888';
  ctx.font = '12px system-ui, sans-serif';
  ctx.fillText(`Certified on ${dateStr} • Offline Play & Kids Scroll Companion`, 300, 640);

  ctx.fillStyle = '#c2185b';
  ctx.font = 'bold 13px system-ui, sans-serif';
  ctx.fillText('www.juniorgenius.club • www.offlinekidsgames.com', 300, 680);
}

function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + width - radius, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
  ctx.lineTo(x + width, y + height - radius);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
  ctx.lineTo(x + radius, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

async function shareReportCard() {
  const canvas = document.getElementById('reportCardCanvas');
  if (!canvas) return;

  canvas.toBlob(async (blob) => {
    const file = new File([blob], `juniorgenius-${state.profile.childName}-milestone.png`, { type: 'image/png' });
    const shareText = `Proud parent moment! ${state.profile.childName} just unlocked the ${CURRICULUM[state.profile.currentWeek - 1]?.badge.name || 'Milestone'} on Junior Genius Club! 🧠✨`;

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          files: [file],
          title: 'Junior Genius Milestone',
          text: shareText
        });
      } catch (err) {
        console.warn('Share dismissed:', err);
      }
    } else {
      // Fallback: Direct Download
      downloadReportCard();
      alert('Report Card downloaded! You can now share it with family on WhatsApp or Instagram.');
    }
  });
}

function downloadReportCard() {
  const canvas = document.getElementById('reportCardCanvas');
  if (!canvas) return;
  const link = document.createElement('a');
  link.download = `juniorgenius-${state.profile.childName || 'kid'}-milestone.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
}

// ==========================================
// 11. PROFILE MODAL & TAB CONTROLLER
// ==========================================
function openProfileModal() {
  const modal = document.getElementById('profileModal');
  if (!modal) return;

  const nameInput = document.getElementById('profileChildNameInput');
  if (nameInput) nameInput.value = state.profile.childName;

  selectAgeCardOption(state.profile.ageGroup);
  modal.showModal();
}

function selectAgeCardOption(ageGroup) {
  state.profile.ageGroup = ageGroup;
  document.querySelectorAll('.age-card-option').forEach((el) => {
    if (el.dataset.age === ageGroup) el.classList.add('selected');
    else el.classList.remove('selected');
  });
}

function saveProfile(e) {
  e.preventDefault();
  const nameInput = document.getElementById('profileChildNameInput');
  if (nameInput && nameInput.value.trim()) {
    state.profile.childName = nameInput.value.trim();
  }

  safeSet(STORAGE_KEYS.PROFILE, state.profile);
  renderCurrentWeek();
  renderQuotientsTab();

  const modal = document.getElementById('profileModal');
  if (modal) modal.close();
}

function switchTab(tabId) {
  document.querySelectorAll('.nav-tab').forEach((t) => {
    if (t.dataset.tab === tabId) t.classList.add('active');
    else t.classList.remove('active');
  });

  document.querySelectorAll('.tab-pane').forEach((p) => {
    if (p.id === tabId) p.classList.add('active');
    else p.classList.remove('active');
  });

  // Reset scroll to top on tab switch across both window scroll and app-container shell
  const appContainer = document.querySelector('.app-container');
  if (appContainer) {
    appContainer.scrollTop = 0;
  }
  window.scrollTo(0, 0);

  if (tabId === 'tab-stats') {
    switchStatsSubMode(currentStatsSubMode);
  }
  if (tabId === 'tab-settings') {
    syncMascotUI();
    syncBgmUI();
    syncNotificationUI();
    syncProfileSettingsUI();
  }
  if (tabId === 'tab-roadmap') renderRoadmapTab();
}

// ==========================================
// 12. KIDS SCROLL CONTROLS (MASCOT, BGM & NOTIFICATIONS)
// ==========================================
const MASCOT_KEY = 'kids_scroll_mascot_enabled';
const BGM_KEY = 'kids_scroll_bgm_enabled';
const NOTIFICATION_KEY = 'kids_scroll_notifications_enabled';

function initKidsScrollControls() {
  initMascotControl();
  initBgmControl();
  initNotificationControl();
  syncProfileSettingsUI();
}

function initMascotControl() {
  const toggle = document.getElementById('mascot-toggle');
  if (!toggle) return;

  syncMascotUI();

  toggle.addEventListener('change', (e) => {
    const enabled = e.target.checked;
    localStorage.setItem(MASCOT_KEY, enabled ? 'true' : 'false');
    showBridgeSyncNotice(enabled ? '👦 Companion Mascot enabled' : 'Companion Mascot disabled');
  });
}

function syncMascotUI() {
  const toggle = document.getElementById('mascot-toggle');
  if (!toggle) return;
  const isEnabled = localStorage.getItem(MASCOT_KEY) !== 'false';
  toggle.checked = isEnabled;
}

function initBgmControl() {
  const toggle = document.getElementById('bgm-toggle');
  if (!toggle) return;

  syncBgmUI();

  toggle.addEventListener('change', (e) => {
    const enabled = e.target.checked;
    localStorage.setItem(BGM_KEY, enabled ? 'true' : 'false');
    showBridgeSyncNotice(enabled ? '🎵 Background Music enabled' : 'Background Music paused');
  });
}

function syncBgmUI() {
  const toggle = document.getElementById('bgm-toggle');
  if (!toggle) return;
  const isEnabled = localStorage.getItem(BGM_KEY) !== 'false';
  toggle.checked = isEnabled;
}

function syncProfileSettingsUI() {
  const summaryEl = document.getElementById('settingsChildSummary');
  if (summaryEl && state.profile) {
    const stageStr = state.profile.ageGroup === 'preschooler' ? '3-5+ yrs' : '1.5-3 yrs';
    summaryEl.textContent = `${state.profile.childName} • ${stageStr}`;
  }
}

function initNotificationControl() {
  const toggle = document.getElementById('notification-toggle');
  if (!toggle) return;

  syncNotificationUI();

  toggle.addEventListener('change', async (e) => {
    const checked = e.target.checked;
    const mgr = window.KidsScrollNotifications;
    if (mgr && typeof mgr.setEnabled === 'function') {
      mgr.setEnabled(checked);
    } else {
      localStorage.setItem(NOTIFICATION_KEY, checked ? 'true' : 'false');
    }

    if (checked && 'Notification' in window && Notification.permission === 'default') {
      await requestNotificationPermission();
    }

    syncNotificationUI();
    showBridgeSyncNotice(checked ? '🔔 Notifications enabled' : 'Notifications disabled');
  });
}

function syncNotificationUI() {
  const toggle = document.getElementById('notification-toggle');
  const badge = document.getElementById('notification-perm-badge');
  const permCta = document.getElementById('notification-perm-cta');
  const nextText = document.getElementById('notification-next-text');

  const mgr = window.KidsScrollNotifications;
  const isEnabled = mgr && typeof mgr.isEnabled === 'function' ? mgr.isEnabled() : (localStorage.getItem(NOTIFICATION_KEY) !== 'false');

  if (toggle) toggle.checked = isEnabled;

  const perm = ('Notification' in window) ? Notification.permission : 'unsupported';

  if (badge) {
    if (!isEnabled) {
      badge.textContent = '⏸️ Notifications Paused';
      badge.className = 'perm-badge';
    } else if (perm === 'granted') {
      badge.textContent = '✅ Notifications Active';
      badge.className = 'perm-badge active';
    } else if (perm === 'denied') {
      badge.textContent = '❌ Blocked in Browser Settings';
      badge.className = 'perm-badge blocked';
    } else {
      badge.textContent = '⚠️ Permission Needed';
      badge.className = 'perm-badge';
    }
  }

  if (permCta) {
    permCta.style.display = (isEnabled && perm === 'default') ? 'block' : 'none';
  }

  if (nextText) {
    if (!isEnabled) {
      nextText.textContent = 'Notifications are turned off.';
    } else {
      const stage = (state.profile && state.profile.ageGroup === 'preschooler') ? 'Preschool (3-5)' : 'Toddler (1.5-3)';
      nextText.textContent = `Bedtime Story & Routine Prompt (7:30 PM) • ${stage}`;
    }
  }
}

async function requestNotificationPermission() {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    alert('Notifications are not supported on this browser.');
    return;
  }
  try {
    const mgr = window.KidsScrollNotifications;
    if (mgr && typeof mgr.requestPermission === 'function') {
      await mgr.requestPermission();
    } else {
      await Notification.requestPermission();
    }
    syncNotificationUI();
  } catch (err) {
    console.error('Error requesting notification permission:', err);
  }
}

async function sendTestNotification() {
  const mgr = window.KidsScrollNotifications;
  if (mgr && typeof mgr.dispatchTestNotification === 'function') {
    const res = await mgr.dispatchTestNotification();
    if (res) {
      showBridgeSyncNotice('🧪 Test notification dispatched!');
    } else {
      alert('Could not dispatch notification. Please ensure notification permission is granted.');
    }
  } else {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('🌟 Kids Scroll Parent App', {
        body: 'Bedtime stories and learning games are ready for your little one!',
        icon: '/assets/icons/icon-192x192.png'
      });
      showBridgeSyncNotice('🧪 Test notification sent!');
    } else {
      alert('Please enable notifications first!');
    }
  }
}

// ==========================================
// 13. HASH ROUTING & INITIALIZATION
// ==========================================
function initHashRouting() {
  function handleRoute() {
    const hash = (window.location.hash || '').toLowerCase();
    if (hash === '#stats' || hash === '#stat') {
      switchTab('tab-stats');
    } else if (hash === '#quotients' || hash === '#quotient') {
      switchTab('tab-stats');
      switchStatsSubMode('quotients');
    } else if (hash === '#games' || hash === '#game') {
      switchTab('tab-stats');
      switchStatsSubMode('games');
    } else if (hash === '#stories' || hash === '#story') {
      switchTab('tab-stats');
      switchStatsSubMode('stories');
    } else if (hash === '#settings' || hash === '#setting' || hash === '#controls') {
      switchTab('tab-settings');
    } else if (hash === '#roadmap' || hash === '#curriculum') {
      switchTab('tab-roadmap');
    } else if (hash === '#week' || hash === '#mission') {
      switchTab('tab-week');
    }
  }

  window.addEventListener('hashchange', handleRoute);
  if (window.location.hash) {
    handleRoute();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  // Bottom Nav Listeners
  document.querySelectorAll('.nav-tab').forEach((tab) => {
    tab.addEventListener('click', () => switchTab(tab.dataset.tab));
  });

  // Onboarding / Profile setup
  const profileForm = document.getElementById('profileForm');
  if (profileForm) profileForm.addEventListener('submit', saveProfile);

  const checkinForm = document.getElementById('sundayQuestionnaireForm');
  if (checkinForm) checkinForm.addEventListener('submit', submitSundayCheckin);

  // Standalone PWA / TWA detection to hide web-only footer in app mode
  checkAppModeAndHideFooter();

  // Initial Renders
  renderCurrentWeek();
  renderQuotientsTab();
  initTelemetryBridge();
  initKidsScrollControls();
  initHashRouting();
  initAppTour();

  // Register Service Worker
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/service-worker.js').catch((err) => {
      console.warn('SW registration failed:', err);
    });
  }

  // Backdrop click dismiss for all modals
  ['appTourModal', 'sundayCheckinModal', 'reportCardModal', 'profileModal', 'badgeDetailModal'].forEach((id) => {
    const dlg = document.getElementById(id);
    if (dlg) {
      dlg.addEventListener('click', (e) => {
        const rect = dlg.getBoundingClientRect();
        const isInDialog = (
          rect.top <= e.clientY &&
          e.clientY <= rect.top + rect.height &&
          rect.left <= e.clientX &&
          e.clientX <= rect.left + rect.width
        );
        if (!isInDialog) {
          if (id === 'appTourModal') {
            closeAppTourModal();
          } else if (id === 'badgeDetailModal') {
            closeBadgeDetailModal();
          } else {
            dlg.close();
          }
        }
      });
    }
  });
});

function checkAppModeAndHideFooter() {
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches ||
                       window.matchMedia('(display-mode: fullscreen)').matches ||
                       window.matchMedia('(display-mode: minimal-ui)').matches ||
                       window.navigator.standalone === true ||
                       document.referrer.includes('android-app://') ||
                       new URLSearchParams(window.location.search).get('source') === 'twa' ||
                       new URLSearchParams(window.location.search).get('utm_source') === 'twa';
  if (isStandalone) {
    document.documentElement.classList.add('is-standalone');
    document.body.classList.add('is-standalone');
    const footer = document.querySelector('.parent-footer');
    if (footer) footer.style.display = 'none';

    // Disable pinch-to-zoom strictly in standalone PWA / TWA
    const metaViewport = document.querySelector('meta[name="viewport"]');
    if (metaViewport) {
      metaViewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover');
    }

    document.addEventListener('touchstart', (e) => {
      if (e.touches && e.touches.length > 1) {
        e.preventDefault();
      }
    }, { passive: false });

    document.addEventListener('touchmove', (e) => {
      if (e.touches && e.touches.length > 1) {
        e.preventDefault();
      }
    }, { passive: false });

    document.addEventListener('gesturestart', (e) => {
      e.preventDefault();
    });
  }
}

/* ========================================================= */
/* ONBOARDING & APP FEATURE TOUR MODAL CONTROLLER            */
/* ========================================================= */
let currentTourSlide = 0;
const TOTAL_TOUR_SLIDES = 3;

function openAppTourModal() {
  const modal = document.getElementById('appTourModal');
  if (!modal) return;
  goToTourSlide(0);
  if (typeof modal.showModal === 'function') {
    modal.showModal();
  } else {
    modal.setAttribute('open', '');
  }
}

function closeAppTourModal() {
  const modal = document.getElementById('appTourModal');
  if (modal) {
    if (typeof modal.close === 'function') {
      modal.close();
    } else {
      modal.removeAttribute('open');
    }
  }
  try {
    localStorage.setItem('kids_scroll_parent_onboarded', 'true');
  } catch (e) {
    console.warn('Failed saving onboarding state:', e);
  }
}

function updateTourUI() {
  const slides = document.querySelectorAll('.tour-slide');
  const dots = document.querySelectorAll('.tour-dot');
  const stepPill = document.getElementById('tourStepPill');
  const prevBtn = document.getElementById('tourPrevBtn');
  const nextBtn = document.getElementById('tourNextBtn');
  const skipBtn = document.getElementById('tourSkipBtn');

  slides.forEach((slide, idx) => {
    slide.classList.toggle('active', idx === currentTourSlide);
  });

  dots.forEach((dot, idx) => {
    dot.classList.toggle('active', idx === currentTourSlide);
  });

  if (stepPill) {
    stepPill.textContent = `Step ${currentTourSlide + 1} of ${TOTAL_TOUR_SLIDES}`;
  }

  if (prevBtn) {
    prevBtn.style.display = currentTourSlide === 0 ? 'none' : 'inline-block';
  }

  if (skipBtn) {
    skipBtn.style.display = currentTourSlide === 0 ? 'inline-block' : 'none';
  }

  if (nextBtn) {
    if (currentTourSlide === TOTAL_TOUR_SLIDES - 1) {
      nextBtn.textContent = 'Get Started 🚀';
    } else {
      nextBtn.textContent = 'Next →';
    }
  }
}

function nextTourSlide() {
  if (currentTourSlide < TOTAL_TOUR_SLIDES - 1) {
    currentTourSlide++;
    updateTourUI();
  } else {
    closeAppTourModal();
  }
}

function prevTourSlide() {
  if (currentTourSlide > 0) {
    currentTourSlide--;
    updateTourUI();
  }
}

function goToTourSlide(index) {
  if (index >= 0 && index < TOTAL_TOUR_SLIDES) {
    currentTourSlide = index;
    updateTourUI();
  }
}

function initAppTour() {
  try {
    const hasOnboarded = localStorage.getItem('kids_scroll_parent_onboarded');
    if (!hasOnboarded) {
      setTimeout(() => {
        openAppTourModal();
      }, 400);
    }
  } catch (e) {
    console.warn('Error checking onboarding state:', e);
  }
}

function launchKidsScrollTarget(path) {
  const isAndroid = /Android/i.test(navigator.userAgent);
  const cleanPath = path && path.startsWith('/') ? path : `/${path || ''}`;
  const playStoreFallback = encodeURIComponent('https://play.google.com/store/apps/details?id=com.kidsscroll.www.twa');

  if (isAndroid) {
    // Android Intent URI: Launches Kids Scroll TWA app if installed, fallbacks to Google Play Store if not installed
    window.location.href = `intent://www.offlinekidsgames.com${cleanPath}#Intent;scheme=https;package=com.kidsscroll.www.twa;S.browser_fallback_url=${playStoreFallback};end`;
  } else {
    // Desktop/iOS fallback: open web page
    window.open(`https://www.offlinekidsgames.com${cleanPath}`, '_blank', 'noopener,noreferrer');
  }
}

function launchKidsScrollApp() {
  launchKidsScrollTarget('/launch/index.html');
}

// Global functions exposed to inline HTML triggers
window.switchTab = switchTab;
window.switchStatsSubMode = switchStatsSubMode;
window.setGameFilterMode = setGameFilterMode;
window.setStoryFilterMode = setStoryFilterMode;
window.captureAndShare = captureAndShare;
window.toggleActivity = toggleActivity;
window.openSundayCheckin = openSundayCheckin;
window.openProfileModal = openProfileModal;
window.selectAgeCardOption = selectAgeCardOption;
window.shareReportCard = shareReportCard;
window.downloadReportCard = downloadReportCard;
window.openBadgeDetailModal = openBadgeDetailModal;
window.closeBadgeDetailModal = closeBadgeDetailModal;
window.selectWeekFromRoadmap = selectWeekFromRoadmap;
window.toggleQuotientAccordion = toggleQuotientAccordion;
window.requestStatsFromBridge = requestStatsFromBridge;
window.requestNotificationPermission = requestNotificationPermission;
window.sendTestNotification = sendTestNotification;
window.openAppTourModal = openAppTourModal;
window.closeAppTourModal = closeAppTourModal;
window.nextTourSlide = nextTourSlide;
window.prevTourSlide = prevTourSlide;
window.goToTourSlide = goToTourSlide;
window.launchKidsScrollApp = launchKidsScrollApp;
window.launchKidsScrollTarget = launchKidsScrollTarget;

