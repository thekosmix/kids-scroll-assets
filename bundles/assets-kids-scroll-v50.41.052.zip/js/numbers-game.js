/**
 * Numbers Trace Game
 * A tracing game for toddlers to learn numbers and counting.
 */

class NumbersGame {
    constructor() {
        this.canvas = document.getElementById('trace-canvas');
        this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
        this.emojiContainer = document.getElementById('emoji-container');
        
        this.isDrawing = false;
        this.points = [];
        this.currentNumber = 1;
        this.totalNumberPixels = 0;
        this.hitMap = null;
        this.hue = 200; // Start with blue-ish
        this.inactivityTimer = null;
        this.isFirstLoad = true;
        
        this.emojis = ['🐶', '🐱', '🐹', '🐰', '🦊', '🐻', '🐼', '🐘', '🦁', '🐯', '🦒', '🦓', '🍎', '🍓', '🍌', '🍇', '⚽', '🏀', '🚗', '🚀'];
        this.emojiNames = ['dog', 'cat', 'hamster', 'rabbit', 'fox', 'bear', 'panda', 'elephant', 'lion', 'tiger', 'giraffe', 'zebra', 'apple', 'strawberry', 'banana', 'grapes', 'ball', 'basketball', 'car', 'rocket'];

        this.init();
    }

    init() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        
        // Touch events
        this.canvas.addEventListener('touchstart', (e) => this.handleStart(e), { passive: false });
        this.canvas.addEventListener('touchmove', (e) => this.handleMove(e), { passive: false });
        this.canvas.addEventListener('touchend', () => this.handleEnd());
        this.canvas.addEventListener('touchcancel', () => this.handleEnd());
        
        // Mouse events
        this.canvas.addEventListener('mousedown', (e) => this.handleStart(e));
        this.canvas.addEventListener('mousemove', (e) => this.handleMove(e));
        this.canvas.addEventListener('mouseup', () => this.handleEnd());

        this.loadNumber();
        this.resetInactivityTimer();

        // Startup guide
        if (this.isFirstLoad && typeof showStartupGuide === 'function') {
            this.isFirstLoad = false;
            const rect = this.canvas.getBoundingClientRect();
            showStartupGuide("Draw over the number to see the magic!", {
                type: 'ghost-trace',
                startX: (rect.left + rect.width * 0.3) + 'px',
                startY: (rect.top + rect.height * 0.3) + 'px',
                endX: (rect.left + rect.width * 0.7) + 'px',
                endY: (rect.top + rect.height * 0.7) + 'px'
            });
        }
    }

    resetInactivityTimer() {
        if (this.inactivityTimer) clearTimeout(this.inactivityTimer);
        this.inactivityTimer = setTimeout(() => {
            if (!this.isDrawing && typeof ghostHand !== 'undefined') {
                const rect = this.canvas.getBoundingClientRect();
                ghostHand.show('ghost-trace', 
                    (rect.left + rect.width * 0.3) + 'px',
                    (rect.top + rect.height * 0.3) + 'px',
                    (rect.left + rect.width * 0.7) + 'px',
                    (rect.top + rect.height * 0.7) + 'px'
                );
            }
        }, 7000);
    }

    resizeCanvas() {
        const parent = this.canvas.parentElement;
        if (!parent) return;
        const rect = parent.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
        this.loadNumber();
    }

    loadNumber() {
        this.emojiContainer.innerHTML = '';
        const currentEmoji = this.emojis[this.currentNumber - 1];
        this.startTime = Date.now();
        this.isWon = false;
        
        for (let i = 0; i < this.currentNumber; i++) {
            const emojiEl = document.createElement('span');
            emojiEl.textContent = currentEmoji;
            // More dynamic font size calculation to fill the space
            let size;
            if (this.currentNumber === 1) size = '7rem';
            else if (this.currentNumber <= 5) size = '5rem';
            else if (this.currentNumber <= 10) size = '4rem';
            else if (this.currentNumber <= 15) size = '3rem';
            else size = '2.5rem';
            
            emojiEl.style.fontSize = size;
            emojiEl.className = 'bounce-in';
            this.emojiContainer.appendChild(emojiEl);
        }
        
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // 1. Draw the guide number with lower opacity so we can distinguish it from user drawing
        this.ctx.font = `bold ${this.canvas.height * 0.8}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.15)'; 
        this.ctx.fillText(this.currentNumber.toString(), this.canvas.width / 2, this.canvas.height / 2);
        
        this.captureHitMap();
    }

    captureHitMap() {
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;
        this.hitMap = new Uint8Array(data.length / 4);
        let count = 0;

        for (let i = 0; i < data.length; i += 4) {
            const alpha = data[i + 3];
            if (alpha > 0) {
                this.hitMap[i / 4] = 1;
                count++;
            }
        }
        this.totalNumberPixels = count;
    }

    getPos(e) {
        const rect = this.canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
            x: (clientX - rect.left),
            y: (clientY - rect.top)
        };
    }

    handleStart(e) {
        if (this.isWon) return;
        if (typeof ghostHand !== 'undefined') ghostHand.stop();
        this.resetInactivityTimer();
        e.preventDefault();
        this.isDrawing = true;
        const pos = this.getPos(e);
        this.points = [pos];
    }

    handleMove(e) {
        if (!this.isDrawing) return;
        this.resetInactivityTimer();
        e.preventDefault();
        const pos = this.getPos(e);
        
        this.hue += 2;
        this.ctx.lineJoin = 'round';
        this.ctx.lineCap = 'round';
        this.ctx.lineWidth = 50;
        this.ctx.strokeStyle = `hsl(${this.hue % 360}, 85%, 55%)`; 
        
        this.ctx.beginPath();
        this.ctx.moveTo(this.points[this.points.length - 1].x, this.points[this.points.length - 1].y);
        this.ctx.lineTo(pos.x, pos.y);
        this.ctx.stroke();

        if (Math.random() > 0.7) {
            this.ctx.fillStyle = 'white';
            this.ctx.beginPath();
            this.ctx.arc(pos.x + (Math.random()-0.5)*40, pos.y + (Math.random()-0.5)*40, 2 + Math.random()*4, 0, Math.PI*2);
            this.ctx.fill();
        }
        
        this.points.push(pos);
    }

    handleEnd() {
        if (!this.isDrawing) return;
        this.isDrawing = false;
        this.checkProgress();
    }

    checkProgress() {
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;
        let hits = 0;

        // Sample every pixel in the hitMap
        for (let i = 0; i < this.hitMap.length; i++) {
            if (this.hitMap[i] === 1) {
                const a = data[i * 4 + 3];
                // Only count if alpha is high (user's drawing, not the guide number)
                if (a > 200) hits++;
            }
        }
        
        const progress = (hits / this.totalNumberPixels) * 100;
        if (progress >= 80) {
            this.win();
        }
    }

    win() {
        if (this.isWon) return;
        this.isWon = true;
        this.isDrawing = false;

        if (typeof vibrateSuccess === 'function') vibrateSuccess();
        const duration = (Date.now() - this.startTime) / 1000;
        if (typeof recordGameStats === 'function') {
            recordGameStats('learn_numbers', duration, { avgTime: duration });
        }

        if (typeof speakText === 'function') {
            const name = this.emojiNames[this.currentNumber - 1];
            const pluralName = (this.currentNumber > 1 && !name.endsWith('s')) ? `${name}s` : name;
            speakText(`${this.currentNumber} ${pluralName}`);
        }
        
        if (typeof triggerCelebration === 'function') {
            triggerCelebration(false);
        }

        setTimeout(() => {
            this.nextNumber();
        }, 3000);
    }

    nextNumber() {
        this.currentNumber = (this.currentNumber % 20) + 1;
        this.loadNumber();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new NumbersGame();
});
