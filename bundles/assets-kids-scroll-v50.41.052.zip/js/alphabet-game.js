/**
 * Alphabet Trace Game
 * A tracing game for toddlers to learn letters and words.
 */

class AlphabetGame {
    constructor() {
        this.canvas = document.getElementById('trace-canvas');
        this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
        this.topHalf = document.getElementById('top-half');
        this.emojiDisplay = document.getElementById('emoji-display');
        this.wordDisplay = document.getElementById('word-display');
        
        this.isDrawing = false;
        this.points = [];
        this.currentLetterIndex = 0;
        this.totalLetterPixels = 0;
        this.hitMap = null;
        this.hue = 0;
        this.inactivityTimer = null;
        this.isFirstLoad = true;
        
        this.alphabet = [
            { letter: 'A', emoji: '🍎', word: 'Apple' },
            { letter: 'B', emoji: '⚽', word: 'Ball' },
            { letter: 'C', emoji: '🐱', word: 'Cat' },
            { letter: 'D', emoji: '🐶', word: 'Dog' },
            { letter: 'E', emoji: '🐘', word: 'Elephant' },
            { letter: 'F', emoji: '🐟', word: 'Fish' },
            { letter: 'G', emoji: '🍇', word: 'Grapes' },
            { letter: 'H', emoji: '🎩', word: 'Hat' },
            { letter: 'I', emoji: '🍦', word: 'Ice Cream' },
            { letter: 'J', emoji: '🧃', word: 'Juice' },
            { letter: 'K', emoji: '🪁', word: 'Kite' },
            { letter: 'L', emoji: '🦁', word: 'Lion' },
            { letter: 'M', emoji: '🐒', word: 'Monkey' },
            { letter: 'N', emoji: '👃', word: 'Nose' },
            { letter: 'O', emoji: '🍊', word: 'Orange' },
            { letter: 'P', emoji: '🐷', word: 'Pig' },
            { letter: 'Q', emoji: '👸', word: 'Queen' },
            { letter: 'R', emoji: '🐰', word: 'Rabbit' },
            { letter: 'S', emoji: '☀️', word: 'Sun' },
            { letter: 'T', emoji: '🐯', word: 'Tiger' },
            { letter: 'U', emoji: '☂️', word: 'Umbrella' },
            { letter: 'V', emoji: '🎻', word: 'Violin' },
            { letter: 'W', emoji: '🐳', word: 'Whale' },
            { letter: 'X', emoji: '🪗', word: 'Xylophone' },
            { letter: 'Y', emoji: '🪀', word: 'Yo-yo' },
            { letter: 'Z', emoji: '🦓', word: 'Zebra' }
        ];

        this.init();
    }

    init() {
        this.resizeCanvas();
        window.addEventListener('resize', () => this.resizeCanvas());
        
        // Touch events
        this.canvas.addEventListener('touchstart', (e) => this.handleStart(e), { passive: false });
        this.canvas.addEventListener('touchmove', (e) => this.handleMove(e), { passive: false });
        this.canvas.addEventListener('touchend', () => this.handleEnd());
        this.canvas.addEventListener('touchcancel', () => this.handleEnd());
        
        // Mouse events
        this.canvas.addEventListener('mousedown', (e) => this.handleStart(e));
        this.canvas.addEventListener('mousemove', (e) => this.handleMove(e));
        this.canvas.addEventListener('mouseup', () => this.handleEnd());

        this.loadLetter();
        this.resetInactivityTimer();

        // Startup guide
        if (this.isFirstLoad && typeof showStartupGuide === 'function') {
            this.isFirstLoad = false;
            const rect = this.canvas.getBoundingClientRect();
            showStartupGuide("Draw over the letters to see the magic!", {
                type: 'ghost-trace',
                startX: (rect.left + rect.width * 0.3) + 'px',
                startY: (rect.top + rect.height * 0.3) + 'px',
                endX: (rect.left + rect.width * 0.7) + 'px',
                endY: (rect.top + rect.height * 0.7) + 'px'
            });
        }
    }

    resetInactivityTimer() {
        if (this.inactivityTimer) clearTimeout(this.inactivityTimer);
        this.inactivityTimer = setTimeout(() => {
            if (!this.isDrawing && typeof ghostHand !== 'undefined') {
                const rect = this.canvas.getBoundingClientRect();
                ghostHand.show('ghost-trace', 
                    (rect.left + rect.width * 0.3) + 'px',
                    (rect.top + rect.height * 0.3) + 'px',
                    (rect.left + rect.width * 0.7) + 'px',
                    (rect.top + rect.height * 0.7) + 'px'
                );
            }
        }, 7000);
    }

    resizeCanvas() {
        const parent = this.canvas.parentElement;
        if (!parent) return;
        const rect = parent.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
        this.loadLetter();
    }

    loadLetter() {
        const item = this.alphabet[this.currentLetterIndex];
        this.emojiDisplay.textContent = item.emoji;
        this.emojiDisplay.className = 'bounce-in';
        setTimeout(() => this.emojiDisplay.classList.remove('bounce-in'), 500);
        this.wordDisplay.textContent = ""; 
        this.startTime = Date.now();
        this.isWon = false;
        
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // 1. Draw the guide letter with lower opacity so we can distinguish it from user drawing
        this.ctx.font = `bold ${this.canvas.height * 0.7}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.15)'; 
        this.ctx.fillText(item.letter, this.canvas.width / 2, this.canvas.height / 2);
        
        // 2. Capture the "Hit Map"
        this.captureHitMap();
    }

    captureHitMap() {
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;
        this.hitMap = new Uint8Array(data.length / 4);
        let count = 0;

        for (let i = 0; i < data.length; i += 4) {
            const alpha = data[i + 3];
            if (alpha > 0) {
                this.hitMap[i / 4] = 1;
                count++;
            }
        }
        this.totalLetterPixels = count;
    }

    getPos(e) {
        const rect = this.canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
            x: (clientX - rect.left),
            y: (clientY - rect.top)
        };
    }

    handleStart(e) {
        if (this.isWon) return;
        if (typeof ghostHand !== 'undefined') ghostHand.stop();
        this.resetInactivityTimer();
        this.isDrawing = true;
        const pos = this.getPos(e);
        this.points = [pos];
    }

    handleMove(e) {
        if (!this.isDrawing) return;
        this.resetInactivityTimer();
        const pos = this.getPos(e);
        
        this.hue += 2;
        this.ctx.lineJoin = 'round';
        this.ctx.lineCap = 'round';
        this.ctx.lineWidth = 45;
        this.ctx.strokeStyle = `hsl(${this.hue % 360}, 80%, 60%)`; 
        
        this.ctx.beginPath();
        this.ctx.moveTo(this.points[this.points.length - 1].x, this.points[this.points.length - 1].y);
        this.ctx.lineTo(pos.x, pos.y);
        this.ctx.stroke();

        // Sparkles
        if (Math.random() > 0.7) {
            this.ctx.fillStyle = 'white';
            this.ctx.beginPath();
            this.ctx.arc(pos.x + (Math.random()-0.5)*40, pos.y + (Math.random()-0.5)*40, 3 + Math.random()*5, 0, Math.PI*2);
            this.ctx.fill();
        }
        
        this.points.push(pos);
    }

    handleEnd() {
        if (!this.isDrawing) return;
        this.isDrawing = false;
        this.checkProgress();
    }

    checkProgress() {
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;
        let hits = 0;

        // Sample every pixel in the hitMap
        for (let i = 0; i < this.hitMap.length; i++) {
            if (this.hitMap[i] === 1) {
                const a = data[i * 4 + 3];
                // Only count if alpha is high (user's drawing, not the guide letter)
                if (a > 200) { 
                    hits++;
                }
            }
        }
        
        const progress = (hits / this.totalLetterPixels) * 100;
        if (progress >= 80) {
            this.win();
        }
    }

    win() {
        if (this.isWon) return;
        this.isWon = true;
        this.isDrawing = false;
        
        if (typeof vibrateSuccess === 'function') vibrateSuccess();
        const duration = (Date.now() - this.startTime) / 1000;
        if (typeof recordGameStats === 'function') {
            recordGameStats('alphabet-trace', duration, { avgTime: duration });
        }

        const item = this.alphabet[this.currentLetterIndex];
        this.wordDisplay.textContent = item.word;
        this.wordDisplay.classList.add('bounce-in');
        
        if (typeof speakText === 'function') {
            speakText(`${item.letter} for ${item.word}`);
        }
        
        if (typeof triggerCelebration === 'function') {
            triggerCelebration(false);
        }

        setTimeout(() => {
            this.wordDisplay.classList.remove('bounce-in');
            this.nextLetter();
        }, 3500);
    }

    nextLetter() {
        this.currentLetterIndex = (this.currentLetterIndex + 1) % this.alphabet.length;
        this.loadLetter();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new AlphabetGame();
});
