const ITEMS_DATA = [
    { emoji: '✈️', type: 'air', name: 'Airplane' },
    { emoji: '🚁', type: 'air', name: 'Helicopter' },
    { emoji: '🦅', type: 'air', name: 'Eagle' },
    { emoji: '🦋', type: 'air', name: 'Butterfly' },
    { emoji: '🎈', type: 'air', name: 'Balloon' },
    { emoji: '🐟', type: 'sea', name: 'Fish' },
    { emoji: '🐬', type: 'sea', name: 'Dolphin' },
    { emoji: '🐳', type: 'sea', name: 'Whale' },
    { emoji: '⛵', type: 'sea', name: 'Boat' },
    { emoji: '🐙', type: 'sea', name: 'Octopus' },
    { emoji: '🐘', type: 'land', name: 'Elephant' },
    { emoji: '🦁', type: 'land', name: 'Lion' },
    { emoji: '🚗', type: 'land', name: 'Car' },
    { emoji: '🚲', type: 'land', name: 'Bicycle' },
    { emoji: '🐕', type: 'land', name: 'Dog' }
];

let remainingItems = [];
let sortedCount = 0;
let roundStartTime = 0;
let isDragging = false;
let draggedElement = null;
let startX, startY, initialX, initialY;
const itemsContainer = document.getElementById('items-container');
const zones = document.querySelectorAll('.zone');

let totalItems = 3;

function initGame() {
    itemsContainer.innerHTML = '';
    document.querySelectorAll('.sorted').forEach(el => el.remove());
    sortedCount = 0;
    roundStartTime = Date.now();
    
    const isLandscape = window.matchMedia('(orientation: landscape)').matches;
    const countPerType = isLandscape ? 2 : 1;
    totalItems = countPerType * 3;

    const airItems = [...ITEMS_DATA.filter(i => i.type === 'air')].sort(() => Math.random() - 0.5);
    const seaItems = [...ITEMS_DATA.filter(i => i.type === 'sea')].sort(() => Math.random() - 0.5);
    const landItems = [...ITEMS_DATA.filter(i => i.type === 'land')].sort(() => Math.random() - 0.5);
    
    remainingItems = [];
    for (let i = 0; i < countPerType; i++) {
        remainingItems.push(airItems[i], seaItems[i], landItems[i]);
    }
    remainingItems.sort(() => Math.random() - 0.5);
    
    spawnItems();
}

function spawnItems() {
    remainingItems.forEach(item => {
        const el = document.createElement('div');
        el.className = 'draggable-item';
        el.textContent = item.emoji;
        el.dataset.type = item.type;
        el.dataset.name = item.name;
        
        el.addEventListener('touchstart', handleDragStart, {passive: false});
        el.addEventListener('touchmove', handleDragMove, {passive: false});
        el.addEventListener('touchend', handleDragEnd);
        el.addEventListener('touchcancel', handleDragEnd);
        el.addEventListener('mousedown', handleDragStart);
        
        itemsContainer.appendChild(el);
    });

    if (!window.hasSpokenIntro) {
        window.hasSpokenIntro = true;
        if (typeof speakText === 'function') {
            speakText("Sort the items into the sky, ocean, or land");
        }
        if (typeof showStartupGuide === 'function') {
            setTimeout(() => {
                const el = itemsContainer.children[0];
                if (el) {
                    const rect = el.getBoundingClientRect();
                    const targetZone = document.querySelector(`.zone[data-type="${el.dataset.type}"]`);
                    if (targetZone) {
                        const targetRect = targetZone.getBoundingClientRect();
                        showStartupGuide('Drag the item to the correct place!', {
                            type: 'ghost-swipe',
                            startX: rect.left + rect.width/2 + 'px',
                            startY: rect.top + rect.height/2 + 'px',
                            endX: targetRect.left + targetRect.width/2 + 'px',
                            endY: targetRect.top + targetRect.height/2 + 'px'
                        });
                    }
                }
            }, 2500);
        }
    }
}

document.addEventListener('mousemove', handleDragMove);
document.addEventListener('mouseup', handleDragEnd);

function handleDragStart(e) {
    if (e.target.classList.contains('sorted')) return;
    if (e.type === 'touchstart') e.preventDefault();
    if (typeof ghostHand !== 'undefined') ghostHand.stop();
    
    isDragging = true;
    draggedElement = e.target;
    
    const clientX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
    const clientY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
    
    if (typeof speakText === 'function') speakText(draggedElement.dataset.name);
    
    const rect = draggedElement.getBoundingClientRect();
    initialX = rect.left;
    initialY = rect.top;
    startX = clientX;
    startY = clientY;
    
    draggedElement.classList.add('dragging');
    draggedElement.style.left = initialX + 'px';
    draggedElement.style.top = initialY + 'px';
}

function handleDragMove(e) {
    if (!isDragging || !draggedElement) return;
    e.preventDefault();
    
    const clientX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
    const clientY = e.type.includes('mouse') ? e.clientY : e.touches[0].clientY;
    
    const dx = clientX - startX;
    const dy = clientY - startY;
    
    draggedElement.style.left = (initialX + dx) + 'px';
    draggedElement.style.top = (initialY + dy) + 'px';
    
    zones.forEach(zone => {
        const rect = zone.getBoundingClientRect();
        if (clientX > rect.left && clientX < rect.right && clientY > rect.top && clientY < rect.bottom) {
            zone.classList.add('highlight');
        } else {
            zone.classList.remove('highlight');
        }
    });
}

function handleDragEnd(e) {
    if (!isDragging || !draggedElement) return;
    isDragging = false;
    
    const clientX = e.type.includes('mouse') ? e.clientX : e.changedTouches[0].clientX;
    const clientY = e.type.includes('mouse') ? e.clientY : e.changedTouches[0].clientY;
    
    let targetZone = null;
    zones.forEach(zone => {
        zone.classList.remove('highlight');
        const rect = zone.getBoundingClientRect();
        if (clientX > rect.left && clientX < rect.right && clientY > rect.top && clientY < rect.bottom) {
            targetZone = zone;
        }
    });
    
    const expectedType = draggedElement.dataset.type;
    
    // Magnetic pull
    if (!targetZone) {
        const itemRect = draggedElement.getBoundingClientRect();
        const itemCenter = { x: itemRect.left + itemRect.width/2, y: itemRect.top + itemRect.height/2 };
        
        const correctZone = document.querySelector(`.zone[data-type="${expectedType}"]`);
        if (correctZone) {
            const zRect = correctZone.getBoundingClientRect();
            if (Math.hypot(itemCenter.x - (zRect.left + zRect.width/2), itemCenter.y - (zRect.top + zRect.height/2)) < 150) {
                targetZone = correctZone;
            }
        }
    }
    
    if (targetZone && targetZone.dataset.type === expectedType) {
        handleSuccessDrop(targetZone);
    } else {
        if (targetZone && typeof speakText === 'function') speakText("Oops! Try another place.");
        draggedElement.style.transition = 'all 0.3s ease';
        draggedElement.style.left = initialX + 'px';
        draggedElement.style.top = initialY + 'px';
        setTimeout(() => {
            if (draggedElement) draggedElement.style.transition = 'transform 0.1s';
        }, 300);
    }
}

function handleSuccessDrop(zone) {
    if (typeof speakText === 'function') {
        speakText("Good job!");
    }
    
    createParticles(draggedElement);
    
    draggedElement.classList.remove('dragging');
    draggedElement.classList.add('sorted');
    draggedElement.style.transition = 'none';
    draggedElement.style.position = 'static';
    
    // Move to zone, which uses flex column with align-items: flex-end
    zone.appendChild(draggedElement);
    
    draggedElement = null;
    sortedCount++;
    
    if (sortedCount >= totalItems) {
        const timeTaken = (Date.now() - roundStartTime) / 1000;
        if (typeof recordGameStats === 'function') {
            recordGameStats('land-sea-air', timeTaken, { avgTime: timeTaken / totalItems });
        }
        
        setTimeout(() => {
            if (typeof triggerCelebration === 'function') triggerCelebration(true);
            setTimeout(initGame, 3000);
        }, 500);
    }
}

function createParticles(element) {
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const colors = ['#FFD700', '#FF8C00', '#FFF', '#87CEFA'];
    
    for (let i=0; i<10; i++) {
        const p = document.createElement('div');
        p.className = 'success-particles';
        p.style.width = '10px';
        p.style.height = '10px';
        p.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        p.style.borderRadius = '50%';
        p.style.position = 'fixed';
        p.style.left = x + 'px';
        p.style.top = y + 'px';
        p.style.zIndex = 1001;
        
        document.body.appendChild(p);
        
        const angle = Math.random() * Math.PI * 2;
        const velocity = 50 + Math.random() * 100;
        const tx = Math.cos(angle) * velocity;
        const ty = Math.sin(angle) * velocity;
        
        p.animate([
            { transform: 'translate(0,0) scale(1)', opacity: 1 },
            { transform: `translate(${tx}px, ${ty}px) scale(0)`, opacity: 0 }
        ], {
            duration: 800,
            easing: 'cubic-bezier(0, .9, .57, 1)',
            fill: 'forwards'
        });
        
        setTimeout(() => p.remove(), 800);
    }
}

window.onload = initGame;
