/**
 * Sound Generator for Kids Scroll
 * Creates fun, cartoonish sounds using Web Audio API
 */

class SoundGenerator {
  constructor() {
    this.audioContext = null;
    this.masterGain = null;
    // Don't initialize immediately to avoid "The AudioContext was not allowed to start" warning
    
    // Add event listeners to resume audio context on first user interaction
    this.setupResumeOnInteraction();
  }

  /**
   * Initialize the audio context
   */
  initializeAudioContext() {
    if (!this.audioContext) {
      try {
        this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        this.masterGain = this.audioContext.createGain();
        this.masterGain.connect(this.audioContext.destination);
        this.masterGain.gain.value = 0.3; // Set a safe default volume
      } catch (e) {
        console.warn("Web Audio API not supported:", e);
      }
    }
  }

  /**
   * Setup listeners to resume AudioContext on user interaction
   */
  setupResumeOnInteraction() {
    const resume = () => {
      if (!this.audioContext) {
        this.initializeAudioContext();
      }
      if (this.audioContext && this.audioContext.state === 'suspended') {
        this.audioContext.resume().then(() => {
          removeListeners();
        });
      } else if (this.audioContext && this.audioContext.state === 'running') {
        removeListeners();
      }
    };

    const removeListeners = () => {
      window.removeEventListener('click', resume);
      window.removeEventListener('touchstart', resume);
      window.removeEventListener('mousedown', resume);
    };

    window.addEventListener('click', resume);
    window.addEventListener('touchstart', resume);
    window.addEventListener('mousedown', resume);
  }

  /**
   * Resume audio context if suspended
   */
  async resumeAudioContext() {
    if (!this.audioContext) {
      this.initializeAudioContext();
    }
    if (this.audioContext && this.audioContext.state === 'suspended') {
      try {
        await this.audioContext.resume();
      } catch (e) {
        console.warn("Failed to resume AudioContext:", e);
      }
    }
  }

  /**
   * Generate a random cartoonish sound
   */
  async playRandomSound() {
    await this.resumeAudioContext();
    if (!this.audioContext) return;

    // Array of different sound types
    const soundTypes = [
      this.playBoingSound,
      this.playPopSound,
      this.playChimeSound,
      this.playBubbleSound,
      this.playSlideSound,
      this.playLaughSound,
      this.playBeepSound,
      this.playTwinkleSound
    ];

    // Select a random sound type
    const randomSoundType = soundTypes[Math.floor(Math.random() * soundTypes.length)];
    
    // Play the selected sound
    randomSoundType.call(this);
  }

  /**
   * Play a boing sound (like a spring)
   */
  playBoingSound() {
    if (!this.audioContext) return;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(200, this.audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(50, this.audioContext.currentTime + 2.0);

    gainNode.gain.setValueAtTime(0.5, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 2.0);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start();
    oscillator.stop(this.audioContext.currentTime + 2.0);
  }

  /**
   * Play a pop sound
   */
  playPopSound() {
    if (!this.audioContext) return;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'square';
    oscillator.frequency.setValueAtTime(150, this.audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(50, this.audioContext.currentTime + 2.0);

    gainNode.gain.setValueAtTime(0.5, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + 2.0);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start();
    oscillator.stop(this.audioContext.currentTime + 2.0);
  }

  /**
   * Play a chime sound
   */
  playChimeSound() {
    if (!this.audioContext) return;
    const now = this.audioContext.currentTime;
    const duration = 2.0;
    
    for (let i = 0; i < 3; i++) {
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();
      
      // Different frequencies for harmonic chime
      const frequencies = [523.25, 659.25, 783.99]; // C, E, G notes
      
      oscillator.type = 'sine';
      oscillator.frequency.value = frequencies[i];
      
      gainNode.gain.setValueAtTime(0.3, now + i * 0.1);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + i * 0.1 + duration);
      
      oscillator.connect(gainNode);
      gainNode.connect(this.masterGain);
      
      oscillator.start(now + i * 0.1);
      oscillator.stop(now + i * 0.1 + duration);
    }
  }

  /**
   * Play a bubble sound
   */
  playBubbleSound() {
    if (!this.audioContext) return;
    const now = this.audioContext.currentTime;
    const bufferSize = this.audioContext.sampleRate * 2.0; // 2.0 seconds
    const noiseBuffer = this.audioContext.createBuffer(1, bufferSize, this.audioContext.sampleRate);
    const output = noiseBuffer.getChannelData(0);

    // Generate white noise
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const noise = this.audioContext.createBufferSource();
    noise.buffer = noiseBuffer;

    const filter = this.audioContext.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1000;
    filter.Q.value = 1.0;

    const gainNode = this.audioContext.createGain();
    gainNode.gain.setValueAtTime(0.3, now);
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + 2.0);

    noise.connect(filter);
    filter.connect(gainNode);
    gainNode.connect(this.masterGain);

    noise.start(now);
    noise.stop(now + 2.0);
  }

  /**
   * Play a slide whistle sound
   */
  playSlideSound() {
    if (!this.audioContext) return;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'sawtooth';
    oscillator.frequency.setValueAtTime(100, this.audioContext.currentTime);
    oscillator.frequency.exponentialRampToValueAtTime(800, this.audioContext.currentTime + 2.0);

    gainNode.gain.setValueAtTime(0.4, this.audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.01, this.audioContext.currentTime + 2.0);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start();
    oscillator.stop(this.audioContext.currentTime + 2.0);
  }

  /**
   * Play a silly laugh sound
   */
  playLaughSound() {
    if (!this.audioContext) return;
    const now = this.audioContext.currentTime;
    // Extended laugh sequence to last at least 2 seconds
    const laughFrequencies = [300, 400, 350, 450, 300, 250, 300, 400, 350, 250];
    
    laughFrequencies.forEach((freq, index) => {
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();
      
      oscillator.type = 'triangle';
      oscillator.frequency.value = freq;
      
      const startTime = now + index * 0.2;
      gainNode.gain.setValueAtTime(0.3, startTime);
      gainNode.gain.linearRampToValueAtTime(0.01, startTime + 0.2);
      
      oscillator.connect(gainNode);
      gainNode.connect(this.masterGain);
      
      oscillator.start(startTime);
      oscillator.stop(startTime + 0.2);
    });
  }

  /**
   * Play a simple beep sound
   */
  playBeepSound() {
    if (!this.audioContext) return;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.value = 600;

    gainNode.gain.setValueAtTime(0.4, this.audioContext.currentTime);
    gainNode.gain.linearRampToValueAtTime(0.01, this.audioContext.currentTime + 2.0);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start();
    oscillator.stop(this.audioContext.currentTime + 2.0);
  }

  /**
   * Play a twinkling star sound
   */
  playTwinkleSound() {
    if (!this.audioContext) return;
    const now = this.audioContext.currentTime;
    // Extended sequence to last at least 2 seconds
    const frequencies = [800, 1000, 1200, 1000, 800, 1000, 800, 1200];
    
    frequencies.forEach((freq, index) => {
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();
      
      oscillator.type = 'sine';
      oscillator.frequency.value = freq;
      
      const startTime = now + index * 0.25;
      gainNode.gain.setValueAtTime(0.3, startTime);
      gainNode.gain.linearRampToValueAtTime(0.01, startTime + 0.25);
      
      oscillator.connect(gainNode);
      gainNode.connect(this.masterGain);
      
      oscillator.start(startTime);
      oscillator.stop(startTime + 0.25);
    });
  }

  /**
   * Play a specific beep sound
   * @param {number} frequency Frequency in Hz
   * @param {number} duration Duration in ms
   */
  async playBeep(frequency = 520, duration = 150) {
    await this.resumeAudioContext();
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.type = 'sine';
    oscillator.frequency.value = frequency;

    const now = this.audioContext.currentTime;
    gainNode.gain.setValueAtTime(0.3, now);
    gainNode.gain.exponentialRampToValueAtTime(0.01, now + duration / 1000);

    oscillator.start(now);
    oscillator.stop(now + duration / 1000);
  }

  /**
   * Play a standard click sound
   */
  playClickSound() {
    this.playBeep(520, 150);
  }

  /**
   * Play a pleasant "right" or "success" sound
   */
  async playCorrectSound() {
    await this.resumeAudioContext();
    if (!this.audioContext) return;
    
    const now = this.audioContext.currentTime;
    const frequencies = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    
    frequencies.forEach((freq, i) => {
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(freq, now + i * 0.08);
      
      gainNode.gain.setValueAtTime(0, now + i * 0.08);
      gainNode.gain.linearRampToValueAtTime(0.2, now + i * 0.08 + 0.02);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + i * 0.08 + 0.2);
      
      oscillator.connect(gainNode);
      gainNode.connect(this.masterGain);
      
      oscillator.start(now + i * 0.08);
      oscillator.stop(now + i * 0.08 + 0.2);
    });
  }

  /**
   * Play a subtle "wrong" or "error" sound
   */
  async playWrongSound() {
    await this.resumeAudioContext();
    if (!this.audioContext) return;
    
    const now = this.audioContext.currentTime;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.type = 'triangle';
    oscillator.frequency.setValueAtTime(220, now);
    oscillator.frequency.linearRampToValueAtTime(110, now + 0.2);
    
    gainNode.gain.setValueAtTime(0.3, now);
    gainNode.gain.linearRampToValueAtTime(0.01, now + 0.2);
    
    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);
    
    oscillator.start(now);
    oscillator.stop(now + 0.2);
  }

  /**
   * Play a short, neutral "tap" or "selection" sound
   */
  async playTapSound() {
    await this.playBeep(600, 100);
  }

  /**
   * Play a specific tone/frequency
   * @param {number} frequency Frequency in Hz
   * @param {number} duration Duration in seconds
   * @param {string} type Oscillator type ('sine', 'square', 'sawtooth', 'triangle')
   */
  async playTone(frequency, duration, type = 'sine') {
    await this.resumeAudioContext();
    if (!this.audioContext) return;

    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);

    gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start();
    oscillator.stop(this.audioContext.currentTime + duration);
  }

  /**
   * Play a watering/bubble sound effect
   */
  async playWateringSound() {
    await this.resumeAudioContext();
    if (!this.audioContext) return;
    
    const now = this.audioContext.currentTime;
    for (let i = 0; i < 5; i++) {
      const oscillator = this.audioContext.createOscillator();
      const gainNode = this.audioContext.createGain();
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(400 + Math.random() * 600, now + i * 0.1);
      oscillator.frequency.exponentialRampToValueAtTime(100, now + i * 0.1 + 0.2);
      
      gainNode.gain.setValueAtTime(0.2, now + i * 0.1);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + i * 0.1 + 0.2);
      
      oscillator.connect(gainNode);
      gainNode.connect(this.masterGain);
      
      oscillator.start(now + i * 0.1);
      oscillator.stop(now + i * 0.1 + 0.2);
    }
  }
}

// Create a global instance of the sound generator
const soundGenerator = new SoundGenerator();

/**
 * Function to play a random sound when an avatar is clicked
 */
function playRandomAvatarSound() {
  soundGenerator.playRandomSound();
}