document.addEventListener('DOMContentLoaded', () => {
    const emojis = ['🍎','🐶','🚗','⚽','🐘','🍔','🚀','🐱','🐼','🐸','🦄','🦖','🍓','🍉','🍌','🥕','🥦','🍆','🍅','🥑','🌽','🥒','🍄','🌰','🍞','🥐'];
    const dragItemsContainer = document.getElementById('drag-items');
    const dropZones = document.querySelectorAll('.drop-zone');
    let startTime = Date.now();
    let sortedCount = 0;
    let isDragging = false;
    
    function initGame() {
        dragItemsContainer.innerHTML = '';
        dropZones.forEach(zone => {
            const label = zone.dataset.size.charAt(0).toUpperCase() + zone.dataset.size.slice(1);
            zone.innerHTML = label;
        });
        sortedCount = 0;
        startTime = Date.now();
        
        const emoji = emojis[Math.floor(Math.random() * emojis.length)];
        const sizes = ['small', 'medium', 'large'];
        
        const shuffled = [...sizes].sort(() => Math.random() - 0.5);
        
        shuffled.forEach(size => {
            const el = document.createElement('div');
            el.className = `drag-item item-${size}`;
            el.textContent = emoji;
            el.dataset.size = size;
            setupDragEvents(el);
            dragItemsContainer.appendChild(el);
        });

        setTimeout(() => {
            const smallItem = document.querySelector('.item-small');
            const smallZone = document.querySelector('.drop-zone[data-size="small"]');
            if (smallItem && smallZone && typeof showStartupGuide === 'function') {
                const itemRect = smallItem.getBoundingClientRect();
                const zoneRect = smallZone.getBoundingClientRect();
                showStartupGuide("Sort the items by size!", {
                    type: 'ghost-swipe',
                    startX: itemRect.left + itemRect.width/2 + 'px',
                    startY: itemRect.top + itemRect.height/2 + 'px',
                    endX: zoneRect.left + zoneRect.width/2 + 'px',
                    endY: zoneRect.top + zoneRect.height/2 + 'px'
                });
            }
        }, 500);
    }

    function setupDragEvents(el) {
        let startX = 0, startY = 0;
        let initialX = 0, initialY = 0;

        el.addEventListener('mousedown', dragStart);
        el.addEventListener('touchstart', dragStart, {passive: false});

        function dragStart(e) {
            if (e.type === 'touchstart') e.preventDefault();
            isDragging = true;
            
            if (typeof ghostHand !== 'undefined') ghostHand.stop();
            
            const clientX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
            const clientY = e.type === 'touchstart' ? e.touches[0].clientY : e.clientY;
            
            const rect = el.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;
            startX = clientX;
            startY = clientY;

            el.style.position = 'fixed';
            el.style.left = initialX + 'px';
            el.style.top = initialY + 'px';
            el.style.zIndex = '1000';
            el.classList.add('dragging');
            playSynth(300);

            document.addEventListener('mousemove', dragMove);
            document.addEventListener('touchmove', dragMove, {passive: false});
            document.addEventListener('mouseup', dragEnd);
            document.addEventListener('touchend', dragEnd);
            document.addEventListener('touchcancel', dragEnd);
        }

        function dragMove(e) {
            if (!isDragging) return;
            e.preventDefault();
            const clientX = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
            const clientY = e.type === 'touchmove' ? e.touches[0].clientY : e.clientY;
            
            const dx = clientX - startX;
            const dy = clientY - startY;
            
            el.style.left = (initialX + dx) + 'px';
            el.style.top = (initialY + dy) + 'px';

            const itemRect = el.getBoundingClientRect();
            dropZones.forEach(zone => {
                const zoneRect = zone.getBoundingClientRect();
                if (isIntersecting(itemRect, zoneRect)) {
                    zone.classList.add('hover');
                } else {
                    zone.classList.remove('hover');
                }
            });
        }

        function dragEnd(e) {
            if (!isDragging) return;
            isDragging = false;
            el.classList.remove('dragging');

            document.removeEventListener('mousemove', dragMove);
            document.removeEventListener('touchmove', dragMove);
            document.removeEventListener('mouseup', dragEnd);
            document.removeEventListener('touchend', dragEnd);
            document.removeEventListener('touchcancel', dragEnd);

            let dropped = false;
            const itemRect = el.getBoundingClientRect();
            
            dropZones.forEach(zone => {
                zone.classList.remove('hover');
                const zoneRect = zone.getBoundingClientRect();
                
                if (isIntersecting(itemRect, zoneRect) || getDistance(itemRect, zoneRect) < 60) {
                    if (el.dataset.size === zone.dataset.size) {
                        dropped = true;
                        zone.innerHTML = '';
                        el.style.position = 'static';
                        el.style.transform = 'none';
                        el.removeEventListener('mousedown', dragStart);
                        el.removeEventListener('touchstart', dragStart);
                        zone.appendChild(el);
                        sortedCount++;
                        playSynth(600);
                    }
                }
            });

            if (!dropped) {
                el.style.position = 'static';
                el.style.zIndex = '1';
                playSynth(200);
            }

            if (sortedCount === 3) {
                if (typeof triggerCelebration === 'function') triggerCelebration(true);
                if (typeof recordGameStats === 'function') {
                    recordGameStats('size-sorter', Math.round((Date.now() - startTime)/1000), { sorted: 3 });
                }
                setTimeout(initGame, 3000);
            }
        }
    }

    function isIntersecting(r1, r2) {
        return !(r2.left > r1.right || r2.right < r1.left || r2.top > r1.bottom || r2.bottom < r1.top);
    }
    
    function getDistance(r1, r2) {
        const c1 = {x: r1.left + r1.width/2, y: r1.top + r1.height/2};
        const c2 = {x: r2.left + r2.width/2, y: r2.top + r2.height/2};
        return Math.hypot(c1.x - c2.x, c1.y - c2.y);
    }

    function playSynth(freq) {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            const audioCtx = new AudioContext();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.frequency.value = freq;
            osc.type = 'sine';
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.1);
        } catch(e){}
    }

    initGame();
});
