const STORAGE_RECENT = 'kids_scroll_recent_wonders';

function loadRecentWonders() {
  const recentSection = document.getElementById('recently-explored-section');
  const recentScroll = document.getElementById('recently-explored-scroll');
  if (!recentSection || !recentScroll) return;

  try {
    const recentIds = JSON.parse(localStorage.getItem(STORAGE_RECENT) || '[]');
    if (!Array.isArray(recentIds) || recentIds.length === 0) {
      recentSection.style.display = 'none';
      return;
    }

    recentScroll.innerHTML = '';
    let addedCount = 0;

    recentIds.forEach(id => {
      const originalNode = document.querySelector(`.category-section:not(#recently-explored-section) .trending-item[data-topic-id="${id}"]`);
      if (originalNode) {
        recentScroll.appendChild(originalNode.cloneNode(true));
        addedCount++;
      }
    });

    recentSection.style.display = addedCount > 0 ? 'block' : 'none';
  } catch (e) {
    recentSection.style.display = 'none';
  }
}

function setupFilters() {
  const ageFilter = document.getElementById('age-filter');
  const searchInput = document.getElementById('wonder-search');

  function filterWonders(mode) {
    const selectedAge = ageFilter ? ageFilter.value : 'all';
    const searchQuery = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const allItems = document.querySelectorAll('.category-section:not(#recently-explored-section) .trending-item');

    allItems.forEach((item) => {
      let shouldShow = true;
      const itemAge = item.getAttribute('data-age');

      if (mode === 'age' && selectedAge !== 'all' && itemAge) {
        const selectedAgeNum = parseInt(selectedAge, 10);
        const itemAgeNum = parseInt(itemAge, 10);
        if (isNaN(itemAgeNum) || itemAgeNum < selectedAgeNum) {
          shouldShow = false;
        }
      } else if (mode === 'search' && searchQuery) {
        const title = item.querySelector('h3')?.textContent.toLowerCase() || '';
        if (!title.includes(searchQuery)) {
          shouldShow = false;
        }
      }

      item.style.display = shouldShow ? '' : 'none';
    });

    // Hide empty category sections
    document.querySelectorAll('.category-section:not(#recently-explored-section)').forEach((section) => {
      const items = section.querySelectorAll('.trending-item');
      if (items.length === 0) return;

      let hasVisible = false;
      items.forEach((item) => {
        if (item.style.display !== 'none') hasVisible = true;
      });

      section.style.display = hasVisible ? 'block' : 'none';
    });
  }

  if (ageFilter) {
    ageFilter.addEventListener('change', (e) => {
      e.target.blur();
      if (searchInput) searchInput.value = '';
      filterWonders('age');
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      if (ageFilter) ageFilter.value = 'all';
      filterWonders('search');
    });
  }
}

function init() {
  loadRecentWonders();
  setupFilters();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

window.addEventListener('pageshow', (event) => {
  if (event.persisted) {
    loadRecentWonders();
  }
});
