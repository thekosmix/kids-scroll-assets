/**
 * Kids Scroll - Questions & Wonder Catalog
 * 8 Canonical Preschool Categories with 76 Curated Topics
 */

export const WONDER_CATEGORIES = [
  { id: 'all', name: 'All Wonders 🌟', emoji: '🌟', color: '#6a11cb', bg: '#f3e8ff' },
  { id: 'animals', name: 'Animals & Wildlife 🦁', emoji: '🦁', color: '#e65100', bg: '#ffe0b2' },
  { id: 'vehicles', name: 'Vehicles & Transport 🚗', emoji: '🚗', color: '#0277bd', bg: '#b3e5fc' },
  { id: 'places', name: 'Places Around Us 🏫', emoji: '🏫', color: '#512da8', bg: '#ede7f6' },
  { id: 'nature', name: 'Nature & Weather 🌍', emoji: '🌍', color: '#00695c', bg: '#b2dfdb' },
  { id: 'everyday', name: 'Everyday Things & Science 🎈', emoji: '🎈', color: '#c2185b', bg: '#f8bbd0' },
  { id: 'food', name: 'Food & Plants 🥦', emoji: '🥦', color: '#2e7d32', bg: '#c8e6c9' },
  { id: 'space', name: 'Space & Sky 🚀', emoji: '🚀', color: '#1a237e', bg: '#c5cae9' },
  { id: 'body', name: 'My Body & Health 🍎', emoji: '🍎', color: '#d81b60', bg: '#fce4ec' }
];

export const WONDER_TOPICS = [
  // ==========================================
  // 1. ANIMALS & WILDLIFE 🦁 (23 topics)
  // ==========================================
  { id: 'cat', name: 'Cat', emoji: '🐱', category: 'animals', age: '1+', actorSound: 'cat', storyUrl: '/story/cat-story.html', file: 'cat.html' },
  { id: 'dog', name: 'Dog', emoji: '🐶', category: 'animals', age: '1+', actorSound: 'dog', storyUrl: '/story/dog-story.html', file: 'dog.html' },
  { id: 'rabbit', name: 'Rabbit', emoji: '🐰', category: 'animals', age: '2+', actorSound: 'rabbit', storyUrl: '/story/rabbit-story.html', file: 'rabbit.html' },
  { id: 'duck', name: 'Duck', emoji: '🦆', category: 'animals', age: '1+', actorSound: 'duck', storyUrl: '/story/duck-story.html', file: 'duck.html' },
  { id: 'cow', name: 'Cow', emoji: '🐮', category: 'animals', age: '1+', actorSound: 'cow', storyUrl: '/story/cow-story.html', file: 'cow.html' },
  { id: 'horse', name: 'Horse', emoji: '🐴', category: 'animals', age: '2+', actorSound: 'horse', storyUrl: '/story/horse-story.html', file: 'horse.html' },
  { id: 'pig', name: 'Pig', emoji: '🐷', category: 'animals', age: '1+', actorSound: 'pig', storyUrl: '/story/pig-story.html', file: 'pig.html' },
  { id: 'sheep', name: 'Sheep', emoji: '🐑', category: 'animals', age: '1+', actorSound: 'sheep', storyUrl: '/story/sheep-story.html', file: 'sheep.html' },
  { id: 'turtle', name: 'Turtle', emoji: '🐢', category: 'animals', age: '1+', actorSound: 'turtle', storyUrl: '/story/turtle-story.html', file: 'turtle.html' },
  { id: 'elephant', name: 'Elephant', emoji: '🐘', category: 'animals', age: '2+', actorSound: 'elephant', storyUrl: '/story/elephant-story.html', file: 'elephant.html' },
  { id: 'lion', name: 'Lion', emoji: '🦁', category: 'animals', age: '3+', actorSound: 'lion', storyUrl: '/story/lion-story.html', file: 'lion.html' },
  { id: 'monkey', name: 'Monkey', emoji: '🐒', category: 'animals', age: '2+', actorSound: 'monkey', storyUrl: '/story/monkey-story.html', file: 'monkey.html' },
  { id: 'bear', name: 'Bear', emoji: '🐻', category: 'animals', age: '2+', actorSound: 'bear', storyUrl: '/story/bear-story.html', file: 'bear.html' },
  { id: 'tiger', name: 'Tiger', emoji: '🐯', category: 'animals', age: '3+', actorSound: 'tiger', storyUrl: '/story/tiger-story.html', file: 'tiger.html' },
  { id: 'giraffe', name: 'Giraffe', emoji: '🦒', category: 'animals', age: '2+', actorSound: 'giraffe', storyUrl: '/story/giraffe-story.html', file: 'giraffe.html' },
  { id: 'zebra', name: 'Zebra', emoji: '🦓', category: 'animals', age: '2+', actorSound: 'zebra', storyUrl: '/story/zebra-story.html', file: 'zebra.html' },
  { id: 'panda', name: 'Panda', emoji: '🐼', category: 'animals', age: '2+', actorSound: 'panda', storyUrl: '/story/panda-story.html', file: 'panda.html' },
  { id: 'fox', name: 'Fox', emoji: '🦊', category: 'animals', age: '3+', actorSound: 'fox', storyUrl: '/story/fox-story.html', file: 'fox.html' },
  { id: 'kangaroo', name: 'Kangaroo', emoji: '🦘', category: 'animals', age: '2+', actorSound: 'kangaroo', storyUrl: '/story/kangaroo-story.html', file: 'kangaroo.html' },
  { id: 'penguin', name: 'Penguin', emoji: '🐧', category: 'animals', age: '2+', actorSound: 'penguin', storyUrl: '/story/penguin-story.html', file: 'penguin.html' },
  { id: 'bird', name: 'Bird', emoji: '🐦', category: 'animals', age: '2+', actorSound: 'duck', storyUrl: null, file: 'bird.html' },
  { id: 'frog', name: 'Frog', emoji: '🐸', category: 'animals', age: '2+', actorSound: null, storyUrl: null, file: 'frog.html' },
  { id: 'bee', name: 'Bee', emoji: '🐝', category: 'animals', age: '3+', actorSound: null, storyUrl: null, file: 'bee.html' },

  // ==========================================
  // 2. VEHICLES & TRANSPORT 🚗 (9 topics)
  // ==========================================
  { id: 'car', name: 'Car', emoji: '🚗', category: 'vehicles', age: '1+', actorSound: null, storyUrl: null, file: 'car.html' },
  { id: 'bus', name: 'Bus', emoji: '🚌', category: 'vehicles', age: '2+', actorSound: null, storyUrl: null, file: 'bus.html' },
  { id: 'train', name: 'Train', emoji: '🚂', category: 'vehicles', age: '2+', actorSound: null, storyUrl: '/story/brush-teeth-toothpaste-train.html', file: 'train.html' },
  { id: 'airplane', name: 'Airplane', emoji: '✈️', category: 'vehicles', age: '2+', actorSound: null, storyUrl: null, file: 'airplane.html' },
  { id: 'rocket', name: 'Rocket', emoji: '🚀', category: 'vehicles', age: '3+', actorSound: null, storyUrl: null, file: 'rocket.html' },
  { id: 'boat', name: 'Boat & Ship', emoji: '🚢', category: 'vehicles', age: '2+', actorSound: null, storyUrl: null, file: 'boat.html' },
  { id: 'bicycle', name: 'Bicycle', emoji: '🚲', category: 'vehicles', age: '2+', actorSound: null, storyUrl: '/story/helmet-on-wheels-roll.html', file: 'bicycle.html' },
  { id: 'bike', name: 'Bike', emoji: '🏍️', category: 'vehicles', age: '3+', actorSound: null, storyUrl: '/story/helmet-on-wheels-roll.html', file: 'bike.html' },
  { id: 'fire-truck', name: 'Fire Truck', emoji: '🚒', category: 'vehicles', age: '2+', actorSound: null, storyUrl: null, file: 'fire-truck.html' },

  // ==========================================
  // 3. PLACES AROUND US 🏫 (9 topics)
  // ==========================================
  { id: 'home', name: 'Home', emoji: '🏠', category: 'places', age: '1+', actorSound: null, storyUrl: '/story/where-do-toys-sleep-cleanup.html', file: 'home.html' },
  { id: 'school', name: 'School', emoji: '🏫', category: 'places', age: '3+', actorSound: null, storyUrl: '/story/circle-time-sunshine.html', file: 'school.html' },
  { id: 'playground', name: 'Playground', emoji: '🛝', category: 'places', age: '2+', actorSound: null, storyUrl: '/story/gentle-slide-line.html', file: 'playground.html' },
  { id: 'park', name: 'Park', emoji: '🌳', category: 'places', age: '1+', actorSound: null, storyUrl: '/story/five-more-minutes-warning.html', file: 'park.html' },
  { id: 'supermarket', name: 'Supermarket', emoji: '🛒', category: 'places', age: '2+', actorSound: null, storyUrl: '/story/the-cart-helper-supermarket.html', file: 'supermarket.html' },
  { id: 'mall', name: 'Mall', emoji: '🏬', category: 'places', age: '2+', actorSound: null, storyUrl: '/story/the-cart-helper-supermarket.html', file: 'mall.html' },
  { id: 'library', name: 'Library', emoji: '📚', category: 'places', age: '2+', actorSound: null, storyUrl: null, file: 'library.html' },
  { id: 'beach', name: 'Beach', emoji: '🏖️', category: 'places', age: '2+', actorSound: null, storyUrl: null, file: 'beach.html' },
  { id: 'farm', name: 'Farm', emoji: '🚜', category: 'places', age: '1+', actorSound: null, storyUrl: '/story/pig-story.html', file: 'farm.html' },

  // ==========================================
  // 4. NATURE & WEATHER 🌍 (9 topics)
  // ==========================================
  { id: 'rain', name: 'Rain', emoji: '🌧️', category: 'nature', age: '1+', actorSound: null, storyUrl: null, file: 'rain.html' },
  { id: 'rainbow', name: 'Rainbow', emoji: '🌈', category: 'nature', age: '2+', actorSound: null, storyUrl: null, file: 'rainbow.html' },
  { id: 'snow', name: 'Snow', emoji: '❄️', category: 'nature', age: '2+', actorSound: null, storyUrl: '/story/penguin-story.html', file: 'snow.html' },
  { id: 'thunder', name: 'Thunder', emoji: '⚡', category: 'nature', age: '3+', actorSound: null, storyUrl: null, file: 'thunder.html' },
  { id: 'wind', name: 'Wind', emoji: '🍃', category: 'nature', age: '2+', actorSound: null, storyUrl: null, file: 'wind.html' },
  { id: 'sea', name: 'Sea & Ocean', emoji: '🌊', category: 'nature', age: '2+', actorSound: null, storyUrl: null, file: 'sea.html' },
  { id: 'sun', name: 'Sun', emoji: '☀️', category: 'nature', age: '1+', actorSound: null, storyUrl: null, file: 'sun.html' },
  { id: 'river', name: 'River', emoji: '🏞️', category: 'nature', age: '2+', actorSound: null, storyUrl: null, file: 'river.html' },
  { id: 'seasons', name: 'Seasons', emoji: '🌸', category: 'nature', age: '2+', actorSound: null, storyUrl: '/story/backyard-bug-safari.html', file: 'seasons.html' },

  // ==========================================
  // 5. EVERYDAY THINGS & SCIENCE 🎈 (8 topics)
  // ==========================================
  { id: 'clock', name: 'Clock & Time', emoji: '⏰', category: 'everyday', age: '3+', actorSound: null, storyUrl: '/story/the-sharing-timer.html', file: 'clock.html' },
  { id: 'mirror', name: 'Mirror', emoji: '🪞', category: 'everyday', age: '2+', actorSound: null, storyUrl: null, file: 'mirror.html' },
  { id: 'magnet', name: 'Magnet', emoji: '🧲', category: 'everyday', age: '3+', actorSound: null, storyUrl: null, file: 'magnet.html' },
  { id: 'ball', name: 'Ball', emoji: '⚽', category: 'everyday', age: '1+', actorSound: null, storyUrl: '/story/pass-the-ball-to-me.html', file: 'ball.html' },
  { id: 'blocks', name: 'Blocks & Toys', emoji: '🧱', category: 'everyday', age: '1+', actorSound: null, storyUrl: '/story/where-do-toys-sleep-cleanup.html', file: 'blocks.html' },
  { id: 'shoes', name: 'Shoes', emoji: '👟', category: 'everyday', age: '1+', actorSound: null, storyUrl: '/story/left-shoe-right-shoe.html', file: 'shoes.html' },
  { id: 'bed', name: 'Bed', emoji: '🛏️', category: 'everyday', age: '1+', actorSound: null, storyUrl: '/story/big-kid-bed-sleep-story.html', file: 'bed.html' },
  { id: 'umbrella', name: 'Umbrella', emoji: '☂️', category: 'everyday', age: '2+', actorSound: null, storyUrl: null, file: 'umbrella.html' },

  // ==========================================
  // 6. FOOD & PLANTS 🥦 (8 topics)
  // ==========================================
  { id: 'apple', name: 'Apple', emoji: '🍎', category: 'food', age: '1+', actorSound: null, storyUrl: '/story/rainbow-plate-adventure.html', file: 'apple.html' },
  { id: 'banana', name: 'Banana', emoji: '🍌', category: 'food', age: '1+', actorSound: null, storyUrl: '/story/monkey-story.html', file: 'banana.html' },
  { id: 'carrot', name: 'Carrot', emoji: '🥕', category: 'food', age: '1+', actorSound: null, storyUrl: '/story/rabbit-story.html', file: 'carrot.html' },
  { id: 'tree', name: 'Tree', emoji: '🌲', category: 'food', age: '2+', actorSound: null, storyUrl: '/story/backyard-bug-safari.html', file: 'tree.html' },
  { id: 'flower', name: 'Flower', emoji: '🌸', category: 'food', age: '1+', actorSound: null, storyUrl: null, file: 'flower.html' },
  { id: 'milk', name: 'Milk', emoji: '🥛', category: 'food', age: '1+', actorSound: null, storyUrl: '/story/cow-story.html', file: 'milk.html' },
  { id: 'bread', name: 'Bread', emoji: '🍞', category: 'food', age: '1+', actorSound: null, storyUrl: '/story/little-chefs-soup.html', file: 'bread.html' },
  { id: 'honey', name: 'Honey', emoji: '🍯', category: 'food', age: '2+', actorSound: null, storyUrl: '/story/bear-story.html', file: 'honey.html' },

  // ==========================================
  // 7. SPACE & SKY 🚀 (4 topics)
  // ==========================================
  { id: 'moon', name: 'Moon', emoji: '🌙', category: 'space', age: '1+', actorSound: null, storyUrl: '/story/big-kid-bed-sleep-story.html', file: 'moon.html' },
  { id: 'star', name: 'Stars', emoji: '⭐', category: 'space', age: '1+', actorSound: null, storyUrl: null, file: 'star.html' },
  { id: 'cloud', name: 'Clouds', emoji: '☁️', category: 'space', age: '1+', actorSound: null, storyUrl: null, file: 'cloud.html' },
  { id: 'planet-earth', name: 'Planet Earth', emoji: '🌍', category: 'space', age: '3+', actorSound: null, storyUrl: null, file: 'planet-earth.html' },

  // ==========================================
  // 8. MY BODY & HEALTH 🍎 (6 topics)
  // ==========================================
  { id: 'heart', name: 'Heart', emoji: '❤️', category: 'body', age: '2+', actorSound: null, storyUrl: '/story/dr-bear-stethoscope.html', file: 'heart.html' },
  { id: 'eyes', name: 'Eyes & Blink', emoji: '👀', category: 'body', age: '1+', actorSound: null, storyUrl: null, file: 'eyes.html' },
  { id: 'hands', name: 'Hands & Fingers', emoji: '✋', category: 'body', age: '1+', actorSound: null, storyUrl: '/story/bubble-monster-wash-hands.html', file: 'hands.html' },
  { id: 'teeth', name: 'Teeth', emoji: '🦷', category: 'body', age: '2+', actorSound: null, storyUrl: '/story/brush-teeth-toothpaste-train.html', file: 'teeth.html' },
  { id: 'sleep', name: 'Sleep & Dreams', emoji: '😴', category: 'body', age: '1+', actorSound: null, storyUrl: '/story/big-kid-bed-sleep-story.html', file: 'sleep.html' },
  { id: 'hiccup', name: 'Hiccups & Yawns', emoji: '🥱', category: 'body', age: '2+', actorSound: null, storyUrl: null, file: 'hiccup.html' }
];

export function getCategoryById(id) {
  return WONDER_CATEGORIES.find(c => c.id === id) || WONDER_CATEGORIES[0];
}

export function getTopicById(id) {
  return WONDER_TOPICS.find(t => t.id === id) || null;
}
