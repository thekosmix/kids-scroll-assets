import { getTopicById, WONDER_TOPICS } from './catalog.js';
import { getFactsForTopic } from './data-fetcher.js';
import { parseStory } from '../story/scene-parser.js';
import { Playground } from '../story/playground.js';
import { StoryPlayer, isTtsSupported } from '../story/tts.js';

const PLAY_ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"></polygon></svg>';
const PAUSE_ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"></rect><rect x="14" y="4" width="4" height="16" rx="1"></rect></svg>';

const pathname = window.location.pathname.split('/').pop().replace('.html', '');
const rawTopicId = document.body.dataset.topicId || pathname;
const topic = getTopicById(rawTopicId) || WONDER_TOPICS[0];

if (!topic) {
  window.location.href = '/question/index.html';
  throw new Error('Unknown wonder topic');
}

// Track recently explored wonders in localStorage
try {
  const RECENT_KEY = 'kids_scroll_recent_wonders';
  let recent = JSON.parse(localStorage.getItem(RECENT_KEY) || '[]');
  recent = recent.filter(id => id !== topic.id);
  recent.unshift(topic.id);
  recent = recent.slice(0, 8);
  localStorage.setItem(RECENT_KEY, JSON.stringify(recent));
} catch (e) {}

const storyPaneEl = document.getElementById('story-pane');
const storyTitleEl = document.getElementById('story-title');
const storyTextEl = document.getElementById('story-text');
const refreshBtn = document.getElementById('refresh-btn');
const speedBtn = document.getElementById('speed-btn');
const playBtn = document.getElementById('play-btn');
const storyLinkBtn = document.getElementById('story-link-btn');
const prevLink = document.getElementById('prev-story-link');
const nextLink = document.getElementById('next-story-link');

// Wire prev/next links within the category if present
const categoryTopics = WONDER_TOPICS.filter(t => t.category === topic.category);
const currentIndex = categoryTopics.findIndex(t => t.id === topic.id);
if (currentIndex !== -1) {
  const prevTopic = categoryTopics[(currentIndex - 1 + categoryTopics.length) % categoryTopics.length];
  const nextTopic = categoryTopics[(currentIndex + 1) % categoryTopics.length];

  if (prevLink && prevTopic) {
    prevLink.href = `/question/${prevTopic.file || prevTopic.id + '.html'}`;
    prevLink.title = `Previous: ${prevTopic.name}`;
  }
  if (nextLink && nextTopic) {
    nextLink.href = `/question/${nextTopic.file || nextTopic.id + '.html'}`;
    nextLink.title = `Next: ${nextTopic.name}`;
  }
}

// Setup Story Cross-Link Button if applicable
if (topic.storyUrl && storyLinkBtn) {
  storyLinkBtn.href = topic.storyUrl;
  storyLinkBtn.title = `${topic.name} Story 📖`;
  storyLinkBtn.setAttribute('aria-label', `${topic.name} Story 📖`);
  storyLinkBtn.style.display = 'flex';
} else if (storyLinkBtn && !topic.storyUrl) {
  storyLinkBtn.style.display = 'none';
}

// Initialize Playground
const playgroundEl = document.getElementById('playground');
const playground = new Playground(playgroundEl);
playground.reset(topic.emoji);

playgroundEl?.addEventListener('pointerdown', (e) => {
  if (e.target.closest('.playground-actor, .playground-prop')) return;
  if (typeof playAnimalSound === 'function' && topic.actorSound) {
    playAnimalSound(topic.actorSound);
  }
});

// Setup TTS Player
const player = new StoryPlayer({
  onSentenceStart: (cue, index) => {
    playground.showCue(cue);
    highlightSentence(index);
    scrollToSentence(index);
  },
  onDone: () => {
    playground.idle();
    highlightSentence(-1);
    if (playBtn) playBtn.innerHTML = PLAY_ICON;
  }
});

function highlightSentence(index) {
  if (!storyTextEl) return;
  const prev = storyTextEl.querySelector('.sentence.active');
  if (prev) prev.classList.remove('active');
  if (index >= 0) {
    const el = storyTextEl.querySelector(`.sentence[data-idx="${index}"]`);
    if (el) el.classList.add('active');
  }
}

function scrollToSentence(index) {
  if (!storyTextEl) return;
  const span = storyTextEl.querySelector(`.sentence[data-idx="${index}"]`);
  if (!span) return;
  if (storyPaneEl) {
    const paneRect = storyPaneEl.getBoundingClientRect();
    const spanRect = span.getBoundingClientRect();
    const buffer = 24;
    const offScreen = spanRect.bottom > paneRect.bottom - buffer || spanRect.top < paneRect.top + buffer;
    if (offScreen) {
      span.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  } else {
    span.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
}

let activeCues = [];
let activeText = '';

function renderWonder(title, text) {
  activeText = text;
  activeCues = parseStory(text, topic.emoji);
  if (storyTitleEl && title) {
    storyTitleEl.textContent = `${title} ${topic.emoji}`;
  }
  if (storyTextEl) {
    storyTextEl.innerHTML = activeCues
      .map((cue, index) => `<span class="sentence" data-idx="${index}">${cue.sentence}</span>`)
      .join(' ');
  }
  if (storyPaneEl) {
    storyPaneEl.scrollTop = 0;
  }
  playground.reset(topic.emoji);
  if (playBtn) playBtn.disabled = false;
}

// Load initial cues from pre-rendered text so play works immediately
if (storyTextEl) {
  const initialText = storyTextEl.textContent.trim();
  const initialTitle = storyTitleEl ? storyTitleEl.textContent.replace(topic.emoji, '').trim() : topic.name;
  renderWonder(initialTitle, initialText);
}

// Rotate through the 50 facts sequentially using localStorage
async function cycleToNextFact() {
  player.stop();
  playground.idle();
  highlightSentence(-1);

  const facts = await getFactsForTopic(topic.id);
  if (!facts || facts.length === 0) return;

  const SEEN_KEY = `kids_wonder_seen_${topic.id}`;
  let seenIndices = [];
  try {
    seenIndices = JSON.parse(localStorage.getItem(SEEN_KEY) || '[]');
  } catch (e) {
    seenIndices = [];
  }

  // Since fact #0 is pre-rendered in HTML, treat 0 as already seen on first refresh
  if (seenIndices.length === 0) {
    seenIndices.push(0);
  } else if (seenIndices.length >= facts.length) {
    seenIndices = [0];
  }

  // Find next unseen index
  let nextIdx = 1;
  for (let i = 0; i < facts.length; i++) {
    if (!seenIndices.includes(i)) {
      nextIdx = i;
      break;
    }
  }

  seenIndices.push(nextIdx);
  try {
    localStorage.setItem(SEEN_KEY, JSON.stringify(seenIndices));
  } catch (e) {}

  const fact = facts[nextIdx];
  if (!fact) return;

  renderWonder(fact.title, fact.text);

  // Play sound if applicable
  if (typeof playAnimalSound === 'function' && topic.actorSound) {
    try { playAnimalSound(topic.actorSound); } catch (e) {}
  }

  // Speak and animate
  if (isTtsSupported()) {
    playBtn.innerHTML = PAUSE_ICON;
    player.play(activeCues);
  }
}

// Button Listeners
if (refreshBtn) {
  refreshBtn.addEventListener('click', () => {
    cycleToNextFact();
  });
}

if (playBtn) {
  playBtn.addEventListener('click', () => {
    if (!isTtsSupported() || !storyTextEl) return;
    if (player.isPlaying) {
      player.pause();
      playBtn.innerHTML = PLAY_ICON;
      return;
    }
    playBtn.innerHTML = PAUSE_ICON;
    const isResuming = player.index > 0 && player.index < player.cues.length;
    if (isResuming) {
      player.resume();
    } else {
      if (!activeCues || activeCues.length === 0) {
        activeCues = parseStory(storyTextEl.textContent.trim(), topic.emoji);
      }
      player.play(activeCues);
    }
  });
}

const SPEEDS = [0.8, 0.9, 1.0, 1.1];
let currentSpeedIndex = 0;
let speedDirection = 1;

if (speedBtn) {
  speedBtn.addEventListener('click', () => {
    currentSpeedIndex += speedDirection;
    if (currentSpeedIndex >= SPEEDS.length - 1) {
      currentSpeedIndex = SPEEDS.length - 1;
      speedDirection = -1;
    } else if (currentSpeedIndex <= 0) {
      currentSpeedIndex = 0;
      speedDirection = 1;
    }
    const speed = SPEEDS[currentSpeedIndex];
    speedBtn.textContent = speed.toFixed(1) + 'x';
    player.setSpeed(speed);
  });
}
