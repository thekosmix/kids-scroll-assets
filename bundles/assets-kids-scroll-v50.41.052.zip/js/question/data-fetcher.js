let wonderDataCache = null;

/**
 * Fetches the 50 facts per topic pool for Wonders and Facts from jsDelivr CDN.
 * Once loaded, keeps in memory and browser HTTP/SW cache for instant offline access.
 */
export async function fetchWonderData() {
  if (wonderDataCache) return wonderDataCache;

  const cdnUrl = 'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/assets/jsons/wonders-and-facts.json';

  try {
    const res = await fetch(cdnUrl);
    if (res.ok) {
      wonderDataCache = await res.json();
      return wonderDataCache;
    } else {
      console.warn('[KidsScroll Wonders] Could not fetch wonder data, status:', res.status);
    }
  } catch (err) {
    console.error('[KidsScroll Wonders] Failed to fetch wonder data:', err);
  }

  return null;
}

/**
 * Returns facts array for a given topic ID.
 */
export async function getFactsForTopic(topicId) {
  const data = await fetchWonderData();
  if (data && data[topicId] && Array.isArray(data[topicId].facts)) {
    return data[topicId].facts;
  }
  return [];
}
