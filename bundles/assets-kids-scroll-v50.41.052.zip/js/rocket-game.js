// Rocket game functionality
document.addEventListener('DOMContentLoaded', function() {
  // Game variables
  const gameContainer = document.getElementById('gameContainer');
  const joyMeter = new JoyMeter('gameContainer', { top: '20px' });
  let score = 0;
  const maxScore = 10;
  let isFirstLoad = true;
  
  function updateJoyMeter() {
    const percentage = (score / maxScore) * 100;
    joyMeter.setProgress(percentage);
  }
  
  // Function to get random direction with start/end positions
  function getRandomDirection() {
    const directionType = Math.floor(Math.random() * 4);
    
    switch(directionType) {
      case 0: // Left to right
        return {
          startX: -50,
          startY: Math.random() * window.innerHeight,
          endX: window.innerWidth + 50,
          endY: Math.random() * window.innerHeight
        };
      case 1: // Right to left
        return {
          startX: window.innerWidth + 50,
          startY: Math.random() * window.innerHeight,
          endX: -50,
          endY: Math.random() * window.innerHeight
        };
      case 2: // Bottom to top
        return {
          startX: Math.random() * window.innerWidth,
          startY: window.innerHeight + 50,
          endX: Math.random() * window.innerWidth,
          endY: -50
        };
      case 3: // Top to bottom
        return {
          startX: Math.random() * window.innerWidth,
          startY: -50,
          endX: Math.random() * window.innerWidth,
          endY: window.innerHeight + 50
        };
    }
  }

  // Define bright, saturated, light colors suitable for toddlers
  const brightColors = [
    '#FFFF00', // Yellow
    '#FFD700', // Gold
    '#FFA500', // Orange
    '#FF6347', // Tomato
    '#FF4500', // OrangeRed
    '#FF1493', // DeepPink
    '#FF69B4', // HotPink
    '#FFC0CB', // Pink
    '#FFB6C1', // LightPink
    '#FFA07A', // LightSalmon
    '#FFD700', // Gold
    '#FFFA90', // Light Yellow
    '#FFFFE0', // Light Yellow
    '#FFFACD', // Lemon Chiffon
    '#FFF8DC', // Cornsilk
    '#FFE4E1', // Misty Rose
    '#FFE4B5', // Moccasin
    '#FFDEAD', // Navajo White
    '#FFEFD5', // Papaya Whip
    '#FFEBCD', // Blanched Almond
    '#F0FFF0', // Honeydew
    '#F5FFFA', // Mint Cream
    '#F0FFFF', // Azure
    '#F0F8FF', // Alice Blue
    '#F8F8FF', // Ghost White
    '#F5F5DC', // Beige
    '#FFF0F5', // Lavender Blush
    '#E6E6FA', // Lavender
    '#E0FFFF', // Light Cyan
    '#FDF5E6', // Old Lace
    '#FAFAD2', // Light Goldenrod Yellow
    '#D8BFD8', // Thistle
    '#DDA0DD', // Plum
    '#DAA520', // Goldenrod
    '#CD5C5C', // Indian Red
    '#C0C0C0', // Silver
    '#BA55D3', // Medium Orchid
    '#98FB98', // Pale Green
    '#9370DB', // Medium Purple
    '#87CEEB', // Sky Blue
    '#7CFC00', // Lawn Green
    '#7B68EE', // Medium Slate Blue
    '#66CDAA', // Medium Aquamarine
    '#48D1CC', // Medium Turquoise
    '#4169E1', // Royal Blue
    '#32CD32', // Lime Green
    '#1E90FF', // Dodger Blue
    '#00FA9A', // Medium Spring Green
    '#00CED1', // Dark Turquoise
    '#00BFFF', // Deep Sky Blue
    '#00FF7F', // Spring Green
    '#00FFFF', // Cyan
    '#00FF00', // Lime
    '#228B22', // Forest Green
    '#2E8B57', // Sea Green
    '#3CB371', // Medium Sea Green
    '#20B2AA', // Light Sea Green
    '#008B8B', // Dark Cyan
    '#008080', // Teal
    '#006400', // Dark Green
    '#0000FF', // Blue
    '#0000CD', // Medium Blue
    '#4B0082', // Indigo
    '#800080', // Purple
    '#8B008B', // Dark Magenta
    '#8A2BE2', // Blue Violet
    '#9400D3', // Violet
    '#9932CC', // Dark Orchid
    '#BA55D3', // Medium Orchid
    '#DA70D6', // Orchid
    '#D8BFD8', // Thistle
    '#DDA0DD', // Plum
    '#EE82EE', // Violet
    '#FF00FF', // Magenta
    '#FF00FF'  // Fuchsia
  ];

  // Function to generate graffiti effect
  function generateGraffitiOnRocket(rocketElement, clientX, clientY) {
    // Create SVG overlay for celebration effect
    const celebrationSVG = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    celebrationSVG.setAttribute('class', 'celebration-overlay');
    celebrationSVG.setAttribute('width', '100%');
    celebrationSVG.setAttribute('height', '100%');
    celebrationSVG.setAttribute('style', 'position: absolute; top: 0; left: 0; pointer-events: none; z-index: 10; overflow: visible;');

    // Get dimensions for positioning
    const rect = rocketElement.getBoundingClientRect();

    // Calculate touch position relative to the rocket
    const touchX = clientX - rect.left;
    const touchY = clientY - rect.top;

    // Ensure touch coordinates are within rocket bounds
    const boundedTouchX = Math.max(5, Math.min(rect.width - 5, touchX));
    const boundedTouchY = Math.max(5, Math.min(rect.height - 5, touchY));

    // Generate more particles for a bigger, more celebratory effect
    const numParticles = 40; // Increased number of particles for even bigger effect

    for (let i = 0; i < numParticles; i++) {
      // Create particle element
      const particle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      const color = brightColors[Math.floor(Math.random() * brightColors.length)];

      // Set initial position at touch location
      particle.setAttribute('cx', boundedTouchX);
      particle.setAttribute('cy', boundedTouchY);
      particle.setAttribute('r', Math.random() * 10 + 5); // Even bigger radius for more visibility
      particle.setAttribute('fill', color);
      particle.setAttribute('fill-opacity', '0.9'); // Higher opacity for more visibility

      // Add to SVG
      celebrationSVG.appendChild(particle);

      // Animate particle movement
      animateParticle(particle, boundedTouchX, boundedTouchY, rect.width * 2, rect.height * 2, color); // Larger area for particles to spread
    }

    // Add the celebration SVG to the rocket container
    rocketElement.appendChild(celebrationSVG);

    // Remove celebration after 2.5 seconds to allow for longer animation
    setTimeout(() => {
      if (celebrationSVG.parentNode) {
        celebrationSVG.parentNode.removeChild(celebrationSVG);
      }
    }, 2500);
  }

  /**
   * Animate individual particle for firecracker effect
   */
  function animateParticle(particle, startX, startY, containerWidth, containerHeight, color) {
    // Calculate random angle and distance
    const angle = Math.random() * Math.PI * 2; // Random angle in radians
    const maxDistance = Math.min(containerWidth, containerHeight) * 0.8; // Increased max travel distance for even bigger effect
    const distance = Math.random() * maxDistance * 0.9 + maxDistance * 0.5; // Vary distance with more range

    // Calculate end position
    const endX = startX + Math.cos(angle) * distance;
    const endY = startY + Math.sin(angle) * distance;

    // Create animation
    const animateX = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
    animateX.setAttribute('attributeName', 'cx');
    animateX.setAttribute('from', startX);
    animateX.setAttribute('to', endX);
    animateX.setAttribute('dur', '2s'); // Longer duration for smoother animation
    animateX.setAttribute('fill', 'freeze');

    const animateY = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
    animateY.setAttribute('attributeName', 'cy');
    animateY.setAttribute('from', startY);
    animateY.setAttribute('to', endY);
    animateY.setAttribute('dur', '2s'); // Longer duration for smoother animation
    animateY.setAttribute('fill', 'freeze');

    // Fade out animation
    const animateOpacity = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
    animateOpacity.setAttribute('attributeName', 'fill-opacity');
    animateOpacity.setAttribute('values', '0.9;0.7;0'); // Starting with higher opacity
    animateOpacity.setAttribute('dur', '2s');
    animateOpacity.setAttribute('fill', 'freeze');

    // Size change animation - make particles grow slightly then shrink
    const animateSize = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
    animateSize.setAttribute('attributeName', 'r');
    animateSize.setAttribute('values', '5;8;3;0'); // Start medium, grow, shrink, disappear
    animateSize.setAttribute('dur', '2s');
    animateSize.setAttribute('fill', 'freeze');

    // Append animations to particle
    particle.appendChild(animateX);
    particle.appendChild(animateY);
    particle.appendChild(animateOpacity);
    particle.appendChild(animateSize);

    // Start animations
    animateX.beginElement();
    animateY.beginElement();
    animateOpacity.beginElement();
    animateSize.beginElement();
  }

  // Function to create a rocket
  function createRocket() {
    // Get random direction with start/end positions
    const direction = getRandomDirection();
    const startCorner = { x: direction.startX, y: direction.startY };
    const destCorner = { x: direction.endX, y: direction.endY };

    // Create rocket element with rocket emoji
    const rocket = document.createElement('div');
    rocket.className = 'rocket';
    rocket.style.left = `${startCorner.x}px`;
    rocket.style.top = `${startCorner.y}px`;
    rocket.style.fontSize = '3rem';
    rocket.textContent = '🚀';
    rocket.style.cursor = 'pointer';
    rocket.style.userSelect = 'none';
    rocket.style.position = 'absolute';
    rocket.style.zIndex = '10';
    rocket.style.transition = 'transform 0.1s';
    rocket.style.margin = '-30px';
    rocket.style.padding = '30px';

    // Track overall rocket click attempts
    rocket.addEventListener('mousedown', function() {
          });

    // Track touch events for mobile
    rocket.addEventListener('touchstart', function() {
          });

    // Add click event to rocket
    rocket.addEventListener('click', function(event) {
      if (rocket.dataset.burst === 'true') return;
      rocket.dataset.burst = 'true';

      // Play random sound
      if (typeof soundGenerator !== 'undefined') {
        soundGenerator.playRandomSound();
      }

      // Generate graffiti effect at click position
      generateGraffitiOnRocket(rocket, event.clientX, event.clientY);

      // Score and Joy Meter
      score++;
      updateJoyMeter();

      if (score >= maxScore) {
        if (typeof triggerCelebration === 'function') {
          triggerCelebration();
        }
        // Celebration sound is now inside triggerCelebration
        score = 0;
        setTimeout(updateJoyMeter, 3500);
      }

      // Remove rocket after the graffiti animation completes (2.5 seconds)
      setTimeout(() => {
        rocket.remove();
      }, 1000);
    });

    // Add rocket to container
    gameContainer.appendChild(rocket);

    // Startup guide for the first rocket
    if (isFirstLoad && typeof showStartupGuide === 'function') {
      isFirstLoad = false;
      const rect = rocket.getBoundingClientRect();
      showStartupGuide("Tap the rockets to burst them!", {
        type: 'ghost-tap',
        startX: (startCorner.x + 30) + 'px',
        startY: (startCorner.y + 30) + 'px'
      });
    }

    // Calculate distance to destination
    const dx = destCorner.x - startCorner.x;
    const dy = destCorner.y - startCorner.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // Calculate speed (pixels per second)
    const speed = 0.15;
    const duration = distance / speed;

    // Calculate rotation angle - rocket emoji points top-right (45°), align with flying direction
    const angle = Math.atan2(dy, dx) * 180 / Math.PI + 45; 

    // Animate rocket movement with rotation
    rocket.animate([
      { transform: `translate(0, 0) rotate(${angle}deg)` },
      { transform: `translate(${dx}px, ${dy}px) rotate(${angle}deg)` }
    ], {
      duration: duration,
      easing: 'linear'
    });

    // Remove rocket after reaching destination (unless already removed by click)
    setTimeout(() => {
      if (rocket.parentNode) {
        rocket.remove();
      }
    }, duration);
  }

  // Launch first rocket after a random delay (0.5-2 seconds)
  setTimeout(() => {
    createRocket();
    // Launch subsequent rockets at random intervals (0.5-3 seconds)
    scheduleNextRocket();
  }, 500 + Math.random() * 2500);

  // Function to schedule next rocket with random interval
  function scheduleNextRocket() {
    const randomDelay = 500 + Math.random() * 2500; // Random between 0.5-3 seconds
    setTimeout(() => {
      createRocket();
      scheduleNextRocket();
    }, randomDelay);
  }
});