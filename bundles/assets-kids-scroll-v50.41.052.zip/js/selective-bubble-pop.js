/**
 * Selective Bubble Pop Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('game-container');
    const joyMeter = new JoyMeter('game-container', { top: '20px' });
    
    const categories = {
        animals: { label: "Pop the animals!", emojis: ['🐶', '🐱', '🐭', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🦆', '🦉', '🦋', '🐢', '🐙'] },
        foods: { label: "Pop the food items!", emojis: ['🍎', '🍌', '🍉', '🍇', '🍓', '🥕', '🌽', '🍕', '🍔', '🍦', '🍩', '🍪', '🍰', '🥦', '🥑', '🧀', '🌮', '🥨', '🥞', '🍒'] },
        vehicles: { label: "Pop the vehicles!", emojis: ['🚗', '🚕', '🚙', '🚌', '🚎', '🏎️', '🚓', '🚑', '🚒', '🚜', '🛵', '🚲', '🚂', '🚁', '✈️', '🚀', '⛵', '🚤', '🛸', '🛶'] },
        toys: { label: "Pop the toys!", emojis: ['🧸', '🪁', '🪀', '⚽', '🧩', '🥁', '🎨', '🎮', '🪄', '⚾', '🏀', '🏈', '🎾', '🏓', '🛹', '🎳', '🎯', '🎰', '🎲', '🪆'] },
        clothes: { label: "Pop the clothes!", emojis: ['👕', '👗', '🧦', '🧤', '🧣', '🧢', '👟', '🎒', '👑', '👖', '👔', '🧥', '🩳', '👙', '👚', '👛', '🥾', '🎩', '🪖'] }
    };

    let targetCategoryKey;
    let targetCategory;
    let otherEmojis = [];
    
    let spawnInterval;
    let score = 0;
    const WIN_SCORE = 10;
    let startTime;
    let isGameOver = false;
    let inactivityTimer;
    let isFirstLoad = true;

    function resetInactivityTimer() {
        clearTimeout(inactivityTimer);
        if (isGameOver) return;
        inactivityTimer = setTimeout(() => {
            if (!isGameOver && targetCategory) {
                speakText(targetCategory.label);
                resetInactivityTimer(); // restart timer
            }
        }, 10000);
    }

    function initGame() {
        score = 0;
        isGameOver = false;
        
        // Clear old bubbles
        document.querySelectorAll('.bubble, .pop-effect').forEach(e => e.remove());

        // Select random category (ensure it changes)
        const keys = Object.keys(categories);
        let newKey = targetCategoryKey;
        while (newKey === targetCategoryKey && keys.length > 1) {
            newKey = keys[Math.floor(Math.random() * keys.length)];
        }
        targetCategoryKey = newKey;
        targetCategory = categories[targetCategoryKey];
        
        // Build "other" pool
        otherEmojis = [];
        keys.forEach(k => {
            if(k !== targetCategoryKey) {
                otherEmojis = otherEmojis.concat(categories[k].emojis);
            }
        });

        joyMeter.reset();
        
        if (isFirstLoad) {
            isFirstLoad = false;
            showStartupGuide(targetCategory.label, null);
        } else {
            if (typeof speakText === 'function') {
                speakText(targetCategory.label);
            }
        }
        
        startTime = Date.now();
        spawnInterval = setInterval(spawnBubble, 1000);
        
        resetInactivityTimer();
        
        if(typeof saveToRecent === 'function') saveToRecent('selective-bubble-pop');
    }

    function spawnBubble() {
        if(isGameOver) return;

        const bubble = document.createElement('div');
        bubble.className = 'bubble';
        
        // 50% chance for target, 50% for random other
        const isTarget = Math.random() > 0.5;
        const emojiPool = isTarget ? targetCategory.emojis : otherEmojis;
        const emoji = emojiPool[Math.floor(Math.random() * emojiPool.length)];
        
        bubble.textContent = emoji;
        bubble.dataset.isTarget = isTarget;

        // Random size and position
        const size = Math.floor(Math.random() * 60) + 80; // 80 to 140px
        bubble.style.width = size + 'px';
        bubble.style.height = size + 'px';
        bubble.style.fontSize = (size * 0.5) + 'px';
        
        const maxX = window.innerWidth - size;
        bubble.style.left = Math.floor(Math.random() * maxX) + 'px';
        
        // Random speed
        const duration = Math.floor(Math.random() * 4000) + 4000; // 4 to 8s
        bubble.style.animationDuration = duration + 'ms';

        bubble.addEventListener('pointerdown', handlePop);
        
        // Remove after animation completes
        bubble.addEventListener('animationend', () => bubble.remove());

        container.appendChild(bubble);
    }

    function handlePop(e) {
        if(isGameOver) return;
        const bubble = e.target;
        const isTarget = bubble.dataset.isTarget === 'true';

        if(isTarget) {
            // Correct pop
            score++;
            joyMeter.setProgress((score / WIN_SCORE) * 100);
            
            createPopEffect(bubble);
            bubble.remove();
            
            if(typeof vibrateSuccess === 'function') vibrateSuccess();
            
            if(score >= WIN_SCORE) {
                winGame();
            }
        } else {
            // Wrong pop
            bubble.classList.add('wrong-tap');
            speakText("Oops! " + targetCategory.label);
            setTimeout(() => {
                if(bubble && bubble.parentNode) {
                    bubble.classList.remove('wrong-tap');
                }
            }, 1000);
        }
    }

    function createPopEffect(bubble) {
        const rect = bubble.getBoundingClientRect();
        const effect = document.createElement('div');
        effect.className = 'pop-effect';
        effect.style.left = (rect.left + rect.width/2) + 'px';
        effect.style.top = (rect.top + rect.height/2) + 'px';
        document.body.appendChild(effect);
        setTimeout(() => effect.remove(), 300);
    }

    function winGame() {
        isGameOver = true;
        clearInterval(spawnInterval);
        clearTimeout(inactivityTimer);
        
        triggerCelebration(true, 100);
        
        const duration = Math.floor((Date.now() - startTime) / 1000);
        if(typeof recordGameStats === 'function') {
            recordGameStats('selective-bubble-pop', duration, { score: WIN_SCORE });
        }

        setTimeout(() => {
            initGame();
        }, 4000);
    }

    initGame();

    // Reset inactivity timer on any screen interaction
    document.addEventListener('pointerdown', () => {
        if (!isGameOver) {
            resetInactivityTimer();
        }
    }, { passive: true });
});
