/**
 * Where Do They Live? - Game Logic
 */

class WhereDoTheyLive {
    constructor() {
        this.habitats = [
            { name: "Ocean", emoji: "🌊", animals: ["🐋", "🦈", "🐙", "🐬", "🐢"] },
            { name: "Jungle", emoji: "🌳", animals: ["🐅", "🐒", "🦍", "🦜", "🐍"] },
            { name: "Mountain", emoji: "🏔️", animals: ["🦅", "🐐", "🐃", "🐆"] },
            { name: "Plain Field", emoji: "🌾", animals: ["🦓", "🦒", "🐘", "🦁"] },
            { name: "Desert", emoji: "🌵", animals: ["🐫", "🦂", "🦎"] },
            { name: "Tree", emoji: "🌲", animals: ["🐿️", "🦉", "🐨"] },
            { name: "Flower", emoji: "🌸", animals: ["🐝", "🦋", "🐞"] },
            { name: "Pond", emoji: "💧", animals: ["🐸", "🐊", "🦛"] },
            { name: "Icy Land", emoji: "❄️", animals: ["🐧", "🐻‍❄️", "🦭"] }
        ];

        this.animalNames = {
            '🐋': 'Whale', '🦈': 'Shark', '🐙': 'Octopus', '🐬': 'Dolphin', '🐢': 'Turtle',
            '🐅': 'Tiger', '🐒': 'Monkey', '🦍': 'Gorilla', '🦜': 'Parrot', '🐍': 'Snake',
            '🦅': 'Eagle', '🐐': 'Goat', '🐃': 'Water Buffalo', '🐆': 'Leopard',
            '🦓': 'Zebra', '🦒': 'Giraffe', '🐘': 'Elephant', '🦁': 'Lion',
            '🐫': 'Camel', '🦂': 'Scorpion', '🦎': 'Lizard',
            '🐿️': 'Chipmunk', '🦉': 'Owl', '🐨': 'Koala',
            '🐝': 'Bee', '🦋': 'Butterfly', '🐞': 'Ladybug',
            '🐸': 'Frog', '🐊': 'Crocodile', '🦛': 'Hippopotamus',
            '🐧': 'Penguin', '🐻‍❄️': 'Polar Bear', '🦭': 'Seal'
        };

        this.currentHabitat = null;
        this.correctAnimal = null;
        this.score = 0;
        this.consecutiveCorrect = 0;
        this.soundManager = new SoundGenerator();
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.nextRound();
    }

    setupEventListeners() {
        document.getElementById('restartBtn').addEventListener('click', () => {
            this.soundManager.playClickSound();
            this.resetGame();
        });
    }

    resetGame() {
        this.score = 0;
        this.consecutiveCorrect = 0;
        this.nextRound();
    }

    nextRound() {
        // Pick a random habitat
        const habitatIndex = Math.floor(Math.random() * this.habitats.length);
        this.currentHabitat = this.habitats[habitatIndex];
        
        // Pick a correct animal
        const animalIndex = Math.floor(Math.random() * this.currentHabitat.animals.length);
        this.correctAnimal = this.currentHabitat.animals[animalIndex];

        // Pick 3 wrong animals from other habitats
        const wrongAnimals = [];
        const otherHabitats = this.habitats.filter(h => h.name !== this.currentHabitat.name);
        
        while (wrongAnimals.length < 3) {
            const h = otherHabitats[Math.floor(Math.random() * otherHabitats.length)];
            const a = h.animals[Math.floor(Math.random() * h.animals.length)];
            if (!wrongAnimals.includes(a)) {
                wrongAnimals.push(a);
            }
        }

        // Combine and shuffle
        const options = [this.correctAnimal, ...wrongAnimals];
        this.shuffleArray(options);

        // Update UI
        this.updateUI(options);

        // Voice prompt
        setTimeout(() => {
            if (typeof speakText === 'function') {
                speakText(`Which animal lives in the ${this.currentHabitat.name}?`);
            }
        }, 500);

            }

    updateUI(options) {
        const habitatDisplay = document.getElementById('habitatDisplay');
        habitatDisplay.textContent = this.currentHabitat.emoji;
        habitatDisplay.className = 'habitat-emoji bounce-in';
        
        const habitatName = document.getElementById('habitatName');
        habitatName.textContent = this.currentHabitat.name;

        const optionsContainer = document.getElementById('optionsContainer');
        optionsContainer.innerHTML = '';

        options.forEach(animal => {
            const card = document.createElement('div');
            card.className = 'animal-card';
            card.textContent = animal;
            card.addEventListener('click', () => this.handleGuess(animal, card));
            optionsContainer.appendChild(card);
        });
    }

    handleGuess(animal, card) {
        if (card.classList.contains('correct') || card.classList.contains('incorrect')) return;

        // Snappy pop-like sound for picking/guessing
        this.soundManager.playBeep(520, 100);

        if (animal === this.correctAnimal) {
            card.classList.add('correct');
            this.consecutiveCorrect++;
            this.score++;
            
            // Success sound
            this.soundManager.playBeep(600, 150);

            // Confetti for every right guess
            this.showMiniConfetti(card);

                        // Voice feedback: "yes, $animal lives in the $habitat"
            if (typeof speakText === 'function') {
                const animalName = this.animalNames[animal] || 'this animal';
                speakText(`Yes, ${animalName} lives in the ${this.currentHabitat.name}`, () => {
                    if (typeof playAnimalSound === 'function') {
                        playAnimalSound(animal);
                    }
                });
            }

            if (this.consecutiveCorrect >= 5) {
                if (typeof triggerCelebration === 'function') {
                    triggerCelebration(false);
                }
                this.consecutiveCorrect = 0;
            }

            setTimeout(() => this.nextRound(), 4500);
        } else {
            card.classList.add('incorrect');

            // Wrong sound
            this.soundManager.playBeep(300, 100);

                        setTimeout(() => {
                card.classList.remove('incorrect');
            }, 1000);
        }
    }

    showMiniConfetti(element) {
        const rect = element.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;

        for (let i = 0; i < 20; i++) {
            const confetto = document.createElement('div');
            confetto.className = 'mini-confetto';
            confetto.style.left = centerX + 'px';
            confetto.style.top = centerY + 'px';
            confetto.style.backgroundColor = this.getRandomColor();
            document.body.appendChild(confetto);

            const angle = Math.random() * Math.PI * 2;
            const velocity = 5 + Math.random() * 5;
            const vx = Math.cos(angle) * velocity;
            const vy = Math.sin(angle) * velocity;
            
            let posX = centerX;
            let posY = centerY;
            let opacity = 1;

            const animate = () => {
                posX += vx;
                posY += vy;
                opacity -= 0.02;
                
                confetto.style.left = posX + 'px';
                confetto.style.top = posY + 'px';
                confetto.style.opacity = opacity;

                if (opacity > 0) {
                    requestAnimationFrame(animate);
                } else {
                    confetto.remove();
                }
            };
            requestAnimationFrame(animate);
        }
    }

    getRandomColor() {
        const colors = ['#FFD700', '#FF6347', '#00FF7F', '#1E90FF', '#FF69B4', '#FFA500'];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }
}

// Start game
document.addEventListener('DOMContentLoaded', () => {
    window.game = new WhereDoTheyLive();
});
