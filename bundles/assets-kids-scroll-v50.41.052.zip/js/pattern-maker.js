document.addEventListener('DOMContentLoaded', () => {
    const patternContainer = document.getElementById('pattern-container');
    const optionsContainer = document.getElementById('options-container');
    
    const emojiSets = [
        ['🍎', '🍌', '🍇', '🍉'],
        ['🐶', '🐱', '🐭', '🐰'],
        ['🚗', '🚌', '🚓', '🚑'],
        ['⭐', '🌙', '☀️', '☁️'],
        ['🔴', '🟦', '🟩', '🟨']
    ];

    let currentPattern = [];
    let correctEmoji = '';
    let isDragging = false;
    let startTime;

    function initGame() {
        patternContainer.innerHTML = '';
        optionsContainer.innerHTML = '';
        startTime = Date.now();

        const set = emojiSets[Math.floor(Math.random() * emojiSets.length)];
        const emojis = shuffleArray([...set]);
        const a = emojis[0];
        const b = emojis[1];
        
        const isLandscape = window.matchMedia('(orientation: landscape)').matches;
        // Generate pattern type: 0 = ABAB, 1 = AAB, 2 = ABB
        const type = Math.floor(Math.random() * 3);
        let pattern = [];
        if (isLandscape) {
            if (type === 0) pattern = [a, b, a, b, a, b, a, b, a];
            else if (type === 1) pattern = [a, a, b, a, a, b, a, a, b];
            else pattern = [a, b, b, a, b, b, a, b, b];
        } else {
            if (type === 0) pattern = [a, b, a, b, a];
            else if (type === 1) pattern = [a, a, b, a, a, b];
            else pattern = [a, b, b, a, b, b];
        }

        // Pick missing slot (ensuring at least 2 items before and 1 after)
        const minIndex = 2;
        const maxIndex = pattern.length - 2;
        const missingIndex = Math.floor(Math.random() * (maxIndex - minIndex + 1)) + minIndex;
        correctEmoji = pattern[missingIndex];
        currentPattern = [...pattern];
        currentPattern[missingIndex] = '?';

        // Render pattern
        currentPattern.forEach((item, index) => {
            const div = document.createElement('div');
            if (item === '?') {
                div.className = 'pattern-slot';
                div.id = 'drop-slot';
            } else {
                div.className = 'pattern-item';
                div.textContent = item;
            }
            patternContainer.appendChild(div);
        });

        // Render options
        let optionPool = [correctEmoji];
        for (let i = 0; i < emojis.length; i++) {
            if (emojis[i] !== correctEmoji && !optionPool.includes(emojis[i])) {
                optionPool.push(emojis[i]);
            }
        }
        const optionsCount = isLandscape ? 4 : 3;
        const options = shuffleArray(optionPool.slice(0, optionsCount));
        options.forEach(emoji => {
            const div = document.createElement('div');
            div.className = 'option';
            div.textContent = emoji;
            div.dataset.emoji = emoji;
            setupDragEvents(div);
            optionsContainer.appendChild(div);
        });

        if (!window.hasShownPatternGuide) {
            window.hasShownPatternGuide = true;
            const guide = new GhostHand();
            setTimeout(() => {
                const opt = document.querySelector(`.option[data-emoji="${correctEmoji}"]`);
                const slot = document.getElementById('drop-slot');
                if (opt && slot) {
                    const optRect = opt.getBoundingClientRect();
                    const slotRect = slot.getBoundingClientRect();
                    guide.show('ghost-swipe', 
                        `${optRect.left + optRect.width/2}px`, `${optRect.top + optRect.height/2}px`,
                        `${slotRect.left + slotRect.width/2}px`, `${slotRect.top + slotRect.height/2}px`
                    );
                }
            }, 500);
        }

        if (!window.hasSpokenIntro) {
            window.hasSpokenIntro = true;
            speakText("Complete the pattern! Drag the right shape to the empty box.");
        }
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function setupDragEvents(el) {
        let startX = 0, startY = 0;
        let initialX = 0, initialY = 0;

        el.addEventListener('mousedown', dragStart);
        el.addEventListener('touchstart', dragStart, {passive: false});

        function dragStart(e) {
            if (e.type === 'touchstart') e.preventDefault();
            isDragging = true;
            
            const clientX = e.type === 'touchstart' ? e.touches[0].clientX : e.clientX;
            const clientY = e.type === 'touchstart' ? e.touches[0].clientY : e.clientY;
            
            const rect = el.getBoundingClientRect();
            initialX = rect.left;
            initialY = rect.top;
            startX = clientX;
            startY = clientY;

            el.style.position = 'fixed';
            el.style.left = initialX + 'px';
            el.style.top = initialY + 'px';
            el.style.zIndex = '1000';
            el.classList.add('dragging');

            document.addEventListener('mousemove', dragMove);
            document.addEventListener('touchmove', dragMove, {passive: false});
            document.addEventListener('mouseup', dragEnd);
            document.addEventListener('touchend', dragEnd);
            document.addEventListener('touchcancel', dragEnd);
        }

        function dragMove(e) {
            if (!isDragging) return;
            e.preventDefault();
            const clientX = e.type === 'touchmove' ? e.touches[0].clientX : e.clientX;
            const clientY = e.type === 'touchmove' ? e.touches[0].clientY : e.clientY;
            
            const dx = clientX - startX;
            const dy = clientY - startY;
            
            el.style.left = (initialX + dx) + 'px';
            el.style.top = (initialY + dy) + 'px';

            const slot = document.getElementById('drop-slot');
            if (isOverlapping(el, slot)) {
                slot.classList.add('drag-over');
            } else {
                slot.classList.remove('drag-over');
            }
        }

        function dragEnd(e) {
            if (!isDragging) return;
            isDragging = false;
            el.classList.remove('dragging');

            document.removeEventListener('mousemove', dragMove);
            document.removeEventListener('touchmove', dragMove);
            document.removeEventListener('mouseup', dragEnd);
            document.removeEventListener('touchend', dragEnd);
            document.removeEventListener('touchcancel', dragEnd);

            const slot = document.getElementById('drop-slot');
            slot.classList.remove('drag-over');

            if (isOverlapping(el, slot)) {
                if (el.dataset.emoji === correctEmoji) {
                    // Success
                    slot.textContent = correctEmoji;
                    slot.style.border = 'none';
                    slot.style.background = 'transparent';
                    el.style.display = 'none';
                    triggerCelebration();
                    if (typeof window.recordGameStats === 'function') {
                        window.recordGameStats('pattern-maker', (Date.now() - startTime)/1000, { avgTime: (Date.now() - startTime)/1000 });
                    }
                    setTimeout(initGame, 2500);
                } else {
                    // Fail
                    resetPosition();
                    speakText("Try another one!");
                }
            } else {
                resetPosition();
            }
        }

        function resetPosition() {
            el.style.position = 'static';
            el.style.zIndex = '1';
        }
    }

    function isOverlapping(el1, el2) {
        if (!el1 || !el2) return false;
        const r1 = el1.getBoundingClientRect();
        const r2 = el2.getBoundingClientRect();
        
        // Magnetic pull ~60px
        const expandedR2 = {
            left: r2.left - 60,
            right: r2.right + 60,
            top: r2.top - 60,
            bottom: r2.bottom + 60
        };

        return !(r1.right < expandedR2.left || 
                 r1.left > expandedR2.right || 
                 r1.bottom < expandedR2.top || 
                 r1.top > expandedR2.bottom);
    }

    initGame();

    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(initGame, 250);
    });
});
