/**
 * Who Makes This Sound Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const playSoundBtn = document.getElementById('play-sound-btn');
    const optionsContainer = document.getElementById('options-container');

    const animals = [
        { emoji: '🐝', sound: 'Buzz buzz', audio: '../assets/sounds/bee.mp3' },
        { emoji: '🐻', sound: 'Growl', audio: '../assets/sounds/bear.mp3' },
        { emoji: '🐱', sound: 'Meow', audio: '../assets/sounds/cat.mp3' },
        { emoji: '🐔', sound: 'Cluck cluck', audio: '../assets/sounds/chicken.mp3' },
        { emoji: '🐮', sound: 'Mooooo', audio: '../assets/sounds/cow.mp3' },
        { emoji: '🐦‍⬛', sound: 'Caw caw', audio: '../assets/sounds/crow.mp3' },
        { emoji: '🦖', sound: 'Roar', audio: '../assets/sounds/dinosaur.mp3' },
        { emoji: '🐶', sound: 'Woof woof', audio: '../assets/sounds/dog.mp3' },
        { emoji: '🐬', sound: 'Click and whistle', audio: '../assets/sounds/dolphin.mp3' },
        { emoji: '🦆', sound: 'Quack quack', audio: '../assets/sounds/duck.mp3' },
        { emoji: '🦊', sound: 'Yip yip', audio: '../assets/sounds/fox.mp3' },
        { emoji: '🐸', sound: 'Ribbit', audio: '../assets/sounds/frog.mp3' },
        { emoji: '🦒', sound: 'Munch munch', audio: '../assets/sounds/giraffe.mp3' },
        { emoji: '🐐', sound: 'Baaaa', audio: '../assets/sounds/goat.mp3' },
        { emoji: '🦛', sound: 'Grunt grunt', audio: '../assets/sounds/hippopotamus.mp3' },
        { emoji: '🐴', sound: 'Neigh', audio: '../assets/sounds/horse.mp3' },
        { emoji: '🐨', sound: 'Grumble', audio: '../assets/sounds/koala.mp3' },
        { emoji: '🦁', sound: 'Roar', audio: '../assets/sounds/lion.mp3' },
        { emoji: '🐒', sound: 'Ooh ooh aah aah', audio: '../assets/sounds/monkey.mp3' },
        { emoji: '🦉', sound: 'Hoot hoot', audio: '../assets/sounds/owl.mp3' },
        { emoji: '🐧', sound: 'Honk honk', audio: '../assets/sounds/penguin.mp3' },
        { emoji: '🐷', sound: 'Oink oink', audio: '../assets/sounds/pig.mp3' },
        { emoji: '🐀', sound: 'Squeak squeak', audio: '../assets/sounds/rat.mp3' },
        { emoji: '🐦', sound: 'Tweet tweet', audio: '../assets/sounds/robin.mp3' },
        { emoji: '🦭', sound: 'Awrk awrk', audio: '../assets/sounds/seal.mp3' },
        { emoji: '🐑', sound: 'Baaaa', audio: '../assets/sounds/sheep.mp3' },
        { emoji: '🐍', sound: 'Sssss', audio: '../assets/sounds/snake.mp3' },
        { emoji: '🐺', sound: 'Howl', audio: '../assets/sounds/wolf.mp3' }
    ];

    let currentCorrectAnimal = null;
    let startTime;
    let attempts = 0;

    function initGame() {
        optionsContainer.innerHTML = '';
        attempts = 0;

        // Pick 3 random animals
        const shuffled = [...animals].sort(() => 0.5 - Math.random());
        const choices = shuffled.slice(0, 3);
        currentCorrectAnimal = choices[Math.floor(Math.random() * choices.length)];

        choices.forEach(animal => {
            const el = document.createElement('div');
            el.className = 'animal-option';
            el.textContent = animal.emoji;
            el.addEventListener('pointerdown', () => handleGuess(el, animal));
            optionsContainer.appendChild(el);
        });

        startTime = Date.now();

        // Guide hand to press the play button
        const btnRect = playSoundBtn.getBoundingClientRect();
        showStartupGuide("Tap the speaker to hear a sound and guess the animal!", {
            type: 'ghost-tap',
            startX: `${btnRect.left + btnRect.width/2}px`,
            startY: `${btnRect.top + btnRect.height/2}px`
        });

        if(typeof saveToRecent === 'function') saveToRecent('who-makes-sound');
    }

    playSoundBtn.addEventListener('pointerdown', () => {
        if(currentCorrectAnimal) {
            playSoundBtn.style.transform = 'scale(0.9)';
            setTimeout(() => playSoundBtn.style.transform = '', 150);
            
            // Play audio from animal audio sprite with speech fallback
            if (typeof playAnimalSound === 'function') {
                playAnimalSound(currentCorrectAnimal.emoji).then(played => {
                    if (!played) speakText(currentCorrectAnimal.sound);
                });
            } else {
                speakText(currentCorrectAnimal.sound);
            }
            
            // Visual feedback that sound is playing
            playSoundBtn.style.backgroundColor = '#f57c00';
            setTimeout(() => playSoundBtn.style.backgroundColor = '', 500);
        }
    });

    function handleGuess(el, animal) {
        if(el.classList.contains('wrong')) return;
        
        attempts++;

        if(animal.emoji === currentCorrectAnimal.emoji) {
            winGame(el);
        } else {
            el.classList.add('wrong');
            speakText("Oops, try again!");
            if(typeof vibrateSuccess === 'function') vibrateSuccess(); // fallback vibrate
        }
    }

    function winGame(el) {
        el.style.transform = 'scale(1.2)';
        el.style.zIndex = '10';
        el.style.boxShadow = '0 10px 20px rgba(0,0,0,0.2)';
        
        triggerCelebration(true, 100);
        speakText(`Yes! The ${currentCorrectAnimal.sound} is the ${currentCorrectAnimal.emoji}!`);
        
        const duration = Math.floor((Date.now() - startTime) / 1000);
        if(typeof recordGameStats === 'function') {
            recordGameStats('who-makes-sound', duration, { attempts: attempts });
        }

        setTimeout(() => {
            initGame();
        }, 4000);
    }

    initGame();
});
