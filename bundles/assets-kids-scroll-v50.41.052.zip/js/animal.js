// Animal Fight Game
let canvas, ctx;
let animals = [];
let animalCount = 0;
const MAX_ANIMALS = 15;
let paused = false;
let isFirstLoad = true;

// Animal emoji names for speech synthesis
const ANIMAL_NAMES = {
    '🐵': 'Monkey', '🐒': 'Monkey', '🦍': 'Gorilla', '🦧': 'Orangutan',
    '🐶': 'Dog', '🐕': 'Dog', '🦮': 'Guide Dog', '🐩': 'Poodle',
    '🐺': 'Wolf', '🦊': 'Fox', '🦝': 'Raccoon', '🐱': 'Cat',
    '🐈': 'Cat', '🦁': 'Lion', '🐯': 'Tiger', '🐅': 'Tiger',
    '🐆': 'Leopard', '🐴': 'Horse', '🐎': 'Horse', '🦄': 'Unicorn',
    '🦓': 'Zebra', '🦌': 'Deer', '🦬': 'Bison', '🐂': 'Ox',
    '🐃': 'Water Buffalo', '🐄': 'Cow', '🐮': 'Cow', '🐷': 'Pig',
    '🐖': 'Pig', '🐗': 'Boar', '🐽': 'Pig Nose', '🐏': 'Ram',
    '🐑': 'Sheep', '🐐': 'Goat', '🐪': 'Camel', '🐫': 'Camel',
    '🦙': 'Llama', '🦒': 'Giraffe', '🐘': 'Elephant', '🦣': 'Mammoth',
    '🦏': 'Rhinoceros', '🦛': 'Hippopotamus', '🐭': 'Mouse', '🐁': 'Mouse',
    '🐀': 'Rat', '🐹': 'Hamster', '🐰': 'Rabbit', '🐇': 'Rabbit',
    '🐿️': 'Chipmunk', '🦫': 'Beaver', '🦔': 'Hedgehog', '🦇': 'Bat',
    '🐻': 'Bear', '🐨': 'Koala', '🐼': 'Panda', '🦥': 'Sloth',
    '🦦': 'Otter', '🦨': 'Skunk', '🦘': 'Kangaroo', '🦡': 'Badger',
    '🐾': 'Paw Prints', '🐔': 'Chicken', '🐓': 'Rooster', '🐣': 'Chick',
    '🐤': 'Chick', '🐥': 'Chick', '🐦': 'Bird', '🐧': 'Penguin',
    '🕊️': 'Dove', '🦅': 'Eagle', '🦆': 'Duck', '🦢': 'Swan',
    '🦉': 'Owl', '🦤': 'Dodo', '🪶': 'Feather', '🦩': 'Flamingo',
    '🦚': 'Peacock', '🦜': 'Parrot', '🪿': 'Goose', '🦃': 'Turkey',
    '🐸': 'Frog', '🐊': 'Crocodile', '🐢': 'Turtle', '🦎': 'Lizard',
    '🐍': 'Snake', '🐲': 'Dragon', '🐉': 'Dragon', '🦕': 'Sauropod',
    '🦖': 'T-Rex', '🐳': 'Whale', '🐋': 'Whale', '🐬': 'Dolphin',
    '🦭': 'Seal', '🐟': 'Fish', '🐠': 'Fish', '🐡': 'Blowfish',
    '🦈': 'Shark', '🐙': 'Octopus', '🐚': 'Shell', '🪼': 'Jellyfish',
    '🪸': 'Coral', '🐌': 'Snail', '🦋': 'Butterfly', '🐛': 'Bug',
    '🐜': 'Ant', '🐝': 'Bee', '🪲': 'Beetle', '🐞': 'Ladybug',
    '🦗': 'Cricket', '🪳': 'Cockroach', '🕷️': 'Spider', '🕸️': 'Web',
    '蠍': 'Scorpion', '🦟': 'Mosquito', '🪰': 'Fly', '🪱': 'Worm',
    '🦠': 'Microbe'
};

const animalRanges = [
    [0x1F400, 0x1F43F],
    [0x1F420, 0x1F42F],
    [0x1F980, 0x1F98F],
    [0x1F990, 0x1F99F]
];

class Animal {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = 40 + Math.random() * 30;
        this.speedX = (Math.random() - 0.5) * 6;
        this.speedY = (Math.random() - 0.5) * 6;
        this.emoji = this.getRandomAnimalEmoji();
        this.width = this.size;
        this.height = this.size;
        this.scale = 0; // For bounce-in effect
    }
    
    getRandomAnimalEmoji() {
        const range = animalRanges[Math.floor(Math.random() * animalRanges.length)];
        const code = Math.floor(Math.random() * (range[1] - range[0] + 1)) + range[0];
        return String.fromCodePoint(code);
    }
    
    draw() {
        if (this.scale < 1) this.scale += 0.1;
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.scale(this.scale, this.scale);
        ctx.font = `${this.size}px Arial`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(this.emoji, 0, 0);
        ctx.restore();
    }
    
    update() {
        this.x += this.speedX;
        this.y += this.speedY;
        
        if (this.x < this.width/2 || this.x > canvas.width - this.width/2) {
            this.speedX = -this.speedX;
            this.x = Math.max(this.width/2, Math.min(canvas.width - this.width/2, this.x));
        }
        
        if (this.y < this.height/2 || this.y > canvas.height - this.height/2) {
            this.speedY = -this.speedY;
            this.y = Math.max(this.height/2, Math.min(canvas.height - this.height/2, this.y));
        }
    }
    
    isColliding(other) {
        const dx = this.x - other.x;
        const dy = this.y - other.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        return distance < (this.width/2 + other.width/2) * 0.8;
    }
}

function initAnimalFight() {
    canvas = document.getElementById('animalCanvas');
    ctx = canvas.getContext('2d');
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    canvas.addEventListener('mousedown', handleCanvasClick);
    canvas.addEventListener('touchstart', handleCanvasTouch, { passive: false });
    
    requestAnimationFrame(gameLoop);

    if (isFirstLoad && typeof showStartupGuide === 'function') {
        isFirstLoad = false;
        showStartupGuide("Tap to make the animals fight", {
            type: 'ghost-tap',
            startX: '30%',
            startY: '40%'
        });
        setTimeout(() => {
            if (animalCount === 0) {
                ghostHand.show('ghost-tap', '70%', '60%');
            }
        }, 2500);
    }
}

function resizeCanvas() {
    const container = document.getElementById('canvas-container');
    const width = container.clientWidth;
    const height = container.clientHeight;
    canvas.width = Math.max(width - 20, 300);
    canvas.height = Math.max(height - 20, 300);
}

function createRipple(x, y) {
    const ripple = document.createElement('div');
    ripple.className = 'ripple-effect';
    ripple.style.left = x + 'px';
    ripple.style.top = y + 'px';
    ripple.style.width = '30px';
    ripple.style.height = '30px';
    document.body.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
}

function handleCanvasClick(event) {
    if (paused || animalCount >= MAX_ANIMALS) return;
    if (typeof ghostHand !== 'undefined') ghostHand.stop();
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    createRipple(event.clientX, event.clientY);
    addAnimal(x, y);
}

function handleCanvasTouch(event) {
    if (paused || animalCount >= MAX_ANIMALS) return;
    event.preventDefault();
    if (typeof ghostHand !== 'undefined') ghostHand.stop();
    const rect = canvas.getBoundingClientRect();
    const touch = event.touches[0];
    const x = touch.clientX - rect.left;
    const y = touch.clientY - rect.top;
    createRipple(touch.clientX, touch.clientY);
    addAnimal(x, y);
}

function addAnimal(x, y) {
    const newAnimal = new Animal(x, y);
    animals.push(newAnimal);
    animalCount++;
    if (typeof soundGenerator !== 'undefined') soundGenerator.playTapSound();
}

function detectCollisions() {
    for (let i = 0; i < animals.length; i++) {
        for (let j = i + 1; j < animals.length; j++) {
            if (animals[i].isColliding(animals[j])) {
                handleCollision(i, j);
                return;
            }
        }
    }
}

function handleCollision(index1, index2) {
    paused = true;
    const remove1 = Math.random() < 0.5;
    const animalToRemove = remove1 ? index1 : index2;
    const winner = remove1 ? animals[index2] : animals[index1];
    const loser = remove1 ? animals[index1] : animals[index2];
    
    announceFightResult(winner.emoji, loser.emoji);
    if (typeof vibrateSuccess === 'function') vibrateSuccess();
    
    const collisionX = (animals[index1].x + animals[index2].x) / 2;
    const collisionY = (animals[index1].y + animals[index2].y) / 2;
    createCelebrationEffect(collisionX, collisionY);
    
    setTimeout(() => {
        animals.splice(animalToRemove, 1);
        animalCount--;
        paused = false;
    }, 1000);
}

function announceFightResult(winnerEmoji, loserEmoji) {
    const winnerName = ANIMAL_NAMES[winnerEmoji] || 'Animal';
    const loserName = ANIMAL_NAMES[loserEmoji] || 'Animal';
    const message = `${winnerName} won against ${loserName}!`;
    if (typeof speakText === 'function') {
        speakText(message, () => {
            if (typeof playAnimalSound === 'function') {
                playAnimalSound(winnerEmoji);
            }
        });
    }
}

function createCelebrationEffect(x, y) {
    // Confetti only (no global popup)
    const container = document.createElement('div');
    container.className = 'confetti-container';
    document.body.appendChild(container);
    const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722'];
    for (let i = 0; i < 50; i++) {
        const piece = document.createElement('div');
        piece.className = 'confetti-piece';
        piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        piece.style.left = Math.random() * 100 + 'vw';
        piece.style.top = -Math.random() * 20 + 'vh';
        container.appendChild(piece);
        piece.animate([
            { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
            { transform: `translateY(110vh) rotate(${Math.random() * 720}deg)`, opacity: 0 }
        ], {
            duration: Math.random() * 2000 + 1000,
            easing: 'cubic-bezier(0, 0.9, 0.57, 1)',
            fill: 'forwards'
        });
    }
    
    setTimeout(() => {
        container.remove();
    }, 3000);
}

function gameLoop() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!paused) {
        for (let i = animals.length - 1; i >= 0; i--) {
            animals[i].update();
            animals[i].draw();
        }
        detectCollisions();
    } else {
        for (let i = 0; i < animals.length; i++) animals[i].draw();
    }
    requestAnimationFrame(gameLoop);
}

window.initAnimalFight = initAnimalFight;
