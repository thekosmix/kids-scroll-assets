// Shared IndexedDB connection - all object stores are defined here in one
// onupgradeneeded handler, since a database can only have one owner of its schema.
const DB_NAME = 'kids-story-db';
const DB_VERSION = 3;

export const STORIES_STORE = 'stories';
export const STATS_STORE = 'stats';
export const FLAGS_STORE = 'flags';

let dbPromise = null;

export function openDb() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORIES_STORE)) {
        db.createObjectStore(STORIES_STORE, { keyPath: 'animal' });
      }
      if (!db.objectStoreNames.contains(STATS_STORE)) {
        db.createObjectStore(STATS_STORE, { keyPath: 'date' });
      }
      if (!db.objectStoreNames.contains(FLAGS_STORE)) {
        db.createObjectStore(FLAGS_STORE, { keyPath: 'id', autoIncrement: true });
      }
    };
    // If another tab has an older version of this DB open, its upgrade would
    // otherwise hang indefinitely waiting for that tab to close - so let a
    // successful connection step aside for a newer one instead of blocking it.
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    req.onblocked = () => console.warn('kids-story-db upgrade blocked by another open tab');
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}
