import { getStoryItem, getAdjacentStory } from './catalog.js';
import { getAnimal } from './animals.js';
import { getRoutineStory } from './routine-stories.js';
import { loadOrCreateStory, regenerateStory, getHistory } from './story-engine.js';
import { markTaleAsPlayed } from './classic-tales.js';
import { parseStory } from './scene-parser.js';
import { Playground } from './playground.js';
import { StoryPlayer, isTtsSupported } from './tts.js';
import { recordPlaySession } from './stats.js';

const PREVIEW_SENTENCES = 3;

const PLAY_ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><polygon points="6 3 20 12 6 21 6 3"></polygon></svg>';
const PAUSE_ICON = '<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"></rect><rect x="14" y="4" width="4" height="16" rx="1"></rect></svg>';

const params = new URLSearchParams(location.search);
const pathname = location.pathname.split('/').pop().replace('.html', '');
const rawStoryId = document.body.dataset.storyId || params.get('story') || params.get('animal') || pathname;

const PET_ANIMAL_IDS = new Set(['dog', 'cat', 'rabbit', 'duck', 'cow', 'horse', 'pig', 'sheep', 'turtle']);

const storyItem = getStoryItem(rawStoryId) || (function() {
  const a = getAnimal(rawStoryId);
  if (a) return { id: a.id, title: a.name, icon: a.emoji, actorEmoji: a.emoji, category: PET_ANIMAL_IDS.has(a.id) ? 'pet-animals' : 'wild-animals', url: `/story/${a.id}-story.html` };
  const r = getRoutineStory(rawStoryId);
  if (r) return { id: r.id, title: r.title, icon: r.icon, actorEmoji: r.actorEmoji || '🧒', category: 'daily-routines', url: `/story/${r.id}.html` };
  return null;
})();

if (!storyItem) {
  location.href = '/story/index.html';
  throw new Error('Unknown story or animal');
}

// Track recently listened stories in localStorage
try {
  const STORAGE_KEY = 'kids_scroll_recent_stories';
  let recent = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  recent = recent.filter((id) => id !== storyItem.id);
  recent.unshift(storyItem.id);
  recent = recent.slice(0, 8);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(recent));
} catch (e) {}

const storyPaneEl = document.getElementById('story-pane');
const storyTitleEl = document.getElementById('story-title');
const storyTextEl = document.getElementById('story-text');
const refreshBtn = document.getElementById('refresh-btn');
const historyBtn = document.getElementById('history-btn');
const speedBtn = document.getElementById('speed-btn');
const playBtn = document.getElementById('play-btn');
const historyOverlay = document.getElementById('history-overlay');
const historyList = document.getElementById('history-list');
const historyClose = document.getElementById('history-close');
const prevAnimalLink = document.getElementById('prev-animal-link');
const nextAnimalLink = document.getElementById('next-animal-link');

// Wire up prev/next navigation links within the current category pointing to static pages
const prevStory = getAdjacentStory(storyItem.id, storyItem.category, -1);
const nextStory = getAdjacentStory(storyItem.id, storyItem.category, 1);

if (prevAnimalLink && prevStory) {
  prevAnimalLink.href = prevStory.url || `/story/${prevStory.file || prevStory.id + '.html'}`;
  prevAnimalLink.title = `Previous: ${prevStory.title}`;
}
if (nextAnimalLink && nextStory) {
  nextAnimalLink.href = nextStory.url || `/story/${nextStory.file || nextStory.id + '.html'}`;
  nextAnimalLink.title = `Next: ${nextStory.title}`;
}

const playground = new Playground(document.getElementById('playground'));
playground.reset(storyItem.actorEmoji || storyItem.icon);

document.getElementById('playground')?.addEventListener('pointerdown', (e) => {
  if (e.target.closest('.playground-actor, .playground-prop')) return;
  const actor = storyItem.actorEmoji || storyItem.icon;
  if (typeof playAnimalSound === 'function' && actor) {
    playAnimalSound(actor);
  }
});

const player = new StoryPlayer({
  onSentenceStart: (cue, index) => {
    playground.showCue(cue);
    highlightSentence(index);
    scrollToSentence(index);
  },
  onDone: () => {
    playground.idle();
    highlightSentence(-1);
    playBtn.innerHTML = PLAY_ICON;
    finishPlaySession();
  },
});

let currentTitle = '';
let currentText = '';
let currentCues = [];
let playStartedAt = null;
let currentFormat = 'story';
try {
  currentFormat = localStorage.getItem('kids_scroll_story_format') || 'story';
} catch (e) {}

function initFormatToggle() {
  const bottomBar = document.querySelector('.bottom-bar');
  if (!bottomBar || document.getElementById('format-toggle-btn')) return;

  const formatBtn = document.createElement('button');
  formatBtn.id = 'format-toggle-btn';
  formatBtn.type = 'button';
  formatBtn.className = 'format-toggle-btn';
  formatBtn.setAttribute('aria-label', currentFormat === 'story' ? 'Switch to Rhyme' : 'Switch to Story');
  formatBtn.innerHTML = currentFormat === 'story' ? '🎵' : '📖';
  formatBtn.title = currentFormat === 'story' ? 'Switch to Rhyme' : 'Switch to Story';

  formatBtn.addEventListener('click', async () => {
    currentFormat = currentFormat === 'story' ? 'rhyme' : 'story';
    try {
      localStorage.setItem('kids_scroll_story_format', currentFormat);
    } catch (err) {}
    formatBtn.innerHTML = currentFormat === 'story' ? '🎵' : '📖';
    formatBtn.setAttribute('aria-label', currentFormat === 'story' ? 'Switch to Rhyme' : 'Switch to Story');
    formatBtn.title = currentFormat === 'story' ? 'Switch to Rhyme' : 'Switch to Story';

    stopPlayback();
    setBusy(true);

    const { title, text } = await regenerateStory(storyItem.id, currentTitle, currentFormat);
    renderStory(title, text);
    setBusy(false);

    if (isTtsSupported()) {
      playBtn.innerHTML = PAUSE_ICON;
      playStartedAt = Date.now();
      player.play(currentCues);
    }
  });

  if (playBtn) {
    bottomBar.insertBefore(formatBtn, playBtn);
  } else {
    bottomBar.appendChild(formatBtn);
  }
}

function finishPlaySession() {
  if (playStartedAt === null) return;
  const elapsed = Date.now() - playStartedAt;
  playStartedAt = null;
  if (elapsed > 500) recordPlaySession(elapsed, storyItem.id).catch(() => {});
}

function stopPlayback() {
  player.stop();
  playground.idle();
  highlightSentence(-1);
  playBtn.innerHTML = PLAY_ICON;
  finishPlaySession();
}

function pausePlayback() {
  player.pause();
  playBtn.innerHTML = PLAY_ICON;
  finishPlaySession();
}

function setBusy(busy) {
  refreshBtn.disabled = busy;
  historyBtn.disabled = busy;
  playBtn.disabled = busy || !currentText;
}

function firstSentences(text, count) {
  const matches = text.match(/[^.!?]*[.!?]+["')\]]?/g) || [text];
  return matches.slice(0, count).join(' ').trim();
}

function highlightSentence(index) {
  const prev = storyTextEl.querySelector('.sentence.active');
  if (prev) prev.classList.remove('active');
  if (index >= 0) {
    const span = storyTextEl.querySelector(`[data-idx="${index}"]`);
    if (span) span.classList.add('active');
  }
}

function scrollToSentence(index) {
  const span = storyTextEl.querySelector(`[data-idx="${index}"]`);
  if (!span) return;
  const paneRect = storyPaneEl.getBoundingClientRect();
  const spanRect = span.getBoundingClientRect();
  const buffer = 24;
  const offScreen = spanRect.bottom > paneRect.bottom - buffer || spanRect.top < paneRect.top + buffer;
  if (offScreen) {
    span.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function renderStory(title, text) {
  currentTitle = title || '';
  currentText = text;
  currentCues = parseStory(text, storyItem.actorEmoji || storyItem.icon);
  storyTitleEl.textContent = title || '';
  storyTextEl.innerHTML = currentCues
    .map((cue, index) => `<span class="sentence" data-idx="${index}">${cue.sentence}</span>`)
    .join(' ');
  storyPaneEl.scrollTop = 0;
  playground.reset(storyItem.actorEmoji || storyItem.icon);
  playBtn.disabled = false;
}

async function init() {
  initFormatToggle();

  // If HTML contains pre-rendered text, initialize from DOM immediately
  const preRenderedText = storyTextEl.textContent.trim();
  const preRenderedTitle = storyTitleEl.textContent.trim();
  if (preRenderedText && !preRenderedText.startsWith('Loading') && !preRenderedText.startsWith('Creating')) {
    renderStory(preRenderedTitle || storyItem.title, preRenderedText);
    if (preRenderedTitle) {
      markTaleAsPlayed(storyItem.id, preRenderedTitle);
    }
  }

  // Load latest or saved story from IndexedDB
  try {
    const { title, text } = await loadOrCreateStory(storyItem.id);
    if (text && text !== currentText) {
      renderStory(title, text);
    }
  } catch (e) {
    console.warn('Could not load saved story, using pre-rendered version', e);
  }
}

refreshBtn.addEventListener('click', async () => {
  stopPlayback();
  setBusy(true);

  const { title, text } = await regenerateStory(storyItem.id, currentTitle, currentFormat);
  renderStory(title, text);
  setBusy(false);

  // Immediately start narration
  if (isTtsSupported()) {
    playBtn.innerHTML = PAUSE_ICON;
    playStartedAt = Date.now();
    player.play(currentCues);
  }
});

const SPEEDS = [0.8, 0.9, 1.0, 1.1];
let currentSpeedIndex = 0;
let speedDirection = 1;

speedBtn?.addEventListener('click', () => {
  currentSpeedIndex += speedDirection;
  if (currentSpeedIndex >= SPEEDS.length - 1) {
    currentSpeedIndex = SPEEDS.length - 1;
    speedDirection = -1;
  } else if (currentSpeedIndex <= 0) {
    currentSpeedIndex = 0;
    speedDirection = 1;
  }
  const speed = SPEEDS[currentSpeedIndex];
  speedBtn.textContent = speed.toFixed(1) + 'x';
  player.setSpeed(speed);
});

playBtn.addEventListener('click', () => {
  if (!isTtsSupported() || !currentText) return;
  if (player.isPlaying) {
    pausePlayback();
    return;
  }
  playBtn.innerHTML = PAUSE_ICON;
  playStartedAt = Date.now();
  const isResuming = player.index > 0 && player.index < player.cues.length;
  if (isResuming) {
    player.resume();
  } else {
    player.play(currentCues);
  }
});

let historyItems = [];

historyBtn.addEventListener('click', async () => {
  historyItems = await getHistory(storyItem.id);
  historyList.innerHTML = historyItems.length
    ? historyItems.map((item, index) => `
        <button class="history-item" data-index="${index}">
          <div class="date">${new Date(item.createdAt).toLocaleDateString()}</div>
          <div class="title">${item.title || 'A Little Story'}</div>
          <div class="preview">${firstSentences(item.text, PREVIEW_SENTENCES)}</div>
        </button>
      `).join('')
    : '<div class="history-empty">No past stories yet.</div>';
  historyOverlay.classList.remove('hidden');
});

historyList.addEventListener('click', (e) => {
  const item = e.target.closest('.history-item');
  if (!item) return;
  const record = historyItems[Number(item.dataset.index)];
  if (!record) return;
  stopPlayback();
  renderStory(record.title, record.text);
  historyOverlay.classList.add('hidden');
});

historyClose.addEventListener('click', () => historyOverlay.classList.add('hidden'));

historyOverlay.addEventListener('click', (e) => {
  if (e.target === historyOverlay) historyOverlay.classList.add('hidden');
});

init();


