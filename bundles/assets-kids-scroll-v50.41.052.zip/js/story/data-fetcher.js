let storyDataCache = null;

export async function fetchStoryData() {
  if (storyDataCache) return storyDataCache;
  try {
    const url = 'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/assets/jsons/story-and-rhymes.json';
    const res = await fetch(url);
    if (res.ok) {
      storyDataCache = await res.json();
      return storyDataCache;
    } else {
      console.warn("Could not fetch story data, status:", res.status);
    }
  } catch (err) {
    console.error("Failed to fetch story data:", err);
  }
  return null;
}
