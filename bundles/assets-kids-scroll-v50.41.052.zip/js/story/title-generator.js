// Derives a short, friendly title for a freshly-generated (non-curated) story,
// since the tiny model only outputs story prose, never a title of its own.
import { parseStory } from './scene-parser.js';

const GENERIC_TITLES = ["'s Little Adventure", "'s Big Day", "'s Happy Surprise", "'s New Friend"];

function capitalize(word) {
  return word.charAt(0).toUpperCase() + word.slice(1);
}

function titleCaseWord(word) {
  return word.split(' ').map(capitalize).join(' ');
}

export function generateTitle(storyText, animalName, animalEmoji) {
  const cues = parseStory(storyText, animalEmoji);
  const animalTitle = capitalize(animalName);

  // Look for a character that's a genuinely different species/character from the
  // main animal - actor1/actor2 slots are assigned by reading order (for animation),
  // so either slot could legitimately hold the main animal itself in some sentences.
  let secondCharacter = null;
  for (const cue of cues) {
    if (cue.actor1Emoji !== animalEmoji) { secondCharacter = null; break; } // some other character narrates first - not a clean "X and Y" pairing
    if (cue.actor2Emoji && cue.actor2Emoji !== animalEmoji) {
      secondCharacter = cue.actor2Word;
      break;
    }
  }
  if (secondCharacter) {
    return `The ${animalTitle} and the ${titleCaseWord(secondCharacter)}`;
  }

  const prop = cues.find((cue) => cue.propWord)?.propWord;
  if (prop) {
    return `The ${animalTitle} and the ${titleCaseWord(prop)}`;
  }

  const generic = GENERIC_TITLES[Math.floor(Math.random() * GENERIC_TITLES.length)];
  return `${animalTitle}${generic}`;
}
