// Local-only listening stats for the parental dashboard. Everything here stays in
// IndexedDB on this device - nothing is ever transmitted anywhere.
import { openDb, STATS_STORE } from './db.js';

function dateKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function tx(db, mode) {
  return db.transaction(STATS_STORE, mode).objectStore(STATS_STORE);
}

function emptyDay(date) {
  return { date, storiesPlayed: 0, listenSeconds: 0, byAnimal: {} };
}

function getDay(db, date) {
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readonly').get(date);
    req.onsuccess = () => {
      const record = req.result;
      // older records (saved before per-animal tracking existed) may be missing byAnimal
      resolve(record ? { ...emptyDay(date), ...record, byAnimal: record.byAnimal || {} } : emptyDay(date));
    };
    req.onerror = () => reject(req.error);
  });
}

/** Call once per completed (or stopped) story playback. */
export async function recordPlaySession(durationMs, animalId) {
  const db = await openDb();
  const date = dateKey();
  const record = await getDay(db, date);
  const seconds = Math.max(0, Math.round(durationMs / 1000));
  record.storiesPlayed += 1;
  record.listenSeconds += seconds;
  if (animalId) {
    const entry = record.byAnimal[animalId] || { plays: 0, seconds: 0 };
    entry.plays += 1;
    entry.seconds += seconds;
    record.byAnimal[animalId] = entry;
  }
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readwrite').put(record);
    req.onsuccess = () => resolve(record);
    req.onerror = () => reject(req.error);
  });
}

/** Returns the last `days` days of stats, oldest first, zero-filled for days with no activity. */
export async function getStatsForRange(days) {
  const db = await openDb();
  const today = new Date();
  const results = [];
  for (let i = days - 1; i >= 0; i -= 1) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    results.push(await getDay(db, dateKey(d)));
  }
  return results;
}

export async function getTodayStats() {
  const [today] = await getStatsForRange(1);
  return today;
}

/** Merges the byAnimal breakdown across a set of day records into one map. */
export function mergeByAnimal(dayRecords) {
  const merged = {};
  for (const day of dayRecords) {
    for (const [animalId, entry] of Object.entries(day.byAnimal || {})) {
      const existing = merged[animalId] || { plays: 0, seconds: 0 };
      existing.plays += entry.plays;
      existing.seconds += entry.seconds;
      merged[animalId] = existing;
    }
  }
  return merged;
}

/** Number of consecutive days (ending today, or yesterday if today has no
 * activity yet since today isn't over) with at least one story listened to. */
export async function getCurrentStreak(maxDays = 60) {
  const db = await openDb();
  const days = [];
  for (let i = 0; i < maxDays; i += 1) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(await getDay(db, dateKey(d)));
  }
  const startIndex = days[0].storiesPlayed === 0 ? 1 : 0;
  let streak = 0;
  for (let i = startIndex; i < days.length; i += 1) {
    if (days[i].storiesPlayed === 0) break;
    streak += 1;
  }
  return streak;
}
