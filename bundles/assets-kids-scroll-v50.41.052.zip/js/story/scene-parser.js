// Rule-based (not model-based) mapping from story sentences to a simple animation cue.
// Tiny SLMs are unreliable at structured output, so scene detection is plain keyword
// matching over the vocabulary these stories actually use - both animal and human
// characters, plus the objects/places they interact with (a tree to climb, a toy to
// play with, a lake to swim in), so scenes read as "someone doing something to/with
// something", not just a single emoji bouncing in place.

const CHARACTER_EMOJI = {
  rabbit: '🐇', bunny: '🐇', hare: '🐇',
  elephant: '🐘',
  lion: '🦁',
  monkey: '🐒',
  dog: '🐶', puppy: '🐶',
  cat: '🐱', kitten: '🐱',
  bear: '🐻',
  duck: '🦆', duckling: '🦆',
  cow: '🐮',
  tiger: '🐯',
  bird: '🐦',
  fish: '🐟',
  frog: '🐸',
  mouse: '🐭', mice: '🐭',
  turtle: '🐢', tortoise: '🐢',
  butterfly: '🦋',
  squirrel: '🐿️',
  fox: '🦊',
  pig: '🐷',
  sheep: '🐑',
  owl: '🦉',
  deer: '🦌',
  goat: '🐐',
  crocodile: '🐊',
  ant: '🐜',
  swan: '🦢',
  giraffe: '🦒',
  zebra: '🦓',
  horse: '🐴', pony: '🐴',
  panda: '🐼',
  kangaroo: '🦘',
  hedgehog: '🦔',
  koala: '🐨',
  camel: '🐫',
  raccoon: '🦝',
  wolf: '🐺',
  chicken: '🐔', hen: '🐔', rooster: '🐔', chick: '🐤',
  whale: '🐳', dolphin: '🐬', seal: '🦭', otter: '🦦',
  snail: '🐌', ladybug: '🐞', spider: '🕷️', snake: '🐍', bee: '🐝', worm: '🪱',
  peacock: '🦚', parrot: '🦜', penguin: '🐧', dove: '🕊️',
  hippo: '🦛', rhino: '🦏',
  girl: '👧',
  boy: '👦',
  child: '🧒', kid: '🧒', children: '🧒', toddler: '🧒', baby: '👶', friend: '🧒', captain: '🧒', superhero: '🧒', prince: '🧒', train: '🚂',
  grandma: '👵', grandpa: '👴',
};

const PROP_EMOJI = {
  lake: '🏞️', pond: '🏞️', river: '🏞️', stream: '🏞️', water: '💧',
  forest: '🌲', jungle: '🌴', woods: '🌲', tree: '🌳', trees: '🌳',
  garden: '🌳', park: '🌳', house: '🏠', home: '🏠',
  hill: '⛰️', mountain: '⛰️', cliff: '⛰️',
  meadow: '🌼', field: '🌼', beach: '🏖️', sand: '🏖️',
  sky: '☁️', cloud: '☁️', cave: '🪨', rock: '🪨', rocks: '🪨',
  nest: '🪹', burrow: '🕳️', hole: '🕳️',
  toy: '🧸', teddy: '🧸', ball: '⚽', kite: '🪁', doll: '🪆', box: '📦',
  basket: '🧺', carrot: '🥕', apple: '🍎', banana: '🍌', berries: '🫐', berry: '🫐',
  food: '🍽️', fruit: '🍎', cookie: '🍪', bone: '🦴', bread: '🍞',
  book: '📖', cake: '🎂', flower: '🌸', flowers: '🌸', leaf: '🍃', leaves: '🍃',
  net: '🕸️', rope: '🪢', bridge: '🌉', boat: '⛵',
  finish: '🏁', race: '🏁',
  sun: '☀️', moon: '🌙', star: '⭐', stars: '⭐', rain: '🌧️', snow: '❄️',
  grass: '🌿', gift: '🎁', present: '🎁', coin: '🪙', key: '🔑',
  bell: '🔔', shell: '🐚', egg: '🥚', umbrella: '☂️', balloon: '🎈',
  candle: '🕯️', lantern: '🏮', drum: '🥁', guitar: '🎸', music: '🎵', song: '🎵',
  crown: '👑', hat: '🎩', map: '🗺️', telescope: '🔭',
  seed: '🌱', seeds: '🌱', pumpkin: '🎃', corn: '🌽', honey: '🍯', milk: '🥛', cheese: '🧀',
  candy: '🍬', chocolate: '🍫',
  bed: '🛏️', door: '🚪', window: '🪟', ladder: '🪜', feather: '🪶', table: '🪑', chair: '🪑',
  toothbrush: '🪥', brush: '🪥', paste: '🪥', toothpaste: '🪥', teeth: '🪥', tooth: '🪥',
  bath: '🛁', tub: '🛁', bathtub: '🛁', sink: '🚰',
  bubble: '🫧', bubbles: '🫧', soap: '🧼', towel: '🧖',
  shoe: '👟', shoes: '👟', sneaker: '👟', sneakers: '👟', boot: '👢', boots: '👢', sock: '🧦', socks: '🧦',
  shirt: '👕', shorts: '🩳', pajamas: '👕', dress: '👗', clothes: '👕', cape: '🦸',
  comb: '🪮', clipper: '✂️', scissors: '✂️', mirror: '🪞',
  car: '🚗', cars: '🚗', block: '🧱', blocks: '🧱', dinosaur: '🦖', crayon: '🖍️', crayons: '🖍️', puzzle: '🧩',
  potty: '🚽', toilet: '🚽', pants: '🩲', underwear: '🩲', flush: '🚾', wipe: '🧻', tissue: '🧻',
  broccoli: '🥦', vegetable: '🥦', vegetables: '🥦', spoon: '🥄', fork: '🍴', plate: '🍽️', bowl: '🥣', soup: '🥣', cup: '🥤',
  backpack: '🎒', school: '🏫', timer: '⏳',
  slide: '🛝', swing: '🛝', soccer: '⚽', bike: '🚲', tricycle: '🚲', scooter: '🛴', helmet: '🪖',
  ladybug: '🐞', bug: '🐛', caterpillar: '🐛', ant: '🐜', snail: '🐌',
  stethoscope: '🩺', dentist: '🦷', bandage: '🩹', barber: '💈',
  cart: '🛒', store: '🏪', stove: '🔥', oven: '🔥',
};

// props that inherently mean "a lot of something", so they always render as a
// cluster of the icon rather than a single one, regardless of grammatical number.
const CLUSTER_PROP_WORDS = new Set(['jungle', 'forest', 'woods', 'meadow', 'field', 'park', 'garden']);
const CLUSTER_SIZE = 3;

// action keyword -> motion preset name (consumed by playground.js)
const ACTION_MOTION = {
  hop: 'hop-across', hopped: 'hop-across', hopping: 'hop-across',
  run: 'run-across', ran: 'run-across', running: 'run-across',
  race: 'run-across', raced: 'run-across', racing: 'run-across',
  chase: 'run-across', chased: 'run-across', chasing: 'run-across',
  jump: 'jump-in-place', jumped: 'jump-in-place', jumping: 'jump-in-place',
  walk: 'walk-across', walked: 'walk-across', walking: 'walk-across',
  swim: 'swim-across', swam: 'swim-across', swimming: 'swim-across',
  fly: 'fly-across', flew: 'fly-across', flying: 'fly-across',
  climb: 'climb-up', climbed: 'climb-up', climbing: 'climb-up',
  sleep: 'sleep', slept: 'sleep', sleeping: 'sleep', napped: 'sleep', napping: 'sleep', rest: 'sleep', rested: 'sleep', resting: 'sleep',
  eat: 'eat', ate: 'eat', eating: 'eat', nibble: 'eat', nibbled: 'eat', bite: 'eat', bit: 'eat',
  play: 'play', played: 'play', playing: 'play', dance: 'play', danced: 'play', dancing: 'play', sing: 'play', sang: 'play', singing: 'play',
  catch: 'jump-in-place', caught: 'jump-in-place', catching: 'jump-in-place',
  throw: 'jump-in-place', threw: 'jump-in-place', throwing: 'jump-in-place',
  hide: 'hide', hid: 'hide', hiding: 'hide',
  smile: 'happy-bounce', smiled: 'happy-bounce', laugh: 'happy-bounce', laughed: 'happy-bounce', laughing: 'happy-bounce',
  happy: 'happy-bounce', help: 'happy-bounce', helped: 'happy-bounce', helping: 'happy-bounce',
  win: 'happy-bounce', won: 'happy-bounce', winning: 'happy-bounce',
  hug: 'happy-bounce', hugged: 'happy-bounce', hugging: 'happy-bounce',
  share: 'happy-bounce', shared: 'happy-bounce', sharing: 'happy-bounce', give: 'happy-bounce', gave: 'happy-bounce',
  find: 'happy-bounce', found: 'happy-bounce', finding: 'happy-bounce', discover: 'happy-bounce', discovered: 'happy-bounce',
  look: 'idle-bounce', looked: 'idle-bounce', looking: 'idle-bounce', watch: 'idle-bounce', watched: 'idle-bounce',
  wave: 'happy-bounce', waved: 'happy-bounce', waving: 'happy-bounce',
  dig: 'eat', dug: 'eat', digging: 'eat',
  build: 'play', built: 'play', building: 'play',
  cook: 'play', cooked: 'play', cooking: 'play', bake: 'play', baked: 'play', baking: 'play',
  paint: 'play', painted: 'play', painting: 'play', draw: 'play', drew: 'play', drawing: 'play',
  write: 'play', wrote: 'play', writing: 'play',
  brush: 'happy-bounce', brushed: 'happy-bounce', brushing: 'happy-bounce',
  wash: 'happy-bounce', washed: 'happy-bounce', washing: 'happy-bounce',
  scrub: 'happy-bounce', scrubbed: 'happy-bounce', scrubbing: 'happy-bounce',
  clean: 'happy-bounce', cleaned: 'happy-bounce', cleaning: 'happy-bounce',
  rinse: 'swim-across', rinsed: 'swim-across', rinsing: 'swim-across',
  dress: 'hop-across', dressed: 'hop-across', dressing: 'hop-across',
  comb: 'happy-bounce', combed: 'happy-bounce', combing: 'happy-bounce',
  trim: 'happy-bounce', trimmed: 'happy-bounce', trimming: 'happy-bounce',
  count: 'idle-bounce', counted: 'idle-bounce', counting: 'idle-bounce',
  listen: 'idle-bounce', listened: 'idle-bounce', listening: 'idle-bounce',
  whisper: 'idle-bounce', whispered: 'idle-bounce', wake: 'idle-bounce', woke: 'idle-bounce', waking: 'idle-bounce',
  roar: 'happy-bounce', roared: 'happy-bounce', roaring: 'happy-bounce',
  growl: 'happy-bounce', growled: 'happy-bounce', bark: 'happy-bounce', barked: 'happy-bounce', barking: 'happy-bounce',
  meow: 'happy-bounce', quack: 'happy-bounce', moo: 'happy-bounce', chirp: 'happy-bounce', chirped: 'happy-bounce', chirping: 'happy-bounce',
  kiss: 'happy-bounce', kissed: 'happy-bounce', tickle: 'happy-bounce', tickled: 'happy-bounce', wag: 'happy-bounce', wagged: 'happy-bounce', wagging: 'happy-bounce',
  ride: 'walk-across', rode: 'walk-across', riding: 'walk-across', drive: 'walk-across', drove: 'walk-across', driving: 'walk-across',
  trot: 'walk-across', trotted: 'walk-across', trotting: 'walk-across',
  skate: 'run-across', skated: 'run-across', skating: 'run-across',
  gallop: 'run-across', galloped: 'run-across', galloping: 'run-across', skip: 'hop-across', skipped: 'hop-across', skipping: 'hop-across',
  splash: 'swim-across', splashed: 'swim-across', splashing: 'swim-across',
  dive: 'swim-across', dove: 'swim-across', diving: 'swim-across', float: 'swim-across', floated: 'swim-across', floating: 'swim-across',
  grow: 'happy-bounce', grew: 'happy-bounce', growing: 'happy-bounce', bloom: 'happy-bounce', bloomed: 'happy-bounce', blooming: 'happy-bounce',
  shine: 'happy-bounce', shone: 'happy-bounce', shining: 'happy-bounce', glow: 'happy-bounce', glowed: 'happy-bounce', sparkle: 'happy-bounce', sparkled: 'happy-bounce',
  spin: 'spin-in-place', spun: 'spin-in-place', spinning: 'spin-in-place',
  roll: 'spin-in-place', rolled: 'spin-in-place', rolling: 'spin-in-place', twirl: 'spin-in-place', twirled: 'spin-in-place', twirling: 'spin-in-place',
  peek: 'hide', peeked: 'hide', peeking: 'hide',
};

const DEFAULT_MOTION = 'idle-bounce';
const IRREGULAR_PLURALS = new Set(['mice', 'children', 'leaves']);

// Returns matches in the order they actually appear in the sentence (not dict
// key order), so "actor1" reliably ends up being whoever is mentioned first.
// Also detects a trailing plural "s"/"es" (or an explicitly-listed irregular
// plural word) so callers can render a small cluster instead of a single emoji.
function allMatches(lowerSentence, dict) {
  const found = [];
  for (const key of Object.keys(dict)) {
    const re = new RegExp(`\\b${key}(es|s)?\\b`);
    const match = re.exec(lowerSentence);
    if (match) {
      const plural = !!match[1] || IRREGULAR_PLURALS.has(match[0]);
      found.push({ word: key, emoji: dict[key], index: match.index, plural });
    }
  }
  found.sort((a, b) => a.index - b.index);
  return found;
}

function firstMatch(lowerSentence, dict) {
  const matches = allMatches(lowerSentence, dict);
  return matches.length ? matches[0] : null;
}

/**
 * @param {string} storyText full story text
 * @param {string} mainAnimalEmoji emoji for the story's title animal (used as fallback actor)
 * @returns {{sentence: string, actor1Emoji: string, actor1Count: number, actor2Emoji: string|null, actor2Word: string|null, actor2Count: number, propEmoji: string|null, propWord: string|null, propCount: number, motion: string}[]}
 */
export function parseStory(storyText, mainAnimalEmoji) {
  const sentences = (storyText.match(/[^.!?]*[.!?]+["')\]]?/g) || [storyText])
    .map((s) => s.trim())
    .filter(Boolean);

  return sentences.map((sentence) => {
    const lower = sentence.toLowerCase();
    const seenEmoji = new Set();
    const characters = allMatches(lower, CHARACTER_EMOJI).filter((c) => {
      if (seenEmoji.has(c.emoji)) return false;
      seenEmoji.add(c.emoji);
      return true;
    });
    const props = allMatches(lower, PROP_EMOJI);
    const prop1 = props[0] || null;
    const prop2 = props.find((p) => p.emoji !== prop1?.emoji) || null;
    // for ACTION_MOTION, the dict "value" is a motion-name string, not an emoji -
    // allMatches/firstMatch are generic, so `.emoji` just holds that mapped value here.
    const motionMatch = firstMatch(lower, ACTION_MOTION);

    const actor1 = characters[0] || null;
    const actor2 = characters.find((c) => c.emoji !== actor1?.emoji) || null;
    const prop1IsCluster = prop1 && (prop1.plural || CLUSTER_PROP_WORDS.has(prop1.word));
    const prop2IsCluster = prop2 && (prop2.plural || CLUSTER_PROP_WORDS.has(prop2.word));

    let motion = motionMatch?.emoji || DEFAULT_MOTION;
    
    // Apply compound motion logic based on presence of props
    if (prop1) {
      if (motion === 'jump-in-place') {
        motion = 'jump-to-prop';
      } else if (motion === 'eat') {
        motion = 'move-and-eat';
      } else if (motion === 'sleep') {
        motion = 'move-and-sleep';
      } else if (motion === 'hide') {
        motion = 'move-and-hide';
      } else if (motion === 'idle-bounce' && motionMatch) {
        motion = 'move-to-prop'; // fallback for 'look', 'watch', etc.
      }
    }

    return {
      sentence,
      actor1Emoji: actor1?.emoji || mainAnimalEmoji,
      actor1Count: actor1?.plural ? CLUSTER_SIZE : 1,
      actor2Emoji: actor2?.emoji || null,
      actor2Word: actor2?.word || null,
      actor2Count: actor2?.plural ? CLUSTER_SIZE : 1,
      propEmoji: prop1?.emoji || null,
      propWord: prop1?.word || null,
      propCount: prop1IsCluster ? CLUSTER_SIZE : 1,
      prop2Emoji: prop2?.emoji || null,
      prop2Word: prop2?.word || null,
      prop2Count: prop2IsCluster ? CLUSTER_SIZE : 1,
      motion,
    };
  });
}
