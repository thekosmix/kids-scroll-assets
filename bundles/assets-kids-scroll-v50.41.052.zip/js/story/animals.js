// Shared animal catalog: id, display name, emoji used both as the home-grid icon
// and as the "actor" emoji in the story playground.
export const ANIMALS = [
  { id: 'rabbit', name: 'Rabbit', emoji: '🐇' },
  { id: 'elephant', name: 'Elephant', emoji: '🐘' },
  { id: 'lion', name: 'Lion', emoji: '🦁' },
  { id: 'monkey', name: 'Monkey', emoji: '🐒' },
  { id: 'dog', name: 'Dog', emoji: '🐶' },
  { id: 'cat', name: 'Cat', emoji: '🐱' },
  { id: 'bear', name: 'Bear', emoji: '🐻' },
  { id: 'duck', name: 'Duck', emoji: '🦆' },
  { id: 'cow', name: 'Cow', emoji: '🐮' },
  { id: 'tiger', name: 'Tiger', emoji: '🐯' },
  { id: 'giraffe', name: 'Giraffe', emoji: '🦒' },
  { id: 'zebra', name: 'Zebra', emoji: '🦓' },
  { id: 'horse', name: 'Horse', emoji: '🐴' },
  { id: 'panda', name: 'Panda', emoji: '🐼' },
  { id: 'fox', name: 'Fox', emoji: '🦊' },
  { id: 'pig', name: 'Pig', emoji: '🐷' },
  { id: 'sheep', name: 'Sheep', emoji: '🐑' },
  { id: 'kangaroo', name: 'Kangaroo', emoji: '🦘' },
  { id: 'turtle', name: 'Turtle', emoji: '🐢' },
  { id: 'penguin', name: 'Penguin', emoji: '🐧' },
];

export function getAnimal(id) {
  return ANIMALS.find((a) => a.id === id) || null;
}
