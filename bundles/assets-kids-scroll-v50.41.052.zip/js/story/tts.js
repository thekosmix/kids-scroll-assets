// Reads a story aloud sentence-by-sentence using the Web Speech API (delegates to
// Android's on-device TTS engine - works offline once voice data exists on device).
// Speaking one utterance per sentence (rather than the whole story at once) gives a
// simple, reliable point to advance the playground animation - no need to depend on
// per-word "boundary" events, which behave inconsistently across OEM TTS engines.

export class StoryPlayer {
  constructor({ onSentenceStart, onDone }) {
    this.onSentenceStart = onSentenceStart;
    this.onDone = onDone;
    this.cues = [];
    this.index = 0;
    this.playing = false;
    // speechSynthesis.cancel() fires the interrupted utterance's onend/onerror
    // asynchronously - without this, that stray callback would advance `index`
    // even for an intentional pause/stop, corrupting where resume()/play() land.
    // Each _speakNext() call stamps its utterance with the current id; a
    // callback only counts if that id is still current when it fires.
    this._utteranceId = 0;
    this.speedMultiplier = 0.8;
    this._currentUtterance = null;
    if (typeof window !== 'undefined' && !window.__storyUtterances) {
      window.__storyUtterances = [];
    }
  }

  get isPlaying() {
    return this.playing;
  }

  get isPaused() {
    return !this.playing && this.index > 0 && this.index < this.cues.length;
  }

  setSpeed(multiplier) {
    this.speedMultiplier = multiplier;
    if (this.playing) {
      // If currently playing, restart the current sentence with new speed
      this.pause();
      this.resume();
    }
  }

  play(cues) {
    this.stop();
    this.cues = cues;
    this.index = 0;
    this.playing = true;
    this._speakNext();
  }

  /**
   * Appends additional sentence cues dynamically while playback is underway.
   * Enables progressive multi-scene narration without restarting or audio stutter.
   */
  appendCues(newCues) {
    if (!Array.isArray(newCues) || newCues.length === 0) return;
    const wasAtEnd = this.index >= this.cues.length;
    this.cues = this.cues.concat(newCues);
    if (this.playing && wasAtEnd) {
      this._speakNext();
    }
  }

  /** Cancels speech but keeps the current sentence index, so resume() picks up from here. */
  pause() {
    this._utteranceId += 1;
    this.playing = false;
    this._currentUtterance = null;
    window.speechSynthesis.cancel();
  }

  /** Continues from wherever pause() left off (re-reads that sentence from its start). */
  resume() {
    if (!this.cues.length || this.index >= this.cues.length) return;
    this.playing = true;
    this._speakNext();
  }

  /** Full stop - resets position, used when switching to a different story entirely. */
  stop() {
    this._utteranceId += 1;
    this.playing = false;
    this.index = 0;
    this._currentUtterance = null;
    window.speechSynthesis.cancel();
  }

  _speakNext() {
    if (!this.playing) return;
    if (this.index >= this.cues.length) {
      this.playing = false;
      this.onDone && this.onDone();
      return;
    }
    const cue = this.cues[this.index];
    this.onSentenceStart && this.onSentenceStart(cue, this.index);

    this._utteranceId += 1;
    const myUtteranceId = this._utteranceId;

    const cleanSentence = cue.sentence
      .replace(/[\p{Extended_Pictographic}\uFE0F\u200D\u20E3]/gu, '')
      .replace(/\s+([.,!?:;])/g, '$1')
      .replace(/\s{2,}/g, ' ')
      .trim();
    const utterance = new SpeechSynthesisUtterance(cleanSentence || cue.sentence);
    // Base rate is 0.90, adjust it based on the speed multiplier
    utterance.rate = 0.85 * this.speedMultiplier;
    utterance.pitch = 1.05;

    // Retain reference to prevent premature garbage collection mid-speech
    this._currentUtterance = utterance;
    if (typeof window !== 'undefined' && window.__storyUtterances) {
      window.__storyUtterances.push(utterance);
    }

    const advance = () => {
      if (typeof window !== 'undefined' && window.__storyUtterances) {
        const uIdx = window.__storyUtterances.indexOf(utterance);
        if (uIdx > -1) window.__storyUtterances.splice(uIdx, 1);
      }
      if (this._currentUtterance === utterance) {
        this._currentUtterance = null;
      }
      if (myUtteranceId !== this._utteranceId) return; // superseded by a pause/stop/new play
      this.index += 1;
      this._speakNext();
    };
    utterance.onend = advance;
    utterance.onerror = advance;
    window.speechSynthesis.speak(utterance);
  }
}

export function isTtsSupported() {
  return 'speechSynthesis' in window;
}
