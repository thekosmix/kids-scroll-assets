// Local-only "flag this story" feedback. Nothing is ever transmitted anywhere -
// flagged stories just sit in IndexedDB on this device so a parent (or the
// developer, if shared manually) can review what the model got wrong.
import { openDb, FLAGS_STORE } from './db.js';

function tx(db, mode) {
  return db.transaction(FLAGS_STORE, mode).objectStore(FLAGS_STORE);
}

export async function recordFlag(animalId, title, text) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readwrite').add({
      animalId,
      title,
      text,
      createdAt: Date.now(),
    });
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function getFlags() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readonly').getAll();
    req.onsuccess = () => resolve(req.result.sort((a, b) => b.createdAt - a.createdAt));
    req.onerror = () => reject(req.error);
  });
}
