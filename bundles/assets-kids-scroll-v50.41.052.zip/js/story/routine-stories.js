// 40 Curated Routine & Behavioral Story Topics across 8 Categories
// Each topic has 5 distinct, high-quality, positive-reinforcement story variations (200 stories total).

export const ROUTINE_STORIES = {
  "toothpaste-train": {
    "id": "toothpaste-train",
    "title": "The Toothpaste Train",
    "subtitle": "Chugga-chugga brush away the sugar bugs!",
    "icon": "🪥",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "daily-routines",
    "stories": [
      {
        "title": "The Toothpaste Train",
        "text": "Once upon a time, it was bedtime, and a little child stood by the bathroom sink. In marched a bright blue toothbrush shaped like a train! \"All aboard the Toothpaste Train!\" said the brush with a squeeze of minty paste. The brush chugged up to the top teeth: \"Chugga-chugga front, chugga-chugga back!\" It tickled the chewing teeth and swept away the tiny sugar bugs. \"Now open wide for the bottom track!\" giggled the little train. Round and round went the soft bristles, making rich white bubbles. The child smiled in the mirror, watching the happy bubbles grow. Then the train gave a gentle sweep over the sleepy tongue. \"Choo-choo! Station stop!\" called the toothbrush. The child rinsed with clean water and spit with a joyful splash. Every tooth was shining bright like little stars in the night sky. \"Good job, super brusher!\" cheered Mommy, and off to bed they danced with the freshest smile."
      },
      {
        "title": "The Sparkle Toothbrush Hero",
        "text": "Once upon a time, a brave little knight had a mission: protect the Pearly Kingdom! The magical glowing toothbrush was the knight's magical wand. \"Swish-swish went the bristles over the kingdom gates!\" Front teeth got a gentle circular polish, top teeth got a sweeping slide, and back molars got a happy tickle. \"Bye-bye, sticky crumbs!\" whispered the bristles. The child rinsed with a big cup of fresh water: Swish, gargle, spit! The mirror reflected a dazzling, pearly white grin. The kingdom was safe, clean, and ready for sweet dreams."
      },
      {
        "title": "Tickle the Teeth Monster",
        "text": "Once upon a time, two rows of happy little teeth were waiting for their evening bubble party. \"Here comes the foamy brush!\" sang Daddy. Tickle-tickle on the left, tickle-tickle on the right! The little bristles danced to a happy 2-minute rhythm: \"Brush the tops, brush the sides, brush where the sneaky sandwich hides!\" The child giggled as tiny strawberry-flavored bubbles filled the sink. A quick rinse, a big spit, and every tooth sparkled bright like polished sea shells."
      },
      {
        "title": "The Toothbrush Rocket",
        "text": "Once upon a time, a bright yellow toothbrush rocket prepared for blast-off at the bathroom sink. \"3, 2, 1, scrub off!\" The rocket zoomed to the upper galaxy of teeth, brushing away galactic crumbs. Then it circled the bottom planets: orbit left, orbit right! Soft bristles made foamy white space clouds. The child counted to ten as the brush cleaned the rear star-molars. \"Mission accomplished!\" cheered the child, rinsing with cool water and flashing a shiny astronaut smile."
      },
      {
        "title": "The Singing Bristles",
        "text": "Once upon a time, a friendly green toothbrush loved to hum gentle lullabies. As it touched the front teeth, it hummed: \"Hum-hum-hum, keep gums strong!\" As it reached the chewing teeth, it swept: \"Swish-swish-swish, bedtime song!\" The gentle bristles tickled away every speck of bedtime snack. With a gentle tongue-brush and a splash of water, the mouth felt cool, minty, and wonderfully clean for the night."
      }
    ]
  },
  "bubble-bath": {
    "id": "bubble-bath",
    "title": "Splish-Splash Bubble Bath",
    "subtitle": "Bath time fun with gentle soap bubbles!",
    "icon": "🛁",
    "actorEmoji": "👶",
    "age": "1+",
    "category": "daily-routines",
    "stories": [
      {
        "title": "Splish-Splash Bubble Bath",
        "text": "Once upon a time, warm water filled the big porcelain tub with gentle swooshing sounds. In went a pour of bubbly soap: poof! A gigantic mountain of warm, fluffy bubbles appeared. A little yellow rubber ducky bobbed happily on top of the waves: \"Quack, quack, jump in!\" The child stepped in, feeling the warm, cozy water hug their toes. Mommy made a silly bubble hat on the child's head and a giant bubble beard on their chin! They laughed and popped the floating bubbles: pop, pop, pop! The soft washcloth washed away sandbox dirt and sticky popsicle hands. \"Time to rinse!\" said Mommy, gently pouring warm water over shoulders without a single drop in the eyes. Wrapped in a big, fluffy dinosaur towel, the child felt cozy, squeaky clean, and smelling like lavender."
      },
      {
        "title": "The Bubble Castle Expedition",
        "text": "Once upon a time, the bathtub turned into a sparkling blue ocean with bubble clouds floating in the sky. The little toy boat sailed across the warm water, dodging foam mountains. The child scooped up a handful of foam and blew: whoosh! Tiny rainbow bubbles floated through the air and landed with soft pops on the water. Arms, belly, and knees got a tickly lather with a soft yellow sponge. After a warm rinse, out stepped the happiest, cleanest explorer in town."
      },
      {
        "title": "Warm Water Lullaby",
        "text": "Once upon a time, the evening bath was calm and peaceful. The warm water made tired little legs feel light as feathers. Gentle lavender soap made soft clouds that floated from elbow to knee. Rubber ducky gently sailed across the calm tub. With a warm cup of water, gentle rinses washed away the day's play. Snuggled in a soft hooded towel, warm and relaxed, the child was ready for the sweetest slumber."
      },
      {
        "title": "Captain Duck and the Foam Island",
        "text": "Once upon a time, Captain Duck led a brave bath time adventure across Tub Bay. \"Ahoy, foam ahead!\" called the captain. The child built huge foam castles on the tub wall, drawing smiley faces with suds. The soapy sponge tickled little toes and scrubbed elbows clean. \"Splash, splash, all clean!\" With a warm towel wrap and a cozy hug, the little sailor was ready for cozy story time."
      },
      {
        "title": "The Rainbow Splash Party",
        "text": "Once upon a time, colorful bath toys floated across a tub filled with warm, fragrant water. The child poured water from a blue cup to a red cup: trickle, trickle, splash! Gentle soap bubbles tickled their nose: achoo! Mommy rinsed the child's hair with a gentle visor, keeping every drop safe and dry. Squeaky clean from ears to toes, the child wrapped up like a warm little burrito in a soft towel."
      }
    ]
  },
  "toy-cleanup": {
    "id": "toy-cleanup",
    "title": "Where Do the Toys Sleep?",
    "subtitle": "Time to tuck all the toys into their bins!",
    "icon": "🧸",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "daily-routines",
    "stories": [
      {
        "title": "Where Do the Toys Sleep?",
        "text": "Once upon a time, the living room rug was covered with wooden blocks, zooming cars, and cuddly teddy bears. But the clock said it was time for cleanup before dinner! \"Where do the cars sleep?\" asked Daddy. \"In the blue garage bin!\" cheered the child, zooming the red race car right into the box: vroom, park! \"Where do the blocks sleep?\" \"In the big green tower box!\" Clink, clank, in went the wooden squares. The soft teddy bear was tucked into the cozy book basket with a gentle pat: \"Goodnight, teddy!\" In just three minutes of fun matching, the rug was clean, wide, and clear. \"Look at our superhero room!\" smiled Mommy with a high-five. Everything was resting in its home, safe and sound for tomorrow's games."
      },
      {
        "title": "The Magic Toy Train Bin",
        "text": "Once upon a time, the toy bins became a big freight train waiting for cargo. \"Chugga-chugga, train is loading!\" sang the child. In hopped the puzzle pieces: clack! In rolled the bouncy balls: boing, boing! The child scooped up the colorful crayons and placed them in their tin. With each toy put away, the room looked brighter and bigger. The floor was clear and safe to walk on, and the toys were all resting happily in their bins."
      },
      {
        "title": "The Tidy Superhero Challenge",
        "text": "Once upon a time, a superhero with a magic cape had a super challenge: clean the playroom before the timer beeped! The superhero picked up five yellow blocks in one scoop: whoosh! Then three toy animals leaped into their basket: hop, hop, hooray! The puzzle pieces clicked into their wooden board. \"Done with one minute to spare!\" cheered the superhero. A tidy room meant lots of space for morning superhero dances."
      },
      {
        "title": "The Bedtime Lullaby for Blocks",
        "text": "Once upon a time, the tall wooden block castle looked very sleepy after a long day of play. \"Time to tuck the blocks into their basket bed,\" whispered the child. Clink, clank, one by one, the red, blue, and yellow blocks snuggled into their wooden chest. The picture books stacked neatly on the low shelf like sleepy owls. The room felt calm, peaceful, and ready for a good night's rest."
      },
      {
        "title": "The Color Basket Game",
        "text": "Once upon a time, Mommy held three baskets: red, blue, and green. \"Can the cleanup superhero find all the red toys first?\" The child dashed across the rug, picking up the red car, red block, and red ball: plop! Next came the blue toys: zoom! In two joyful minutes, the floor was shining clean. The child clapped their hands, proud of their tidy, cozy room."
      }
    ]
  },
  "big-kid-bed": {
    "id": "big-kid-bed",
    "title": "The Big Kid Bed",
    "subtitle": "A cozy starry night in your very own bed!",
    "icon": "🛏️",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "daily-routines",
    "stories": [
      {
        "title": "The Big Kid Bed",
        "text": "Once upon a time, a brand new bed arrived with soft blue sheets and a fluffy cloud pillow. \"Look at your big kid bed!\" cheered Mommy and Daddy. The child climbed up the small wooden step: it was cozy, roomy, and just right! A little bear night light glowed softly by the wall, casting a warm golden light. Teddy snuggled right under the starry blanket beside the child. Mommy read a gentle story about a sleeping moon, and Daddy gave two butterfly kisses on each cheek. \"You are safe, loved, and brave,\" whispered Daddy. The child closed their eyes, feeling the soft mattress hold them snug. Outside, the twinkling stars smiled through the window, and sweet dreams drifted in until morning sun."
      },
      {
        "title": "The Starry Night Fort",
        "text": "Once upon a time, the big kid bed turned into a cozy starship sailing through dreamland. With soft blankets tucked around toes and favorite stuffed bunny in arm, the child looked out at the gentle night light. The house was quiet and peaceful. The child took three deep, slow belly breaths: in and out. Warm and cozy, the child drifted off into a magical dream of flying with friendly cloud birds."
      },
      {
        "title": "Brave Little Sleeper",
        "text": "Once upon a time, a little boy wondered if his big bed was too big. But when he snuggled under the warm quilt, his toes felt toasty and safe. \"My bed is my own cozy castle,\" he whispered. The soft night light kept the room friendly and warm. He closed his eyes and listened to the gentle hum of the house. With a happy sigh, he slept peacefully all through the starry night."
      },
      {
        "title": "Teddy's Slumber Party",
        "text": "Once upon a time, Teddy and Bunny had an official invitation to the big kid bed slumber party. The child arranged their pillows in a cozy row. Mommy tucked the soft blanket all the way up to Teddy's chin. \"Goodnight, room; goodnight, moon,\" they whispered together. The big kid bed was the warmest spot in the world, and sleep arrived with a gentle smile."
      },
      {
        "title": "The Morning Sunshine Club",
        "text": "Once upon a time, a little girl loved waking up in her big kid bed when the golden morning sun peeeeked through the curtains. She had slept all through the night like a champ! She stretched her arms up high, hugged her pillow, and gave Mommy a big morning smile. \"I slept in my own big bed all night!\" she cheered proudly."
      }
    ]
  },
  "shoes-and-clothes": {
    "id": "shoes-and-clothes",
    "title": "Left Shoe, Right Shoe",
    "subtitle": "Two happy shoes finding their correct feet!",
    "icon": "👟",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "daily-routines",
    "stories": [
      {
        "title": "Left Shoe, Right Shoe",
        "text": "Once upon a time, two sneakers sat by the door waiting for morning playground time. Inside each shoe was half of a smiling kitten sticker. \"When our shoes kiss, the kitten smiles!\" remembered the child. The child placed the shoes side by side until the kitten sticker matched: perfect! In slipped the left foot: wiggle, push, click! The velcro strap went zzzip! In slipped the right foot: wiggle, push, zzzip! \"Look, Mommy, I put on my own shoes!\" cheered the child, doing a happy stomping dance on the rug: tap, tap, tap! Next came the cozy blue jacket: arms through the tunnel sleeves, one and two! Fully dressed like a superstar, the child was ready to conquer the park."
      },
      {
        "title": "The Sleeve Tunnel Adventure",
        "text": "Once upon a time, getting dressed was a fun safari through clothing caves. \"Here goes the train through the shirt tunnel!\" called the child. Pop went the head through the neck hole with a peek-a-boo smile! In went the left arm: zoom! In went the right arm: zoom! Next came the comfy pants: two legs stepping through the pants tunnels like a champion. Dressed all by themselves, the little explorer was ready for the day."
      },
      {
        "title": "The High-Five Shoes",
        "text": "Once upon a time, two red sneakers loved to give each other a high-five before walking out the door. The child aligned the inner curves: when they touched, they were ready to go! Left foot pushed in with a stomp, right foot pushed in with a stomp. The velcro snapped closed with a satisfying crunch. Stomp, stomp, hop! Ready to run fast as the wind in the sunny garden."
      },
      {
        "title": "The Super Sock Monster",
        "text": "Once upon a time, two colorful dinosaur socks were looking for wiggly toes. \"Nom, nom, nom!\" giggled Daddy as the sock slid over the heel. The child pulled the cuff up high: one, two! Now the feet were warm and ready for sneakers. The child pushed their heels in with pride: \"I did it all by myself!\""
      },
      {
        "title": "Button and Zip Champions",
        "text": "Once upon a time, a cozy yellow raincoat had three big buttons and a shiny zipper. The child held the zipper pull and zipped it up to the collar: zzzip! Then they slipped into bright yellow rainboots: plop, plop! Ready for puddle-jumping fun, dressed independently with a proud, sunny grin."
      }
    ]
  },
  "hand-washing": {
    "id": "hand-washing",
    "title": "The Bubble Monster",
    "subtitle": "Wash hands with soap to send germs away!",
    "icon": "🧼",
    "actorEmoji": "🧒",
    "age": "1+",
    "category": "daily-routines",
    "stories": [
      {
        "title": "The Bubble Monster",
        "text": "Once upon a time, after a busy morning making mud pies in the sandbox, little hands were full of dirt and invisible playground germs. \"Time for the Bubble Monster to help!\" said Mommy. The child stepped on the wooden stool and turned on the tap: warm water splashed over fingers. Squeeze went the soap pump! The child rubbed palms together, making fluffy white soap mittens. \"Rub the tops, scrub between fingers, twist the thumbs, and clean under the nails!\" They sang the ABC song together while the bubbles grew bigger and foamy. Then, under the warm stream of water: swoosh! The bubbles washed away down the drain, taking every speck of dirt with them. The child dried hands with a soft blue towel until they were warm and dry. Clean hands were ready for crunchy apple slices!"
      },
      {
        "title": "The 20-Second Soap Party",
        "text": "Once upon a time, two hands wanted to throw a foam party at the bathroom sink. The warm water splashed, and one drop of bubble-gum soap joined in. Swish-swish went the palms, scratch-scratch on the fingertips, and tickle-tickle around the wrists! By the time they sang \"Happy Birthday\" twice, hands were covered in rich, fragrant foam. A warm rinse sent all germs swimming down the drain. Squeaky clean and smelling fresh!"
      },
      {
        "title": "The Soap Superhero Shield",
        "text": "Once upon a time, soap bubbles created a super invisible shield on toddler hands. Whenever the child washed hands before eating lunch, the soap bubbles swept away sneaky sandbox dust: \"Away you go, dust bugs!\" With clean, dry hands, the superhero sat down at the table, proud and ready to enjoy delicious lunch."
      },
      {
        "title": "Splish-Splash Sink Fun",
        "text": "Once upon a time, the faucet was a gentle waterfall. The child loved turning the knob and watching water trickle over fingers. One pump of foamy soap made two fluffy white snow gloves! Rubbing fingers together made tiny rainbow bubbles. A warm rinse and a soft towel pat made little hands fresh, clean, and ready for drawing."
      },
      {
        "title": "The Handwashing Song",
        "text": "Once upon a time, a little song played whenever water turned on at the sink: \"Top and bottom, in between, wash until your hands are clean!\" The child rubbed fingers like playing the piano in the foam. With a quick swoosh in the warm water, all bubbles said goodbye. Clean hands gave Mommy a happy high-five!"
      }
    ]
  },
  "hair-nail-trim": {
    "id": "hair-nail-trim",
    "title": "The Gentle Hair & Nail Trim",
    "subtitle": "Ten little fingers getting a gentle trim!",
    "icon": "✂️",
    "actorEmoji": "🧒",
    "age": "1+",
    "category": "daily-routines",
    "stories": [
      {
        "title": "The Gentle Hair & Nail Trim",
        "text": "Once upon a time, it was grooming time on Mommy's lap. The soft bristles of the baby brush went stroke, stroke over the child's head. It felt like gentle finger tickles. \"Now let's check your ten little musical fingers!\" said Mommy. The little clipper went soft click-click on the thumb: \"Tickle one!\" Click-click on the pointer finger: \"Tickle two!\" The child watched calmly while holding their soft stuffed bunny. Not a single pinch, just gentle little clicks that made nails smooth and neat so they wouldn't scratch during sleep. Mommy put a drop of sweet lotion on little hands and gave a butterfly kiss to each fingertip. \"All done, brave little champion!\" cheered Mommy, and they high-fived with smooth, happy hands."
      },
      {
        "title": "The Magic Hairbrush Gentle Dance",
        "text": "Once upon a time, a wide-toothed comb had a gentle mission: smooth out sleepy morning curls. With a light mist of sweet water that smelled like flowers, the comb glided softly from roots to tips. \"Stroke, stroke, soft as a kitten!\" The child looked in the mirror, smiling as their curls shone like golden sunshine. Grooming was easy, calm, and cozy."
      },
      {
        "title": "Tickly Finger Rhyme",
        "text": "Once upon a time, ten little fingers played a counting game on Daddy's knee. With each gentle clip-clip of the tiny nail trimmer, Daddy made a funny sound: \"Boop on the pinky! Boop on the ring finger!\" The child giggled at the funny sounds. In two quick minutes, all ten fingernails were trimmed smooth, rounded, and ready for building block towers."
      },
      {
        "title": "The Barber Cape Superhero",
        "text": "Once upon a time, the child wore a shiny blue cape for a quick hair trim. Snip-snip went the safety scissors around the ears, light as a feather. A soft brush tickled the back of the neck to sweep away stray hairs. In the mirror, the child saw a handsome, neat superhero smiling back. A big hug sealed the deal!"
      },
      {
        "title": "Smooth Nails and Butterfly Hugs",
        "text": "Once upon a time, sitting under the warm living room lamp after bath time, Mommy gently filed a tiny rough nail with a soft emery board: swish, swish. It felt tickly and soothing. The child counted along: \"One, two, three, four, five!\" Soft lotion made hands feel like velvet clouds. Ready for sweet, cozy bedtime snuggles."
      }
    ]
  },
  "tummy-bell": {
    "id": "tummy-bell",
    "title": "Listen to the Tummy Bell",
    "subtitle": "Pause the game when your body says \"It's time!\"",
    "icon": "⏰",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "potty-training",
    "stories": [
      {
        "title": "Listen to the Tummy Bell",
        "text": "Once upon a time, Leo was building the tallest block tower in the world. Suddenly, a little feeling in his tummy went ding-dong! \"The tummy bell is ringing!\" remembered Leo. He wanted to finish his tower, but he knew blocks can wait. \"I will be right back, blocks!\" he said. He zoomed straight to the bathroom, pulled down his shorts, and sat on the potty. Psssssh! He went pee right into the potty! \"Hooray!\" cheered Mommy, giving him a big high-five. Leo washed his hands with bubbly soap, dried them, and ran back to his tower. Listening to his body made him feel like a big kid superstar."
      },
      {
        "title": "The Pause Button Power",
        "text": "Once upon a time, Mia was playing tag with her puppy. Her tummy felt tight and wiggly. Mia knew her body had a secret superpower: the Pause Button! She pressed her imaginary button: \"Freeze, game!\" Mia ran to the toilet, sat down calmly, and went pee-pee. She flushed the toilet: whoosh! Then she unpaused her game and ran outside, feeling light, happy, and dry."
      },
      {
        "title": "The Tummy Whisper",
        "text": "Once upon a time, Sam heard a tiny whisper inside his belly: \"Time to go potty!\" Sam stopped coloring his dinosaur picture. He walked to the bathroom and sat on his little green potty. Clink! He made a pee-pee! Sam wiped, flushed, and washed his hands. When he returned to his coloring book, the dinosaur seemed to smile at the big kid artist."
      },
      {
        "title": "The Potty Express Train",
        "text": "Once upon a time, the Potty Express was ready to depart from Playroom Station. \"Choo-choo, all passengers with full tummies aboard!\" called Daddy. The child chugged down the hallway straight into the bathroom. Sitting on the potty, the child took a deep breath and relaxed. Success! The whistle blew: \"Hooray for the clean, dry Potty Express!\""
      },
      {
        "title": "Super Body Signals",
        "text": "Once upon a time, superheroes knew that listening to body signals is the most important skill. When the superhero felt the potty wiggle, they stopped flying their toy jet immediately. In the bathroom, they did their business like a champion. Clean underwear stayed dry all day long, proving superheroes always listen to their bodies."
      }
    ]
  },
  "potty-crown": {
    "id": "potty-crown",
    "title": "The Potty Crown",
    "subtitle": "Sitting on the royal potty like a champion!",
    "icon": "👑",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "potty-training",
    "stories": [
      {
        "title": "The Potty Crown",
        "text": "Once upon a time, a shiny golden paper crown sat on the bathroom shelf. It was the Royal Potty Crown! Whenever the little prince or princess sat on the potty chair, they got to wear the crown and hold the royal storybook. The child sat calmly, resting feet flat on the floor. In went the pee: tinkle, tinkle! \"All hail the Potty Champion!\" sang Mommy with a royal dance. The child pressed the shiny silver flush handle: whoosh went the water, waving goodbye to the pee. Wearing the shiny crown, the child washed hands with royal bubbles, feeling very proud and grown-up."
      },
      {
        "title": "The Royal Flush Fanfare",
        "text": "Once upon a time, the big toilet was not scary at all—it was a magical throne! With a comfy toddler seat reducer on top, the child climbed up the sturdy step stool. They sat like a king, singing a happy royal song. When they finished, they gave the silver handle a firm push: whoosh! The swirling water carried everything away. \"Goodbye, pee!\" waved the child with a bright, happy smile."
      },
      {
        "title": "The Golden Potty Sticker",
        "text": "Once upon a time, every successful visit to the potty throne earned a sparkling star sticker on the royal chart. The child sat patiently, relaxed their tummy, and went poop in the potty! Mommy clapped and handed over a glittery gold star. The chart was filling up fast, and the big kid felt like the proudest king in the castle."
      },
      {
        "title": "The Throne of Bravery",
        "text": "Once upon a time, a little girl was nervous about the loud flushing sound of the big toilet. Daddy showed her the magic trick: \"We say 1, 2, 3, bye-bye!\" When the flush went whoosh, they clapped together. The sound became a fun celebratory cheer. Sitting on the throne was now her favorite milestone."
      },
      {
        "title": "The Potty Champion Parade",
        "text": "Once upon a time, teddy bear, bunny, and toy puppy lined up outside the bathroom door. They were holding a parade for the Potty Champion! The child walked out with clean, dry pants and washed hands. The toy animals cheered: \"Hip, hip, hooray!\" Using the potty was a big step that everyone celebrated."
      }
    ]
  },
  "big-kid-underwear": {
    "id": "big-kid-underwear",
    "title": "Big Kid Underwear Day",
    "subtitle": "Saying goodbye to diapers with cool superhero pants!",
    "icon": "🩲",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "potty-training",
    "stories": [
      {
        "title": "Big Kid Underwear Day",
        "text": "Once upon a time, a colorful box arrived in the mail. Inside were five pairs of bright, soft big kid underwear! One had red fire trucks, one had green dinosaurs, and one had shining yellow stars. \"Bye-bye, bulky diapers!\" cheered the child. In slipped the left leg, in slipped the right leg: pull up to the waist! It felt so light, soft, and comfy. \"My job is to keep my dinosaur pants clean and dry!\" said the child proudly. Every time the tummy felt full, they zoomed straight to the potty. At the end of the day, the dinosaur pants were still completely dry. \"You are growing so big!\" hugged Daddy with pride."
      },
      {
        "title": "The Superhero Pants",
        "text": "Once upon a time, a little boy put on his special blue superhero pants. The superhero pants had a secret rule: keep them dry all day long! Whenever the tummy bell rang, the superhero used his super speed to reach the potty. At bedtime, the superhero pants were dry as a desert. The superhero went to sleep with a huge smile on his face."
      },
      {
        "title": "The Dinosaur Underwear Safari",
        "text": "Once upon a time, a little girl wore her favorite green triceratops underwear. She marched around the house: stomp, stomp! \"Triceratops loves the potty!\" she sang. She went potty before naptime and after naptime. Dry, comfy, and proud, she showed Grandma how grown-up she had become."
      },
      {
        "title": "Goodnight, Diaper Box",
        "text": "Once upon a time, the big diaper box in the closet was officially empty. Instead, a neat little drawer was filled with soft cotton underwear in every color of the rainbow. The child picked yellow for Monday and blue for Tuesday. Wearing real underwear made running and jumping feel ten times easier!"
      },
      {
        "title": "The Dry Pants High-Five",
        "text": "Once upon a time, every dry check during the day earned a high-five. \"Check time!\" called Mommy. The child checked their pants: completely dry! \"High-five!\" slapped their hands together with joy. Staying clean and dry was a fun team game that the child won every single day."
      }
    ]
  },
  "wipe-flush-cheer": {
    "id": "wipe-flush-cheer",
    "title": "Wipe, Flush, and Cheer!",
    "subtitle": "The 3 magic steps to finish at the potty!",
    "icon": "🧻",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "potty-training",
    "stories": [
      {
        "title": "Wipe, Flush, and Cheer!",
        "text": "Once upon a time, there was a secret code for every potty champion: Step 1, Step 2, Step 3! Step 1 was Wipe: take soft toilet paper and wipe gently from front to back until clean. Drop the paper into the bowl: plop! Step 2 was Flush: push down the shiny silver handle and watch the water swirl: whoosh! Step 3 was Wash & Cheer: scrub hands with warm bubbly soap for 20 seconds, dry with a clean towel, and shout: \"Hooray, all done!\" The child practiced the 3 magic steps every single time. Doing it all by themselves felt like unlocking a brand new superpower."
      },
      {
        "title": "The Front-to-Back Detective",
        "text": "Once upon a time, a little detective learned the golden hygiene rule: always wipe from front to back! Soft toilet tissue made sure everything was clean and fresh. Into the toilet went the paper. With a push of the handle, the swirling water cleaned the bowl. Clean hands, clean body, and a happy detective ready for playtime."
      },
      {
        "title": "The Magical Swirling Water",
        "text": "Once upon a time, pushing the toilet handle was like turning on a waterfall. Whoosh went the water in a fast, sparkling spiral! The child waved: \"Bye-bye!\" Then, at the sink, the soap bubbles made a sweet foam castle on little fingers. Three simple steps made potty time completely independent."
      },
      {
        "title": "The Three-Step Dance",
        "text": "Once upon a time, the child invented a silly potty dance: \"Wipe front-to-back, flush with a clack, wash hands at the rack!\" Singing the rhyme made sure no step was ever forgotten. Mommy smiled from the doorway, so proud of her independent little helper."
      },
      {
        "title": "The Master of the Bathroom",
        "text": "Once upon a time, a preschooler did not need any reminders. They felt the cue, went to the bathroom, pulled down pants, went potty, wiped, flushed, and washed hands with soap. Walking out with a huge grin, they said: \"I did all three steps myself!\""
      }
    ]
  },
  "oops-its-okay": {
    "id": "oops-its-okay",
    "title": "Oops, It's Okay!",
    "subtitle": "Little accidents happen—we try again next time!",
    "icon": "🌈",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "potty-training",
    "stories": [
      {
        "title": "Oops, It's Okay!",
        "text": "Once upon a time, Tommy was having so much fun painting a giant rainbow that he didn't notice his tummy was full. Suddenly: drip, drop! A little puddle appeared on the floor, and Tommy's pants felt wet. Tommy looked down and felt sad. But Mommy knelt down with a warm, comforting hug. \"Oops, it's okay, Tommy! Accidents happen when we are learning. It's just pee-pee, and we can easily clean it up.\" Mommy helped Tommy change into fresh, dry pants. Together they wiped the floor with a towel. \"Next time your tummy feels full, we will pause and run to the potty!\" said Mommy. Tommy smiled, feeling safe and loved. He took a deep breath, and on the very next try, he made it to the potty right on time."
      },
      {
        "title": "The Learning Raindrops",
        "text": "Once upon a time, a little girl felt bad when she had a small accident during story time. Her teacher smiled gently: \"Even flowers need a little rain before they bloom! Accidents are just how our brain learns.\" They changed into clean clothes, washed hands, and went right back to reading. The little girl learned that trying your best is what truly matters."
      },
      {
        "title": "Hugs and Dry Pants",
        "text": "Once upon a time, a little boy was playing with cars when a wet spot appeared on his shorts. Daddy gave him a big hug: \"No worries at all, buddy! We change pants, wash hands, and try again.\" There was no scolding, only warmth and patience. Feeling confident and calm, the boy made it to the potty every time after that."
      },
      {
        "title": "The Comeback Champion",
        "text": "Once upon a time, an accident happened at Grandma's house. Grandma smiled: \"No problem, sweetie! Let's get your backup pants from the bag.\" Ten minutes later, the tummy bell rang again. This time, the child dashed to the bathroom and went in the potty! Grandma clapped: \"Look at the comeback champion!\""
      },
      {
        "title": "Gentle Patience Wins",
        "text": "Once upon a time, learning to use the potty was like learning to ride a tricycle: sometimes you wobble, and that is part of the fun! With loving hugs and zero pressure, the child felt relaxed. Soon, dry days turned into dry weeks, filled with high-fives and confidence."
      }
    ]
  },
  "rainbow-plate": {
    "id": "rainbow-plate",
    "title": "The Rainbow Plate Adventure",
    "subtitle": "Taste the crunch of orange carrots and green trees!",
    "icon": "🥦",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "healthy-eating",
    "stories": [
      {
        "title": "The Rainbow Plate Adventure",
        "text": "Once upon a time, dinner time looked like a magical painter's palette! On the plate sat tiny green broccoli trees, bright orange carrot wheels, red strawberry hearts, and sunny yellow corn. \"Welcome to the Rainbow Food Safari!\" announced Daddy. The child was not sure about the green broccoli tree. \"What does a hungry giraffe do?\" asked Daddy. The child picked up one little broccoli tree and took a tiny mouse nibble: crunch! It was warm, sweet, and surprisingly tasty! \"I ate a green tree!\" giggled the child. Next came an orange carrot wheel: chomp, crunch! Trying \"just one bite\" was fun and exciting. By the end of dinner, the plate was full of colorful memories, and the child felt strong like a superhero."
      },
      {
        "title": "The Brave Taster Crown",
        "text": "Once upon a time, a little girl had a magic rule: the \"One Polite Bite\" rule. Whenever a new vegetable appeared on her plate, she took one small, gentle bite with her front teeth. Crunch went the sweet red pepper! \"Hey, this is crunchy and sweet like an apple!\" she exclaimed. Being an adventurous taster filled her tummy with good energy for playground races."
      },
      {
        "title": "The Forest of Little Broccoli",
        "text": "Once upon a time, a friendly giant visited a miniature broccoli forest on a white ceramic plate. The giant dipped a little green tree into warm yogurt dip: dip, dip, crunch! \"Mmm, delicious!\" cheered the giant. Soon, the whole miniature forest was happily explored, and the giant had boundless energy for evening games."
      },
      {
        "title": "The Colors of Energy",
        "text": "Once upon a time, Mommy explained the superpowers of colors: \"Orange carrots give sharp eagle eyes, green spinach gives mighty muscles, and blue berries make your brain super smart!\" The child tasted a bite of each color to collect all three superpowers. Dinner was the most exciting game of the day."
      },
      {
        "title": "The Sweet Crunch Contest",
        "text": "Once upon a time, Daddy and the child had a crunching contest with cucumber slices. Daddy crunched: crunch! The child crunched louder: CRUNCH! They laughed together as the cool, fresh slices vanished one by one. Eating fresh vegetables was the funnest game at the table."
      }
    ]
  },
  "table-astronaut": {
    "id": "table-astronaut",
    "title": "The Table Astronaut",
    "subtitle": "Fasten your napkin seatbelt until mealtime ends!",
    "icon": "🪑",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "healthy-eating",
    "stories": [
      {
        "title": "The Table Astronaut",
        "text": "Once upon a time, the dining chair was transformed into a high-tech space capsule! The child placed a soft cloth napkin on their lap: \"Seatbelt fastened, ready for dining mission!\" While the space capsule was in flight, astronauts had to stay safely in their seats so their space soup wouldn't float away. The child held their spoon, taking steady, calm bites: scoop, chew, swallow. No running around the room, no jumping on the floor! Daddy and Mommy sat in neighboring capsules, chatting about the day's adventures. When everyone finished eating, the child wiped their mouth with the napkin: \"Mission complete! May I please be excused?\" \"Permission granted, Captain!\" smiled Daddy with a proud salute."
      },
      {
        "title": "The Dining Room Restaurant",
        "text": "Once upon a time, the dining table became a fancy five-star restaurant. The child was the VIP guest! They sat politely on their booster seat, using their quiet indoor voice: \"More peas, please!\" When food was in their mouth, they chewed with lips closed. Eating calmly together made family dinners feel warm, special, and full of smiles."
      },
      {
        "title": "The Happy Chair Hug",
        "text": "Once upon a time, a dining chair loved giving big, steady hugs during mealtime. The child rested their back against the chair, feet planted on the stool. Staying in the chair until tummy was full meant eating was easy, peaceful, and choked-free. After finishing dinner, the child hopped down ready for dessert hugs."
      },
      {
        "title": "The Table Manners Knight",
        "text": "Once upon a time, a polite knight used magic words at every meal: \"Please pass the potatoes,\" and \"Thank you for the delicious chicken!\" The knight kept elbows off the table and chewed slowly like a wise owl. Good manners made everyone happy to share dinner together."
      },
      {
        "title": "The Calm Dinner Voyage",
        "text": "Once upon a time, dinner was a peaceful boat ride. Running around made the boat rock, but sitting calmly in the seat kept the voyage smooth and safe. The child ate their warm meal, chatted about kindergarten, and helped carry their plastic cup to the sink when done."
      }
    ]
  },
  "water-sipper": {
    "id": "water-sipper",
    "title": "The Mighty Water Sipper",
    "subtitle": "Pure water fuels your superhero running energy!",
    "icon": "💧",
    "actorEmoji": "🧒",
    "age": "1+",
    "category": "healthy-eating",
    "stories": [
      {
        "title": "The Mighty Water Sipper",
        "text": "Once upon a time, after running fast on the playground grass, a little girl felt hot and thirsty. Her red water bottle was filled with cool, sparkling fresh water. Gulp, gulp, gulp went the cool water down her throat: ahhh, refreshing! \"Water is the magic fuel of the body!\" said Mommy. It quenched her thirst better than any sugary juice, giving her pure energy without any sticky tummy aches. Her cheeks cooled down, and her eyes sparkled with vitality. With a full water tank, the little runner zoomed back to the slide with endless bouncy power."
      },
      {
        "title": "The Mountain Stream Drink",
        "text": "Once upon a time, a little boy pretended his water cup came from a cool, clear mountain stream. Each sip felt like a splash of cold mountain rain on a sunny day. He took slow, steady sips through his colorful straw: slurp, slurp! Pure water kept his teeth healthy, his mind bright, and his body hydrated."
      },
      {
        "title": "The Thirsty Superhero Battery",
        "text": "Once upon a time, a superhero's power meter needed a recharge. Mommy handed over a cup of cool water with a slice of lemon: \"Super fuel incoming!\" The superhero drank half the cup in three refreshing gulps. The power meter flashed green: 100% recharged and ready for backyard missions!"
      },
      {
        "title": "The Clinking Ice Cube Game",
        "text": "Once upon a time, two clear ice cubes clinked happily inside a blue toddler cup: clink, clink! The child tipped the cup gently, taking cool, soothing sips after playing soccer. Drinking water made their smile shine bright and kept them energized all afternoon."
      },
      {
        "title": "The Water Bottle Explorer",
        "text": "Once upon a time, every outdoor adventure began with clicking the water bottle into the backpack side-pocket: snap! Whenever the sun shone bright, the explorer took a water break under the shady tree. Water was their most faithful travel companion."
      }
    ]
  },
  "spoon-fork-explorer": {
    "id": "spoon-fork-explorer",
    "title": "Spoon & Fork Explorers",
    "subtitle": "Scooping and poking food like a pro!",
    "icon": "🥄",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "healthy-eating",
    "stories": [
      {
        "title": "Spoon & Fork Explorers",
        "text": "Once upon a time, a shiny silver spoon and a rounded blue toddler fork were waiting by the bowl. \"I am the Fork, master of poking!\" said the fork. \"I am the Spoon, master of scooping!\" said the spoon. The child held the fork gently in their fingers and poked a sweet watermelon cube: poke! Up it went into the mouth: chomp! Next, the spoon dove into the warm rice and vegetable bowl: scoop, balance, deliver! Not a single grain fell on the table. The child chewed each bite slowly and carefully. \"Look at my expert hands!\" beamed the child, showing Mommy their empty bowl and clean table."
      },
      {
        "title": "The Soup Crane Adventure",
        "text": "Once upon a time, the spoon was a mighty crane lifting golden chicken noodle soup. The crane dipped into the bowl, scooped a carrot and a noodle, and gently transported the cargo to the mouth: open wide, delivery arrived! Eating soup with a steady spoon was fun, neat, and cozy."
      },
      {
        "title": "The Pasta Poke Party",
        "text": "Once upon a time, curly pasta wheels waited to be captured on the plate. The child held the toddler fork like a pencil and poked three pasta wheels in a row: one, two, three! Into the mouth they went: yummy! Using utensils made eating mealtime a satisfying puzzle."
      },
      {
        "title": "The Careful Chewer",
        "text": "Once upon a time, a little boy learned the secret of eating like a big kid: small bites and slow chewing. He cut his soft pancake with the side of his fork, chewed twenty times until soft, and swallowed with ease. Taking small bites made food taste twice as delicious."
      },
      {
        "title": "The Clean Tray Champion",
        "text": "Once upon a time, a little girl practiced scooping oatmeal without spilling a drop. Spoon level, steady hand, straight to the mouth: success! The high chair tray remained spotless. Mommy clapped with joy at her big girl's remarkable spoon skills."
      }
    ]
  },
  "little-chef-soup": {
    "id": "little-chef-soup",
    "title": "The Little Chef's Soup",
    "subtitle": "Washing greens and stirring the pot together!",
    "icon": "👨‍🍳",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "healthy-eating",
    "stories": [
      {
        "title": "The Little Chef's Soup",
        "text": "Once upon a time, the kitchen was filled with the delicious aroma of herbs and olive oil. The child wore a miniature white chef hat and stood on the sturdy kitchen helper stool. \"Welcome, Chef!\" said Mommy. Chef's first job was washing the crisp green spinach leaves in a bowl of cool water: swish, splash! Next, Chef tore the soft lettuce leaves into bite-sized pieces: rip, tear! Together, they poured the green veggies into the warm soup pot. Mommy stirred with the big wooden spoon while the soup bubbled gently: blup, blup! When dinner was served, the child tasted the warm soup with pride: \"I made this delicious soup!\" Eating food they helped prepare tasted better than anything in the world."
      },
      {
        "title": "The Fruit Salad Masterpiece",
        "text": "Once upon a time, Chef prepared a colorful afternoon fruit salad. With a safe butter knife, Chef sliced soft bananas into round coins: slice, slice! Then dropped blueberries into the glass bowl: plop, plop! Stirring with a wooden spoon, Chef served a bowl to Daddy. \"Best fruit salad in town!\" cheered Daddy."
      },
      {
        "title": "The Dough Rolling Champion",
        "text": "Once upon a time, Chef rolled out homemade whole-wheat pizza dough. Roll forward, roll back! Chef sprinkled colorful red tomatoes, green peppers, and mild cheese on top. Watching their pizza bake in the warm oven filled the kitchen with excitement and delicious smells."
      },
      {
        "title": "The Herb Garden Picker",
        "text": "Once upon a time, Chef visited the sunny windowsill herb garden. Chef gently snipped sweet basil leaves with safety scissors and sprinkled them over pasta sauce. Cooking with fresh ingredients made Chef feel like a real culinary artist."
      },
      {
        "title": "The Muffin Mixing Party",
        "text": "Once upon a time, Chef poured oat flour, mashed bananas, and warm milk into a big mixing bowl. Stir, stir, round and round with the whisk! Spooning the batter into muffin cups was magical. The warm, fresh banana muffins were enjoyed by the whole family with grateful smiles."
      }
    ]
  },
  "pocket-kiss": {
    "id": "pocket-kiss",
    "title": "The Magic Pocket Kiss",
    "subtitle": "Mommy & Daddy always come back for you!",
    "icon": "💛",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "play-school",
    "stories": [
      {
        "title": "The Magic Pocket Kiss",
        "text": "Once upon a time, on the first day of playschool, little Maya felt butterflies fluttering in her tummy. She held Mommy's hand very tight at the classroom door. Mommy knelt down at eye level and smiled warmly. She took Maya's small palm and pressed a warm, loving kiss right in the center: mwah! Then Mommy gently closed Maya's fingers into a soft fist: \"Now put the kiss in your pocket! Whenever you miss me, press your pocket against your heart, and you will feel my love holding you.\" Maya tucked the magic kiss into her pocket. She waved goodbye: \"See you after snack time, Mommy!\" Inside, Maya painted a big yellow sun and built block towers with new friends. Whenever she felt a little shy, she tapped her pocket and smiled. And just as promised, when the afternoon bell rang, Mommy was right there waiting with open arms and a giant hug."
      },
      {
        "title": "The Red String of Love",
        "text": "Once upon a time, Daddy drew a tiny red heart on Leo's wrist before preschool drop-off. \"Whenever you look at this heart, remember that Daddy is thinking of you and will be back at pick-up time!\" Leo looked at his heart during puzzle time and smiled. Knowing parents always return made the preschool day full of fun and confidence."
      },
      {
        "title": "The Magic Hug Button",
        "text": "Once upon a time, Mommy and Sam had a secret handshake: tap shoulder, tap elbow, and press the magic hug button on the chest: beep! The hug button stored enough warm cuddles to last all through morning circle time and outdoor recess. Sam skipped into class with a happy, brave wave."
      },
      {
        "title": "The Playground Window Wave",
        "text": "Once upon a time, a little boy had a special goodbye ritual: two waves at the door and three blown kisses through the big glass window: mwah, mwah, mwah! Watching Daddy wave his silly hat made the boy giggle. Separation was easy when filled with loving rituals."
      },
      {
        "title": "The Reassurance Song",
        "text": "Once upon a time, the classroom sang a cheerful drop-off song: \"Grown-ups come back, they always come back, after we play, learn, and snack!\" Singing together chased all worries away. The classroom was a bright world of puzzles, crayons, and friendly laughter."
      }
    ]
  },
  "hello-new-friend": {
    "id": "hello-new-friend",
    "title": "Hi, My Name Is Sam!",
    "subtitle": "Saying hello and making a new playground pal!",
    "icon": "👋",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "play-school",
    "stories": [
      {
        "title": "Hi, My Name Is Sam!",
        "text": "Once upon a time, Sam stood near the preschool sandbox watching a boy with a yellow toy dump truck. Sam wanted to play, but felt shy. His teacher gently whispered: \"You can try the Magic Hello!\" Sam took a brave step forward, smiled warmly, and waved his hand: \"Hi, my name is Sam! Would you like to build a sandcastle together?\" The boy looked up, smiled with bright eyes, and said: \"I'm Toby! Yes, let's fill the dump truck with sand!\" Together, they scooped sand, made tall towers with plastic cups, and dug a moat around the castle. By afternoon recess, Sam and Toby were the best of friends, racing tricycles side by side. Saying a simple \"Hello\" had opened the door to a whole new world of fun."
      },
      {
        "title": "The Shared Crayon Mystery",
        "text": "Once upon a time, Emma noticed a girl looking for a blue crayon to color the ocean. Emma held out her bright blue crayon: \"Here, you can share mine!\" The girl beamed: \"Thank you! I'm Lily.\" They colored together, combining blue ocean waves with sunny yellow fish. A small gesture of sharing sparked a wonderful friendship."
      },
      {
        "title": "The Swing Pusher Pal",
        "text": "Once upon a time, Leo saw a friend who needed a gentle push on the tire swing. \"Need a boost?\" asked Leo. He gave a gentle push: swoosh! The friend giggled and offered to push Leo next. Taking turns on the swing made recess the best part of the preschool day."
      },
      {
        "title": "The Smile Ice-Breaker",
        "text": "Once upon a time, Nina felt nervous entering a new music class. She looked across the circle and gave a warm smile to a boy holding a tambourine. He smiled right back and handed her a pair of wooden maracas: shake, shake! A friendly smile was the universal language of friendship."
      },
      {
        "title": "The Block Tower Architects",
        "text": "Once upon a time, two toddlers wanted to build a giant bridge with wooden arches. \"I'll hold the base, you put the top block!\" said one. Working together, their bridge stood taller than any single tower could ever be. Teamwork made play twice as rewarding."
      }
    ]
  },
  "circle-time": {
    "id": "circle-time",
    "title": "Circle Time Sunshine",
    "subtitle": "Criss-cross applesauce and listening ears on!",
    "icon": "⭕",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "play-school",
    "stories": [
      {
        "title": "Circle Time Sunshine",
        "text": "Once upon a time, the classroom bell chimed with a musical chime: ting-ting! \"Time for Circle Time, little friends!\" called Teacher Sarah. The children walked to the big colorful rug and sat down criss-cross applesauce in a wide, happy circle. The child turned their listening ears on: click, click! Teacher Sarah opened a giant picture book about whales in the deep blue sea. The child wanted to shout out an answer, but remembered the magic rule: raise a quiet hand! Up went the child's hand like a gentle flower. \"Yes, Noah?\" asked Teacher Sarah with a warm smile. Noah shared his answer using his polite speaking voice. Everyone clapped together, singing the morning calendar song. Sitting together in the circle felt like being part of one big, joyful family."
      },
      {
        "title": "The Singing Rug Caterpillar",
        "text": "Once upon a time, the colorful circle rug was like a friendly caterpillar holding hands. Each child sat on their colored circle: red, yellow, green, blue! When the guitar strummed, they clapped to the beat and sang the morning weather rhyme. Listening quietly when others spoke made circle time magical for everyone."
      },
      {
        "title": "The Magic Listening Ears",
        "text": "Once upon a time, a little boy pretended his ears had golden dials. Before story time, he gently turned the dial: \"Listening mode: ON!\" He heard the rustle of turning pages and the soft melody of the story. Raising his hand to answer questions made him feel like a super smart student."
      },
      {
        "title": "The Finger Puppet Show",
        "text": "Once upon a time, Teacher brought out five little animal finger puppets for circle time. All children sat with hands in their laps, watching the little monkey puppet dance and giggle. Patient listening made the puppet show ten times more entertaining."
      },
      {
        "title": "The Morning Sharing Stick",
        "text": "Once upon a time, whoever held the soft plush star got to share their favorite weekend memory. The child held the star and spoke clearly, while all friends listened quietly. When finished, they gently passed the star to their neighbor with a warm smile."
      }
    ]
  },
  "sharing-timer": {
    "id": "sharing-timer",
    "title": "The Sharing Timer",
    "subtitle": "Taking turns with the red race car!",
    "icon": "⏳",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "play-school",
    "stories": [
      {
        "title": "The Sharing Timer",
        "text": "Once upon a time, in the preschool play corner, there was a super speedy red race car with roaring wheels. Both Ben and Lucas wanted to drive it down the wooden ramp at the exact same moment. \"My turn!\" shouted Ben. \"No, my turn!\" pulled Lucas. Teacher Emily brought over a little sand timer filled with blue sand. \"Let's use the Sharing Timer! Lucas drives the car while the blue sand trickles down. When the sand reaches the bottom: beep-beep, Ben's turn!\" Ben waited patiently, watching the blue sand fall: trickle, trickle. While waiting, Ben built a ramp out of blocks. Beep! The sand ran out. Lucas handed the red car to Ben with a smile: \"Here you go, Ben!\" \"Thanks, Lucas!\" They zoomed the car down Ben's ramp together. Taking turns meant no fighting, and playing together was twice as fun."
      },
      {
        "title": "The Turn-Taking Stopwatch",
        "text": "Once upon a time, two friends wanted to ride the shiny green tricycle. They agreed on three laps each. One, two, three laps around the chalk track: ding! Slipped off the seat and handed the handlebars to the next friend with a high-five. Fair turns made recess smooth and joyful."
      },
      {
        "title": "The Two-Minute Play Clock",
        "text": "Once upon a time, sharing the magnetic building tiles was easy with the play clock. One friend built the castle walls, and the next friend placed the roof towers. By combining their ideas, the castle turned into a magnificent fortress."
      },
      {
        "title": "The Puzzle Piece Trade",
        "text": "Once upon a time, two toddlers were solving wooden animal puzzles. \"I have your elephant piece, and you have my giraffe piece!\" They traded with gentle hands: \"Thank you!\" Clicking the pieces into place felt like a shared victory."
      },
      {
        "title": "The Train Track Cooperation",
        "text": "Once upon a time, rather than fighting over the single train engine, the children connected all the wooden tracks into one giant oval. One drove the train, one operated the crossing gate, and one was the station master. Working together was the greatest game of all."
      }
    ]
  },
  "super-backpack": {
    "id": "super-backpack",
    "title": "Pack My Super Backpack",
    "subtitle": "Water bottle, crayons, and a sunny smile!",
    "icon": "🎒",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "play-school",
    "stories": [
      {
        "title": "Pack My Super Backpack",
        "text": "Once upon a time, it was morning prep time for preschool. On the table sat a bright yellow backpack with friendly rocket badges. \"Let's pack like a preschool superhero!\" said the child. First item: the stainless steel water bottle, zipped snugly into the side pocket: zip! Second item: the blue snack box with sliced apples and crackers, placed inside the main compartment. Third item: the spare cozy clothes pouch in case of paint splatters. Fourth item: the favorite little notebook. The child pulled the big main zipper closed: zzzip! They slipped their arms through the padded shoulder straps: one and two! The backpack rested lightly on their back. \"All packed and ready for school adventures!\" cheered the child, stepping out the front door with confidence."
      },
      {
        "title": "The Morning Checklist Hero",
        "text": "Once upon a time, a little girl used a fun picture checklist on the fridge: Shoes on? Check! Teeth brushed? Check! Backpack zipped? Check! Ticking off every morning item made school mornings calm, cheerful, and on time."
      },
      {
        "title": "The Secret Note in the Bag",
        "text": "Once upon a time, Mommy tucked a tiny drawing of a smiling sun inside the front pocket of the backpack. During snack time at preschool, the child unzipped the pocket and saw the sunny note. A warm burst of love made the whole classroom feel cozy."
      },
      {
        "title": "The Cubby Explorer",
        "text": "Once upon a time, arriving at school meant finding the wooden cubby with the child's name and picture badge. The child hung their jacket on the peg and placed their backpack inside neatly. Knowing where belongings live was a proud big-kid habit."
      },
      {
        "title": "The Ready-for-Action Routine",
        "text": "Once upon a time, packing the backpack the night before made mornings breezy and smooth. In the morning, all the child had to do was slip on shoes, grab the bag, and head out with a happy skip in their step."
      }
    ]
  },
  "blow-the-candle": {
    "id": "blow-the-candle",
    "title": "Blowing Out the Candle",
    "subtitle": "Take a deep breath when the mad volcano rumbles!",
    "icon": "🌬️",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "big-feelings",
    "stories": [
      {
        "title": "Blowing Out the Candle",
        "text": "Once upon a time, Leo felt a big red volcano of anger rumbling inside his chest because his block tower fell down. His hands wanted to stomp and throw. But Daddy knelt down calmly and held up five fingers like birthday candles. \"Let's blow out the birthday candles together, Leo. Smell the sweet cake: breathe in through your nose, 1, 2, 3...\" Leo breathed in deep, filling his belly with cool air. \"Now blow out candle number one: whooooo!\" Down went one finger. \"Breathe in sweet cake... blow out candle number two: whooooo!\" With each slow breath, the hot volcano inside Leo cooled down into a calm, quiet garden. By the time all five candles were blown out, Leo's chest felt light, his fists were relaxed, and his face had a peaceful smile. \"I feel better, Daddy,\" whispered Leo. \"Deep breaths always bring peace back,\" hugged Daddy."
      },
      {
        "title": "The Hot Cocoa Breath",
        "text": "Once upon a time, when big feelings felt overwhelming, Maya used the Hot Cocoa trick. She held an imaginary warm mug of cocoa in her hands. Smell the delicious chocolate: breathe in deep through the nose! Cool down the hot cocoa: blow gently through the mouth: whoooosh. Three gentle breaths melted away all tears and brought gentle calmness."
      },
      {
        "title": "The Magic Calm Down Cloud",
        "text": "Once upon a time, a little boy imagined a soft white cloud floating above him. When he took a deep, slow breath, the cloud turned golden and warm. Breathing out slowly sent all grumpiness floating away like dandelion seeds in the wind."
      },
      {
        "title": "The 4-Count Star Breath",
        "text": "Once upon a time, tracing the points of a drawing star helped calm a stormy afternoon. Inhale going up the star point, exhale going down the point. Tracing all five star points restored steady calm and peaceful thoughts."
      },
      {
        "title": "The Gentle Belly Balloon",
        "text": "Once upon a time, the child placed both hands over their belly button. Inhale: inflate the balloon with calm air! Exhale: deflate the balloon slowly: shhhhh. Feeling their tummy rise and fall made big angry storms vanish like morning mist."
      }
    ]
  },
  "talking-voice": {
    "id": "talking-voice",
    "title": "Use Your Talking Voice",
    "subtitle": "Words are for telling, hands are for helping!",
    "icon": "🗣️",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "big-feelings",
    "stories": [
      {
        "title": "Use Your Talking Voice",
        "text": "Once upon a time, little Oliver wanted the blue crayon, but his sister was coloring with it. Oliver felt mad and raised his hand to grab and push! Mommy gently caught Oliver's hand and held it softly: \"Hands are for helping and giving hugs, Oliver. Words are for telling how you feel. Use your talking voice.\" Oliver took a breath, lowered his hand, and said with his clear talking voice: \"Can I please have the blue crayon when you are done?\" His sister looked up, smiled, and said: \"Sure, Oliver, here is the blue crayon!\" Oliver realized that using words worked ten times better than pushing or screaming. His talking voice was his greatest superpower."
      },
      {
        "title": "The Magic Words Key",
        "text": "Once upon a time, screaming locked the door to fun, but polite words were the magic golden key. Saying \"I feel frustrated\" or \"I need help\" unlocked warm support from parents and teachers every time."
      },
      {
        "title": "Hands Are for Building",
        "text": "Once upon a time, two toddler hands were taught to do wonderful things: build block castles, pet soft puppies, clap to music, and give gentle high-fives. Using hands to help made the playground a safe and happy place."
      },
      {
        "title": "The Polite Indoor Voice",
        "text": "Once upon a time, when feelings got loud, the child dialed down their volume knob from 10 to a friendly 3. Speaking in a calm, clear voice made everyone listen closely and understand what they needed."
      },
      {
        "title": "The \"I Feel\" Superhero",
        "text": "Once upon a time, saying \"I feel mad because I wanted to swing longer\" helped Daddy understand right away. A comforting hug and a plan for next time solved the problem without any tantrums."
      }
    ]
  },
  "broken-crayon": {
    "id": "broken-crayon",
    "title": "The Broken Crayon",
    "subtitle": "Feeling sad is okay—we can still draw together!",
    "icon": "🖍️",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "big-feelings",
    "stories": [
      {
        "title": "The Broken Crayon",
        "text": "Once upon a time, Emma was drawing a purple butterfly when—snap! Her favorite purple crayon broke into two pieces. Emma gasped, and big tears welled up in her eyes. \"Oh no, my crayon is ruined!\" she sobbed. Grandma sat beside her, wiped her tears gently, and picked up the two broken pieces. \"Look, Emma! Before, you had one purple crayon. But now you have two purple crayons! One for your left hand, and one for your right hand. Or one for you, and one for me to draw with!\" Emma blinked. She tried drawing with the smaller piece: it drew just as brightly as before! Together, Emma and Grandma used both pieces to color the prettiest butterfly in the sketchbook. Emma learned that when something breaks or goes wrong, we can find a new way to make it wonderful."
      },
      {
        "title": "The Spilled Milk Sunshine",
        "text": "Once upon a time, a cup of white milk tipped over on the table: splash! The little boy gasped, worried. Daddy smiled: \"Accidents happen, buddy! Let's grab the sponge and make it clean.\" Wiping the table together was fun, and a fresh cup of milk was poured with a smile."
      },
      {
        "title": "The Ripped Paper Collage",
        "text": "Once upon a time, a piece of green craft paper tore accidentally. Instead of crying, the child used the ripped pieces to create a textured mosaic tree. The accidental rip turned into the most creative art piece in class."
      },
      {
        "title": "The Fixed Toy Workshop",
        "text": "Once upon a time, a toy car lost a wheel. The child brought it to Daddy's repair bench. With a drop of glue and a click, the wheel was back on and rolling smoothly again. Mistakes and breaks can always be fixed with patience."
      },
      {
        "title": "Resilient Little Explorer",
        "text": "Once upon a time, when rain cancelled the park trip, the explorer built a living room obstacle course with cushions instead. Bouncing over couch cushions proved that a flexible attitude makes every day an adventure."
      }
    ]
  },
  "apology-hug": {
    "id": "apology-hug",
    "title": "The Warm Apology Hug",
    "subtitle": "\"I'm sorry\" heals hearts and brings smiles back!",
    "icon": "🤝",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "big-feelings",
    "stories": [
      {
        "title": "The Warm Apology Hug",
        "text": "Once upon a time, while running fast in the hallway, Lucas accidentally bumped into his friend Noah, knocking Noah's picture book to the floor. Noah looked startled and rubbed his elbow. Lucas felt a knot in his stomach. He remembered what Daddy taught him: \"When we make a mistake or hurt someone, we fix it with kind words and care.\" Lucas walked over, picked up the book, and looked Noah in the eye: \"I'm sorry I bumped into you, Noah. Are you okay?\" Noah rubbed his elbow and smiled: \"I'm okay, thank you for picking up my book.\" Lucas gave Noah a gentle high-five and a warm hug. The knot in Lucas's stomach vanished, replaced by warmth. Saying a sincere \"I'm sorry\" had healed feelings in a heartbeat."
      },
      {
        "title": "The Heart Mending Words",
        "text": "Once upon a time, speaking unkind words left a little gray cloud over playtime. Saying \"I am sorry, let's play nicely together\" was like a burst of warm sunshine that dissolved the gray cloud and brought smiles back."
      },
      {
        "title": "The Rebuilding Bridge",
        "text": "Once upon a time, accidentally knocking down a friend's tower was quickly fixed by saying: \"I'm sorry! Let me help you build it back up even taller.\" Working side by side restored the tower and strengthened the friendship."
      },
      {
        "title": "The Forgiveness High-Five",
        "text": "Once upon a time, forgiving a friend who apologized felt just as good as saying sorry. Saying \"It's okay, thank you\" allowed both friends to jump right back into their game with happy hearts."
      },
      {
        "title": "The Kindness Bandage",
        "text": "Once upon a time, an apology paired with a gentle pat or hug was the best medicine for accidental bumps. Kind words showed that friends care deeply about each other."
      }
    ]
  },
  "big-sibling-helper": {
    "id": "big-sibling-helper",
    "title": "Big Sibling Helper",
    "subtitle": "A tiny baby joins the family with lots of love!",
    "icon": "👶",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "big-feelings",
    "stories": [
      {
        "title": "Big Sibling Helper",
        "text": "Once upon a time, a tiny baby brother arrived home wrapped in a soft white blanket. He had tiny fingers, tiny toes, and made sweet little cooing sounds. At first, big sister Mia wondered if Mommy and Daddy would be too busy. But Mommy smiled and called Mia over: \"Mia, we have the most important job in the world for you: Chief Big Sister Helper!\" Mia brought the baby's clean diaper, shook the rattle to make baby smile, and sang a gentle lullaby when baby cried. The baby looked up at Mia and gave a big, gummy smile! Mommy wrapped her arm around Mia: \"Look how much your little brother loves you! You are his superhero.\" Mia felt so proud, tall, and full of love for her new little sidekick."
      },
      {
        "title": "The Rattle Shaker Superstar",
        "text": "Once upon a time, a big brother knew the secret to cheering up his baby sister: gentle shaking of the colorful rattle: chk-chk-chk! The baby stopped crying and giggled with delight. Being a big brother was the coolest job in the universe."
      },
      {
        "title": "The Special Big Kid Time",
        "text": "Once upon a time, while baby took a nap in the crib, Daddy and the big sibling had their special \"Big Kid Puzzle Time\" together. Knowing that parents have endless love for all their children brought deep comfort and peace."
      },
      {
        "title": "The Bedtime Story for Two",
        "text": "Once upon a time, the big sister held the picture book and pointed to the pictures while Mommy rocked the baby. Reading together turned bedtime into the warmest family cuddle time."
      },
      {
        "title": "The Proud Big Helper",
        "text": "Once upon a time, fetching the baby's soft blanket and picking up the dropped pacifier made the big brother feel responsible and capable. The baby watched his big brother's every move with pure admiration."
      }
    ]
  },
  "slide-line": {
    "id": "slide-line",
    "title": "The Gentle Slide Line",
    "subtitle": "Waiting for our turn on the tall spiral slide!",
    "icon": "🛝",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "outdoor-play",
    "stories": [
      {
        "title": "The Gentle Slide Line",
        "text": "Once upon a time, on a sunny park afternoon, the big yellow spiral slide was the most popular attraction in town! A line of happy children stood on the wooden steps. Little Jack wanted to zoom right now, but he stood patiently behind his friend Maya. \"One at a time keeps everyone safe!\" remembered Jack. Maya slid down: whoooosh, splash into the soft woodchips! Once Maya stood up and stepped away, Jack climbed to the top seat, counted to three, and swooshed down: whoooosh! The wind tickled his cheeks, and he landed with a joyful giggle. He hopped up quickly so the next friend could slide. Waiting in turn made the slide safe, smooth, and fun for all the playground pals."
      },
      {
        "title": "The Swing Safety Zone",
        "text": "Once upon a time, a little girl knew to walk far around the moving swings: \"Give the swings lots of room to fly!\" She waited on the park bench until a swing was open. Soaring high into the blue sky felt like flying with the birds."
      },
      {
        "title": "The Sandbox Manners",
        "text": "Once upon a time, keeping sand low in the buckets made sure no sand got into anyone's eyes. Sharing shovels and buckets allowed three toddlers to construct a gigantic sand volcano together."
      },
      {
        "title": "The Jungle Gym Climber",
        "text": "Once upon a time, holding on with two strong hands while climbing the ladder made the little climber feel like a mountain explorer. Reaching the platform with safe steps was rewarded with a beautiful park view."
      },
      {
        "title": "The Playground Courtesy Train",
        "text": "Once upon a time, stepping aside at the bottom of the slide kept the runway clear for incoming friends. Good playground etiquette meant endless smiles and zero tears."
      }
    ]
  },
  "pass-the-ball": {
    "id": "pass-the-ball",
    "title": "Pass the Ball to Me!",
    "subtitle": "Kicking, chasing, and scoring fun outdoor goals!",
    "icon": "⚽",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "outdoor-play",
    "stories": [
      {
        "title": "Pass the Ball to Me!",
        "text": "Once upon a time, on the green grass of the town park, a black-and-white soccer ball rolled between three little friends. \"Pass the ball to me, Leo!\" called Sam. Leo tapped the ball gently with the inside of his sneaker: kick, roll! The ball rolled straight to Sam's feet. Sam trapped it with his shoe, looked up, and passed it to Maya. Maya ran forward, aimed between two red cones, and scored a goal: \"GOAAAL!\" All three friends danced and gave each other high-fives. It didn't matter who scored the most—passing the ball and running across the sunny grass as a team was the best game in the world."
      },
      {
        "title": "The Bouncy Basketball Bounce",
        "text": "Once upon a time, bouncing a big orange ball on the driveway went boing, boing, boing! The child bounced it to Daddy, and Daddy bounced it back. Catching with two hands built coordination and shared laughter."
      },
      {
        "title": "The Rolling Ball Race",
        "text": "Once upon a time, rolling a colorful beach ball across the lawn had two toddlers chasing and giggling. Catching the bouncy ball under the warm sun filled their lungs with fresh outdoor air."
      },
      {
        "title": "The Kick and Chase Game",
        "text": "Once upon a time, kicking the soft foam ball across the backyard gave little legs a mighty workout. Running, stopping, and turning helped the little athlete grow stronger every single day."
      },
      {
        "title": "The Team High-Five",
        "text": "Once upon a time, after every soccer game with friends, everyone lined up for friendly high-fives: \"Good game, good game!\" Celebrating together was the true spirit of sportsmanship."
      }
    ]
  },
  "bug-safari": {
    "id": "bug-safari",
    "title": "The Backyard Bug Safari",
    "subtitle": "Spotting ladybugs, caterpillars, and fluttering leaves!",
    "icon": "🔍",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "outdoor-play",
    "stories": [
      {
        "title": "The Backyard Bug Safari",
        "text": "Once upon a time, armed with a toy magnifying glass, little explorer Zoe stepped into the backyard garden. Down on hands and knees in the soft clover, she looked closely at a green leaf. \"Look, Mommy!\" whispered Zoe. A tiny red ladybug with seven black dots was crawling along the leaf edge: crawl, crawl. Zoe watched gently with quiet hands, never squishing or hurting the tiny creature. Next, a fuzzy green caterpillar munched on a leaf, and a shiny black beetle scurried under a pebble. \"Nature is full of tiny wonders!\" smiled Zoe. She waved a gentle goodbye as the ladybug spread its shiny wings and flew up into the blue sky."
      },
      {
        "title": "The Busy Ant Trail",
        "text": "Once upon a time, an explorer discovered a long line of tiny ants marching across a smooth garden stone. Each ant carried a tiny breadcrumb. Watching the ants work together showed how mighty small creatures can be."
      },
      {
        "title": "The Fluttering Butterfly Dance",
        "text": "Once upon a time, a bright yellow butterfly danced from yellow dandelion to purple clover. The child tiptoed softly beside it, watching the delicate wings open and close in the warm sun."
      },
      {
        "title": "The Snail's Shiny Trail",
        "text": "Once upon a time, a little snail with a spiral shell glided slowly across a wet garden leaf, leaving a shiny silver trail behind. Slow and steady, the snail showed that taking your time is a peaceful way to travel."
      },
      {
        "title": "The Garden Worm Friend",
        "text": "Once upon a time, after a gentle morning rain, an earthworm wiggled through the rich garden soil. The child watched the worm help the flowers grow, learning that every little bug has an important job in nature."
      }
    ]
  },
  "helmet-on": {
    "id": "helmet-on",
    "title": "Helmet On, Wheels Roll!",
    "subtitle": "Safety gear for our speedy tricycle ride!",
    "icon": "🚲",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "outdoor-play",
    "stories": [
      {
        "title": "Helmet On, Wheels Roll!",
        "text": "Once upon a time, a shiny blue tricycle was parked on the sidewalk, ready for a speedy ride. But before touching the handlebars, there was rule number one: \"Helmet on head, chin strap clicked!\" Mommy placed the cool dinosaur helmet on the child's head and snapped the buckle under the chin: click! \"Snug and secure like a real racecar driver!\" cheered the child. In went the feet on the pedals: push, roll, push, roll! The child stayed on the wide sidewalk, looking ahead with eagle eyes. When a walking neighbor passed by, the child tapped the handlebar bell: ding-ding! Safety gear kept the little rider protected, confident, and ready for neighborhood adventures."
      },
      {
        "title": "The Scooter Superhero Shield",
        "text": "Once upon a time, a bright red scooter had two rules: helmet on head and both hands on handlebars! The child glided down the driveway, foot pushing off the smooth concrete: glide, glide! Safe riding made outdoor play thrilling and worry-free."
      },
      {
        "title": "The Sidewalk Boundary Rule",
        "text": "Once upon a time, the little cyclist knew the golden rule: wheels stay on the sidewalk, away from the road! Stopping at every driveway and looking both ways kept the cyclist safe and smart."
      },
      {
        "title": "The Shiny Bell Chime",
        "text": "Once upon a time, ringing the bell warned friendly pedestrians with a cheerful chime: \"Ding-ding, bike coming through!\" Smiling and waving made neighborhood rides delightful."
      },
      {
        "title": "The Safe Balance Champion",
        "text": "Once upon a time, learning on a balance bike was easy with knee pads and a snug helmet. Pushing with feet and lifting toes to glide taught balance and courage under the watchful eye of parents."
      }
    ]
  },
  "five-minutes-warning": {
    "id": "five-minutes-warning",
    "title": "Five More Minutes Warning",
    "subtitle": "Wrapping up play and waving goodbye to the park!",
    "icon": "⏰",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "outdoor-play",
    "stories": [
      {
        "title": "Five More Minutes Warning",
        "text": "Once upon a time, the park was full of sunshine and laughter. But the sun was turning golden, and dinner was waiting at home. Daddy called out with a smile: \"Five more minutes, Mia! Choose your last two favorite things to do before we say goodbye to the park!\" Mia knew that the five-minute warning meant no surprises. \"One more trip down the big slide, and one last swing on the tire swing!\" decided Mia. She took her final thrilling slide, gave the tire swing three big pushes, and then ran to Daddy's open arms with a happy smile. They waved to the swings: \"Goodbye swings, see you tomorrow!\" Leaving the park without tears made the walk home peaceful, with songs about yummy dinner and cozy bath time."
      },
      {
        "title": "The Goodbye Park Song",
        "text": "Once upon a time, saying goodbye to the playground was easy with a silly goodbye song: \"Goodbye slide, goodbye tree, see you soon for you and me!\" Waving goodbye to playground equipment made departures fun and tear-free."
      },
      {
        "title": "The Last Lap Celebration",
        "text": "Once upon a time, when the 5-minute timer beeped, the child took one grand final victory lap around the sandbox. Skipping to the stroller with a smile felt like winning a gold medal."
      },
      {
        "title": "The Park Memory Treasure",
        "text": "Once upon a time, picking one smooth fallen leaf to take home kept the magic of the park alive in the backpack. The child walked home holding Daddy's hand, excited to paste the leaf in their scrapbook."
      },
      {
        "title": "The Smooth Transition",
        "text": "Once upon a time, knowing that the park will always be there tomorrow made saying goodbye simple and easy. A warm snack in the stroller made the ride home cozy and calm."
      }
    ]
  },
  "dr-bear-stethoscope": {
    "id": "dr-bear-stethoscope",
    "title": "Dr. Bear's Stethoscope",
    "subtitle": "Listening to your strong, happy heartbeat!",
    "icon": "🩺",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "brave-hero",
    "stories": [
      {
        "title": "Dr. Bear's Stethoscope",
        "text": "Once upon a time, little Oliver visited the clinic for his yearly wellness checkup. In the waiting room were colorful building blocks and a big fish tank. When the nurse called his name, Dr. Bear smiled warmly. \"Let's see how big and strong you have grown, Oliver!\" Dr. Bear weighed Oliver on the scale: whoosh, look how tall! Then Dr. Bear warmed the cold metal stethoscope in her palm: \"Let's listen to your superhero heartbeat!\" Dr. Bear placed it on Oliver's chest: lub-dub, lub-dub, went Oliver's strong little heart! Dr. Bear let Oliver listen through the earpieces: lub-dub! Oliver giggled. A quick peek in the ears with a little flashlight, a gentle tap on the knees, and checkup was complete! Dr. Bear handed Oliver a shiny gold star sticker: \"You are growing healthy and strong, little hero!\""
      },
      {
        "title": "The Magic Ear Flashlight",
        "text": "Once upon a time, the doctor used a tiny light to look for hidden stars inside the ears. \"No stars, just two healthy, clean ears!\" smiled the doctor. The gentle checkup was friendly, quick, and painless."
      },
      {
        "title": "The Brave Tiger Roar",
        "text": "Once upon a time, looking at the throat was fun: \"Open wide and make a gentle roar like a friendly lion: AHHH!\" The doctor looked with a soft wooden stick and smiled: \"Super clean throat!\" Being cooperative made checkups breezy."
      },
      {
        "title": "The Temperature Wand",
        "text": "Once upon a time, the doctor tapped a soft thermometer wand against the forehead: beep! A normal, healthy green light shone. The little patient felt proud of their strong, healthy body."
      },
      {
        "title": "The Well-Child Champion",
        "text": "Once upon a time, doctor visits were celebrated with a trip to the playground. Having healthy lungs, strong legs, and a big smile made the little hero ready for another year of growth."
      }
    ]
  },
  "counting-pearly-whites": {
    "id": "counting-pearly-whites",
    "title": "Counting Pearly Whites",
    "subtitle": "The magical chair that goes up, up, and shines!",
    "icon": "🦷",
    "actorEmoji": "🧒",
    "age": "3+",
    "category": "brave-hero",
    "stories": [
      {
        "title": "Counting Pearly Whites",
        "text": "Once upon a time, Maya visited the friendly dental office. Inside the room was a magical dental chair that could ride up like an elevator! Maya hopped on with her sunglasses on. The chair went up, up, up: wheee! The friendly dentist smiled: \"Let's count your sparkling pearls, Maya!\" Maya opened wide: \"Ahhh!\" The dentist used a tiny round mirror to count: \"One, two, three... twenty shiny white teeth! And not a single sugar bug in sight!\" The dentist gave each tooth a tickly polish with sweet strawberry paste: buzz, tickle! Then Maya rinsed with a tiny cup of water and spit with a splash. \"You take such good care of your teeth!\" cheered the dentist, letting Maya choose a toy ring from the treasure box. Maya smiled her brightest, pearliest smile all the way home."
      },
      {
        "title": "The Dental Chair Elevator",
        "text": "Once upon a time, riding the dentist's chair was like being in an amusement park. Push the button and go up! Put on sunglasses and open wide. The tiny mirror counted every tooth like shining stars in the sky."
      },
      {
        "title": "The Sugar Bug Detective",
        "text": "Once upon a time, the dentist was a detective hunting for sneaky plaque bugs. With a soft spinning brush, all teeth were polished into sparkling diamonds. The detective reported: \"Zero bugs found! Toothpaste Train is doing its job!\""
      },
      {
        "title": "The Strawberry Polish Party",
        "text": "Once upon a time, teeth got a special fruit polish that tickled like a gentle electric toothbrush. Rinsing with cool water left the mouth minty, fresh, and sparkling clean."
      },
      {
        "title": "The Treasure Chest Reward",
        "text": "Once upon a time, after opening wide and cooperating bravely, the child unlocked the dentist's treasure chest and picked a bouncy ball. A healthy smile was the greatest treasure of all."
      }
    ]
  },
  "cape-of-courage": {
    "id": "cape-of-courage",
    "title": "The Cape of Courage",
    "subtitle": "Snip-snip goes the comb for a stylish new look!",
    "icon": "💈",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "brave-hero",
    "stories": [
      {
        "title": "The Cape of Courage",
        "text": "Once upon a time, little Sam sat in the red booster chair at the kid-friendly barber shop. The barber snapped a shiny superhero cape around Sam's shoulders: \"Behold, the Cape of Courage!\" A gentle spray bottle went spritz, spritz, cooling down Sam's hair like gentle morning rain. The barber combed the bangs and went snip-snip with scissors, light as butterfly wings. Soft hair fell onto the cape without touching Sam's skin. Then the barber used a fluffy powder brush to tickle Sam's neck: tickle-tickle! Sam giggled. The barber spun the chair around to the big mirror: \"Look at that handsome superstar!\" Sam beamed, loving his clean, stylish haircut. He gave the barber a high-five and flew home with his superhero cape."
      },
      {
        "title": "The Spritz-Spritz Rain Game",
        "text": "Once upon a time, the water spray bottle at the hair salon was a gentle rain cloud. The soft comb glided through curls, and the scissors trimmed away long strands with gentle snip-snip sounds. Haircuts were quick, easy, and fun."
      },
      {
        "title": "The Red Car Salon Chair",
        "text": "Once upon a time, sitting in a salon chair shaped like a red race car let the child steer the wheel while the hairdresser trimmed the back. Honking the horn made the haircut pass in the blink of an eye."
      },
      {
        "title": "The Soft Neck Duster",
        "text": "Once upon a time, the softest brush in the world tickled away every stray hair from ears and shoulders. Looking in the mirror at the neat, fresh haircut brought a proud, beaming smile."
      },
      {
        "title": "The Brave Little Barber Pal",
        "text": "Once upon a time, holding Mommy's hand and watching the mirror made sitting still easy and calm. A shiny lollipop at the end sealed a successful salon trip."
      }
    ]
  },
  "magic-bandage": {
    "id": "magic-bandage",
    "title": "The Magic Bandage",
    "subtitle": "A cool sticker and a warm hug make boo-boos vanish!",
    "icon": "🩹",
    "actorEmoji": "🧒",
    "age": "1+",
    "category": "brave-hero",
    "stories": [
      {
        "title": "The Magic Bandage",
        "text": "Once upon a time, while running on the path, little Emma tripped on a small pebble and scraped her knee: ouch! Big tears rolled down her cheeks. Daddy knelt down instantly with open arms and a warm hug: \"I've got you, Emma. You are safe.\" Daddy washed the knee with a cool, gentle wipe: \"Washing away the dust bugs!\" Then Daddy pulled out a magic bandage with a smiling blue dinosaur on it. Peel, peel, stick! The bandage covered the scrape snugly. Daddy gave the bandage a gentle magic kiss: mwah! \"The dinosaur is guarding your knee while your skin heals!\" smiled Daddy. Emma touched the smooth sticker, sniffled, and smiled. The pain was gone, and she hopped right back up, ready to run again."
      },
      {
        "title": "The Magic Ice Pack Penguin",
        "text": "Once upon a time, a small bump on the forehead was treated with a cold, squishy penguin ice pack. Resting the cool pack against the bump felt soothing and refreshing. In five minutes, the bump was cooled down and forgotten."
      },
      {
        "title": "The Healing Kiss Formula",
        "text": "Once upon a time, Mommy had a proven scientific formula for scraped elbows: one cool rinse, one colorful sticker bandage, and two warm butterfly kisses. The tears dried up instantly, replaced by happy giggles."
      },
      {
        "title": "The Medicine Spoon Superhero",
        "text": "Once upon a time, taking sweet strawberry medicine from the tiny plastic syringe was easy: open wide, swallow with a sip of water, and say AHH! The medicine fought off the fever bugs and restored superhero energy."
      },
      {
        "title": "The Brave Heart Sticker",
        "text": "Once upon a time, every bump and scrape was a badge of courage for active little explorers. A quick clean, a cool bandage, and the explorer was back on the trail exploring nature."
      }
    ]
  },
  "parking-lot-hold": {
    "id": "parking-lot-hold",
    "title": "The Parking Lot Super-Hold",
    "subtitle": "Holding hands tight until we reach the door!",
    "icon": "🤝",
    "actorEmoji": "🧒",
    "age": "1+",
    "category": "safety-first",
    "stories": [
      {
        "title": "The Parking Lot Super-Hold",
        "text": "Once upon a time, Mommy parked the car at the busy supermarket lot. Cars were backing up and driving slowly down the aisles. Before stepping onto the asphalt, Mommy and Leo locked hands: \"Activate the Parking Lot Super-Hold!\" Their hands locked together like two interlocking puzzle pieces: strong, snug, and safe. \"Eyes looking forward, walking feet on!\" said Leo. Leo walked right beside Mommy, watching for white reversing lights and listening for car engines. When they stepped onto the safe concrete sidewalk by the entrance: \"Safe at base!\" cheered Leo, unlocking his hand with a high-five. Holding hands in parking lots kept little superheroes 100% safe."
      },
      {
        "title": "The Crosswalk Looking Game",
        "text": "Once upon a time, crossing the street had a 3-step safety dance: \"Stop at the curb, look left, look right, look left again, and hold hands tight!\" Walking calmly across the white zebra stripes kept everyone safe and sound."
      },
      {
        "title": "The Car Hand Magnet",
        "text": "Once upon a time, while Mommy loaded groceries into the trunk, the child's hand was a \"car magnet\" resting flat on the car door: stick! Staying right by the car until ready to buckle up was the smartest safety rule in town."
      },
      {
        "title": "The Supermarket Safety Hero",
        "text": "Once upon a time, walking side-by-side with parents through crowded parking plazas made the child a true safety champion. Sharp eyes and connected hands protected the whole family."
      },
      {
        "title": "The Sidewalk Safety Fortress",
        "text": "Once upon a time, the concrete sidewalk was a safe green zone, and the road was a river where cars swam. Staying safely in the green zone while holding hands made every walk a joyful expedition."
      }
    ]
  },
  "cart-helper": {
    "id": "cart-helper",
    "title": "The Cart Helper",
    "subtitle": "Staying close to Mom & Dad in the big store!",
    "icon": "🛒",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "safety-first",
    "stories": [
      {
        "title": "The Cart Helper",
        "text": "Once upon a time, the big supermarket was filled with tall shelves, bright lights, and colorful displays. Little Maya was the Official Grocery Cart Helper! She held onto the side handle of the shopping cart with one hand, walking right beside Daddy. \"No wandering down empty aisles alone—helpers stay with the cart!\" When Daddy needed red apples, Maya pointed them out: \"Three red apples, please!\" She placed them gently in the basket. Maya stayed close, never running out of sight. At the checkout counter, Maya helped put the cereal box on the belt: beep! Daddy smiled: \"You are the best cart helper in the world!\" Staying close kept shopping fun, safe, and cooperative."
      },
      {
        "title": "The Grocery List Detective",
        "text": "Once upon a time, holding the colorful picture grocery list kept the child focused right next to the shopping cart. Finding bananas, milk, and bread made grocery shopping an exciting treasure hunt."
      },
      {
        "title": "The Mall Safety Anchor",
        "text": "Once upon a time, inside the crowded shopping mall, holding the stroller handle was the child's safety anchor. Staying connected made sure the family stayed together and enjoyed their outing."
      },
      {
        "title": "The Store Helper Badge",
        "text": "Once upon a time, helping carry the light box of oatmeal to the cart made the preschooler feel capable and responsible, staying safely by Mommy's side the entire trip."
      },
      {
        "title": "The Safe Reunion Plan",
        "text": "Once upon a time, the child learned the golden rule: if you ever lose sight of parents, freeze in place and ask a store worker with a name badge for help. Knowing what to do brought peace and safety."
      }
    ]
  },
  "click-clack-seat": {
    "id": "click-clack-seat",
    "title": "Click-Clack, Safe & Snug",
    "subtitle": "The car seat click that keeps superheroes secure!",
    "icon": "🚗",
    "actorEmoji": "🧒",
    "age": "1+",
    "category": "safety-first",
    "stories": [
      {
        "title": "Click-Clack, Safe & Snug",
        "text": "Once upon a time, getting into the car was the start of an epic road adventure. The child climbed into their padded car seat and slipped arms through the harness straps like a race car driver. Daddy pulled the chest clip together: click! Then pushed the buckle into the base: clack! \"Click-clack, safe and snug!\" sang Daddy. The harness was smooth and snug against the chest, not twisted or loose. The car engine purred, and off they drove. While the car was moving, hands stayed away from the red buckle because superheroes stay strapped in until the car is safely parked. Looking out the window at passing trees and singing radio songs made every car ride a breeze."
      },
      {
        "title": "The Space Shuttle Harness",
        "text": "Once upon a time, the car seat was an astronaut's launch cockpit. Strapped in snugly with the five-point harness, the astronaut was ready for highway travel. Staying buckled kept everyone safe through turns and stops."
      },
      {
        "title": "The Window Watching Game",
        "text": "Once upon a time, strapped safely in the booster seat, the child spotted red trucks, barking dogs, and flying birds through the window. Safe seating made road trips entertaining and relaxing."
      },
      {
        "title": "The Buckle Song Routine",
        "text": "Once upon a time, the family sang their favorite road trip tune as soon as the buckle clicked: \"Click goes the seat, clack goes the lock, ready to roll around the block!\""
      },
      {
        "title": "The Safe Passenger Champion",
        "text": "Once upon a time, knowing that the car only moves when everyone is safely buckled made the child remind Daddy: \"Buckle up, Daddy!\" Safety was a team habit for the whole family."
      }
    ]
  },
  "freeze-feet-kitchen": {
    "id": "freeze-feet-kitchen",
    "title": "Hot Stove, Freeze Feet!",
    "subtitle": "Knowing what is cool to touch and what is too hot!",
    "icon": "🔥",
    "actorEmoji": "🧒",
    "age": "2+",
    "category": "safety-first",
    "stories": [
      {
        "title": "Hot Stove, Freeze Feet!",
        "text": "Once upon a time, delicious soup was bubbling on the kitchen stove. The child walked near the counter, but Mommy pointed to the red floor mat: \"Hot stove zone! Freeze feet!\" The child stopped feet immediately right at the edge of the mat. \"The stove, the oven, and the kettle are HOT—only grown-up hands touch them!\" explained Mommy. The child nodded wisely. To be safe, the child sat at the kitchen table with crayons, coloring a picture while Mommy cooked safely. Knowing the boundary kept little fingers safe from burns. When the soup was served cool in the toddler bowl, it was safe, delicious, and enjoyed without worry."
      },
      {
        "title": "The Hot and Cold Detective",
        "text": "Once upon a time, a little detective explored the kitchen: ice cube is COLD and safe to hold, hot kettle is HOT and eyes-only! Knowing the difference made the detective a home safety expert."
      },
      {
        "title": "The Outlet Safety Boundary",
        "text": "Once upon a time, electrical wall outlets had safety covers. The child learned: \"Outlets are for plugs, never for fingers!\" Respecting house boundaries kept the home safe and happy."
      },
      {
        "title": "The Safe Helper Stool",
        "text": "Once upon a time, helping in the kitchen was fun when standing on the safe, sturdy helper tower away from the hot stove, washing berries in the sink with cool water."
      },
      {
        "title": "The Steam Warning Signal",
        "text": "Once upon a time, seeing steam rise from a fresh bowl of oatmeal meant: \"Wait and blow gently until it cools down!\" Patience prevented burnt tongues and made breakfast delicious."
      }
    ]
  }
};

export function getRoutineStory(id) {
  return ROUTINE_STORIES[id] || null;
}
