import { getClassicTale, getFirstClassicTale, markTaleAsPlayed, getRandomClassicTale, getClassicRhyme, markRhymeAsPlayed, getRandomClassicRhyme } from './classic-tales.js';
import { getAnimal } from './animals.js';
import { getRoutineStory } from './routine-stories.js';
import { getStory as dbGetStory, saveNewStory, getHistory as dbGetHistory } from './storage.js';
import { fetchStoryData } from './data-fetcher.js';

function getPlayedIndexList(storageKey) {
  try {
    return JSON.parse(localStorage.getItem(storageKey) || '[]');
  } catch (e) {
    return [];
  }
}

function savePlayedIndex(storageKey, index) {
  try {
    const list = getPlayedIndexList(storageKey);
    list.push(index);
    localStorage.setItem(storageKey, JSON.stringify(list));
  } catch (e) {}
}

function resetPlayedIndexList(storageKey) {
  try {
    localStorage.removeItem(storageKey);
  } catch (e) {}
}

async function getNextPreGeneratedItem(category, topicId, avoidTitle, type = 'stories') {
  const data = await fetchStoryData();
  if (!data || !data[category] || !data[category][topicId]) return null;
  
  const pool = data[category][topicId][type] || [];
  if (pool.length === 0) return null;

  const storageKey = `kids_scroll_played_${category}_${topicId}_${type}`;
  let played = getPlayedIndexList(storageKey);
  
  // If all played, reset
  if (played.length >= pool.length) {
    resetPlayedIndexList(storageKey);
    played = [];
  }

  // Find unplayed indices
  const unplayedIndices = pool.map((_, i) => i).filter(i => !played.includes(i) && pool[i].title !== avoidTitle);
  
  if (unplayedIndices.length === 0) {
    // If somehow all unplayed are avoidTitle, just pick a random one
    return pool[Math.floor(Math.random() * pool.length)];
  }

  const selectedIndex = unplayedIndices[Math.floor(Math.random() * unplayedIndices.length)];
  savePlayedIndex(storageKey, selectedIndex);
  
  return pool[selectedIndex];
}

async function createNewStory(animal, avoidTitle, format = 'story', onSceneReady) {
  if (format === 'rhyme') {
    // 1. Mandatory: Serve all unplayed static classic rhymes first until exhausted
    const classicRhyme = getClassicRhyme(animal.id, avoidTitle);
    if (classicRhyme) {
      markRhymeAsPlayed(animal.id, classicRhyme.title);
      if (onSceneReady) onSceneReady(classicRhyme.text, 1, true);
      return classicRhyme;
    }

    // 2. Fetch from massive pre-generated JSON pool
    const preGenerated = await getNextPreGeneratedItem('animals', animal.id, avoidTitle, 'rhymes');
    if (preGenerated) {
      if (onSceneReady) onSceneReady(preGenerated.text, 1, true);
      return preGenerated;
    }

    // 3. Graceful fallback when offline and JSON not cached
    const fallback = getRandomClassicRhyme(animal.id);
    if (onSceneReady) onSceneReady(fallback.text, 1, true);
    return fallback;
  }

  // 1. Mandatory: Serve all unplayed static classic tales first until exhausted
  const classicTale = getClassicTale(animal.id, avoidTitle);
  if (classicTale) {
    markTaleAsPlayed(animal.id, classicTale.title);
    if (onSceneReady) onSceneReady(classicTale.text, 1, true);
    return classicTale;
  }

  // 2. Fetch from massive pre-generated JSON pool
  const preGenerated = await getNextPreGeneratedItem('animals', animal.id, avoidTitle, 'stories');
  if (preGenerated) {
    if (onSceneReady) onSceneReady(preGenerated.text, 1, true);
    return preGenerated;
  }

  // 3. Graceful fallback when offline and JSON not cached
  const fallback = getRandomClassicTale(animal.id) || getFirstClassicTale(animal.id);
  if (onSceneReady) onSceneReady(fallback.text, 1, true);
  return fallback;
}

async function getNextRoutineItemWrapper(routine, avoidTitle, format = 'story', onSceneReady) {
  const type = format === 'rhyme' ? 'rhymes' : 'stories';
  const preGenerated = await getNextPreGeneratedItem('routines', routine.id, avoidTitle, type);
  if (preGenerated) {
    if (onSceneReady) onSceneReady(preGenerated.text, 1, true);
    return preGenerated;
  }
  
  // Fallback to the hardcoded ones
  const available = (routine.stories || []).filter(s => s.title !== avoidTitle);
  let fallback;
  if (available.length > 0) {
    fallback = available[Math.floor(Math.random() * available.length)];
  } else {
    fallback = (routine.stories && routine.stories[0]) || { title: routine.title, text: routine.subtitle };
  }
  
  if (onSceneReady) onSceneReady(fallback.text, 1, true);
  return fallback;
}

/**
 * Loads the story's current saved text.
 */
export async function loadOrCreateStory(storyId) {
  const record = await dbGetStory(storyId);
  if (record && record.current) {
    return { title: record.current.title, text: record.current.text, isNew: false };
  }

  // Pre-load data in background
  fetchStoryData().catch(() => {});

  // Check if it's a routine story
  const routine = getRoutineStory(storyId);
  if (routine && routine.stories && routine.stories.length > 0) {
    const defaultStory = routine.stories[0];
    await saveNewStory(storyId, defaultStory.text, defaultStory.title);
    return { title: defaultStory.title, text: defaultStory.text, isNew: false };
  }

  // Animal story fallback
  const defaultStory = getFirstClassicTale(storyId) || getRandomClassicRhyme(storyId);
  if (defaultStory) {
    markTaleAsPlayed(storyId, defaultStory.title);
    await saveNewStory(storyId, defaultStory.text, defaultStory.title);
    return { title: defaultStory.title, text: defaultStory.text, isNew: false };
  }
}

/**
 * Forces a brand new story or rhyme
 */
export async function regenerateStory(storyId, avoidTitle, format = 'story', onSceneReady) {
  const routine = getRoutineStory(storyId);
  if (routine) {
    const nextItem = await getNextRoutineItemWrapper(routine, avoidTitle, format, onSceneReady);
    await saveNewStory(storyId, nextItem.text, nextItem.title);
    return { title: nextItem.title, text: nextItem.text };
  }

  const animal = getAnimal(storyId);
  if (animal) {
    const { title, text } = await createNewStory(animal, avoidTitle, format, onSceneReady);
    await saveNewStory(storyId, text, title);
    return { title, text };
  }

  // Fallback if unknown
  const fallback = format === 'rhyme' ? getRandomClassicRhyme('rabbit') : getRandomClassicTale('rabbit');
  if (onSceneReady) onSceneReady(fallback.text, 1, true);
  return { title: fallback.title, text: fallback.text };
}

export async function getHistory(storyId) {
  return dbGetHistory(storyId);
}
