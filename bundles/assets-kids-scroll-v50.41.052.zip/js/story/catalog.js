import { ANIMALS } from './animals.js';
import { ROUTINE_STORIES } from './routine-stories.js';

// Animal metadata mapping for subtitle hooks, SEO filenames, and recommended age ratings
const ANIMAL_METADATA = {
  rabbit: { file: 'rabbit-story.html', subtitle: 'The Tortoise, the Hare, and the Carrot Patch', age: '2+' },
  elephant: { file: 'elephant-story.html', subtitle: "Ellie's Big Bridge & The Helpful Ant", age: '2+' },
  lion: { file: 'lion-story.html', subtitle: 'The Gentle Roar & The Brave Little Mouse', age: '3+' },
  monkey: { file: 'monkey-story.html', subtitle: 'Curious Forest Adventures & Sweet Bananas', age: '2+' },
  dog: { file: 'dog-story.html', subtitle: 'The Faithful Puppy & The Hidden Treasure', age: '1+' },
  cat: { file: 'cat-story.html', subtitle: 'The Cozy Kitten & The Ball of Yarn', age: '1+' },
  bear: { file: 'bear-story.html', subtitle: 'The Sleepy Honey Bear & The Forest Picnic', age: '2+' },
  duck: { file: 'duck-story.html', subtitle: 'Splish-Splash Quacks & The Lily Pad Race', age: '1+' },
  cow: { file: 'cow-story.html', subtitle: 'The Gentle Daisy Meadow & Warm Morning Milk', age: '1+' },
  tiger: { file: 'tiger-story.html', subtitle: 'The Friendly Stripes & The Jungle Hide-and-Seek', age: '3+' },
  giraffe: { file: 'giraffe-story.html', subtitle: 'The Treetop Hero Reaching for the Stars', age: '2+' },
  zebra: { file: 'zebra-story.html', subtitle: 'The Dancing Stripes & The Savanna Sun', age: '2+' },
  horse: { file: 'horse-story.html', subtitle: 'The Galloping Breeze Across the Green Hill', age: '2+' },
  panda: { file: 'panda-story.html', subtitle: 'The Sweet Bamboo Feast & The Tumble Game', age: '2+' },
  fox: { file: 'fox-story.html', subtitle: 'The Clever Forest Friend with a Bushy Tail', age: '3+' },
  pig: { file: 'pig-story.html', subtitle: 'The Muddy Puddle Splash & The Sunny Farm', age: '1+' },
  sheep: { file: 'sheep-story.html', subtitle: 'The Fluffy Cloud Fleece & The Sweet Lullaby', age: '1+' },
  kangaroo: { file: 'kangaroo-story.html', subtitle: 'Boing-Boing Hops & The Pouch Hug', age: '2+' },
  turtle: { file: 'turtle-story.html', subtitle: 'Slow and Steady & The Cozy Shell Rest', age: '1+' },
  penguin: { file: 'penguin-story.html', subtitle: 'The Wobbly Snow Slide & The Cold Ocean Splash', age: '2+' },
};

const ROUTINE_FILE_MAP = {
  // 1. Daily Routines
  'toothpaste-train': 'brush-teeth-toothpaste-train.html',
  'bubble-bath': 'splish-splash-bubble-bath.html',
  'toy-cleanup': 'where-do-toys-sleep-cleanup.html',
  'big-kid-bed': 'big-kid-bed-sleep-story.html',
  'shoes-and-clothes': 'left-shoe-right-shoe.html',
  'hand-washing': 'bubble-monster-wash-hands.html',
  'hair-nail-trim': 'gentle-hair-nail-trim.html',

  // 2. Potty Training
  'tummy-bell': 'listen-to-tummy-bell.html',
  'potty-crown': 'the-potty-crown.html',
  'big-kid-underwear': 'big-kid-underwear-day.html',
  'wipe-flush-cheer': 'wipe-flush-and-cheer.html',
  'oops-its-okay': 'oops-its-okay-potty.html',

  // 3. Healthy Eating
  'rainbow-plate': 'rainbow-plate-adventure.html',
  'table-astronaut': 'table-astronaut-manners.html',
  'water-sipper': 'mighty-water-sipper.html',
  'spoon-fork-explorer': 'spoon-and-fork-explorers.html',
  'little-chef-soup': 'little-chefs-soup.html',

  // 4. Play School
  'pocket-kiss': 'magic-pocket-kiss-goodbye.html',
  'hello-new-friend': 'hi-my-name-is-sam.html',
  'circle-time': 'circle-time-sunshine.html',
  'sharing-timer': 'the-sharing-timer.html',
  'super-backpack': 'pack-my-super-backpack.html',

  // 5. Big Feelings
  'blow-the-candle': 'blowing-out-the-candle.html',
  'talking-voice': 'use-your-talking-voice.html',
  'broken-crayon': 'the-broken-crayon.html',
  'apology-hug': 'warm-apology-hug.html',
  'big-sibling-helper': 'big-sibling-helper.html',

  // 6. Outdoor Play
  'slide-line': 'gentle-slide-line.html',
  'pass-the-ball': 'pass-the-ball-to-me.html',
  'bug-safari': 'backyard-bug-safari.html',
  'helmet-on': 'helmet-on-wheels-roll.html',
  'five-minutes-warning': 'five-more-minutes-warning.html',

  // 7. Brave Little Hero
  'dr-bear-stethoscope': 'dr-bear-stethoscope.html',
  'counting-pearly-whites': 'counting-pearly-whites-dentist.html',
  'cape-of-courage': 'the-cape-of-courage-haircut.html',
  'magic-bandage': 'the-magic-bandage.html',

  // 8. Safety First
  'parking-lot-hold': 'parking-lot-super-hold.html',
  'cart-helper': 'the-cart-helper-supermarket.html',
  'click-clack-seat': 'click-clack-safe-and-snug.html',
  'freeze-feet-kitchen': 'hot-stove-freeze-feet.html'
};

const PET_ANIMAL_IDS = new Set(['dog', 'cat', 'rabbit', 'duck', 'cow', 'horse', 'pig', 'sheep', 'turtle']);

// Formatted list of animal stories conforming to the unified story card format
export const ANIMAL_STORIES = ANIMALS.map((animal) => {
  const meta = ANIMAL_METADATA[animal.id] || { file: `${animal.id}-story.html`, subtitle: `Gentle read-aloud tales of the ${animal.name}`, age: '2+' };
  const isPet = PET_ANIMAL_IDS.has(animal.id);
  return {
    id: animal.id,
    title: animal.name,
    subtitle: meta.subtitle,
    icon: animal.emoji,
    actorEmoji: animal.emoji,
    age: meta.age,
    category: isPet ? 'pet-animals' : 'wild-animals',
    file: meta.file,
    url: `/story/${meta.file}`,
    type: 'animal'
  };
});

export const PET_ANIMAL_STORIES = ANIMAL_STORIES.filter(s => s.category === 'pet-animals');
export const WILD_ANIMAL_STORIES = ANIMAL_STORIES.filter(s => s.category === 'wild-animals');

export const ALL_ROUTINE_STORIES = Object.values(ROUTINE_STORIES).map((routine) => {
  const file = ROUTINE_FILE_MAP[routine.id] || `${routine.id}.html`;
  return {
    ...routine,
    file,
    url: `/story/${file}`,
    type: 'routine'
  };
});

// 10 Categories with Pet Animals and Wild Animals as the first two categories
export const STORY_CATEGORIES = [
  {
    id: 'pet-animals',
    title: 'Pet Animal Stories',
    icon: '🐶',
    description: 'Gentle read-aloud tales of playful puppies, cozy kittens, bunnies, and friendly farmyard pals.',
    stories: PET_ANIMAL_STORIES
  },
  {
    id: 'wild-animals',
    title: 'Wild Animal Stories',
    icon: '🦁',
    description: 'Exciting yet gentle fables of jungle lions, tall giraffes, playful monkeys, and savanna giants.',
    stories: WILD_ANIMAL_STORIES
  },
  {
    id: 'daily-routines',
    title: 'Daily Routines & Self-Care',
    icon: '🪥',
    description: 'Encouraging stories for bedtime, brushing, bath time, cleanup, and healthy daily habits.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'daily-routines')
  },
  {
    id: 'potty-training',
    title: 'Potty Training & Body Cues',
    icon: '🚽',
    description: 'Listening to tummy bells, wearing big kid pants, and confident potty milestones.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'potty-training')
  },
  {
    id: 'healthy-eating',
    title: 'Healthy Eating & Table Manners',
    icon: '🥦',
    description: 'Rainbow plates, table astronauts, water drinking, and enjoying new crunchy veggies.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'healthy-eating')
  },
  {
    id: 'play-school',
    title: 'Play School & Big Steps',
    icon: '🎒',
    description: 'Magic pocket kisses, making friends, circle time listening, and sharing toys.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'play-school')
  },
  {
    id: 'big-feelings',
    title: 'Big Feelings & Calming Down',
    icon: '🌋',
    description: 'Deep candle breathing, using talking voices, resilience, and warm apology hugs.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'big-feelings')
  },
  {
    id: 'outdoor-play',
    title: 'Outdoor Play & Movement',
    icon: '⚽',
    description: 'Slide line safety, kicking soccer goals, bug safaris, and wearing helmets.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'outdoor-play')
  },
  {
    id: 'brave-hero',
    title: 'Brave Little Hero',
    icon: '🏥',
    description: 'Doctor checkups, friendly dentists, haircut capes, and magic boo-boo bandages.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'brave-hero')
  },
  {
    id: 'safety-first',
    title: 'Safety First & Important Rules',
    icon: '🛑',
    description: 'Parking lot super-holds, grocery helpers, car seat safety, and kitchen boundaries.',
    stories: ALL_ROUTINE_STORIES.filter(s => s.category === 'safety-first')
  }
];

export const ALL_STORIES_MAP = new Map();
STORY_CATEGORIES.forEach(cat => {
  cat.stories.forEach(story => {
    ALL_STORIES_MAP.set(story.id, story);
    if (story.file) {
      ALL_STORIES_MAP.set(story.file.replace('.html', ''), story);
    }
  });
});

export function getStoryItem(id) {
  if (!id) return null;
  return ALL_STORIES_MAP.get(id) || null;
}

export function getCategoryStories(categoryId) {
  const cat = STORY_CATEGORIES.find(c => c.id === categoryId);
  return cat ? cat.stories : [];
}

export function getAdjacentStory(storyId, categoryId = null, direction = 1) {
  const item = getStoryItem(storyId);
  const targetCategory = categoryId || (item ? item.category : 'pet-animals');
  const stories = getCategoryStories(targetCategory);
  if (!stories.length) return null;

  const index = stories.findIndex(s => s.id === storyId);
  if (index === -1) {
    return stories[0];
  }

  const nextIndex = (index + direction + stories.length) % stories.length;
  return stories[nextIndex];
}
