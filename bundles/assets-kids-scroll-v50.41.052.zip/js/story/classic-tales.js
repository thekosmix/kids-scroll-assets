// Curated, hand-written classic-fable-style stories (~200 words each), adapted to be
// gentle and safe for 1-6yo listeners. The on-device SLM is a tiny model trained on
// generic simple stories - it has no real knowledge of Aesop/folk tales, so well-known
// tales like these are hand-authored rather than generated, then mixed into the same
// "new story" pool as fresh model-generated ones.
export const CLASSIC_TALES = {
  "rabbit": [
    {
      "title": "The Tortoise and the Hare",
      "text": "Once upon a time, in a green meadow, a quick little hare loved to boast. \"I am the fastest runner in the whole forest!\" he said proudly. A slow, gentle tortoise heard him and smiled. \"Would you like to race me?\" asked the tortoise. The hare laughed and laughed. \"That is the silliest idea I have ever heard!\" But he agreed, just for fun. All the animals gathered by the big oak tree to watch. \"Ready, set, go!\" shouted the wise old owl. The hare zoomed ahead so fast that he was soon far, far away. He looked back and could not see the tortoise anywhere. \"I have so much time,\" the hare said with a yawn, and curled up under a shady tree for a little nap. Meanwhile, the tortoise kept walking, slow and steady, one step after another. While the hare was napping, the tortoise quietly passed him by. When the hare woke up, the sun was low in the sky. He dashed toward the finish line as fast as his legs could go. But the tortoise was already there, smiling by the ribbon. All the animals cheered. \"Slow and steady wins the race!\" they sang together. The hare hugged the tortoise. \"You taught me something important today,\" he said, and from then on they became the very best of friends."
    },
    {
      "title": "The Rabbit Who Planted a Garden",
      "text": "Once upon a time, in a sunny meadow, a little rabbit named Hazel found a handful of carrot seeds. \"I will grow the biggest carrots in the meadow,\" she said, and planted them in a neat little row. Every morning, Hazel watered her seeds, but the ground stayed dry and thirsty under the hot sun. A family of birds saw her working so hard and flew off, returning with drops of rain caught in the leaves. \"Let us help you,\" they chirped, sprinkling the water over the little seeds. Slowly, tiny green shoots popped up from the soil, and Hazel clapped her paws with joy. A gentle mole tunneled by and loosened the earth around the roots so they could grow deep and strong. Day by day, the shoots grew taller, until one morning Hazel saw bright orange carrot tops peeking through the ground. \"They are ready!\" she cheered, and pulled up the biggest, crunchiest carrots she had ever seen. Hazel remembered how the birds and the mole had helped her, so she shared her harvest with all of them. \"A garden grown together tastes the very best,\" said Hazel happily, and every friend agreed as they munched on sweet, crunchy carrots together under the warm afternoon sun."
    },
    {
      "title": "The Rabbit and the Moon",
      "text": "Once upon a time, a clever rabbit looked into a clear, still lake and saw the bright moon reflecting on the water. A greedy bear came by and said he wanted to catch the moon. The rabbit smiled and pointed to the water. 'There it is, dive in and get it!' she said. The bear splashed into the cold water, only to find the moon was safe in the sky. The rabbit hopped away, laughing at her clever trick."
    },
    {
      "title": "The Rabbit's Big Leap",
      "text": "Once upon a time, a little rabbit wanted to cross a wide stream to get to a patch of sweet clover. He asked a row of lazy crocodiles to line up so he could count them. As he counted, he hopped from one crocodile's back to the next. 'One, two, three!' he cheered. Before the crocodiles knew it, the rabbit had safely reached the other side and enjoyed his delicious clover."
    },
    {
      "title": "The Rabbit and the Hedgehog",
      "text": "Once upon a time, a speedy rabbit challenged a hedgehog to a race. The hedgehog asked his wife to stand at the finish line, while he stood at the start. They looked exactly alike! When the rabbit zoomed to the end, the hedgehog's wife said, 'I am already here!' The rabbit ran back and forth, but a hedgehog was always there. The rabbit learned that being clever is just as good as being fast."
    },
    {
      "title": "Hoppy's Little Adventure",
      "text": "Once upon a time, there was a little rabbit named Hoppy. Hoppy loved to hop through the green grass. One day, Hoppy found a big carrot near the lake. Hoppy shared the carrot with a friendly duck. They played together until the sun went down. Then Hoppy hopped home and went to sleep."
    }
  ],
  "lion": [
    {
      "title": "The Lion and the Little Girl",
      "text": "Once upon a time, in a warm and sunny jungle, a big lion was walking home. Ouch! A sharp thorn was stuck in his soft paw. The lion sat down and looked at his paw sadly. Just then, a kind little girl came skipping through the jungle path. She saw the lion and was not afraid at all. \"Oh no, you have a thorn in your paw,\" she said gently, and carefully pulled it out. The lion felt so much better right away and gave a happy little roar. \"Thank you, little friend,\" he seemed to say. From that day, the lion and the little girl met every morning by the big tree. They shared berries and told each other stories, and the lion let her ride upon his back through the tall grass. One day, the little girl's kitten got stuck up in a tall tree. The lion stood up and gently helped the kitten climb down to safety. The whole jungle talked about the lion and the little girl who helped each other. They played together every single day, through sunny days and rainy days too. The little girl learned that even a big lion can be gentle and kind. And the lion learned that a small act of kindness can grow into a wonderful friendship."
    },
    {
      "title": "The Lion's Gentle Roar",
      "text": "Once upon a time, in a golden savanna, a young lion named Leo loved to roar as loudly as he could. \"ROAR!\" he shouted every morning, just to hear how big his voice sounded. But every time Leo roared, the little rabbits and birds nearby scattered and hid, too startled to come out and play. Leo felt lonely, wondering why none of the other animals ever wanted to be near him. A wise old elephant noticed Leo sitting by himself and ambled over. \"Perhaps your big roar makes your little friends feel small,\" she said kindly. Leo thought about this all afternoon, watching the birds chirp softly and the rabbits thump gently to talk to each other. The next morning, instead of roaring, Leo tried a soft, friendly \"Good morning!\" A curious rabbit peeked out from the grass, surprised to hear such a gentle voice. Slowly, more animals came closer, and soon Leo was surrounded by new friends who wanted to hear his stories. \"I did not know a quiet voice could bring so many friends,\" Leo said happily. From that day on, Leo saved his big roar for playing games, and used his gentle voice for saying hello, and the whole savanna felt like home."
    },
    {
      "title": "The Lion and the Mouse",
      "text": "Once upon a time, a mighty lion caught a tiny mouse. The mouse squeaked, 'Please let me go! Someday I will help you.' The lion laughed and let him go. Days later, the lion got caught in a hunter's net. The little mouse heard his roar and hurried over. With his sharp teeth, he chewed through the ropes and set the lion free. The lion learned that even the smallest friend can be a big help."
    },
    {
      "title": "The Lion's Reflection",
      "text": "Once upon a time, a proud lion thought he was the strongest animal in the world. A clever rabbit told him there was another lion in the well who claimed to be stronger. The angry lion looked into the well and saw his own reflection. He roared, and the echo roared back. He jumped in to fight the 'other' lion, only to end up soaking wet. The rabbit smiled, knowing pride had tricked the mighty lion."
    },
    {
      "title": "The Lion's Share",
      "text": "Once upon a time, a lion, a fox, and a wolf went hunting together. When it was time to share their food, the lion divided it into three parts. 'The first part is mine because I am the king,' he said. 'The second is mine because I am the strongest. And if anyone wants the third part, they will have to fight me for it.' The fox and the wolf walked away, learning that working with a greedy leader is no fun at all."
    },
    {
      "title": "Leo's Little Adventure",
      "text": "Once upon a time, there was a lion named Leo. Leo loved to nap under the warm sun. One day, Leo found a soft patch of grass by the hill. Leo invited his friends to nap with him. They all rested together and told happy stories. Then Leo stretched, smiled, and went to sleep."
    }
  ],
  "elephant": [
    {
      "title": "The Elephant and the Tiny Ant",
      "text": "Once upon a time, in a sunny meadow, there lived a very big elephant named Ellie. One day, Ellie was walking to the lake for a cool drink of water when she heard a tiny voice calling from the tall grass. It was a little ant, stuck under a heavy leaf. \"Please, can you help me?\" the ant squeaked. Ellie leaned down carefully and lifted the leaf with her long trunk. The tiny ant crawled out and thanked her with a big smile. \"You are so big and strong,\" said the ant. \"And you were so brave to ask for help,\" said Ellie, and they became good friends. A few days later, Ellie's foot got stuck between two big rocks by the water. She could not pull herself free, no matter how hard she tried. The tiny ant remembered how kind Ellie had been. She called all her ant friends, and together they dug around the rocks. Slowly, gently, Ellie's foot came loose at last. \"Thank you, little friend,\" said Ellie happily. \"Even someone very small can help someone very big,\" said the ant with a proud smile. From that day on, the elephant and the ant shared every sunny afternoon together, showing everyone in the meadow that friendship comes in all sizes."
    },
    {
      "title": "Ellie's Bridge Across the Stream",
      "text": "Once upon a time, on a warm sunny morning, Ellie the elephant was walking through the jungle when she came to a wide, bubbling stream. On the other side, a family of tiny mice stood looking puzzled, unable to find a way across. \"We cannot swim, and the water is too fast for us,\" squeaked the littlest mouse. Ellie looked at the stream and had a wonderful idea. She waded into the shallow water and lowered her long trunk down like a curvy little bridge. \"Climb aboard, one at a time,\" she said with a smile. The mice scurried up her trunk, giggling as she gently lifted them over the rushing water and set them safely on the other side. One by one, more animals came by needing to cross - a family of turtles, a shy hedgehog, and even a wobbly baby duck. Ellie carried every single one across, never once getting tired of helping. By sunset, a whole crowd of grateful animals had gathered on the far bank to thank her. \"Your trunk makes the best bridge in the whole jungle,\" said the littlest mouse happily. Ellie beamed with pride, realizing that being big and strong was even better when it helped so many little friends get where they needed to go."
    },
    {
      "title": "The Blind Friends and the Elephant",
      "text": "Once upon a time, three blind friends met an elephant for the first time. One touched his trunk and said, 'It is like a big snake!' Another touched his leg and said, 'No, it is like a tree!' The third touched his ear and said, 'It is like a giant fan!' The elephant giggled and said, 'You are all right, but you only felt one part of me.' They realized that everyone sees things a little differently."
    },
    {
      "title": "The Elephant and the Dog",
      "text": "Once upon a time, a royal elephant and a stray dog became best friends. They ate together and slept side by side. One day, a farmer took the dog away. The elephant missed his friend so much he refused to eat or drink. The king ordered the dog to be found and returned. When the dog ran back, the elephant trumpeted with joy. They lived happily together, proving that true friendship is a powerful thing."
    },
    {
      "title": "The Elephant's Big Ears",
      "text": "Once upon a time, a young elephant was sad because his ears were so big. All the other animals had small, neat ears. One very hot day, the sun beat down on the savanna, and everyone was sweating. The elephant flapped his big ears and created a wonderful, cool breeze. All the animals gathered around him to cool off. The elephant smiled, proud of his big, helpful ears."
    },
    {
      "title": "Ellie's Little Adventure",
      "text": "Once upon a time, there was a big elephant named Ellie. Ellie loved to splash water with her trunk. One day, Ellie found a small pond in the forest. Ellie sprayed water on her friends and they all laughed. They played together all afternoon. Then Ellie walked home happy and slept well."
    }
  ],
  "monkey": [
    {
      "title": "The Monkey and the Crocodile",
      "text": "Once upon a time, by a wide blue river, a cheerful monkey lived in a fruit tree on one bank. Every day, he dropped sweet, juicy berries down to a friendly crocodile swimming below. \"Thank you, monkey! These are delicious,\" the crocodile said with a happy splash, and they became the best of friends. One day, the crocodile said, \"My family lives on the other side of the river. Would you like to meet them?\" The monkey happily hopped onto the crocodile's back for a ride. Halfway across, the monkey looked down at the sparkling water. \"Hold on tight,\" said the crocodile, swimming steady and slow. When they reached the other side, the crocodile's family was waiting with a big pile of fresh fruit, and they all shared a wonderful feast under the warm sun. The little crocodiles listened, amazed, as the monkey told funny stories about life in the treetops. From that day on, the monkey visited his crocodile friends every week, sometimes bringing berries and sometimes shiny river stones as gifts. The monkey learned that friends can look very different and still love each other very much. And the crocodile family learned that the best rides across the river come with the best of friends."
    },
    {
      "title": "The Monkey Who Learned to Wait",
      "text": "Once upon a time, in a tall banana tree, a young monkey named Miko spotted a bunch of bananas just beginning to turn from green to yellow. \"I want a banana right now!\" Miko said, reaching for one that was still hard and green. A wise old turtle resting below looked up and said gently, \"That one is not quite ready yet, little friend.\" Miko frowned and picked it anyway, but the banana tasted sour and strange, not sweet at all. \"Patience makes everything taste better,\" said the turtle with a small smile. Miko sighed and decided to wait, watching the bananas every single day as they slowly turned a brighter and brighter yellow. It felt like a very long time, so Miko played games with the birds and practiced swinging from branch to branch to pass the time. Finally, one sunny morning, the whole bunch of bananas had turned perfectly golden and sweet-smelling. Miko picked one carefully and took a big bite - it was the most delicious banana he had ever tasted! He shared the rest of the bunch with the wise old turtle and all his forest friends. \"Waiting really was worth it,\" Miko said happily, and from then on, he always gave the sweetest things time to be ready."
    },
    {
      "title": "The Monkey and the Cap Seller",
      "text": "Once upon a time, a tired cap seller fell asleep under a tree. A group of playful monkeys climbed down, took all his colorful caps, and put them on their heads. When the man woke up, he yelled at the monkeys, but they just yelled back. Finally, in frustration, he threw his own cap on the ground. The monkeys copied him and threw their caps down too! The man gathered his caps and went on his way."
    },
    {
      "title": "The Monkey and the Dolphin",
      "text": "Once upon a time, a monkey fell off a ship into the sea. A kind dolphin rescued him and carried him toward an island. The dolphin asked, 'Are you the king of this island?' The monkey lied and said, 'Yes, I am a very important king here.' The dolphin swam away, leaving the monkey stranded on a tiny rock. The monkey learned that telling lies to impress others never ends well."
    },
    {
      "title": "The Two Cats and the Monkey",
      "text": "Once upon a time, two cats found a piece of cheese but could not agree on how to share it. They asked a monkey to divide it equally. The monkey broke it into two pieces, but one was bigger. He took a bite of the bigger one to make them equal, but then the other piece was bigger! He kept taking bites until the cheese was all gone. The cats learned it is better to share peacefully than to ask a tricky monkey."
    },
    {
      "title": "Milo's Little Adventure",
      "text": "Once upon a time, there was a monkey named Milo. Milo loved to swing from tree to tree. One day, Milo found a tree full of yellow bananas. Milo shared the bananas with his friends. They swung and played together in the forest. Then Milo climbed home and went to sleep."
    }
  ],
  "dog": [
    {
      "title": "Buddy's Bone by the Stream",
      "text": "Once upon a time, a happy little dog named Buddy found a big, juicy bone in the garden. \"This is the best bone I have ever found!\" Buddy said, wagging his tail, and trotted off toward home. On his way, he crossed a little wooden bridge over a clear, calm stream. Buddy looked down into the water and saw another dog looking back at him, holding a bone that looked even bigger. Buddy did not know it was only his own reflection. \"I want that bone too,\" Buddy thought, and opened his mouth to grab it. Splash! His own bone fell right into the stream and floated away. Buddy felt silly, but then he laughed at himself. \"That was just me the whole time!\" he giggled, and walked home a little hungry but still wagging his tail. When Buddy got home, his best friend, a duckling named Daisy, waddled over. She had found two bones that morning and happily gave one to Buddy. \"Thank you, Daisy! Sharing is even better than having the biggest bone,\" said Buddy. From that day on, Buddy always remembered to be grateful for what he already had, and to share whenever he could."
    },
    {
      "title": "Buddy Finds a Lost Kitten",
      "text": "Once upon a time, while trotting through the park, a friendly dog named Buddy heard a tiny, sad meow coming from behind a big bush. He sniffed around and found a small kitten, all alone and unsure which way was home. \"Are you lost, little one?\" Buddy asked gently. The kitten nodded, her whiskers drooping, too shy to speak at first. \"Do not worry, I will help you find your way home,\" said Buddy, and he let the kitten walk close beside him for safety. Together they explored the park, sniffing along the path and looking behind every tree and bench. They passed a friendly squirrel who pointed them toward a cozy house with a red door, and a wise old owl who remembered seeing the kitten play there before. Buddy and the kitten walked all the way to the red door, and the kitten's whiskers twitched with excitement. The door opened, and there stood the kitten's family, overjoyed to see her safe and sound. \"Thank you for bringing her home,\" they said, giving Buddy a big grateful hug. The kitten nuzzled Buddy goodbye, and from that day on, they waved to each other every time Buddy trotted past on his walks, the very best of park friends."
    },
    {
      "title": "The Dog in the Manger",
      "text": "Once upon a time, a grumpy dog fell asleep in a manger full of sweet hay. A tired horse came in, hoping for a meal. But the dog barked and snapped, refusing to let the horse eat. 'You do not even eat hay,' said the horse, 'yet you will not let me have any.' The dog learned that it is selfish to keep things you do not need when others could use them."
    },
    {
      "title": "The Dog and the Wolf",
      "text": "Once upon a time, a hungry wolf met a well-fed farm dog. The dog said, 'Come live with me, you will have plenty of food!' The wolf agreed, until he saw a worn mark on the dog's neck. 'What is that?' asked the wolf. 'It is from the collar they tie me up with,' the dog replied. The wolf turned around and ran back to the forest. 'I would rather be hungry and free than full and tied up,' he said."
    },
    {
      "title": "The Loyal Dog",
      "text": "Once upon a time, a faithful dog guarded his master's house every night. One evening, a thief tossed a juicy piece of meat to the dog to keep him quiet. The dog sniffed the meat but did not eat it. He barked loudly, waking his master and scaring the thief away. The master praised his brave dog, and the dog knew that loyalty was more important than a free meal."
    },
    {
      "title": "Buddy's Little Adventure",
      "text": "Once upon a time, there was a happy dog named Buddy. Buddy loved to run in the sunny garden. One day, Buddy found a bouncy ball under a bush. Buddy played fetch with his friend all day. They ran and laughed in the warm sun. Then Buddy curled up and went to sleep."
    }
  ],
  "cat": [
    {
      "title": "The Clever Cat and the Big Dog",
      "text": "Once upon a time, in a cozy little town, a big friendly dog loved to nap in the warm sunshine. A clever cat named Milly lived right next door in a small blue house. Every day, the big dog's ball would roll into Milly's garden, and his big paws could never fit through the little fence. \"Do not worry,\" said Milly. \"I have an idea.\" Milly's paws were small and quick, perfect for squeezing through the fence gaps, and she would gently roll the ball back to her big friend every time. \"Thank you, Milly! You are small, but so very clever,\" said the big dog. One warm afternoon, the big dog heard Milly meowing from the tallest branch of a tree. She had climbed up to chase a butterfly but now felt too high to climb down. The big dog stood underneath and said, \"Jump down to me, I will catch you safely.\" Milly took a deep breath and jumped into his big, soft paws. \"Thank you for catching me,\" said Milly with a happy purr. \"Now we have both helped each other,\" said the big dog, smiling. From that day on, the small clever cat and the big gentle dog were the very best of friends in the whole town."
    },
    {
      "title": "Milly and the Great Yarn Unraveling",
      "text": "Once upon a time, Milly the cat found a fluffy ball of red yarn in the garden and could not resist giving it one little bat with her paw. The ball rolled and rolled, unraveling a long red thread all the way across the yard, over the fence, and into the flower bed. \"Oh no,\" said Milly, looking at the tangled mess she had made. A friendly dog trotted over and offered to help, carefully picking up one end with his teeth. A family of birds fluttered down and helped tug the thread loose from the flower bed, chirping cheerfully as they worked. Even a slow little snail helped by pushing a stray loop out from under a leaf. Together, they all pulled and wound the long red thread back into a neat, tidy ball, taking turns and giggling at how far it had traveled. \"I could never have fixed this all by myself,\" Milly said, purring with gratitude. The dog wagged his tail, the birds chirped a happy tune, and the snail smiled slowly from his shell. From that day on, whenever Milly played with her yarn, her friends gathered around just to watch the fun, ready to help wind it back up together."
    },
    {
      "title": "The Belling of the Cat",
      "text": "Once upon a time, a family of mice was very afraid of the house cat. They held a meeting to think of a plan. A young mouse suggested, 'Let us tie a bell around the cat's neck, so we can hear her coming!' All the mice cheered, until an old, wise mouse asked, 'But who will be brave enough to tie the bell?' The mice went quiet, realizing that a good idea must also be possible to do."
    },
    {
      "title": "The Cat and the Fox",
      "text": "Once upon a time, a cat and a fox were talking about how to escape danger. The fox boasted, 'I know a hundred tricks to get away!' The cat said humbly, 'I only know one trick, but it usually works.' Just then, a pack of wild dogs ran toward them. The cat quickly climbed up a tall tree, safe and sound. The fox tried to decide which of his hundred tricks to use, but he was too slow."
    },
    {
      "title": "The Cat and the Birds",
      "text": "Once upon a time, a cat heard that the birds in a nearby nest were sick. She dressed up as a doctor and knocked on their tree, hoping for an easy meal. 'I am a doctor, let me in to heal you,' she purred. But the birds saw her sharp claws and whiskers. 'We will feel much better when you go away,' they chirped safely from their nest. The cat learned that true intentions cannot be hidden."
    },
    {
      "title": "Milly's Little Adventure",
      "text": "Once upon a time, there was a curious cat named Milly. Milly loved to chase butterflies in the yard. One day, Milly found a cozy basket by the window. Milly invited her friend to sit with her. They watched the clouds float by together. Then Milly curled up and went to sleep."
    }
  ],
  "bear": [
    {
      "title": "Goldilocks and the Three Bears",
      "text": "Once upon a time, in a cozy cottage deep in the forest, lived Papa Bear, Mama Bear, and Baby Bear. One morning, they made warm porridge for breakfast, but it was much too hot to eat. So the three bears decided to go for a walk in the forest while it cooled down. A curious little girl named Goldilocks was walking nearby and saw their cottage door open. She peeked inside and saw three bowls of porridge on the table. She tried the big bowl, but it was too hot. She tried the medium bowl, but it was too cold. Then she tried the tiny bowl, and it was just right, so she ate it all up. Feeling sleepy, Goldilocks went upstairs and found three cozy beds. The big bed was too hard, and the medium bed was too soft. But the tiny bed was just right, so she curled up and fell asleep. Soon, the three bears came home and found their porridge and beds all a bit different. \"Someone has been eating my porridge!\" said Baby Bear, and then he found Goldilocks fast asleep. Goldilocks woke up and saw the three kind bears smiling at her. \"I am sorry for coming in without asking,\" she said politely. The bears invited her to stay for a warm bowl of porridge, and they all became happy new friends."
    },
    {
      "title": "Barnaby's Honeycomb Gift",
      "text": "Once upon a time, Barnaby the bear followed a sweet, buzzing sound to a tall tree and found a golden honeycomb dripping with honey. His tummy rumbled, but instead of taking it right away, Barnaby noticed a little bee watching him nervously. \"May I please have a small taste of your honey?\" Barnaby asked politely. The bee was so surprised by his kind manners that she buzzed off to ask the whole hive. The bees buzzed together and decided that a bear with such good manners deserved a generous gift, so they filled a large leaf with golden honey for him. \"Thank you so much,\" said Barnaby, and he carried the honey-filled leaf carefully back through the forest. On his way, he met a hungry family of ants, a shy little mouse, and two hopping rabbits, all looking a bit tired and hungry. Barnaby remembered how kind the bees had been to him, so he shared the honey with every single one of them. Everyone gathered around for a sweet little feast, licking their paws and giggling in the warm afternoon sun. \"Asking nicely and sharing kindly go together perfectly,\" Barnaby said with a happy, honey-sticky smile, and the whole forest agreed."
    },
    {
      "title": "The Bear and the Two Travelers",
      "text": "Once upon a time, two friends were walking through a forest when a large bear appeared. One friend quickly climbed a tree and hid. The other friend could not climb, so he fell to the ground and pretended to be dead. The bear sniffed him, whispered in his ear, and walked away. The friend in the tree came down and asked, 'What did the bear say?' The other replied, 'He said never trust a friend who leaves you in danger.'"
    },
    {
      "title": "The Bear's Big Hug",
      "text": "Once upon a time, a strong bear wanted to show everyone how powerful he was. He squeezed a tree trunk so hard it snapped. He squeezed a rock until his arms ached. But the animals were scared of his strength. One day, a little lost bird landed on his nose. The bear gently scooped it up and gave it the softest, warmest hug. The animals realized true strength is knowing when to be gentle."
    },
    {
      "title": "The Bear Who Wanted to Fly",
      "text": "Once upon a time, a heavy bear watched the eagles soar in the sky and wished he could fly. He gathered lots of feathers and glued them to his arms with sticky sap. He climbed a hill and jumped off, flapping hard! But he just rolled down into a soft bush. An eagle landed nearby and said, 'You may not fly, but no eagle can climb a tree or swim a river like you.' The bear smiled, happy to be a bear."
    },
    {
      "title": "Barnaby's Little Adventure",
      "text": "Once upon a time, there was a gentle bear named Barnaby. Barnaby loved to pick berries in the forest. One day, Barnaby found a big bush full of sweet berries. Barnaby shared the berries with his forest friends. They had a happy little picnic together. Then Barnaby went home to his cave and slept."
    }
  ],
  "duck": [
    {
      "title": "The Little Duckling Who Was Different",
      "text": "Once upon a time, on a sunny farm pond, a mother duck watched her eggs hatch one by one. Out popped five fluffy yellow ducklings, and then one more that looked quite different - he was bigger, with grey feathers instead of yellow. The other ducklings did not want to play with him because he looked different. The little duckling felt sad, so he swam away to explore the wide, wide world. He met friendly frogs by the reeds and gentle fish in the cool water, and traveled through meadows and over hills as the seasons changed. One cold winter, he found a beautiful lake covered in soft white snow. In spring, he saw a group of graceful white swans gliding across the water. He swam over shyly, unsure if they would want to be his friends. When he looked down at his reflection, he gasped with surprise and joy - he had grown into a beautiful swan himself, with long elegant feathers. The other swans welcomed him warmly, and he swam among them, happy at last. He learned that everyone grows and changes in their own special time, and that he was loved for exactly who he was, both before and after he changed."
    },
    {
      "title": "Daisy Leads the Way",
      "text": "Once upon a time, Daisy the duck was the oldest of her brothers and sisters, and one morning their mother asked her to lead the little ducklings across the pond. \"Follow me closely,\" Daisy said proudly, paddling out in front of the wobbly line of fluffy ducklings. Halfway across, the smallest duckling started paddling the wrong way, drifting toward the tall reeds instead of following the group. Daisy noticed right away and paddled back gently. \"This way, little one, stay close to me,\" she said kindly, guiding him back into line. A strong breeze rippled the water, and the ducklings wobbled, but Daisy quacked cheerfully to keep everyone calm and steady. \"We are almost there, keep paddling!\" she called out, and one by one, the ducklings found their courage again. When they finally reached the sunny bank on the other side, all the ducklings cheered and hugged Daisy with their soft little wings. \"You kept us safe the whole way,\" they said happily. Their mother swam up, so proud of how well Daisy had led her siblings. \"Being a leader means looking out for everyone, even the smallest one,\" Daisy said with a warm smile, and from that day on, she always led the way with a caring eye on every duckling behind her."
    },
    {
      "title": "The Golden Egg",
      "text": "Once upon a time, a farmer had a special duck that laid one golden egg every single day. The farmer grew rich, but he also grew greedy. 'If I open the duck, I can get all the gold at once!' he thought. But when he did, he found the duck was just like any other duck inside. He lost his duck and his daily golden eggs, learning that greed can make you lose everything."
    },
    {
      "title": "The Duck and the Frog",
      "text": "Once upon a time, a duck and a frog lived in the same pond. The frog croaked loudly, 'I am the best swimmer!' The duck quacked, 'No, I am the best!' They decided to race. The frog leaped far, but got tired quickly. The duck paddled steadily and crossed the pond first. The frog learned that slow, steady effort can beat a fast start that fades away."
    },
    {
      "title": "The Duck's New Song",
      "text": "Once upon a time, a little duck was tired of just quacking. She wanted to sing beautifully like a nightingale. She practiced all day, opening her beak wide, but only loud 'Quacks' came out. The other ducks laughed, but a wise owl said, 'Your quack warns your family of danger and calls them to dinner. It is the most useful song of all.' The duck felt proud and quacked happily ever after."
    },
    {
      "title": "Daisy's Little Adventure",
      "text": "Once upon a time, there was a little duck named Daisy. Daisy loved to swim in the calm lake. One day, Daisy found a family of fish swimming below. Daisy waved hello and they swam together. They splashed and played until the evening. Then Daisy waddled home and went to sleep."
    }
  ],
  "cow": [
    {
      "title": "Clover's Shared Meadow",
      "text": "Once upon a time, on a green and sunny farm, a gentle cow named Clover lived in a big meadow full of clover flowers. One morning, a family of rabbits came looking for a new home nearby. \"There is so little grass left where we live,\" said the littlest rabbit. Clover looked at her big, beautiful meadow and said kindly, \"There is more than enough room here for all of us.\" The rabbits happily made their new burrow under the old oak tree. Soon, a family of ducks arrived too, looking for a pond to swim in, and Clover showed them the little pond at the edge of her meadow. Every animal that came to Clover's meadow was welcomed with a warm smile, and the meadow grew busier and busier, full of hopping, swimming, and singing friends. One day, a strong summer storm knocked down part of the old fence. All the animals worked together, carrying branches and stones to fix it. \"Thank you for sharing your home with us,\" said the rabbit family. \"A meadow is always better and more beautiful when it is shared,\" said Clover. From that day on, Clover's meadow was known as the happiest, friendliest place on the whole farm."
    },
    {
      "title": "Clover's Missing Bell",
      "text": "Once upon a time, Clover the cow woke up from her nap and realized the little golden bell she always wore around her neck was gone. \"Oh no, where could it be?\" she said, feeling quite puzzled, since the bell had been a gift from the farmer. A family of rabbits heard her fretting and hopped over to help her search through the tall grass. A curious crow flew overhead, scanning the meadow from high in the sky for any golden glint. Even the other cows wandered over, sniffing around the fence posts and the old oak tree together. They searched all morning, but the little bell was nowhere to be found, and Clover began to feel quite down. Just then, the crow gave a loud caw and swooped down toward the pond. \"I see something shiny by the water!\" he called out. Everyone rushed over, and there, resting gently in the mud by the pond, was Clover's golden bell. \"You found it!\" Clover said joyfully, and the farmer helped tie it snugly back around her neck. She gave the crow, the rabbits, and all her cow friends a grateful nuzzle. \"A whole meadow of friends searching together can find anything,\" Clover said happily, her little bell jingling all the way home."
    },
    {
      "title": "The Cow and the Tiger",
      "text": "Once upon a time, a tiger caught a cow in the forest. The cow pleaded, 'Please let me go feed my hungry calf one last time. I promise I will return.' The tiger, curious, agreed. The cow fed her calf, said goodbye, and walked bravely back to the tiger. The tiger was so amazed by her honesty and courage that he let her go free. True honesty is always rewarded."
    },
    {
      "title": "The Three Cows",
      "text": "Once upon a time, three cows—one red, one white, and one black—lived together and always stayed close. A hungry lion wanted to eat them, but they were too strong together. The lion whispered lies to the red and black cows, saying the white cow was eating all the best grass. They left the white cow alone, and the lion caught her. Soon, divided, they were all caught. They learned that unity is strength."
    },
    {
      "title": "The Cow's Sweet Milk",
      "text": "Once upon a time, a proud cow refused to give milk because she thought she was too important. The farmer sighed and gave her no fresh hay. A little calf came by, hungry and sad. The cow's heart softened, and she gave the calf a warm drink. The farmer smiled and brought her the sweetest hay. The cow learned that giving kindly to others brings kindness back to you."
    },
    {
      "title": "Clover's Little Adventure",
      "text": "Once upon a time, there was a friendly cow named Clover. Clover loved to graze in the green meadow. One day, Clover found a field full of yellow flowers. Clover shared the pretty spot with her friends. They rested together under the big blue sky. Then Clover walked home and went to sleep."
    }
  ],
  "tiger": [
    {
      "title": "The Tiger Who Learned to Share",
      "text": "Once upon a time, deep in the tall green jungle, there was a watering hole where all the animals came to drink. A proud tiger named Tara believed it belonged only to her. \"This is my water, go find your own!\" she would say to the other animals, and the elephants, monkeys, and birds all had to walk far away to find water instead. One very hot summer, the sun blazed down and every other watering hole dried up completely. Tara's own watering hole began to shrink smaller and smaller each day. A wise old elephant gently said, \"Water is meant to be shared by everyone, Tara.\" Tara thought about all her friends walking so far away just for a drink, and she felt sorry for how she had acted. She invited everyone back to the watering hole, and the monkeys, birds, and elephants all came together, drinking side by side happily. Tara found that sharing the water made the jungle feel warm and friendly again. She even made new friends who taught her fun games to play in the water. From that day on, Tara welcomed every animal to her watering hole with a warm smile, and learned that some things, like water and friendship, are always better when shared."
    },
    {
      "title": "Tara's Stripe Surprise",
      "text": "Once upon a time, Tara the tiger loved to play hide and seek in the tall, striped grass of the jungle. \"You will never find me!\" she giggled, crouching down low so her orange and black stripes blended perfectly with the swaying grass around her. Her friends, a chattering monkey and a waddling duck, searched high and low, peeking behind trees and under bushes. \"Where could she be?\" the monkey wondered, scratching his head as he walked right past Tara without noticing her at all. Tara had to cover her mouth to stop from giggling as her friends searched right beside her. Finally, the little duck spotted the tip of her tail swishing gently and shouted, \"Found you!\" Tara jumped out, laughing so hard that the whole jungle seemed to laugh along with her. \"Your stripes are like a magic hiding cloak,\" said the monkey, amazed at how well she had blended in. \"I used to think my stripes just made me look different from everyone,\" Tara said thoughtfully, \"but now I know they make me special.\" From that day on, Tara's stripes became the best part of every hide and seek game, and her friends always begged her to play just one more round."
    },
    {
      "title": "The Tiger and the Woodpecker",
      "text": "Once upon a time, a tiger got a sharp bone stuck in his throat. He roared in pain. A brave woodpecker offered to pull it out if the tiger promised not to eat him. The bird pulled the bone out perfectly. Later, the bird asked for a small piece of the tiger's meal as a reward. The tiger growled, 'Your reward is that I did not eat you!' The bird flew away, knowing never to trust a selfish tiger again."
    },
    {
      "title": "The Tiger's Golden Bangle",
      "text": "Once upon a time, an old tiger held a shiny golden bangle and called out to a traveler, 'Come take this gift! I have changed my ways and am now a peaceful tiger.' The traveler wanted the gold but was afraid. The tiger spoke so softly that the traveler finally stepped near. Snap! The tiger caught him. The traveler learned that a shiny trap is still a trap."
    },
    {
      "title": "The Brave Tiger",
      "text": "Once upon a time, a young tiger was afraid of the dark. When night fell, he hid in his den while the other tigers explored. One night, a little firefly flew into his den. 'Follow my light,' the firefly buzzed. The tiger followed the tiny glow out into the cool, quiet jungle. He saw the beautiful moon and stars, and realized the dark was nothing to fear when you look for the light."
    },
    {
      "title": "Tara's Little Adventure",
      "text": "Once upon a time, there was a playful tiger named Tara. Tara loved to explore the jungle paths. One day, Tara found a cool stream between the trees. Tara invited her friends to splash and play. They had a wonderful time together in the jungle. Then Tara walked home and went to sleep."
    }
  ],
  "fox": [
    {
      "title": "The Fox and the Grapes",
      "text": "Once upon a time, in a sunny vineyard, a hungry fox named Finn went looking for a snack. He spotted a bunch of juicy purple grapes hanging from a tall vine. \"Those grapes look delicious,\" Finn said, and jumped up to reach them. He jumped once, but the grapes were too high. He jumped twice, and still could not reach them. He tried again and again, jumping as high as he could. But no matter how hard he tried, the grapes stayed just out of reach. Finn sat down under the vine, feeling a little disappointed. Just then, a friendly bird landed beside him. \"Would you like some help?\" the bird chirped. The bird flew up and gently dropped a few grapes down to Finn. \"Thank you, friend!\" said Finn happily, munching on the sweet grapes. \"I could not reach them alone, but together we did it.\" From that day on, Finn and the bird looked for snacks together every single day. Finn learned that asking for help is never something to be shy about. And the bird learned that even a clever fox appreciates a helping wing. They shared many more sunny afternoons, and every grape tasted sweeter when shared with a friend."
    },
    {
      "title": "Finn's Winter Trade",
      "text": "Once upon a time, as autumn leaves turned gold and the air grew crisp, Finn the fox realized he had no warm blanket for the coming winter. He had plenty of juicy red berries from his favorite bush, but no wool or feathers to keep him cozy. Finn visited his friend the sheep and offered a basket of sweet berries in exchange for a soft tuft of wool. \"A fair trade,\" said the sheep happily, munching on the berries while Finn gathered the fluffy wool. Next, Finn visited a family of geese, trading a handful of shiny pebbles he had found by the stream for a few soft, downy feathers. He wove the wool and feathers together with dried grass, working carefully every evening until he had a warm, cozy blanket. When the first snow began to fall, Finn snuggled into his new blanket, toasty and warm inside his den. He remembered his friends' kindness and made sure to visit them all winter, sharing stories and keeping each other company. \"Helping each other made all of us ready for winter,\" Finn said, wrapping his fluffy tail around himself contentedly. The sheep, the geese, and Finn became the best of friends, trading favors and warm company all season long."
    },
    {
      "title": "The Fox and the Crow",
      "text": "Once upon a time, a crow found a delicious piece of cheese and flew to a high branch. A hungry fox saw the cheese and said, 'Oh, beautiful crow! Your feathers are so shiny. I bet your voice is the most beautiful in the forest. Please sing for me!' The flattered crow opened her beak to sing, and the cheese fell right into the fox's mouth. The fox trotted away, and the crow learned not to trust sweet words."
    },
    {
      "title": "The Fox and the Stork",
      "text": "Once upon a time, a fox invited a stork to dinner. He served tasty soup in a very flat dish. The fox lapped it up easily, but the stork's long beak could not get a single drop. The next day, the stork invited the fox. She served a delicious meal in a tall, narrow jar. The stork ate easily, but the fox's nose would not fit. The fox learned that you should treat others the way you want to be treated."
    },
    {
      "title": "The Fox without a Tail",
      "text": "Once upon a time, a fox got his tail caught in a trap and had to leave it behind. He felt very embarrassed without his fluffy tail. He called a meeting of all the foxes and said, 'Tails are so heavy and useless! We should all cut ours off.' The other foxes laughed and said, 'You only say that because you lost yours.' The fox walked away, realizing he could not trick his friends."
    },
    {
      "title": "Fenn's Little Adventure",
      "text": "Once upon a time, there was a clever fox named Fenn. Fenn loved to explore the quiet forest paths. One day, Fenn found a shiny berry bush near a stream. Fenn shared the berries with a hungry little bird. They became good friends and explored the forest together. Then Fenn curled up in his den and went to sleep."
    }
  ],
  "pig": [
    {
      "title": "The Three Little Pigs",
      "text": "Once upon a time, three little pigs decided to build their own houses in the meadow. The first little pig built his house out of straw because it was quick and easy. The second little pig built his house out of sticks because it was a little sturdier. The third little pig worked hard and built his house out of strong red bricks. One day, a big windy storm rolled across the meadow, huffing and puffing through the trees. The straw house wobbled and swayed, so the first little pig hurried to his brother's stick house. But the stick house creaked and shook too, so both pigs ran to their sister's brick house. The brick house stood strong and steady, keeping out the wind and rain. All three pigs snuggled inside, warm and safe, listening to the storm outside. \"Your house is the strongest of all!\" said the first little pig. \"Building carefully takes longer, but it was worth it,\" said the third little pig with a smile. The next morning, the storm passed and the sun came out brightly. The three pigs worked together to rebuild the straw and stick houses, stronger this time. From that day on, the three little pigs always helped each other build, and their meadow became the coziest place around."
    },
    {
      "title": "Percy's Rainy Day Fun",
      "text": "Once upon a time, dark clouds rolled over the farmyard and rain began to patter down, sending most of the animals scurrying for cover. But Percy the pig loved rainy days more than anything, because rain meant the best, squishiest mud puddles in the whole farmyard. He trotted outside and jumped into a big puddle with a happy splash. Nearby, a little chick and a wooly lamb watched from under the barn roof, wishing they could play but not wanting to get wet and cold. \"Come join me!\" Percy called out cheerfully, splashing about with glee. \"But rain is so gloomy,\" said the lamb, peeking out from the dry barn. Percy thought for a moment, then invited them to play a splashing game instead, hopping from dry spot to dry spot without ever getting fully wet. Soon the chick was hopping along the fence rail, and the lamb was leaping over little puddles, both giggling with delight. By the time the rain stopped, the whole barnyard was full of happy laughter instead of gloom. \"You turned a rainy day into the best day ever,\" said the lamb, shaking a bit of water from her wool. Percy grinned his muddiest grin. \"Every kind of weather can be fun, if you share it with friends,\" he said happily."
    },
    {
      "title": "The Pig and the Sheep",
      "text": "Once upon a time, a pig was put into a pen with a flock of sheep. When the farmer came and picked the pig up, he squealed and kicked loudly. The sheep said, 'He catches us all the time, and we do not make such a fuss.' The pig replied, 'He only wants your wool, but he wants my bacon!' The sheep realized that everyone's worries are different, and some have more to fear."
    },
    {
      "title": "The Pig's Clean House",
      "text": "Once upon a time, a messy pig lived in a very untidy house. His friends did not want to visit because there was mud everywhere. One day, the pig found a beautiful, shiny mirror. He put it on his wall, but the mud made the room look even messier in the reflection. The pig spent all day cleaning until the room sparkled. His friends came over, and they all admired his bright, clean home."
    },
    {
      "title": "The Flying Pig",
      "text": "Once upon a time, a little pig dreamed of flying. He tied big palm leaves to his arms and jumped off a small rock, landing softly in a mud puddle. The birds giggled, but the pig didn't mind. He kept practicing, jumping off higher rocks and into deeper puddles. He never truly flew, but he became the best mud-jumper in the farmyard, which he decided was just as fun."
    },
    {
      "title": "Percy's Little Adventure",
      "text": "Once upon a time, there was a happy pig named Percy. Percy loved to splash in the cool mud puddle. One day, Percy found a garden full of ripe red apples. Percy shared the apples with his farmyard friends. They played and splashed together until the sun set. Then Percy trotted to the barn and went to sleep."
    }
  ],
  "giraffe": [
    {
      "title": "Gigi and the Kite in the Treetop",
      "text": "Once upon a time, on a breezy afternoon, a little rabbit's bright red kite got caught high in the branches of the tallest tree in the meadow. \"My kite, oh my poor kite,\" the rabbit sniffled, hopping up and down but unable to reach it. Gigi the giraffe heard the sad little voice and ambled over on her long, graceful legs. \"Do not worry, let me see if I can help,\" she said kindly, stretching her long neck up toward the very top branches. She stretched and stretched, her neck reaching higher than any animal in the meadow had ever seen. With a gentle nudge of her nose, Gigi carefully freed the kite string from the tangled branch. The bright red kite came fluttering down, and the rabbit caught it with a joyful hop. \"Thank you, thank you!\" the rabbit cheered, hugging Gigi's tall leg. Word spread quickly through the meadow, and soon other animals came running with their own stuck balloons, kites, and even a lost hat caught in the trees. Gigi spent the whole afternoon happily rescuing treasures from high branches with her long, helpful neck. \"Being tall is wonderful, especially when it helps so many friends,\" Gigi said with a smile, as the whole meadow flew their kites together once again."
    },
    {
      "title": "The Tallest Tree",
      "text": "Once upon a time, Gigi the giraffe was the only animal who could reach the sweet leaves of the star-tree. A cheeky monkey tried to climb it, but the trunk was too slippery. The monkey asked Gigi for a boost. Gigi happily let the monkey climb her long neck. Together, they reached the very top and shared the sweetest leaves in the whole jungle."
    },
    {
      "title": "The Giraffe's Scarf",
      "text": "Once upon a time, winter came early to the savanna. A tall giraffe felt very cold on her long neck. A flock of friendly weaver birds decided to help. They gathered soft grass and warm feathers, weaving the longest, coziest scarf anyone had ever seen. They wrapped it around the giraffe's neck, and she smiled warmly, thankful for her little friends."
    },
    {
      "title": "The Giraffe and the Hippo",
      "text": "Once upon a time, a tall giraffe and a short, heavy hippo wanted to play a game. The hippo wanted to play hide-and-seek in the water, but the giraffe could not hide her long neck. The giraffe wanted to race, but the hippo was too slow. Finally, they decided to play a guessing game in the shade. They learned that the best games are the ones everyone can enjoy."
    },
    {
      "title": "The Giraffe Who Shared the Treetops",
      "text": "Once upon a time, Gigi the giraffe was tall enough to see the sunrise before anyone else. Every morning, she would look across the savanna and tell the sleepy animals that the golden sun was rising. One morning, dark rain clouds rolled in. Gigi looked high above the mist and saw a bright rainbow forming. She called down to all her forest friends to look up. Together, they watched the beautiful colors stretch across the sky, happy to have a tall friend who shared the morning wonder."
    },
    {
      "title": "The Giraffe Who Shared the Treetops",
      "text": "Once upon a time, in a sunny savanna, there lived a tall giraffe named Gigi. Gigi could reach the juiciest leaves at the very top of the tallest trees. One day, a family of small rabbits hopped by, looking hungry and tired. \"There is no food left down here,\" said the littlest rabbit sadly. Gigi looked down at her new friends and had a wonderful idea. She gently lowered her long neck and pulled down a branch full of fresh green leaves. The rabbits nibbled happily on the leaves Gigi shared with them. Soon, a family of turtles and a family of mice came by too, and Gigi lowered branch after branch for all of them. \"Thank you, Gigi! You are the tallest and the kindest,\" said the rabbits together. From that day on, every morning, all the animals gathered under Gigi's favorite tree. Gigi would reach up high and share the treetop leaves with everyone below. The little animals brought her flowers and berries in return, and they all had a wonderful picnic together. Gigi realized that being tall was not just for reaching the sky, but for helping her friends reach it too. And every single day, the savanna felt a little more like one big happy family."
    }
  ],
  "zebra": [
    {
      "title": "Ziggy's Stripe Painting Day",
      "text": "Once upon a time, on a sunny afternoon, Ziggy the zebra and his friends decided to have a painting day by the watering hole. \"I only have black and white stripes,\" Ziggy said, looking a little wistfully at a peacock's colorful feathers nearby. The peacock smiled and offered to share some of her bright blue and green paint, while a flamingo offered a splash of pink. Ziggy dipped his hoof carefully and painted swirling patterns onto a big smooth rock, mixing his stripes with all the borrowed colors. A young elephant joined in with gray paint for clouds, and a family of parrots added yellow suns and orange flowers all around the edges. Soon the plain rock had become a beautiful, colorful mural made by every animal's favorite color, working together side by side. \"Your stripes gave the painting its pattern, and everyone else gave it color,\" said the peacock, admiring their teamwork. Ziggy looked at the finished painting and felt proud that his simple black and white stripes had helped hold the whole colorful picture together. \"We each brought something different, and together it is beautiful,\" Ziggy said happily. From that day on, the animals painted by the watering hole every sunny afternoon, always finding new colors and patterns to share."
    },
    {
      "title": "The Zebra's New Run",
      "text": "Once upon a time, a young zebra named Ziggy wanted to be the fastest runner. He practiced running in straight lines every day. A wise old cheetah told him, 'Speed is good, but turning is better.' Ziggy practiced zigzagging through the trees. One day, a lion chased the herd. Ziggy zigged and zagged so well that the lion got dizzy and gave up. Ziggy saved the day with his clever turns."
    },
    {
      "title": "The Zebra and the Donkey",
      "text": "Once upon a time, a tired donkey wished he looked as beautiful as his cousin, the zebra. He painted black and white stripes on himself with mud and chalk. He strutted proudly, until a heavy rainstorm washed all the stripes away. The other animals laughed, but the donkey realized he was happy just being a strong, useful donkey, stripes or no stripes."
    },
    {
      "title": "The Zebra's Shadow",
      "text": "Once upon a time, a little zebra was frightened of his own shadow. Every time he ran, the dark shape followed him. He tried running faster, but it stayed right behind him. His mother gently guided him into the shade of a big tree. 'Look,' she said, 'in the cool shade, the shadow rests.' The little zebra learned that there is always a safe place to rest when you are afraid."
    },
    {
      "title": "The Zebra's Secret Crossing",
      "text": "Once upon a time, Ziggy the zebra was leading his herd across a wide, rushing river. The river stones were slick and slippery, and the baby zebras were frightened of the swirling water. Ziggy stepped forward boldly, planting his strong hooves firmly on each smooth stone to test the path. 'Step right where my stripes shine,' he called encouragingly. Following his clear black and white stripes, every little zebra crossed the river safely to the green meadow on the other side."
    },
    {
      "title": "The Zebra's New Friend",
      "text": "Once upon a time, on a wide grassy plain, a young zebra named Ziggy loved to gallop with his herd. One sunny morning, Ziggy noticed a little lion cub wandering alone near the tall grass. The cub looked lost and did not know which way was home. Most zebras would have run far away, but Ziggy was curious and kind. \"Are you lost, little one?\" Ziggy asked gently. The cub nodded, feeling very small and unsure. \"Climb up close to my stripes and stay near me,\" said Ziggy. \"We will find your family together.\" Ziggy trotted slowly across the plain, letting the little cub walk right beside him. They crossed a bubbling stream and passed a grove of tall trees. Finally, they heard a familiar roar in the distance. The cub's family came running, so happy to see their little one safe and sound. \"Thank you for helping my cub,\" said the mother lion warmly. \"Any friend in need deserves a helping hoof,\" said Ziggy with a smile. From that day on, the zebras and the lions shared the plain peacefully, checking on each other every day. Ziggy learned that even animals who look very different can become the best of friends."
    }
  ],
  "horse": [
    {
      "title": "Star's Muddy Race",
      "text": "Once upon a time, Star the horse invited all her farmyard friends to race across the big meadow to the old oak tree. \"Ready, set, go!\" she called, and everyone dashed off - a bouncy rabbit, a waddling duck, and a slow little tortoise trailing far behind. Star galloped ahead easily, but when she glanced back, she noticed the little tortoise had gotten stuck in a patch of soft, sticky mud. The rabbit and the duck were too far ahead to notice, racing eagerly toward the finish line. Star turned around and trotted back through the mud to where the tortoise was waiting. \"Climb up here with me,\" Star said gently, lowering herself so the tortoise could hop onto her back. Together, they trotted the rest of the way, the tortoise holding on tight and giggling at the bumpy ride. When they crossed the finish line together, the rabbit and duck, who had arrived first, cheered just as loudly for Star and the tortoise as they had for themselves. \"It is not just about who finishes first,\" Star said, nuzzling the tortoise kindly. \"It is about making sure everyone finishes together.\" From that day on, every race in the meadow ended the same joyful way - with all four friends crossing the line side by side."
    },
    {
      "title": "The Horse and the Stag",
      "text": "Once upon a time, a horse and a stag had a fight over a meadow. The horse asked a man for help to chase the stag away. The man agreed, but put a saddle on the horse and a bit in his mouth. They chased the stag away, but when the horse asked the man to take off the saddle, the man refused. The horse learned that asking for revenge can cost you your freedom."
    },
    {
      "title": "The Horse's Silver Shoes",
      "text": "Once upon a time, a proud horse wore shiny silver shoes. He clomped loudly on the stones so everyone would look at him. A quiet pony walked by on soft hooves, carrying a heavy load of apples for the hungry village. The people cheered for the pony and ignored the loud horse. The horse learned that doing good deeds shines brighter than silver shoes."
    },
    {
      "title": "The Proud Horse",
      "text": "Once upon a time, a beautiful horse wearing a fancy saddle pushed past a tired donkey carrying a heavy load of wood. 'Make way for me!' the horse neighed proudly. The donkey stepped aside in silence. Months later, the horse grew old and was sent to carry heavy logs himself. He saw the donkey and bowed his head, realizing that pride does not last forever."
    },
    {
      "title": "The Gentle Farm Guardian",
      "text": "Once upon a time, Star the horse lived in a peaceful barn at the foot of the rolling green hills. Whenever the farmer left the gate open by mistake, the little piglets and ducklings would wander near the tall forest edge. Star would gently trot behind them, making soft neighing sounds to guide them safely back to the warm hay barn. The whole farm trusted Star because her big, kind heart kept everyone safe and snug."
    },
    {
      "title": "The Horse Who Carried Everyone Home",
      "text": "Once upon a time, on a green and hilly farm, there lived a strong and gentle horse named Star. Star loved carrying her animal friends on her back through the meadow. One afternoon, dark clouds rolled in and rain began to fall softly, then harder. A family of ducklings waddled as fast as they could, but the barn was still far away. \"Hop onto my back,\" said Star kindly, lowering herself so the little ducklings could climb up. She trotted carefully through the wet grass, carrying the ducklings safely along. On the way, she found a family of chickens huddled under a small bush, feathers damp and cold. \"There is always room for more,\" said Star, and the chickens climbed up too. She carried everyone gently across the field, step by careful step, until the big red barn came into view. Everyone cheered as Star trotted through the barn doors just as the rain grew heavy outside. Warm and dry, the ducklings and chickens thanked Star for her strong back and kind heart. \"That is what friends are for,\" said Star with a happy neigh. From that day on, whenever the sky turned grey, all the farm animals knew exactly where to find their favorite ride home."
    }
  ],
  "panda": [
    {
      "title": "Bao's Quiet Afternoon",
      "text": "Once upon a time, in a peaceful bamboo forest, Bao the panda loved nothing more than sitting quietly and watching the leaves sway gently in the breeze. His energetic friend, a bouncy little rabbit, zoomed past him again and again, hopping and tumbling with endless excitement. \"Bao, why do you just sit there? Come play chase with me!\" the rabbit asked, a little breathless from all his hopping. Bao smiled softly and patted the soft grass beside him. \"Would you like to try something different with me instead?\" he asked kindly. The rabbit plopped down, curious, and Bao showed him how to watch a single leaf drift slowly down from a tall branch, and how to listen closely to the birds singing far away. At first, the rabbit wiggled and fidgeted, unused to sitting so still, but slowly his breathing grew calm and easy. They watched clouds drift by, shaped like bunnies and boats, and listened to the gentle rustle of the bamboo leaves together. \"I did not know quiet could feel this nice,\" the rabbit said softly, resting his head against Bao's soft, round belly. \"Sometimes the best adventures are the quiet ones,\" Bao said with a peaceful smile, and from then on, they shared both quiet afternoons and bouncy playtimes together, each just as special as the other."
    },
    {
      "title": "The Panda's Bamboo",
      "text": "Once upon a time, a panda found a huge, tasty bamboo shoot. He wanted to save it all for himself, so he hid it behind a rock. But while he slept, a family of beetles ate the whole thing! The panda woke up sad. His friend offered him a fresh piece of bamboo to share. The panda learned that sharing a little today is better than losing everything tomorrow."
    },
    {
      "title": "The Panda and the Moon",
      "text": "Once upon a time, a panda loved the moon so much he wanted to hold it. He climbed the tallest mountain, reaching up into the night sky, but the moon was still too far away. He sat down and cried. A little firefly flew by and landed on his nose, glowing brightly. The panda smiled, realizing he didn't need the moon when he had a little star right here."
    },
    {
      "title": "The Panda's Soft Bed",
      "text": "Once upon a time, a panda was looking for the softest place to sleep. He tried a pile of dry leaves, but they crunched too loudly. He tried a patch of moss, but it was too wet. Finally, he cuddled up next to his sleeping brother. It was warm, quiet, and perfectly soft. The panda learned that the best place to rest is close to family."
    },
    {
      "title": "The Bamboo Waterfall Adventure",
      "text": "Once upon a time, Bao the panda discovered a hidden waterfall deep in the mist-covered mountains. Beside the sparkling water grew the sweetest, crunchiest bamboo shoots he had ever seen. Instead of keeping the secret waterfall to himself, Bao marked a gentle trail through the mossy rocks with bright flowers. Soon, his panda cousins and woodland bird friends joined him for a wonderful picnic beside the cool, misting spray."
    },
    {
      "title": "The Panda Who Loved to Share",
      "text": "Once upon a time, deep in a misty bamboo forest, there lived a round and cuddly panda named Bao. Bao loved munching on fresh green bamboo every single day. One morning, Bao noticed a family of small birds chirping sadly on a nearby branch. \"What is wrong?\" asked Bao, looking up with curious eyes. \"Our nest is empty, and we cannot find enough to eat,\" chirped the littlest bird. Bao thought for a moment, then broke off a soft, tender piece of bamboo shoot. \"Try this,\" said Bao, holding it up gently. The birds pecked happily at the bamboo, chirping with delight. Word soon spread through the forest, and more hungry friends came to visit Bao's favorite bamboo patch. A family of rabbits, a shy fox, and even a family of squirrels all came by for a snack. Bao happily shared bamboo with every visitor, never keeping the best pieces just for himself. Soon, the whole forest gathered around Bao's patch every afternoon, munching and chatting together happily. \"Sharing makes everything taste better,\" said Bao with a happy smile. The animals agreed, and from that day on, Bao's bamboo patch became the friendliest spot in the whole misty forest."
    }
  ],
  "sheep": [
    {
      "title": "Wooly's Warm Wool Blanket",
      "text": "Once upon a time, as the first winter frost settled over the hillside, Wooly the sheep noticed her friend the little lamb shivering behind a bush. \"You look so cold,\" Wooly said, trotting over with concern. \"I lost my warm coat and I cannot find it anywhere,\" the lamb said, teeth chattering softly. Wooly looked down at her own thick, fluffy wool coat and had a wonderful idea. She visited the kind farmer, who gently combed a soft handful of extra wool from her back, easy and painless as could be. Wooly carried the fluffy wool to a family of birds, who helped weave it into a warm, cozy little blanket using their nimble beaks. Together, they wrapped the finished blanket snugly around the shivering lamb, who immediately stopped shaking and let out a happy sigh. \"This is the warmest, softest blanket I have ever felt,\" the lamb said, snuggling in gratefully. Wooly felt warm inside too, even though she had a little less wool than before. \"Sharing warmth is the best way to stay warm yourself,\" Wooly said with a smile. From that winter on, Wooly and the birds made cozy wool blankets for any chilly friend on the hillside, and no one ever shivered alone again."
    },
    {
      "title": "The Boy Who Cried Wolf",
      "text": "Once upon a time, a young shepherd boy was bored watching his sheep. He yelled, 'Wolf! Wolf!' just for fun. The villagers ran up the hill to help, but there was no wolf. He did it again the next day, laughing at the angry villagers. On the third day, a real wolf appeared. The boy yelled for help, but nobody came. They learned that a liar is not believed, even when telling the truth."
    },
    {
      "title": "The Black Sheep",
      "text": "Once upon a time, a black sheep lived in a flock of white sheep. The white sheep thought she was strange and left her out of their games. One winter, a heavy snowstorm covered the hills in white. The shepherd could not find his flock in the snow! But then he spotted the black sheep standing out against the snow. He rescued them all, and the flock learned that being different is a wonderful thing."
    },
    {
      "title": "The Sheep and the Pig",
      "text": "Once upon a time, a sheep and a pig shared a pen. The sheep quietly gave her wool every spring, but the pig complained about everything. 'The mud is too dry! The food is too boring!' he grunted. One day, the farmer brought them a basket of sweet apples. The sheep ate happily, but the pig complained the apples were too small. The sheep smiled, knowing that gratitude makes everything taste sweeter."
    },
    {
      "title": "The Meadow Bell of Kindness",
      "text": "Once upon a time, Wooly the sheep was given a shiny silver bell to wear around her fluffy neck. Whenever a timid little lamb got lost in the clover fields, Wooly would ring her gentle bell: 'Tinkle, tinkle!' Hearing the warm, familiar chime, the lost lambs followed the sound right back to the cozy flock. Wooly learned that her cheerful bell was a beacon of safety and warmth for everyone."
    },
    {
      "title": "The Sheep Who Counted Her Friends",
      "text": "Once upon a time, on a quiet hill under a starry sky, a fluffy sheep named Wooly could not fall asleep. She tossed and turned in the soft grass, wide awake. \"Maybe counting will help,\" Wooly thought, and she began to count the twinkling stars above. As she counted, a little rabbit hopped over the fence nearby. \"One rabbit,\" Wooly counted with a smile. Soon, a family of ducks waddled by and hopped over the fence too. \"Two, three, four ducks,\" Wooly counted happily, feeling a little sleepier already. A gentle cow ambled over and hopped playfully over the fence as well. \"Five!\" giggled Wooly, watching her friends gather around her in the soft moonlight. One by one, more animals came to visit, hopping over the fence and settling down in the grass beside her. Soon the whole hillside was filled with cozy, sleepy friends, all counted and all welcome. Wooly realized she was not just counting sheep anymore, but counting all her wonderful friends. Snuggled together under the twinkling stars, the animals drifted off to sleep one by one. Wooly smiled, feeling warm and happy, surrounded by every friend she had counted that night."
    }
  ],
  "kangaroo": [
    {
      "title": "Roo's Big Hop Adventure",
      "text": "Once upon a time, at the edge of a wide, sandy field, Roo the kangaroo practiced her bouncing hops higher and higher every single day. Her friend, a small and timid turtle, watched from a safe distance, wishing she could hop so high but feeling much too nervous to try. \"Would you like to learn?\" Roo asked kindly, noticing the turtle's longing look. \"I am too slow and my legs are too short,\" the turtle said shyly, tucking into her shell a little. Roo did not laugh or hurry her; instead, she sat down beside the turtle and showed her a tiny hop, just barely off the ground. The turtle tried it, wobbling but managing a small, proud little bounce. \"You did it!\" Roo cheered, clapping her paws together. Every day after that, they practiced a little more, the turtle's hops growing just a bit bigger and braver each time. She would never hop as high as Roo, and that was perfectly fine, because she had found her own happy bounce. One sunny morning, the turtle hopped clean over a little stick, and the whole field of animals cheered for her. \"Being brave does not mean hopping the highest,\" Roo said proudly. \"It means trying your very own hop.\" And the turtle smiled the biggest smile of her life."
    },
    {
      "title": "The Kangaroo's Jump",
      "text": "Once upon a time, a young kangaroo wanted to jump over the tallest fence in the outback. He tried and tried, but always bumped his toes. An old kangaroo told him, 'Do not look at the fence, look at the sky beyond it.' The young kangaroo took a deep breath, looked up at the blue sky, and gave a mighty leap. He cleared the fence easily, learning that where you look is where you will go."
    },
    {
      "title": "The Kangaroo and the Emu",
      "text": "Once upon a time, a kangaroo and an emu were arguing about who could travel faster. They decided to race across the desert. The kangaroo bounced high and fast, but got very tired. The emu ran with long, steady strides and never stopped. The emu reached the finish line first, proving that a steady pace beats a tiring bounce."
    },
    {
      "title": "The Kangaroo's Pouch",
      "text": "Once upon a time, a mother kangaroo found a shiny gold coin and put it in her pouch. But when her little joey wanted to climb in, the cold, hard coin made him uncomfortable. The mother took the gold coin out and threw it away in the grass. She hugged her soft, warm joey, knowing that family is much more valuable than any shiny treasure."
    },
    {
      "title": "The Out-Back Starry Night",
      "text": "Once upon a time, in the great Australian outback, Roo the kangaroo leaped across the red sands under a sky full of twinkling stars. A baby koala was lost and crying softly at the base of a tall eucalyptus tree. Roo knelt down gently, letting the little koala snuggle into her soft, warm pouch. With graceful, gentle hops that rocked the baby to sleep, Roo carried the little one safely back to its mother's loving arms."
    },
    {
      "title": "The Kangaroo's Pocket Full of Friends",
      "text": "Once upon a time, in the sunny outback, there lived a bouncy kangaroo named Roo with a big, cozy pouch. Roo loved hopping across the wide open fields every single day. One afternoon, Roo found a tired little joey who had wandered far from home. \"Hop into my pocket and rest,\" said Roo kindly, and the little joey climbed in gratefully. As Roo bounced along, she found a sleepy koala who had fallen from a low branch. \"There is room for one more,\" said Roo, and the koala snuggled in beside the joey. Soon, a tiny lizard too tired to walk climbed aboard as well, tucked safely in Roo's warm pouch. Roo bounced gently across the fields, careful not to jostle her sleepy passengers. One by one, she delivered each friend safely home, hopping from burrow to burrow. The joey's family thanked Roo with a basket of berries, and the koala waved happily from his tree. \"My pocket may be small, but it is always big enough for a friend in need,\" said Roo. From that day on, every tired animal in the outback knew exactly whose pocket to hop into."
    }
  ],
  "turtle": [
    {
      "title": "The Tortoise and the Birds",
      "text": "Once upon a time, a tortoise wanted to fly south with the birds. Two strong birds offered to carry him by holding a stick in their beaks, while the tortoise bit the middle. 'Do not open your mouth!' they warned. High in the sky, people pointed and cheered at the flying tortoise. He opened his mouth to say 'Thank you!' and fell right into a soft pond. He learned to listen to good advice."
    },
    {
      "title": "The Turtle's Shell",
      "text": "Once upon a time, a turtle complained that his shell was too heavy. He wished he could leave it behind and run fast like the rabbit. One day, a sudden hailstorm started. The rabbit ran frantically looking for cover, getting bumped by hailstones. The turtle simply tucked his head and legs inside his heavy shell, safe and warm. He realized his heavy shell was his greatest protector."
    },
    {
      "title": "The Turtle and the Monkey",
      "text": "Once upon a time, a turtle and a monkey found a banana tree. They divided it in two. The monkey took the leafy top, thinking it would grow bananas quickly, and the turtle planted the roots. The monkey's top withered and died, while the turtle's roots grew into a big tree full of fruit. The monkey learned that patience and strong roots are the secret to a good harvest."
    },
    {
      "title": "The Turtle's Long Walk",
      "text": "Once upon a time, a turtle decided to walk to the top of a big hill to see the sunset. The other animals laughed, saying he was too slow and would miss it. The turtle walked all day, step by step, never stopping to rest. Just as he reached the top, the sky turned beautiful shades of pink and orange. He smiled, proving that persistence always gets you to the top."
    },
    {
      "title": "The Turtle and the Fish",
      "text": "Once upon a time, a wise turtle lived in a deep blue pond. A flashy little fish swam circles around him, showing off her shiny scales. 'You are so dull and slow,' the fish teased. Suddenly, a fishing net swooped into the water. The turtle calmly sank to the muddy bottom, while the flashy fish got tangled in the net. The turtle helped untangle her, and she learned that being flashy isn't everything."
    },
    {
      "title": "Toby's Little Adventure",
      "text": "Once upon a time, there was a gentle turtle named Toby. Toby loved to swim slowly in the quiet pond. One day, Toby found a sunny rock near the water. Toby invited his friends to rest on the rock. They warmed themselves in the bright sun. Then Toby swam home and went to sleep."
    }
  ],
  "penguin": [
    {
      "title": "The Penguin's Slide",
      "text": "Once upon a time, a little penguin was afraid to slide on the ice. He watched his friends swoosh down the snowy hills on their bellies, laughing and splashing into the sea. He stood at the edge, trembling. His father gave him a gentle nudge. Swoosh! The little penguin slid down, the cold wind blowing on his face. He splashed into the water with a joyful cheer, learning that being brave is fun."
    },
    {
      "title": "The Penguin Who Wanted to Fly",
      "text": "Once upon a time, a penguin watched the seagulls soar in the sky and wished he could fly too. He flapped his flippers as hard as he could, but his feet stayed on the ice. Disappointed, he dived into the ocean. Underwater, he flapped his flippers and soared through the blue water, dodging icebergs like a bird in the sky. He realized he was already a wonderful flyer, just in a different sky."
    },
    {
      "title": "The Penguin's Warm Huddle",
      "text": "Once upon a time, a terrible blizzard hit the South Pole. A young penguin tried to stand alone against the freezing wind, but he was too cold. The older penguins called him over to join their large huddle. They stood close together, sharing their body heat, taking turns standing on the cold outside edge. The young penguin felt safe and warm, learning that sticking together helps everyone survive the storm."
    },
    {
      "title": "The Penguin's Fish Catch",
      "text": "Once upon a time, a penguin boasted he could catch the biggest fish in the sea. He swam far away from his friends, looking for a giant fish. He found one, but it was too strong and pulled him deep underwater. He had to let go and swim back, tired and hungry. His friends shared a pile of small, tasty fish with him. He learned that small, shared successes are better than big, lonely failures."
    },
    {
      "title": "The Penguin's Dance",
      "text": "Once upon a time, a penguin loved to tap dance on the hard ice. The other penguins told him to stop making so much noise. He walked away sadly. But soon, the ice started to crack, and a leopard seal appeared! The dancing penguin quickly tap-danced a loud, confusing rhythm on the ice, scaring the seal away. The other penguins cheered, realizing his noisy talent was a true gift."
    },
    {
      "title": "Pippa's Little Adventure",
      "text": "Once upon a time, there was a playful penguin named Pippa. Pippa loved to slide on the cold, white snow. One day, Pippa found a long, slippery ice hill. Pippa shared the hill with her friends. They slid down and laughed together. Then Pippa waddled home and went to sleep."
    }
  ]
};

export function getClassicTale(animalId, excludeTitle) {
  const tales = CLASSIC_TALES[animalId];
  if (!tales || tales.length === 0) return null;
  
  // Exclude the currently viewed title, and also check localStorage for played tales
  let playedTales = [];
  try {
    const stored = localStorage.getItem('played_tales_' + animalId);
    if (stored) {
      playedTales = JSON.parse(stored);
    }
  } catch(e) {}
  
  // Filter out the currently viewed title AND tales already played
  let options = tales.filter(t => t.title !== excludeTitle && !playedTales.includes(t.title));
  
  if (options.length === 0) {
    // If all classic tales have been played, return null to fall back to LLM generation
    return null;
  }
  
  return options[Math.floor(Math.random() * options.length)];
}

// Deterministic (not random) - used for the "default story" shown the first
// time an animal is opened, so that default is stable rather than a surprise.
export function getFirstClassicTale(animalId) {
  const tales = CLASSIC_TALES[animalId];
  return tales && tales.length ? tales[0] : null;
}

export function markTaleAsPlayed(animalId, title) {
  let playedTales = [];
  try {
    const stored = localStorage.getItem('played_tales_' + animalId);
    if (stored) playedTales = JSON.parse(stored);
  } catch(e) {}
  if (!playedTales.includes(title)) {
    playedTales.push(title);
    localStorage.setItem('played_tales_' + animalId, JSON.stringify(playedTales));
  }
}

export function getPlayedTalesCount(animalId) {
  try {
    const stored = localStorage.getItem('played_tales_' + animalId);
    if (stored) return JSON.parse(stored).length;
  } catch(e) {}
  return 0;
}


export function getRandomClassicTale(animalId) {
  const tales = CLASSIC_TALES[animalId];
  if (!tales || tales.length === 0) return null;
  return tales[Math.floor(Math.random() * tales.length)];
}

export const CLASSIC_RHYMES = {
  "rabbit": [
    {
      "title": "Hoppy Little Bunny",
      "text": "Hop, hop, little bunny through the clover green,\nFluffiest white cottontail that you've ever seen.\nTwitching your pink nose in the morning sun,\nNibbling on a crunchy carrot, having so much fun!\nSkipping through the daisies with your ears so tall,\nWaving to the robin resting on the wall.\nCurling in your burrow warm and soft and deep,\nClosing sleepy bunny eyes for a cozy sleep."
    },
    {
      "title": "The Carrot Patch Dance",
      "text": "One hop, two hops, dancing in a line,\nBunny found a carrot sweet and superfine!\nShared it with a hedgehog, shared it with a bird,\nHappiest little giggles that were ever heard!\nLeaping over puddles in the golden light,\nPlaying with the butterflies fluttering and bright.\nTucking in the nest when the stars appear,\nDreaming happy bunny dreams through the nighttime clear."
    }
  ],
  "lion": [
    {
      "title": "Leo the Friendly Lion",
      "text": "Leo is a lion with a golden mane,\nDancing in the sunshine after gentle rain.\nHe gives a happy smile and a friendly cheer,\nThe kindest little lion in the forest here.\nPaws upon the meadow, leaping high with grace,\nBringing sunny smiles to every friendly face.\nHe doesn't need to roar to be strong and true,\nA warm lion hug is his gift to you!"
    },
    {
      "title": "The Gentle Lion's Lullaby",
      "text": "Big golden paws resting on the grass,\nWatching fluffy white clouds slowly, softly pass.\nA tiny little yawn and a gentle purr,\nSoft evening breeze in his warm golden fur.\nStars begin to twinkle in the purple sky,\nSinging sleepy lions a sweet lullaby.\nResting near the acacia tree safe and deep,\nClosing heavy eyelids for a peaceful sleep."
    }
  ],
  "elephant": [
    {
      "title": "Ellie the Little Elephant",
      "text": "Ellie has big ears that gently flap around,\nStomping her happy feet upon the grassy ground.\nSplishing in the river with water cool and blue,\nSpraying happy waterdrops on all her friends too!\nTrunk goes up high, reaching for the trees,\nCatching sweet green apples blowing in the breeze.\nWaddling to her family when the day is done,\nCuddled in the moonlight having so much fun."
    },
    {
      "title": "Elephant Splash",
      "text": "Trunk goes up and the trunk goes down,\nCheeriest little elephant in the jungle town.\nSprinkling clean water like a summer shower,\nWashing green leaves and a sleepy flower.\nBirds come flying down to take a sunny bath,\nGiggling with the elephant on the river path.\nWalking back together in the evening glow,\nStomping big gray footsteps soft and calm and slow."
    }
  ],
  "monkey": [
    {
      "title": "Milo Monkey Swing",
      "text": "Swinging from the treetops, high up in the air,\nMilo the monkey hasn't got a care.\nPeeling a yellow banana sweet and ripe,\nSinging a happy song with all his might!\nLeaping from the branches, catching every vine,\nShowing all his monkey pals how the sun can shine.\nCurled up in the treehouse as the stars ignite,\nWaving to the silver moon, whispering goodnight!"
    },
    {
      "title": "Monkey Treehouse Party",
      "text": "Up in the vines where the green leaves grow,\nChattering and laughing in a lively row.\nHanging by his tail, giving friends a wink,\nSipping cool coconut water for a drink!\nDoing little flips on the jungle floor,\nRunning to the river for a fun explore.\nTucking in a hammock made of leafy twine,\nResting till the morning sun begins to shine."
    }
  ],
  "bear": [
    {
      "title": "Barnaby the Cozy Bear",
      "text": "Barnaby the brown bear loves sweet golden honey,\nWalking through the forest when the day is sunny.\nRolling in the soft leaves, giving a big hug,\nCurled up in his cozy cave, warm and snug.\nTiptoe to the river where the salmon leap,\nSplashing in the shallow water cool and deep.\nResting fuzzy paws on a mossy bed,\nDreaming sweet honey dreams in his sleepy head."
    },
    {
      "title": "Teddy Bear Picnic",
      "text": "Tiptoe, tiptoe to the blueberry patch,\nSweetest juicy berries for a bear to catch!\nSharing with the squirrels and the robin red,\nResting fuzzy paws on a mossy bed.\nSinging happy songs by the bubbling stream,\nCatching yellow sunbeams in a cozy dream.\nTucking in the blanket as the shadows creep,\nSnuggling with his teddy friends fast asleep."
    }
  ],
  "dog": [
    {
      "title": "Puppy Waggy Tail",
      "text": "Wag, wag, waggy tail, puppy full of joy,\nChasing through the yard with his squeaky toy.\nRunning to the door with a happy bark,\nCatching flying balls at the sunny park!\nLicking little fingers, giving puppy kisses,\nGranting all your playtime happy wishes.\nCurling in your lap when the evening comes,\nSleeping to the rhythm as the night-wind hums."
    },
    {
      "title": "Sleepy Puppy Snuggles",
      "text": "Soft floppy ears and two shining eyes,\nCatching colorful garden butterflies.\nRolling on the carpet with a squeaky bone,\nHappiest little puppy that was ever known.\nSniffing in the garden where the blossoms grow,\nWaddling through the grass with a golden glow.\nResting on his pillow soft and warm and bright,\nGuarding all your sleepy dreams through the night."
    }
  ],
  "cat": [
    {
      "title": "Purring Little Kitten",
      "text": "Soft little kitten with whiskers on her nose,\nChasing little yarn balls everywhere she goes.\nPurring like a motor on a sunny rug,\nCurling up for bedtime, warm and snug.\nPaws so quiet stepping on the floor,\nPeeking at the butterflies by the open door.\nDrinking creamy milk from a little dish,\nWishing every friend a sweet bedtime wish."
    },
    {
      "title": "Kitty Moon Dance",
      "text": "Paws so quiet stepping through the hall,\nWatching silver shadows dancing on the wall.\nStretching little claws with a happy meow,\nClimbing on the windowsill softly now.\nCurling like a donut in the starry beam,\nDrifting far away in a kitty dream.\nWhiskers twitching gently in the velvet night,\nSleeping safe and sound until the morning light."
    }
  ],
  "duck": [
    {
      "title": "Quacky Ducklings",
      "text": "Quack, quack, mama duck swimming in a row,\nFollowing her ducklings everywhere they go.\nDipping in the pond with their orange feet,\nFinding watercress for a tasty treat!\nFlapping little wings in the sunny breeze,\nGliding past the cattails and the willow trees.\nTucking under mama's wings warm and deep,\nSoft little ducklings drifting off to sleep."
    },
    {
      "title": "Splish Splash Duck",
      "text": "Waddle to the water on a sunny day,\nFlapping little wings in the misty spray.\nBobbing like a cork on the ripples blue,\nQuacking cheerful hellos to me and you!\nFloating with the lily pads floating in a line,\nFeathers staying dry and looking superfine.\nResting on the grassy bank under evening skies,\nClosing happy little golden ducky eyes."
    }
  ],
  "cow": [
    {
      "title": "Daisy the Gentle Cow",
      "text": "Moo, moo, Daisy cow in the meadow green,\nSweetest gentle face that you've ever seen.\nMunching morning clover underneath the sky,\nWaving at the butterflies fluttering by!\nWalking to the barn with a gentle stroll,\nEating yummy apples from a wooden bowl.\nResting on the sweet hay, warm and softly curled,\nKindest little milk-cow in the whole wide world."
    }
  ],
  "tiger": [
    {
      "title": "Toby Tiger Stripes",
      "text": "Orange and black stripes shining in the sun,\nToby little tiger loves to leap and run.\nPouncing on a leaf in the jungle breeze,\nPlaying hide-and-seek underneath the trees!\nCreeping through the ferns with his padded paws,\nSmiling at his friends with no scary claws.\nResting on a rock in the afternoon glow,\nPurring little tiger purrs soft and slow."
    }
  ],
  "giraffe": [
    {
      "title": "Gerry the Tall Giraffe",
      "text": "Tall neck reaching to the sky so blue,\nNibbling on the leaves covered in morning dew.\nLooking over treetops with a friendly grin,\nWatching morning sunshine gently pour right in!\nStretching long spots high above the ground,\nKindest gentle giant that was ever found.\nResting by the river under starry beams,\nHaving tall and wonderful giraffe dreams."
    }
  ],
  "zebra": [
    {
      "title": "Ziggy Zebra Dance",
      "text": "Black and white stripes running fast and free,\nHappiest zebra that you'll ever see.\nGalloping across the savanna plain,\nDancing in the puddles of the summer rain!\nTrotting with his herd in a zigzag line,\nSmiling as the golden sun begins to shine.\nResting on the grass as the crickets play,\nSleeping till the dawn of a brand new day."
    }
  ],
  "horse": [
    {
      "title": "The Galloping Pony",
      "text": "Clip-clop, clip-clop over hills of green,\nPrettiest brown pony that was ever seen.\nSwishing his long mane in the gentle breeze,\nTrotting past the flowers and the apple trees!\nLeaping over fences with a joyful neigh,\nMunching golden oats and sweet summer hay.\nResting in the stable warm and safe and dry,\nWatching little stars in the evening sky."
    }
  ],
  "panda": [
    {
      "title": "Pip the Playful Panda",
      "text": "Black and white panda rolling on the ground,\nSweetest little bundle that was ever found.\nCrunching green bamboo with a happy crunch,\nEating leafy shoots for a yummy lunch!\nClimbing up the hill for a silly tumble,\nLaughing with a happy little panda rumble.\nCurled up in a ball on a cozy branch,\nResting after playtime in the sunny ranch."
    }
  ],
  "fox": [
    {
      "title": "Freddy the Clever Fox",
      "text": "Bushy orange tail and two pointed ears,\nRunning through the forest when the morning clears.\nTiptoe through the leaves with a gentle leap,\nCurling in the den for a cozy sleep!\nSniffing out sweet berries on the woody trail,\nSwishing in the air with his furry tail.\nResting with his family under starry skies,\nClosing little shiny amber foxy eyes."
    }
  ],
  "pig": [
    {
      "title": "Penny Pig Puddle Fun",
      "text": "Oink, oink, Penny pig splashing in the mud,\nRolling on her belly with a happy thud.\nCurly pink tail and a little snout,\nGiggling and playing as she runs about!\nWaddling to the trough for a crunchy treat,\nTapping with her shiny little trotter feet.\nSnuggling in the straw bed, warm and pink and clean,\nHappiest little piggy that you've ever seen."
    }
  ],
  "sheep": [
    {
      "title": "Fluffy Woolly Lamb",
      "text": "Baa, baa, little lamb with a coat so white,\nSoft like a cloud in the morning light.\nSkipping through the hills with the happy flock,\nResting in the shade of a mossy rock!\nNibbling tender blades on the grassy hill,\nDrinking cool water from the sparkling rill.\nCuddled close together as the stars alight,\nWarm and fluffy wool keeps you safe tonight."
    }
  ],
  "kangaroo": [
    {
      "title": "Joey Kangaroo Hop",
      "text": "Boing, boing, kangaroo hopping high and low,\nLeaping through the Outback where the bushes grow.\nSnuggling in the pouch warm and safe and deep,\nClosing baby eyes for a cozy sleep!\nJumping over red rocks with a giant bound,\nLanding very softly on the sunny ground.\nPeeking at the stars from the cozy pocket,\nZooming in your dreams like a little rocket."
    }
  ],
  "turtle": [
    {
      "title": "Tommy Turtle Slow and Sweet",
      "text": "Tommy is a turtle with a shell so green,\nThe calmest little swimmer that you've ever seen.\nWalking very gently on his little feet,\nTaking time to smile at everyone he meets!\nTucking in his head when he needs a rest,\nCarrying his home like a cozy nest.\nPaddling in the pond under sunset beams,\nFloating into peaceful little turtle dreams."
    }
  ],
  "penguin": [
    {
      "title": "Pip Penguin Ice Slide",
      "text": "Waddle, waddle penguin on the chilly snow,\nSliding on his belly where the cold winds blow.\nDiving in the ocean with his shiny wings,\nHappy little songs that the penguin sings!\nSplashing in the water with his flipper feet,\nCatching little fish for a yummy treat.\nStanding with his friends in the winter night,\nSnuggled in a circle till the morning light."
    }
  ]
};

export function getClassicRhyme(animalId, avoidTitle) {
  const rhymes = CLASSIC_RHYMES[animalId];
  if (!rhymes || rhymes.length === 0) return null;

  let playedRhymes = [];
  try {
    const stored = localStorage.getItem('played_rhymes_' + animalId);
    if (stored) {
      playedRhymes = JSON.parse(stored);
    }
  } catch (e) {}

  const options = rhymes.filter(r => r.title !== avoidTitle && !playedRhymes.includes(r.title));
  if (options.length === 0) {
    return null;
  }
  return options[Math.floor(Math.random() * options.length)];
}

export function markRhymeAsPlayed(animalId, title) {
  let playedRhymes = [];
  try {
    const stored = localStorage.getItem('played_rhymes_' + animalId);
    if (stored) playedRhymes = JSON.parse(stored);
  } catch (e) {}
  if (!playedRhymes.includes(title)) {
    playedRhymes.push(title);
    localStorage.setItem('played_rhymes_' + animalId, JSON.stringify(playedRhymes));
  }
}

export function getRandomClassicRhyme(animalId) {
  const rhymes = CLASSIC_RHYMES[animalId];
  if (!rhymes || rhymes.length === 0) {
    const formatted = animalId ? animalId.charAt(0).toUpperCase() + animalId.slice(1) : 'Friend';
    return {
      title: `Little ${formatted} Rhyme`,
      text: `A happy little ${animalId || 'friend'} jumping in the sun.\nPlaying with all friends and having lots of fun.\nSmiling in the morning, cheerful and bright.\nResting in cozy dreams through the gentle night.`
    };
  }
  return rhymes[Math.floor(Math.random() * rhymes.length)];
}
