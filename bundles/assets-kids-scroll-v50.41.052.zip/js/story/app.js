const STORAGE_RECENT = 'kids_scroll_recent_stories';

function loadRecentStories() {
  const recentSection = document.getElementById('recently-listened-section');
  const recentScroll = document.getElementById('recently-listened-scroll');
  if (!recentSection || !recentScroll) return;

  try {
    const recentIds = JSON.parse(localStorage.getItem(STORAGE_RECENT) || '[]');
    if (!Array.isArray(recentIds) || recentIds.length === 0) {
      recentSection.style.display = 'none';
      return;
    }

    recentScroll.innerHTML = '';
    let addedCount = 0;

    recentIds.forEach(id => {
      // Find the first matching menu-item in the document
      const originalNode = document.querySelector(`.category-section:not(#recently-listened-section) .trending-item[data-story-id="${id}"]`);
      if (originalNode) {
        recentScroll.appendChild(originalNode.cloneNode(true));
        addedCount++;
      }
    });

    recentSection.style.display = addedCount > 0 ? 'block' : 'none';
  } catch (e) {
    recentSection.style.display = 'none';
  }
}

function setupFilters() {
  const ageFilter = document.getElementById('age-filter');
  const searchInput = document.getElementById('story-search');

  function filterStories(mode) {
    const selectedAge = ageFilter ? ageFilter.value : 'all';
    const searchQuery = searchInput ? searchInput.value.toLowerCase().trim() : '';
    
    // We only filter items inside main category sections (skip recent)
    const allItems = document.querySelectorAll('.category-section:not(#recently-listened-section) .trending-item');

    allItems.forEach((item) => {
      let shouldShow = true;
      const storyAge = item.getAttribute('data-age');

      if (mode === 'age' && selectedAge !== 'all' && storyAge) {
        const selectedAgeNum = parseInt(selectedAge, 10);
        const storyAgeNum = parseInt(storyAge, 10);
        if (isNaN(storyAgeNum) || storyAgeNum < selectedAgeNum) {
          shouldShow = false;
        }
      } else if (mode === 'search' && searchQuery) {
        const title = item.querySelector('h2')?.textContent.toLowerCase() || '';
        if (!title.includes(searchQuery)) {
          shouldShow = false;
        }
      }

      item.style.display = shouldShow ? '' : 'none';
    });

    // Hide empty category sections
    document.querySelectorAll('.category-section:not(#recently-listened-section)').forEach((section) => {
      const items = section.querySelectorAll('.trending-item');
      if (items.length === 0) return;

      let hasVisible = false;
      items.forEach((item) => {
        if (item.style.display !== 'none') hasVisible = true;
      });

      section.style.display = hasVisible ? 'block' : 'none';
    });
  }

  if (ageFilter) {
    ageFilter.addEventListener('change', (e) => {
      e.target.blur();
      if (searchInput) searchInput.value = '';
      filterStories('age');
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      if (ageFilter) ageFilter.value = 'all';
      filterStories('search');
    });
  }
}

function init() {
  loadRecentStories();
  setupFilters();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
