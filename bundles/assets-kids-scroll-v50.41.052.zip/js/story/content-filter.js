// Simple safety net for a tiny generative model aimed at 1-6yo listeners.
// Not a moderation system for adversarial input - just a guard against the
// tiny model occasionally drifting into scary/sad/violent territory.
const BLOCKED_WORDS = [
  'kill', 'killed', 'killing', 'die', 'died', 'dying', 'dead', 'death',
  'blood', 'bleeding', 'gun', 'knife', 'shoot', 'shot', 'fight', 'fighting',
  'punch', 'hit', 'hurt', 'hurts', 'hurting', 'pain', 'cry', 'crying',
  'scared', 'scary', 'afraid', 'fear', 'monster', 'ghost', 'devil',
  'hate', 'hated', 'stupid', 'ugly', 'fat', 'lost forever', 'alone forever',
];

// Character bounds suited for single scenes (120+ chars) up to full multi-scene stories (2500 chars)
const MIN_CHARS = 120;
const MAX_CHARS = 2500;

// word-boundary check so "hit" doesn't reject "white", "afraid" doesn't reject "afraid-of-nothing", etc.
export function containsBlockedWord(text) {
  if (!text) return false;
  const lower = text.toLowerCase();
  return BLOCKED_WORDS.some((word) => {
    const re = new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`);
    return re.test(lower);
  });
}

export function sanitizeStoryScene(text) {
  if (!text) return '';
  let cleaned = text;

  // 1. Remove markdown bold/italic/headers
  cleaned = cleaned.replace(/^\s*[*_#]+\s*/g, '');

  // 2. Remove repeated scene/chapter/act/part labels (e.g. Scene 1:, Scene 3: Scene 3:)
  cleaned = cleaned.replace(/^(?:[\"'\`“‘\s*#_]*\b(?:scene|act|chapter|part)\s*\d*[\s:\-.]*[\"'\`”’*#_]*)+/gi, '');

  // 3. Remove conversational preambles & instruction echoes
  cleaned = cleaned.replace(/^(?:title\s*:[^\n]*\n*)/gi, '');
  cleaned = cleaned.replace(/^(?:sure!?\s*)?(?:here\s+is\s+(?:the\s+|a\s+|an\s+)?(?:\d+-line\s+|bedtime\s+|short\s+|cheerful\s+|rhyming\s+)*(?:story|scene|rhyme|poem)?[\s:\-.]*)/gi, '');
  cleaned = cleaned.replace(/^(?:once\s+upon\s+a\s+time,\s*)?introducing\s+(?:an?|the)?\s*[^.!?]+[.!?]\s*/gi, '');
  cleaned = cleaned.replace(/^(?:write\s+(?:the|a)?\s*[^.!?]+[.!?]\s*)/gi, '');
  cleaned = cleaned.replace(/^(?:continuing\s+(?:the\s+story)?[\s:\-.]*)/gi, '');

  // 4. Secondary pass for labels that followed a preamble
  cleaned = cleaned.replace(/^(?:[\"'\`“‘\s*#_]*\b(?:scene|act|chapter|part)\s*\d*[\s:\-.]*[\"'\`”’*#_]*)+/gi, '');

  // 5. Strip boundary quotes and markdown markers
  cleaned = cleaned.replace(/^[\"'\`“‘\s*#_]+|[\"'\`”’\s*#_]+$/g, '');

  return cleaned.trim();
}

export function isStorySafe(text) {
  if (!text) return false;
  const trimmed = sanitizeStoryScene(text);
  if (trimmed.length < MIN_CHARS || trimmed.length > MAX_CHARS) return false;
  if (containsBlockedWord(trimmed)) return false;

  const endsCleanly = /[.!?]["')\]]?\s*$/.test(trimmed);
  return endsCleanly;
}

// Trim trailing partial sentence (model output often cuts off mid-sentence at max_tokens).
export function trimToCompleteSentences(text) {
  const matches = [...text.matchAll(/[^.!?]*[.!?]+["')\]]?/g)];
  if (matches.length === 0) return text.trim();
  return matches.map((m) => m[0].trim()).join(' ');
}

export function wordCount(text) {
  if (!text) return 0;
  return text.trim().split(/\s+/).filter(Boolean).length;
}

const STOP_MARKER = /once upon a time|\bthe end\b\.?/i;

export function stopAtRestart(text) {
  if (!text) return '';
  const match = STOP_MARKER.exec(text);
  if (match && match.index > 20) {
    return text.slice(0, match.index);
  }
  return text;
}

