// Renders the current scene cue (from scene-parser.js) as an animated emoji
// scene using plain CSS transform animations - no external animation libraries.
// Supports up to two simultaneous characters (e.g. a race, or two friends together)
// plus one prop/location emoji they are interacting with.

export class Playground {
  constructor(container) {
    this.container = container;
    this.container.classList.add('playground-stage');
    this.container.innerHTML = `
      <div class="playground-prop playground-prop-1" aria-hidden="true"></div>
      <div class="playground-prop playground-prop-2" aria-hidden="true"></div>
      <div class="playground-actor playground-actor-1" aria-hidden="true"></div>
      <div class="playground-actor playground-actor-2" aria-hidden="true"></div>
    `;
    this.actor1El = this.container.querySelector('.playground-actor-1');
    this.actor2El = this.container.querySelector('.playground-actor-2');
    this.prop1El = this.container.querySelector('.playground-prop-1');
    this.prop2El = this.container.querySelector('.playground-prop-2');

    this._bindTap(this.actor1El);
    this._bindTap(this.actor2El);
    this._bindTap(this.prop1El);
    this._bindTap(this.prop2El);
  }

  _bindTap(el) {
    el.addEventListener('pointerdown', (e) => {
      e.stopPropagation();
      const text = el.textContent ? el.textContent.trim() : '';
      if (!text) return;

      // Extract emoji
      const emojiMatch = text.match(/[\uD800-\uDBFF][\uDC00-\uDFFF]|\p{Extended_Pictographic}/u);
      const emoji = emojiMatch ? emojiMatch[0] : text;

      // Trigger pop/bounce animation
      el.classList.remove('tap-bounce');
      void el.offsetWidth;
      el.classList.add('tap-bounce');

      // Audio feedback: animal sound if available, else gentle tap sound
      if (typeof window.playAnimalSound === 'function' && window.ANIMAL_SOUNDS && window.ANIMAL_SOUNDS[emoji]) {
        window.playAnimalSound(emoji);
      } else if (typeof window.soundGenerator !== 'undefined' && typeof window.soundGenerator.playTapSound === 'function') {
        window.soundGenerator.playTapSound();
      }
    });
  }

  reset(actorEmoji) {
    this.actor1El.textContent = actorEmoji || '';
    this.actor1El.className = 'playground-actor playground-actor-1 motion-idle-bounce';
    this.actor2El.textContent = '';
    this.actor2El.className = 'playground-actor playground-actor-2';
    this.prop1El.textContent = '';
    this.prop1El.className = 'playground-prop playground-prop-1';
    this.prop2El.textContent = '';
    this.prop2El.className = 'playground-prop playground-prop-2';
  }

  showCue(cue) {
    if (!cue) return;
    const actor1Emoji = cue.actor1Emoji || this.actor1El.textContent || '';
    this.actor1El.textContent = actor1Emoji ? actor1Emoji.repeat(cue.actor1Count || 1) : '';
    this._restartMotion(this.actor1El, 'playground-actor playground-actor-1', cue.motion || 'idle-bounce');

    if (cue.actor2Emoji) {
      this.actor2El.textContent = cue.actor2Emoji.repeat(cue.actor2Count || 1);
      this._restartMotion(this.actor2El, 'playground-actor playground-actor-2', cue.motion);
    } else {
      this.actor2El.textContent = '';
      this.actor2El.className = 'playground-actor playground-actor-2';
    }

    if (cue.propEmoji) {
      this.prop1El.textContent = cue.propEmoji.repeat(cue.propCount || 1);
      this.prop1El.classList.add('visible');
    } else {
      this.prop1El.classList.remove('visible');
    }

    if (cue.prop2Emoji) {
      this.prop2El.textContent = cue.prop2Emoji.repeat(cue.prop2Count || 1);
      this.prop2El.classList.add('visible');
    } else {
      this.prop2El.classList.remove('visible');
    }
  }

  _restartMotion(el, baseClass, motion) {
    el.className = baseClass;
    void el.offsetWidth; // force reflow so the animation restarts
    el.classList.add(`motion-${motion}`);
  }

  idle() {
    this.actor1El.className = 'playground-actor playground-actor-1 motion-idle-bounce';
    this.actor2El.className = 'playground-actor playground-actor-2';
    this.prop1El.textContent = '';
    this.prop1El.className = 'playground-prop playground-prop-1';
    this.prop2El.textContent = '';
    this.prop2El.className = 'playground-prop playground-prop-2';
  }
}
