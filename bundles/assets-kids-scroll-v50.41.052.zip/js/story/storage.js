// IndexedDB wrapper: one record per animal { animal, current: {title, text, createdAt}, history: [...] }
import { openDb, STORIES_STORE } from './db.js';

const MAX_HISTORY = 5;

function tx(db, mode) {
  return db.transaction(STORIES_STORE, mode).objectStore(STORIES_STORE);
}

export async function getStory(animal) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readonly').get(animal);
    req.onsuccess = () => resolve(req.result || null);
    req.onerror = () => reject(req.error);
  });
}

export async function saveNewStory(animal, text, title) {
  const db = await openDb();
  const existing = await getStory(animal);
  let history = existing ? [...existing.history] : [];
  
  if (existing && existing.current) {
    // If the new story is identical to the current one, don't push the current into history
    if (existing.current.title !== title || existing.current.text !== text) {
      history.unshift(existing.current);
    }
  }

  // Remove any older duplicate from history if it matches the new story
  history = history.filter(h => h.title !== title || h.text !== text);
  
  if (history.length > MAX_HISTORY) history.length = MAX_HISTORY;

  const record = {
    animal,
    current: { title, text, createdAt: Date.now() },
    history,
  };
  return new Promise((resolve, reject) => {
    const req = tx(db, 'readwrite').put(record);
    req.onsuccess = () => resolve(record);
    req.onerror = () => reject(req.error);
  });
}

export async function getHistory(animal) {
  const record = await getStory(animal);
  return record ? record.history : [];
}
