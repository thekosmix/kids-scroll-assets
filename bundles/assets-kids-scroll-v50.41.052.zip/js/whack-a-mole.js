// Whack-a-Mole Game Logic
document.addEventListener('DOMContentLoaded', function() {
    // Game configuration
    const config = {
        minMoleTime: 1200,     // Initial time mole stays up (ms)
        maxMoleTime: 600,      // Minimum time mole stays up (ms)
        minSpawnRate: 1000,    // Initial time between spawns (ms)
        maxSpawnRate: 400,     // Minimum time between spawns (ms)
        points: 10,            // Points per mole
        winPoints: 200         // Points needed to fill Joy Meter
    };

    // Game state
    let score = 0;
    let gameActive = false;
    let moleTimeout = null;
    let spawnTimeout = null;
    let lastHole = -1;
    let moleTime = config.minMoleTime;
    let spawnRate = config.minSpawnRate;
    let isFirstLoad = true;
    let currentLevel = 1;

    // DOM Elements
    const gameBoard = document.getElementById('gameBoard');
    let holes = [];
    const scoreDisplay = document.getElementById('score');
    const joyMeter = new JoyMeter('game-container', { top: '20px' });

    function createBoard() {
        gameBoard.innerHTML = '';
        const numHoles = currentLevel === 1 ? 9 : (currentLevel === 2 ? 12 : 15);
        
        let maxHoleWidth = '180px';
        if (currentLevel === 2) maxHoleWidth = '145px';
        if (currentLevel === 3) maxHoleWidth = '115px';

        for (let i = 0; i < numHoles; i++) {
            const hole = document.createElement('div');
            hole.className = 'mole-hole large-hitbox';
            hole.dataset.index = i;
            hole.style.maxWidth = maxHoleWidth;
            
            const mole = document.createElement('div');
            mole.className = 'mole';
            mole.textContent = '🐹';
            
            hole.appendChild(mole);
            
            hole.addEventListener('click', whackMole);
            hole.addEventListener('touchstart', function(e) {
                e.preventDefault();
                whackMole.call(this, e);
            });

            gameBoard.appendChild(hole);
        }
        
        holes = document.querySelectorAll('.mole-hole');
    }

    function randomHole() {
        const randomIndex = Math.floor(Math.random() * holes.length);
        if (randomIndex === lastHole) {
            return randomHole();
        }
        lastHole = randomIndex;
        return holes[randomIndex];
    }

    function showMole() {
        if (!gameActive) return;

        const hole = randomHole();
        holes.forEach(h => h.classList.remove('whacked'));
        hole.classList.add('active');
        
        // Visual bounce for toddler engagement
        const mole = hole.querySelector('.mole');
        mole.classList.add('bounce-in');
        setTimeout(() => mole.classList.remove('bounce-in'), 500);

        if (typeof soundGenerator !== 'undefined') {
            soundGenerator.playBeep();
        }

        moleTimeout = setTimeout(() => {
            hole.classList.remove('active');
            if (gameActive) {
                // Adaptive Difficulty: if missing, slow down slightly
                moleTime = Math.min(config.minMoleTime, moleTime + 50);
                spawnRate = Math.min(config.minSpawnRate, spawnRate + 50);
                
                const randomDelay = Math.random() * 200;
                spawnTimeout = setTimeout(showMole, spawnRate + randomDelay);
            }
        }, moleTime);
    }

    function startGame() {
        if (gameActive) return;
        
        // Speak current level if not first load instructions
        if (!isFirstLoad && typeof speakText === 'function') {
            speakText("Level " + currentLevel);
        }

        score = 0;
        moleTime = config.minMoleTime;
        spawnRate = config.minSpawnRate;
        gameActive = true;

        if (scoreDisplay) scoreDisplay.textContent = score;
        updateJoyMeter();

        if (typeof soundGenerator !== 'undefined') {
            soundGenerator.playTapSound();
        }

        showMole();

        // Visual guide: show how to whack after the first mole pops up
        if (isFirstLoad) {
            isFirstLoad = false;
            setTimeout(() => {
                const activeHole = document.querySelector('.mole-hole.active');
                if (activeHole && typeof ghostHand !== 'undefined') {
                    const rect = activeHole.getBoundingClientRect();
                    ghostHand.show('ghost-tap', 
                        (rect.left + rect.width/2) + 'px', 
                        (rect.top + rect.height/2) + 'px'
                    );
                }
            }, 500);
        }
    }

    function updateJoyMeter() {
        const percentage = Math.min(100, (score / config.winPoints) * 100);
        joyMeter.setProgress(percentage);
        
        if (score >= config.winPoints) {
            endGame();
        }
    }

    function endGame() {
        gameActive = false;
        clearTimeout(moleTimeout);
        clearTimeout(spawnTimeout);

        holes.forEach(hole => {
            hole.classList.remove('active');
            hole.classList.remove('whacked');
        });

        // Celebration
        if (typeof triggerCelebration === 'function') {
            triggerCelebration();
        }
        
        if (typeof playCelebrationSound === 'function') {
            playCelebrationSound();
        }

        // Move to the next level
        currentLevel++;
        if (currentLevel > 3) {
            currentLevel = 1;
        }

        // Recreate board and restart after celebration
        setTimeout(() => {
            createBoard();
            startGame();
        }, 5000);
    }

    function whackMole(e) {
        if (!gameActive) return;
        if (typeof ghostHand !== 'undefined') ghostHand.stop();

        const hole = e.currentTarget;
        
        if (!hole.classList.contains('active') || hole.classList.contains('whacked')) {
            // Soft mistake sound
            if (window.soundGenerator) {
                soundGenerator.playTone(200, 0.1, 'sine');
            }
            return;
        }

        hole.classList.add('whacked');
        hole.classList.remove('active');

        // Adaptive Difficulty: if hitting, speed up slightly
        moleTime = Math.max(config.maxMoleTime, moleTime - 40);
        spawnRate = Math.max(config.maxSpawnRate, spawnRate - 40);

        score += config.points;
        if (scoreDisplay) scoreDisplay.textContent = score;
        updateJoyMeter();

        if (typeof vibrateSuccess === 'function') vibrateSuccess();
        showHitEffect(hole);
        
        if (typeof soundGenerator !== 'undefined') {
            soundGenerator.playCorrectSound();
        }
        
        if (Math.random() > 0.7) playEncouragement();
    }

    function showHitEffect(hole) {
        const effect = document.createElement('div');
        effect.className = 'hit-effect';
        effect.textContent = '✨';
        hole.appendChild(effect);

        setTimeout(() => {
            effect.remove();
        }, 800);
    }

    createBoard();

    // Play audio instruction immediately on landing
    if (typeof speakText === 'function') {
        setTimeout(() => speakText("Beat the moles to win the game"), 500);
    }

    // Start game after 4 seconds to give time for audio
    setTimeout(startGame, 4000);
});
