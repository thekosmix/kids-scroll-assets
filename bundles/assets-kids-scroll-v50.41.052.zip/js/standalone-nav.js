/**
 * Standalone-only nav: hides the marketing footer (blog/contact/social links
 * a kid could tap out to) and adds a toddler-friendly circular floating switcher:
 * Play & Learn (🎮) -> Stories & Rhymes (📖) -> Wonders & Facts (💡) -> Play & Learn (🎮)
 * only when running installed (PWA/TWA). No-op in a regular browser tab.
 */
(function () {
  if (typeof isStandaloneMode !== 'function' || !isStandaloneMode()) return;

  var path = window.location.pathname;
  var isGameMenu = path.endsWith('/game/') || path.endsWith('/game/index.html');
  var isStoryMenu = path.endsWith('/story/') || path.endsWith('/story/index.html');
  var isQuestionMenu = path.endsWith('/question/') || path.endsWith('/question/index.html');
  if (!isGameMenu && !isStoryMenu && !isQuestionMenu) return;

  var footer = document.querySelector('footer');
  if (footer) footer.style.display = 'none';

  var nextMode = isGameMenu
    ? { key: 'story', emoji: '📖', label: 'Stories & Rhymes', url: '/story/index.html', bg: 'linear-gradient(135deg, #ffb347 0%, #ffcc33 100%)', shadow: 'rgba(255, 179, 71, 0.45)' }
    : isStoryMenu
    ? { key: 'question', emoji: '💡', label: 'Wonders & Facts', url: '/question/index.html', bg: 'linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%)', shadow: 'rgba(251, 194, 235, 0.45)' }
    : { key: 'game', emoji: '🎮', label: 'Play & Learn', url: '/game/index.html', bg: 'linear-gradient(135deg, #00C9FF 0%, #92FE9D 100%)', shadow: 'rgba(0, 201, 255, 0.45)' };

  var switcher = document.createElement('button');
  switcher.id = 'mode-switcher';
  switcher.type = 'button';
  switcher.setAttribute('aria-label', 'Switch to ' + nextMode.label);
  switcher.style.cssText = [
    'position: fixed',
    'right: 20px',
    'bottom: calc(20px + env(safe-area-inset-bottom))',
    'z-index: 9999',
    'width: 58px',
    'height: 58px',
    'border-radius: 50%',
    'border: 3px solid rgba(255, 255, 255, 0.9)',
    'background: ' + nextMode.bg,
    'color: white',
    'box-shadow: 0 6px 18px ' + nextMode.shadow + ', 0 2px 6px rgba(0,0,0,0.15)',
    'cursor: pointer',
    'display: flex',
    'align-items: center',
    'justify-content: center',
    'padding: 0',
    'transition: transform 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
    'animation: float-switcher 3s ease-in-out infinite',
    '-webkit-tap-highlight-color: transparent'
  ].join(';');

  switcher.innerHTML = '<span style="font-size: 28px; line-height: 1; pointer-events: none; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.15));">' + nextMode.emoji + '</span>';

  // Floating animation style
  if (!document.getElementById('switcher-float-anim')) {
    var style = document.createElement('style');
    style.id = 'switcher-float-anim';
    style.innerHTML = '@keyframes float-switcher { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-6px); } } #mode-switcher:active { transform: scale(0.88) !important; }';
    document.head.appendChild(style);
  }

  switcher.addEventListener('click', function () {
    switcher.style.transform = 'scale(0.88)';
    localStorage.setItem('kids_scroll_last_mode', nextMode.key);
    setTimeout(function() {
      window.location.href = nextMode.url;
    }, 120);
  });

  document.documentElement.appendChild(switcher);
})();
