document.addEventListener('DOMContentLoaded', () => {
    const gameArea = document.getElementById('game-area');
    const container = document.getElementById('xylophone-container');
    const noteCaptureBar = document.getElementById('note-capture-bar');
    const playBtn = document.getElementById('play-btn');
    
    let capturedNotes = [];
    
    // Setup Audio Context
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    let audioCtx = null;
    
    // C Major scale frequencies
    const notes = [
        { note: 'C4', freq: 261.63, color: '#FF5252', emoji: '🍎', height: 200 },
        { note: 'D4', freq: 293.66, color: '#FF9800', emoji: '🍊', height: 180 },
        { note: 'E4', freq: 329.63, color: '#FFEB3B', emoji: '🍋', height: 160 },
        { note: 'F4', freq: 349.23, color: '#4CAF50', emoji: '🍏', height: 140 },
        { note: 'G4', freq: 392.00, color: '#2196F3', emoji: '🫐', height: 120 },
        { note: 'A4', freq: 440.00, color: '#3F51B5', emoji: '🍇', height: 100 },
        { note: 'B4', freq: 493.88, color: '#9C27B0', emoji: '🍆', height: 80 },
        { note: 'C5', freq: 523.25, color: '#E91E63', emoji: '🍉', height: 60 }
    ];

    function initAudio() {
        if (!audioCtx) {
            audioCtx = new AudioContext();
        }
    }

    function playSoundForFrequency(freq) {
        initAudio();
        if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }

        const osc = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
        
        // Attack, Decay, Sustain, Release envelope
        gainNode.gain.setValueAtTime(0, audioCtx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.5, audioCtx.currentTime + 0.05); // Attack
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 1); // Decay/Release

        osc.connect(gainNode);
        gainNode.connect(audioCtx.destination);

        osc.start();
        osc.stop(audioCtx.currentTime + 1);
    }

    function createXylophone() {
        container.innerHTML = '';
        notes.forEach((noteData, index) => {
            const bar = document.createElement('div');
            bar.className = 'xylophone-bar';
            bar.style.backgroundColor = noteData.color;
            bar.style.setProperty('--bar-height-ratio', (noteData.height / 200).toString());
            bar.style.height = `calc(var(--xylophone-height, 200px) * var(--bar-height-ratio, 1))`;
            bar.textContent = noteData.emoji;
            
            // Interaction events
            const trigger = (e) => {
                e.preventDefault();
                playSoundForFrequency(noteData.freq);
                bar.classList.add('active');
                setTimeout(() => bar.classList.remove('active'), 150);
                
                // Capture note
                capturedNotes.push(noteData);
                const noteEl = document.createElement('div');
                noteEl.className = 'captured-note';
                noteEl.textContent = noteData.emoji;
                noteCaptureBar.appendChild(noteEl);
                noteCaptureBar.scrollLeft = noteCaptureBar.scrollWidth;
                
                if (playBtn) playBtn.disabled = false;
            };

            bar.addEventListener('mousedown', trigger);
            bar.addEventListener('touchstart', trigger, { passive: false });
            
            container.appendChild(bar);
        });
    }

    function showGuide() {
        speakText('Tap the colorful bars to play music!');
        if (window.GhostHand) {
            const guide = new GhostHand();
            const firstBar = container.children[0];
            const lastBar = container.children[container.children.length - 1];
            
            if (firstBar && lastBar) {
                const rect1 = firstBar.getBoundingClientRect();
                const rect2 = lastBar.getBoundingClientRect();
                const startX = rect1.left + rect1.width / 2;
                const startY = rect1.top + rect1.height / 2;
                const endX = rect2.left + rect2.width / 2;
                const endY = rect2.top + rect2.height / 2;
                
                guide.show('ghost-swipe', startX, startY, endX, endY);
            }
        }
    }


    // Initialize
    createXylophone();
    
    if (playBtn) {
        playBtn.addEventListener('click', async () => {
            if (capturedNotes.length === 0) return;
            playBtn.disabled = true;
            
            if (window.recordGameStats) {
                window.recordGameStats('emoji-xylophone', capturedNotes.length, { notesPlayed: capturedNotes.length });
            }
            
            for (let i = 0; i < capturedNotes.length; i++) {
                playSoundForFrequency(capturedNotes[i].freq);
                
                if (noteCaptureBar.children[i]) {
                    noteCaptureBar.children[i].style.transform = 'scale(1.3)';
                    setTimeout(() => {
                        if (noteCaptureBar.children[i]) {
                            noteCaptureBar.children[i].style.transform = 'scale(1)';
                        }
                    }, 200);
                }
                
                await new Promise(r => setTimeout(r, 400));
            }
            
            triggerCelebration(true);
            
            setTimeout(() => {
                capturedNotes = [];
                noteCaptureBar.innerHTML = '';
            }, 3000);
        });
    }
    
    // Auto show guide on first load
    setTimeout(showGuide, 1000);
    
    if (window.saveToRecent) {
        window.saveToRecent('emoji-xylophone');
    }
});
