// Configuration
const AVATARS_PER_STYLE = 15; // Reduced number of avatars to load per style for better performance
const SCROLL_THRESHOLD = 1000; // pixels from bottom to trigger load
const MAX_AVATARS_PER_SECOND = 5; // Increased avatars per second to improve user experience while preventing rate limiting
const MIN_TIME_BETWEEN_LOADS = 1000 / MAX_AVATARS_PER_SECOND; // Minimum time in ms between avatar loads
const DEBOUNCE_DELAY = 100; // Delay for scroll event debouncing

// State variables
let isLoading = false;
let currentStyleIndex = 0; // Index of the current style in the categories array
let avatarsLoadedForCurrentStyle = 0; // Count of avatars loaded for current style
let currentStyle = getRandomStyle(); // Current category based on index
let lastLoadTime = 0; // Timestamp of the last avatar load
let scrollCount = 0; // Count of scroll events in the current session
let scrollTrackingInitialized = false; // Flag to ensure scroll tracking is initialized only once

// DOM elements
const avatarContainer = document.getElementById('avatar-container');
const loadingElement = document.getElementById('loading');

/**
 * Initializes the app
 */
function initApp() {
  // Set up event listeners with optimized debounce
  window.addEventListener('scroll', debounce(handleScroll, DEBOUNCE_DELAY));
  window.addEventListener('resize', debounce(checkAndFillViewport, DEBOUNCE_DELAY));

  // Initialize scroll tracking
  initializeScrollTracking();

  // Load initial avatars
  loadAvatars(AVATARS_PER_STYLE);
}

/**
 * Cycles to the next emoji category
 */
function cycleToNextStyle() {
  currentStyle = getRandomStyle();
  avatarsLoadedForCurrentStyle = 0;
}

/**
 * Handles scroll event for infinite loading
 */
function handleScroll() {
  if (isLoading) return;

  const scrollY = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
  const scrollPosition = window.innerHeight + scrollY;
  const pageHeight = Math.max(
    document.documentElement.scrollHeight,
    document.body.scrollHeight,
    document.documentElement.offsetHeight,
    document.body.offsetHeight
  );

  if (pageHeight - scrollPosition < SCROLL_THRESHOLD) {
    // Check if we've loaded enough avatars for the current style
    if (avatarsLoadedForCurrentStyle >= AVATARS_PER_STYLE) {
      cycleToNextStyle();
    }
    loadAvatars(AVATARS_PER_STYLE);
  }

  // Track scroll events for analytics
  trackScrollEvent();
}

/**
 * Loads avatars and adds them to the container
 * @param {number} count Number of avatars to load
 */
async function loadAvatars(count) {
  if (isLoading) return;

  isLoading = true;
  loadingElement.classList.remove('hidden');

  try {
    for (let i = 0; i < count; i++) {
      // Rate limiting: ensure minimum time between avatar loads
      const currentTime = Date.now();
      const timeSinceLastLoad = currentTime - lastLoadTime;

      if (timeSinceLastLoad < MIN_TIME_BETWEEN_LOADS) {
        // Wait until the minimum time has passed
        await new Promise(resolve =>
          setTimeout(resolve, MIN_TIME_BETWEEN_LOADS - timeSinceLastLoad)
        );
      }

      const seed = generateSeed();

      // Create a container for the avatar with a data attribute for lazy loading
      const card = document.createElement('div');
      card.className = 'avatar-card';
      card.dataset.seed = seed;
      card.dataset.style = currentStyle;
      card.innerHTML = '<div>Loading...</div>';
      card.addEventListener('click', function(event) {
        const target = event.currentTarget;
        if (!target) return;

        const emojiChar = target.dataset.emoji || (target.textContent ? target.textContent.trim() : '');
        if (typeof playAnimalSound === 'function' && typeof ANIMAL_SOUNDS !== 'undefined' && emojiChar && ANIMAL_SOUNDS[emojiChar]) {
            playAnimalSound(emojiChar);
        } else {
            playRandomAvatarSound();
        }

        // Remove the animation class if it's already applied to restart the animation
        target.classList.remove('rotate-animation');

        // Force a reflow to restart the animation
        void target.offsetWidth;

        // Add rotation animation class
        target.classList.add('rotate-animation');

        // Remove the class after the animation completes
        setTimeout(() => {
          if (target && target.classList) {
            target.classList.remove('rotate-animation');
          }
        }, 2000); // Match the 2 second animation duration

        // Generate random graffiti on avatar click at touch location
        generateGraffitiOnAvatar(target, event.clientX, event.clientY);
      });

      avatarContainer.appendChild(card);

      // Use Intersection Observer to implement true lazy loading
      if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries) => {
          entries.forEach(async (entry) => {
            if (entry.isIntersecting) {
              try {
                const emoji = getRandomEmoji();
                const svgData = generateEmojiSvg(emoji);

                // Set the SVG content directly in the card
                entry.target.innerHTML = svgData;
                // Store the emoji character for discovery mode
                entry.target.dataset.emoji = emoji;

                avatarsLoadedForCurrentStyle++; // Increment counter after successful load
                lastLoadTime = Date.now(); // Update the last load time after successful load

                // Stop observing this element
                observer.unobserve(entry.target);
              } catch (error) {
                console.error('Failed to generate emoji:', error);
                entry.target.innerHTML = '<div>Failed to load</div>';
                lastLoadTime = Date.now(); // Still update the time to prevent getting stuck
              }
            }
          });
        }, {
          rootMargin: '50px' // Start loading when 50px from viewport
        });

        observer.observe(card);
      } else {
        // Fallback for browsers that don't support IntersectionObserver
        try {
          const emoji = getRandomEmoji();
          const svgData = generateEmojiSvg(emoji);

          // Set the SVG content directly in the card
          card.innerHTML = svgData;
          card.dataset.emoji = emoji;

          avatarsLoadedForCurrentStyle++; // Increment counter after successful load
          lastLoadTime = Date.now(); // Update the last load time after successful load
        } catch (error) {
          console.error('Failed to generate emoji:', error);
          card.innerHTML = '<div>Failed to load</div>';
          lastLoadTime = Date.now(); // Still update the time to prevent getting stuck
        }
      }
    }
  } catch (error) {
    console.error('Error loading avatars:', error);
  } finally {
    isLoading = false;
    loadingElement.classList.add('hidden');
    // Ensure viewport is filled on large screens/tablets so infinite scroll is active
    setTimeout(checkAndFillViewport, 150);
  }
}

/**
 * Checks if the page is scrollable, and loads more avatars if needed on large screens
 */
function checkAndFillViewport() {
  if (isLoading) return;
  const scrollY = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
  const scrollPosition = window.innerHeight + scrollY;
  const pageHeight = Math.max(
    document.documentElement.scrollHeight,
    document.body.scrollHeight,
    document.documentElement.offsetHeight,
    document.body.offsetHeight
  );

  if (pageHeight - scrollPosition < SCROLL_THRESHOLD) {
    if (avatarsLoadedForCurrentStyle >= AVATARS_PER_STYLE) {
      cycleToNextStyle();
    }
    loadAvatars(AVATARS_PER_STYLE);
  }
}

/**
 * Tracks scroll events for analytics
 */
function trackScrollEvent() {
  scrollCount++;

  // Send scroll event to Google Analytics once per 10 scrolls to avoid excessive events
  if (scrollCount % 10 === 0) {
      }
}

/**
 * Initializes scroll tracking
 */
function initializeScrollTracking() {
  if (scrollTrackingInitialized) return;

  // Track initial scroll event
  window.addEventListener('scroll', () => {
    // Use requestAnimationFrame to throttle scroll tracking
    if (!window.requestAnimationFrame) return;

    requestAnimationFrame(() => {
      trackScrollEvent();
    });
  });

  scrollTrackingInitialized = true;
}

/**
 * Generate firecracker-like celebration effect using SVG
 */
function generateGraffitiOnAvatar(avatarCard, clientX, clientY) {
  // Define bright, saturated, light colors suitable for toddlers
  const brightColors = [
    '#FFFF00', '#FFD700', '#FFA500', '#FF6347', '#FF4500', '#FF1493', '#FF69B4', '#FFC0CB',
    '#FFB6C1', '#FFA07A', '#FFFA90', '#FFFFE0', '#FFFACD', '#FFF8DC', '#FFE4E1', '#FFE4B5',
    '#FFDEAD', '#FFEFD5', '#FFEBCD', '#F0FFF0', '#F5FFFA', '#F0FFFF', '#F0F8FF', '#F8F8FF',
    '#F5F5DC', '#FFF0F5', '#E6E6FA', '#E0FFFF', '#FDF5E6', '#FAFAD2', '#D8BFD8', '#DDA0DD',
    '#DAA520', '#CD5C5C', '#C0C0C0', '#BA55D3', '#98FB98', '#9370DB', '#87CEEB', '#7CFC00',
    '#7B68EE', '#66CDAA', '#48D1CC', '#4169E1', '#32CD32', '#1E90FF', '#00FA9A', '#00CED1',
    '#00BFFF', '#00FF7F', '#00FFFF', '#00FF00', '#228B22', '#2E8B57', '#3CB371', '#20B2AA',
    '#008B8B', '#008080', '#006400', '#0000FF', '#0000CD', '#4B0082', '#800080', '#8B008B',
    '#8A2BE2', '#9400D3', '#9932CC', '#BA55D3', '#DA70D6', '#D8BFD8', '#DDA0DD', '#EE82EE',
    '#FF00FF', '#FF00FF'
  ];

  // Create SVG overlay for celebration effect
  const celebrationSVG = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  celebrationSVG.setAttribute('class', 'celebration-overlay');
  celebrationSVG.setAttribute('width', '100%');
  celebrationSVG.setAttribute('height', '100%');
  celebrationSVG.setAttribute('style', 'position: absolute; top: 0; left: 0; pointer-events: none; z-index: 10; overflow: visible;');

  // Get dimensions for positioning
  const rect = avatarCard.getBoundingClientRect();

  // Calculate touch position relative to the avatar card
  const touchX = clientX - rect.left;
  const touchY = clientY - rect.top;

  // Ensure touch coordinates are within avatar bounds
  const boundedTouchX = Math.max(10, Math.min(rect.width - 10, touchX));
  const boundedTouchY = Math.max(10, Math.min(rect.height - 10, touchY));

  // Generate more particles for a bigger, more celebratory effect
  const numParticles = 30; // Increased number of particles for bigger effect

  for (let i = 0; i < numParticles; i++) {
    // Create particle element
    const particle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    const color = brightColors[Math.floor(Math.random() * brightColors.length)];

    // Set initial position at touch location
    particle.setAttribute('cx', boundedTouchX);
    particle.setAttribute('cy', boundedTouchY);
    particle.setAttribute('r', Math.random() * 6 + 3); // Bigger radius for more visibility
    particle.setAttribute('fill', color);
    particle.setAttribute('fill-opacity', '0.9'); // Higher opacity for more visibility

    // Add to SVG
    celebrationSVG.appendChild(particle);

    // Animate particle movement
    animateParticle(particle, boundedTouchX, boundedTouchY, rect.width, rect.height, color);
  }

  // Add the celebration SVG to the avatar container
  avatarCard.appendChild(celebrationSVG);

  // Remove celebration after 2.5 seconds to allow for longer animation
  setTimeout(() => {
    if (celebrationSVG.parentNode) {
      celebrationSVG.parentNode.removeChild(celebrationSVG);
    }
  }, 2500);
}

/**
 * Animate individual particle for firecracker effect
 */
function animateParticle(particle, startX, startY, containerWidth, containerHeight, color) {
  // Calculate random angle and distance
  const angle = Math.random() * Math.PI * 2; // Random angle in radians
  const maxDistance = Math.min(containerWidth, containerHeight) * 0.6; // Increased max travel distance for bigger effect
  const distance = Math.random() * maxDistance * 0.8 + maxDistance * 0.4; // Vary distance with more range

  // Calculate end position
  const endX = startX + Math.cos(angle) * distance;
  const endY = startY + Math.sin(angle) * distance;

  // Create animation
  const animateX = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
  animateX.setAttribute('attributeName', 'cx');
  animateX.setAttribute('from', startX);
  animateX.setAttribute('to', endX);
  animateX.setAttribute('dur', '1.5s'); // Longer duration for smoother animation
  animateX.setAttribute('fill', 'freeze');

  const animateY = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
  animateY.setAttribute('attributeName', 'cy');
  animateY.setAttribute('from', startY);
  animateY.setAttribute('to', endY);
  animateY.setAttribute('dur', '1.5s'); // Longer duration for smoother animation
  animateY.setAttribute('fill', 'freeze');

  // Fade out animation
  const animateOpacity = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
  animateOpacity.setAttribute('attributeName', 'fill-opacity');
  animateOpacity.setAttribute('values', '0.9;0.7;0'); // Starting with higher opacity
  animateOpacity.setAttribute('dur', '1.5s');
  animateOpacity.setAttribute('fill', 'freeze');

  // Size change animation - make particles grow slightly then shrink
  const animateSize = document.createElementNS('http://www.w3.org/2000/svg', 'animate');
  animateSize.setAttribute('attributeName', 'r');
  animateSize.setAttribute('values', '4;6;2;0'); // Start medium, grow, shrink, disappear
  animateSize.setAttribute('dur', '1.5s');
  animateSize.setAttribute('fill', 'freeze');

  // Append animations to particle
  particle.appendChild(animateX);
  particle.appendChild(animateY);
  particle.appendChild(animateOpacity);
  particle.appendChild(animateSize);

  // Start animations
  animateX.beginElement();
  animateY.beginElement();
  animateOpacity.beginElement();
  animateSize.beginElement();
}

// Initialize the app when the DOM is loaded
document.addEventListener('DOMContentLoaded', initApp);
