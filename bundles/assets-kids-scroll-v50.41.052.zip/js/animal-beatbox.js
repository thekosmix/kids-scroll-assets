document.addEventListener('DOMContentLoaded', () => {
    const grid = document.getElementById('beatbox-grid');
    const sequenceDisplay = document.getElementById('sequenceDisplay');
    const playButton = document.getElementById('playButton');
    
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    let audioCtx = null;
    let tapCount = 0;
    let startTime = Date.now();
    
    const instruments = [
        { id: 'kick', emoji: '🐘', name: 'Elephant' },
        { id: 'snare', emoji: '🐶', name: 'Dog' },
        { id: 'hihat', emoji: '🐍', name: 'Snake' },
        { id: 'bass', emoji: '🐻', name: 'Bear' },
        { id: 'meow', emoji: '🐱', name: 'Cat' },
        { id: 'croak', emoji: '🐸', name: 'Frog' },
        { id: 'chirp', emoji: '🐥', name: 'Bird' },
        { id: 'roar', emoji: '🦁', name: 'Lion' },
        { id: 'moo', emoji: '🐮', name: 'Cow' },
        { id: 'buzz', emoji: '🐝', name: 'Bee' }
    ];
    
    let currentGridInstruments = [];
    const pads = {};
    let sequence = [];
    let isPlaying = false;

    function initAudio() {
        if (!audioCtx) {
            audioCtx = new AudioContext();
        } else if (audioCtx.state === 'suspended') {
            audioCtx.resume();
        }
    }

    function playInstrumentSound(id, time) {
        initAudio();
        const t = time || audioCtx.currentTime;
        switch(id) {
            case 'kick': playKick(t); break;
            case 'snare': playSnare(t); break;
            case 'hihat': playHihat(t); break;
            case 'bass': playBass(t); break;
            case 'meow': playMeow(t); break;
            case 'croak': playCroak(t); break;
            case 'chirp': playChirp(t); break;
            case 'roar': playRoar(t); break;
            case 'moo': playMoo(t); break;
            case 'buzz': playBuzz(t); break;
        }
    }

    function playKick(time) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.frequency.setValueAtTime(150, time);
        osc.frequency.exponentialRampToValueAtTime(0.01, time + 0.5);
        
        gain.gain.setValueAtTime(1, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
        
        osc.start(time);
        osc.stop(time + 0.5);
        animatePad('kick');
    }

    function playSnare(time) {
        const bufferSize = audioCtx.sampleRate * 0.2;
        const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }
        
        const noise = audioCtx.createBufferSource();
        noise.buffer = buffer;
        const noiseFilter = audioCtx.createBiquadFilter();
        noiseFilter.type = 'highpass';
        noiseFilter.frequency.value = 1000;
        noise.connect(noiseFilter);
        
        const noiseGain = audioCtx.createGain();
        noiseGain.gain.setValueAtTime(1, time);
        noiseGain.gain.exponentialRampToValueAtTime(0.01, time + 0.2);
        noiseFilter.connect(noiseGain);
        noiseGain.connect(audioCtx.destination);
        
        const osc = audioCtx.createOscillator();
        osc.type = 'triangle';
        const oscGain = audioCtx.createGain();
        oscGain.gain.setValueAtTime(0.5, time);
        oscGain.gain.exponentialRampToValueAtTime(0.01, time + 0.1);
        osc.connect(oscGain);
        oscGain.connect(audioCtx.destination);
        osc.frequency.setValueAtTime(250, time);
        
        noise.start(time);
        osc.start(time);
        osc.stop(time + 0.2);
        animatePad('snare');
    }

    function playHihat(time) {
        const bufferSize = audioCtx.sampleRate * 0.1;
        const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }
        
        const noise = audioCtx.createBufferSource();
        noise.buffer = buffer;
        const noiseFilter = audioCtx.createBiquadFilter();
        noiseFilter.type = 'bandpass';
        noiseFilter.frequency.value = 10000;
        noise.connect(noiseFilter);
        
        const gain = audioCtx.createGain();
        gain.gain.setValueAtTime(0.5, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.1);
        noiseFilter.connect(gain);
        gain.connect(audioCtx.destination);
        
        noise.start(time);
        animatePad('hihat');
    }

    function playBass(time) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.type = 'square';
        osc.frequency.setValueAtTime(65.41, time);
        
        gain.gain.setValueAtTime(0.3, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.2);
        
        osc.start(time);
        osc.stop(time + 0.2);
        animatePad('bass');
    }

    function playMeow(time) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(400, time);
        osc.frequency.exponentialRampToValueAtTime(800, time + 0.1);
        osc.frequency.exponentialRampToValueAtTime(600, time + 0.4);
        
        gain.gain.setValueAtTime(0.01, time);
        gain.gain.linearRampToValueAtTime(0.4, time + 0.1);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.4);
        
        osc.start(time);
        osc.stop(time + 0.4);
        animatePad('meow');
    }

    function playCroak(time) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(80, time);
        
        gain.gain.setValueAtTime(0.3, time);
        for (let i = 0; i < 6; i++) {
            gain.gain.setValueAtTime(0.3, time + i * 0.05);
            gain.gain.setValueAtTime(0.05, time + i * 0.05 + 0.025);
        }
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);
        
        const filter = audioCtx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 300;
        
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.start(time);
        osc.stop(time + 0.3);
        animatePad('croak');
    }

    function playChirp(time) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1000, time);
        osc.frequency.exponentialRampToValueAtTime(3000, time + 0.1);
        osc.frequency.exponentialRampToValueAtTime(2500, time + 0.15);
        
        gain.gain.setValueAtTime(0.3, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.15);
        
        osc.start(time);
        osc.stop(time + 0.15);
        animatePad('chirp');
    }

    function playRoar(time) {
        const gain = audioCtx.createGain();
        const bufferSize = audioCtx.sampleRate * 0.5;
        const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }
        
        const noise = audioCtx.createBufferSource();
        noise.buffer = buffer;
        
        const filter = audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 120;
        filter.Q.value = 1.0;
        
        noise.connect(filter);
        filter.connect(gain);
        gain.connect(audioCtx.destination);
        
        gain.gain.setValueAtTime(0.8, time);
        for (let i = 0; i < 10; i++) {
            gain.gain.setValueAtTime(0.8 - (i % 2) * 0.3, time + i * 0.05);
        }
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.5);
        
        noise.start(time);
        animatePad('roar');
    }

    function playMoo(time) {
        const osc1 = audioCtx.createOscillator();
        const osc2 = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        
        osc1.type = 'sawtooth';
        osc2.type = 'sine';
        
        osc1.frequency.setValueAtTime(120, time);
        osc1.frequency.linearRampToValueAtTime(90, time + 0.6);
        osc2.frequency.setValueAtTime(121, time);
        osc2.frequency.linearRampToValueAtTime(91, time + 0.6);
        
        const filter = audioCtx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 250;
        
        osc1.connect(filter);
        osc2.connect(filter);
        filter.connect(gain);
        gain.connect(audioCtx.destination);
        
        gain.gain.setValueAtTime(0.01, time);
        gain.gain.linearRampToValueAtTime(0.4, time + 0.15);
        gain.gain.linearRampToValueAtTime(0.01, time + 0.6);
        
        osc1.start(time);
        osc2.start(time);
        osc1.stop(time + 0.6);
        osc2.stop(time + 0.6);
        animatePad('moo');
    }

    function playBuzz(time) {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, time);
        
        const fmOsc = audioCtx.createOscillator();
        const fmGain = audioCtx.createGain();
        fmOsc.frequency.value = 35;
        fmGain.gain.value = 50;
        
        fmOsc.connect(fmGain);
        fmGain.connect(osc.frequency);
        
        const filter = audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 500;
        
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(audioCtx.destination);
        
        gain.gain.setValueAtTime(0.3, time);
        gain.gain.exponentialRampToValueAtTime(0.01, time + 0.35);
        
        fmOsc.start(time);
        osc.start(time);
        fmOsc.stop(time + 0.35);
        osc.stop(time + 0.35);
        animatePad('buzz');
    }

    function animatePad(id) {
        if (pads[id]) {
            pads[id].classList.add('pulse');
            setTimeout(() => pads[id].classList.remove('pulse'), 100);
        }
    }

    function displayNote(emoji) {
        const noteElement = document.createElement('div');
        noteElement.className = 'note';
        noteElement.textContent = emoji;
        sequenceDisplay.appendChild(noteElement);
    }

    function handlePadClick(inst) {
        if (isPlaying) return;
        initAudio();
        
        if (typeof ghostHand !== 'undefined') ghostHand.stop();

        if (typeof playAnimalSound === 'function' && typeof ANIMAL_SOUNDS !== 'undefined' && ANIMAL_SOUNDS[inst.emoji]) {
            playAnimalSound(inst.emoji);
        } else {
            playInstrumentSound(inst.id);
        }

        if (typeof speakText === 'function') {
            speakText(inst.name);
        }

        sequence.push(inst);
        displayNote(inst.emoji);

        if (sequence.length > 0) {
            playButton.removeAttribute('disabled');
        }

        tapCount++;
        if (tapCount % 15 === 0 && typeof triggerCelebration === 'function') {
            triggerCelebration(false);
        }
        
        if (tapCount === 20 && typeof recordGameStats === 'function') {
            recordGameStats('animal-beatbox', Math.round((Date.now() - startTime)/1000), { taps: tapCount });
        }
    }

    function createGrid() {
        grid.innerHTML = '';
        Object.keys(pads).forEach(k => delete pads[k]);

        const shuffled = [...instruments].sort(() => 0.5 - Math.random());
        currentGridInstruments = shuffled.slice(0, 6);

        currentGridInstruments.forEach(inst => {
            const pad = document.createElement('div');
            pad.className = 'animal-pad';
            pad.innerHTML = `<span>${inst.emoji}</span><span class="pad-label">${inst.name}</span>`;
            
            const trigger = (e) => {
                e.preventDefault();
                handlePadClick(inst);
            };

            pad.addEventListener('mousedown', trigger);
            pad.addEventListener('touchstart', trigger, { passive: false });
            
            grid.appendChild(pad);
            pads[inst.id] = pad;
        });
    }

    async function playSequence() {
        if (sequence.length === 0 || isPlaying) return;
        isPlaying = true;
        playButton.setAttribute('disabled', 'true');

        const animalPads = document.querySelectorAll('.animal-pad');
        animalPads.forEach(pad => {
            pad.style.pointerEvents = 'none';
        });

        for (let i = 0; i < sequence.length; i++) {
            const noteElement = sequenceDisplay.children[i];
            const inst = sequence[i];

            if (noteElement) {
                noteElement.classList.add('highlight');
            }

            if (typeof playAnimalSound === 'function' && typeof ANIMAL_SOUNDS !== 'undefined' && ANIMAL_SOUNDS[inst.emoji]) {
                playAnimalSound(inst.emoji);
            } else {
                playInstrumentSound(inst.id);
            }

            await new Promise(resolve => setTimeout(resolve, 800));

            if (noteElement) {
                noteElement.classList.remove('highlight');
            }
        }

        setTimeout(() => {
            sequence = [];
            sequenceDisplay.innerHTML = '';
            createGrid();

            animalPads.forEach(pad => {
                pad.style.pointerEvents = 'auto';
            });
            isPlaying = false;
        }, 1000);
    }

    function setupPlayButton() {
        playButton.addEventListener('click', playSequence);
        playButton.setAttribute('disabled', 'true');
    }

    function showGuide() {
        if (typeof speakText === 'function') speakText('Tap the animals to play their music');
        if (window.GhostHand) {
            const guide = new GhostHand();
            const firstPad = grid.children[0];
            if (firstPad) {
                const rect = firstPad.getBoundingClientRect();
                guide.show('ghost-tap', (rect.left + rect.width / 2) + 'px', (rect.top + rect.height / 2) + 'px');
            }
        }
    }

    window.addEventListener('beforeunload', () => {
        if (audioCtx) {
            audioCtx.close();
        }
    });

    createGrid();
    setupPlayButton();
    setTimeout(showGuide, 1000);
    
    if (window.saveToRecent) {
        window.saveToRecent('animal-beatbox');
    }
});
