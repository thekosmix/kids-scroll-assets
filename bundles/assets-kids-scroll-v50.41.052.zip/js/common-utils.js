/**
 * Common utilities for Kids Scroll application
 */

// Dynamically synchronize --app-height with window.innerHeight to prevent mobile viewport clipping
(function initAppHeight() {
  function updateAppHeight() {
    if (typeof document !== 'undefined' && typeof window !== 'undefined') {
      const vh = window.innerHeight;
      document.documentElement.style.setProperty('--app-height', `${vh}px`);
    }
  }
  if (typeof window !== 'undefined') {
    window.addEventListener('resize', updateAppHeight);
    window.addEventListener('orientationchange', updateAppHeight);
    updateAppHeight();
  }
})();

/**
 * Display a temporary snackbar / toast message
 */
function showToast(message, duration = 3200) {
  if (typeof document === 'undefined') return;
  let toast = document.getElementById('app-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'app-toast';
    document.body.appendChild(toast);
  }
  toast.innerHTML = message;
  toast.classList.add('show');
  clearTimeout(toast._timeout);
  toast._timeout = setTimeout(() => {
    toast.classList.remove('show');
  }, duration);
}
window.showToast = showToast;

// Intercept link clicks when offline to prevent navigating to uncached pages
(function initOfflineLinkProtection() {
  if (typeof document === 'undefined' || typeof window === 'undefined') return;
  document.addEventListener('click', async (e) => {
    const link = e.target.closest('a');
    if (!link || !link.href) return;
    try {
      const url = new URL(link.href, window.location.origin);
      if (url.origin !== window.location.origin) return;

      const isActivity = url.pathname.includes('/game/') || url.pathname.includes('/story/') || url.pathname.includes('/question/');
      if (isActivity && !navigator.onLine && 'caches' in window) {
        let matchUrl = url.origin + url.pathname;
        if (url.pathname.endsWith('/')) matchUrl += 'index.html';
        const cached = await caches.match(matchUrl, { ignoreSearch: true });
        if (!cached) {
          e.preventDefault();
          showToast('📡 Connect to internet to download');
        }
      }
    } catch (err) {}
  });
})();

// Auto-recover from offline module loading failures
(function() {
  let hadCriticalError = false;
  window.addEventListener('error', function(e) {
    if ((e.message && e.message.toLowerCase().includes('module')) || (e.target && e.target.tagName === 'SCRIPT')) {
      hadCriticalError = true;
    }
  }, true);
  window.addEventListener('unhandledrejection', function(e) {
    if (e.reason && e.reason.message && (e.reason.message.includes('fetch') || e.reason.message.includes('module'))) {
      hadCriticalError = true;
    }
  });
  window.addEventListener('online', function() {
    if (hadCriticalError || document.body.innerHTML.trim() === '') {
      window.location.reload();
    } else {
      // Also trigger a SW update check immediately upon reconnection
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then(reg => reg.update());
      }
    }
  });
})();

// Global variable for PWA install prompt
let deferredPrompt;

// Autoplay policy helpers
let userHasInteracted = false;
let pendingStartupInstruction = null;

// Animal Sprite Manifest Auto-loader
(function initAnimalSpriteManifest() {
  if (typeof window.ANIMAL_SPRITE_MANIFEST === 'undefined' && typeof document !== 'undefined') {
    const script = document.createElement('script');
    script.src = '/js/animal-manifest.js?v=1.0.0';
    script.async = false;
    document.head.appendChild(script);
  }
})();

/**
 * Detects whether the app is running in installed PWA (standalone/fullscreen) or Android TWA mode.
 * Standard web browser tabs will return false.
 */
function isPWAOrTWA() {
  if (typeof window === 'undefined') return false;

  // 1. Session Storage Cache (persists mode across in-app navigations)
  try {
    if (sessionStorage.getItem('kids_scroll_app_mode') === 'standalone') {
      return true;
    }
  } catch (e) {}

  // 2. Display mode matchMedia (PWA standalone, fullscreen, minimal-ui)
  const isDisplayModeStandalone = 
    (window.matchMedia && (
      window.matchMedia('(display-mode: standalone)').matches ||
      window.matchMedia('(display-mode: fullscreen)').matches ||
      window.matchMedia('(display-mode: minimal-ui)').matches
    ));

  // 3. iOS Safari standalone mode (Add to Home Screen)
  const isIOSStandalone = window.navigator && window.navigator.standalone === true;

  // 4. Android TWA / Custom Tabs referrer check
  const isAndroidTWAReferrer = document.referrer && document.referrer.includes('android-app://');

  // 5. Query parameters from manifest or Android shortcuts
  const urlParams = (typeof URLSearchParams !== 'undefined') ? new URLSearchParams(window.location.search) : null;
  const isQueryParamApp = urlParams ? (
    urlParams.get('source') === 'pwa' || 
    urlParams.get('source') === 'twa' || 
    urlParams.get('utm_source') === 'homescreen' ||
    urlParams.get('utm_source') === 'twa'
  ) : false;

  if (isDisplayModeStandalone || isIOSStandalone || isAndroidTWAReferrer || isQueryParamApp) {
    try {
      sessionStorage.setItem('kids_scroll_app_mode', 'standalone');
    } catch (e) {}
    return true;
  }

  return false;
}
window.isPWAOrTWA = isPWAOrTWA;

// Soothing Background Music Manager for Kids Scroll Games & Hubs
class BackgroundMusicManager {
  constructor() {
    this.audio = null;
    this.url = 'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/assets/sounds/kids-scroll-background-music.mp3';
    this.baseVolume = 0.15;
    this.duckedVolume = 0.05;
    this.duckCount = 0;
    this.fadeInterval = null;
    this.isInitialized = false;
    this.isEnabled = false;
    this._wasPlayingBeforeHidden = false;
  }

  init() {
    if (this.isInitialized || typeof window === 'undefined') return;
    this.isInitialized = true;
    this.audio = new Audio(this.url);
    this.audio.loop = true;
    this.audio.volume = this.baseVolume;
    this.audio.preload = 'auto';

    // Auto-pause when user leaves the page or switches apps, resume upon return
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (this.audio && !this.audio.paused) {
          this.audio.pause();
          this._wasPlayingBeforeHidden = true;
        }
      } else {
        if (this._wasPlayingBeforeHidden && this.isEnabled) {
          this._wasPlayingBeforeHidden = false;
          this.play();
        }
      }
    });

    window.addEventListener('pagehide', () => {
      if (this.audio) this.audio.pause();
    });
  }

  async play() {
    this.init();
    this.isEnabled = true;
    if (!this.audio) return;
    try {
      await this.audio.play();
    } catch (e) {
      // Browser autoplay restriction: start on the first user interaction
      const startOnInteraction = () => {
        if (this.isEnabled && this.audio && this.audio.paused) {
          this.audio.play().catch(() => {});
        }
        window.removeEventListener('pointerdown', startOnInteraction);
        window.removeEventListener('touchstart', startOnInteraction);
        window.removeEventListener('click', startOnInteraction);
      };
      window.addEventListener('pointerdown', startOnInteraction, { once: true });
      window.addEventListener('touchstart', startOnInteraction, { once: true });
      window.addEventListener('click', startOnInteraction, { once: true });
    }
  }

  pause() {
    this.isEnabled = false;
    if (this.audio) {
      this.audio.pause();
    }
  }

  duck() {
    this.duckCount++;
    this._fadeTo(this.duckedVolume, 150);
  }

  unduck() {
    this.duckCount = Math.max(0, this.duckCount - 1);
    if (this.duckCount === 0) {
      this._fadeTo(this.baseVolume, 300);
    }
  }

  _fadeTo(targetVolume, durationMs) {
    if (!this.audio) return;
    if (this.fadeInterval) clearInterval(this.fadeInterval);
    const startVolume = this.audio.volume;
    const stepTime = 25;
    const steps = Math.max(1, Math.floor(durationMs / stepTime));
    const stepDiff = (targetVolume - startVolume) / steps;
    let stepCount = 0;

    this.fadeInterval = setInterval(() => {
      stepCount++;
      const nextVol = startVolume + stepDiff * stepCount;
      this.audio.volume = Math.max(0, Math.min(1, nextVol));
      if (stepCount >= steps) {
        clearInterval(this.fadeInterval);
        this.fadeInterval = null;
        this.audio.volume = targetVolume;
      }
    }, stepTime);
  }
}

const backgroundMusicManager = new BackgroundMusicManager();
window.backgroundMusicManager = backgroundMusicManager;
function startBackgroundMusic() { backgroundMusicManager.play(); }
function stopBackgroundMusic() { backgroundMusicManager.pause(); }

// Web Audio API Sprite Engine for zero-latency animal sound effects
class AnimalSpriteManager {
  constructor() {
    this.audioCtx = null;
    this.animalBuffer = null;
    this.isLoading = false;
  }

  initAudioContext() {
    if (!this.audioCtx) {
      const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
      if (AudioCtxClass) {
        this.audioCtx = new AudioCtxClass();
      }
    }
  }

  resume() {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  async loadAnimalSprite() {
    if (this.animalBuffer || this.isLoading) return this.animalBuffer;
    if (!window.ANIMAL_SPRITE_MANIFEST) return null;
    this.initAudioContext();
    if (!this.audioCtx) return null;

    this.isLoading = true;
    try {
      const url = window.ANIMAL_SPRITE_MANIFEST.spriteUrl;
      const resp = await fetch(url);
      const arrayBuf = await resp.arrayBuffer();
      this.animalBuffer = await this.audioCtx.decodeAudioData(arrayBuf);
      return this.animalBuffer;
    } catch (e) {
      console.warn('Failed to load animal sprite:', e);
      return null;
    } finally {
      this.isLoading = false;
    }
  }

  async play(startTime, duration) {
    this.initAudioContext();
    this.resume();

    let buf = this.animalBuffer;
    if (!buf) {
      buf = await this.loadAnimalSprite();
    }
    if (!buf || !this.audioCtx) return false;

    return new Promise((resolve) => {
      const source = this.audioCtx.createBufferSource();
      source.buffer = buf;
      source.connect(this.audioCtx.destination);

      let ended = false;
      const finish = () => {
        if (ended) return;
        ended = true;
        resolve(true);
      };

      source.onended = finish;
      source.start(0, startTime, duration);
      setTimeout(finish, Math.ceil(duration * 1000) + 50);
    });
  }
}

const animalSpriteManager = new AnimalSpriteManager();

// Animal Sounds dictionary for instant lookup and backward compatibility
const ANIMAL_SOUNDS = {
  '🐊': 'alligator', '🦍': 'ape', '🦇': 'bat', '🐻': 'bear', '🧸': 'bear', '🐝': 'bee',
  '🐋': 'bowhead-whale', '🐳': 'humpback-whale', '🐪': 'camel', '🐫': 'camel',
  '🐈': 'cat', '🐱': 'cat', '🐣': 'chick', '🐥': 'chick', '🐔': 'chicken',
  '🐓': 'rooster', '🐄': 'cow', '🐮': 'cow', '🦗': 'cricket', '🐦‍⬛': 'crow',
  '🦌': 'deer', '🦖': 'dinosaur', '🦕': 'dinosaur', '🐕': 'dog', '🐶': 'dog',
  '🐬': 'dolphin', '🦆': 'duck', '🐘': 'elephant', '🦅': 'falcon', '🦊': 'fox',
  '🐸': 'frog', '🦒': 'giraffe', '🐐': 'goat', '🐹': 'guinea-pig', '🦔': 'hedgehog',
  '🦛': 'hippopotamus', '🐎': 'horse', '🐴': 'horse', '🦘': 'kangaroo', '🐨': 'koala',
  '🐆': 'leopard', '🦁': 'lion', '🐒': 'monkey', '🐵': 'monkey', '🐭': 'rat',
  '🦦': 'otter', '🦉': 'owl', '🐼': 'panda', '🦜': 'parrot', '🐧': 'penguin',
  '🐖': 'pig', '🐷': 'pig', '🐇': 'rabbit', '🐰': 'rabbit', '🦝': 'raccoon',
  '🐀': 'rat', '🐁': 'rat', '🦏': 'rhinoceros', '🐦': 'robin', '🦭': 'seal',
  '🦈': 'shark', '🐑': 'sheep', '🐏': 'sheep', '🐍': 'snake', '🐿️': 'squirrel',
  '🐿': 'squirrel', '🐅': 'tiger', '🐯': 'tiger', '🦃': 'turkey', '🐢': 'turtle',
  '🐺': 'wolf', '🐂': 'yak', '🦓': 'zebra'
};
window.ANIMAL_SOUNDS = ANIMAL_SOUNDS;

/**
 * Plays an animal sound using the CDN animal audio sprite.
 * Supports emojis ('🐶'), names ('dog'), or filenames ('dog.mp3').
 * Returns a Promise that resolves when the audio finishes, or immediately if no sound.
 */
async function playAnimalSound(emojiOrKey) {
  if (!emojiOrKey) return false;
  if (!window.ANIMAL_SPRITE_MANIFEST) {
    let attempts = 0;
    while (!window.ANIMAL_SPRITE_MANIFEST && attempts < 20) {
      await new Promise(r => setTimeout(r, 50));
      attempts++;
    }
  }

  let soundKey = emojiOrKey;
  if (window.ANIMAL_SOUNDS && window.ANIMAL_SOUNDS[emojiOrKey]) {
    soundKey = window.ANIMAL_SOUNDS[emojiOrKey];
  } else if (window.ANIMAL_SPRITE_MANIFEST && window.ANIMAL_SPRITE_MANIFEST.emojiMap && window.ANIMAL_SPRITE_MANIFEST.emojiMap[emojiOrKey]) {
    soundKey = window.ANIMAL_SPRITE_MANIFEST.emojiMap[emojiOrKey];
  } else {
    soundKey = String(emojiOrKey).toLowerCase().replace('.mp3', '').replace('../assets/sounds/', '').replace('assets/sounds/', '').trim();
  }

  if (window.ANIMAL_SPRITE_MANIFEST && window.ANIMAL_SPRITE_MANIFEST.sounds && window.ANIMAL_SPRITE_MANIFEST.sounds[soundKey]) {
    const timing = window.ANIMAL_SPRITE_MANIFEST.sounds[soundKey];
    backgroundMusicManager.duck();
    try {
      const success = await animalSpriteManager.play(timing[0], timing[1]);
      return !!success;
    } catch (e) {
      return false;
    } finally {
      backgroundMusicManager.unduck();
    }
  }
  return false;
}

// Global list of all games for navigation and trending
const ALL_GAMES = [
  { id: 'avatar-scroll', name: 'Avatar Scroll', url: 'game/emoji-scroll.html', image: 'avatar-scroll-icon.svg', age: '1+' },
  { id: 'drawing-canvas', name: 'Drawing Canvas', url: 'game/drawing-canvas.html', image: 'drawing-canvas-icon.svg', age: '2+' },
  { id: 'scrub-mud', name: 'Scrub the Mud', url: 'game/scrub-the-mud.html', image: 'scrub-the-mud-icon.svg', age: '1+' },
  { id: 'emoji-jigsaw', name: 'Emoji Jigsaw', url: 'game/emoji-jigsaw.html', image: 'emoji-jigsaw-icon.svg', age: '3+' },
  { id: 'garden-growing', name: 'Garden Growing', url: 'game/garden-growing.html', image: 'garden-growing-icon.svg', age: '2+' },
  { id: 'shadow-match', name: 'Shadow Match', url: 'game/shadow-match.html', image: 'shadow-match-icon.svg', age: '3+' },
  { id: 'spot-the-pair', name: 'Spot the Pair', url: 'game/spot-the-pair.html', image: 'spot-the-pair-icon.svg', age: '3+' },
  { id: 'shape-sorter', name: 'Shape Sorter', url: 'game/shape-sorter.html', image: 'shape-sorter-icon.svg', age: '2+' },
  { id: 'build-the-zoo', name: 'Build the Zoo', url: 'game/build-the-zoo.html', image: 'build-the-zoo-icon.svg', age: '4+' },
  { id: 'who-is-it', name: 'What is it?', url: 'game/who-is-it.html', image: 'who-is-it-icon.svg', age: '4+' },
  { id: 'rocket-burst', name: 'Rocket Burst', url: 'game/rocket-burst.html', image: 'rocket-burst-icon.svg', age: '2+' },
  { id: 'make_fruit_salad', name: 'Make Fruit Salad', url: 'game/make-fruit-salad.html', image: 'make-fruit-salad-icon.svg', age: '3+' },
  { id: 'balloon-pop', name: 'Balloon Pop', url: 'game/balloon-pop.html', image: 'balloon-pop-icon.svg', age: '1+' },
  { id: 'whack-a-mole', name: 'Whack-a-Mole', url: 'game/whack-a-mole.html', image: 'whack-a-mole-icon.svg', age: '3+' },
  { id: 'traffic-light', name: 'Traffic Light', url: 'game/traffic-light.html', image: 'traffic-light-icon.svg', age: '4+' },
  { id: 'odd-one-out', name: 'Odd One Out', url: 'game/odd-one-out.html', image: 'odd-one-out-icon.svg', age: '3+' },
  { id: 'guess-the-time', name: 'Guess the Time', url: 'game/guess-the-time.html', image: 'guess-the-time-icon.svg', age: '5+' },
  { id: 'alphabet-trace', name: 'Learn Letters', url: 'game/learn-letters.html', image: 'learn-letters-icon.svg', age: '4+' },
  { id: 'learn_numbers', name: 'Learn Numbers', url: 'game/learn-numbers.html', image: 'learn-numbers-icon.svg', age: '3+' },
  { id: 'musical-instrument', name: 'Musical Instruments', url: 'game/musical-instruments.html', image: 'music-note-icon.svg', age: '1+' },
  { id: 'hidden-friend', name: 'Hidden Friend', url: 'game/find-the-hidden-friend.html', image: 'find-the-hidden-friend-icon.svg', age: '1+' },
  { id: 'build-a-face', name: 'Build a Face', url: 'game/build-a-face.html', image: 'build-a-face-icon.svg', age: '2+' },
  { id: 'day-night', name: 'Day and Night', url: 'game/day-and-night.html', image: 'day-and-night-icon.svg', age: '1+' },
  { id: 'animal-fight', name: 'Animal Fight', url: 'game/animal-fight.html', image: 'animal-fight-icon.svg', age: '2+' },
  { id: 'sort-the-groceries', name: 'Sort the Groceries', url: 'game/sort-the-groceries.html', image: 'sort-the-groceries-icon.svg', age: '3+' },
  { id: 'color-train', name: 'Color Train', url: 'game/color-train.html', image: 'color-train-icon.svg', age: '2+' },
  { id: 'feed-animals', name: 'Feed the Animals', url: 'game/feed-animals.html', image: 'feed-the-animals-icon.svg', age: '2+' },
  { id: 'color-mixture', name: 'Color Mixture', url: 'game/color-mixture.html', image: 'color-mixture-icon.svg', age: '3+' },
  { id: 'where-do-they-live', name: 'Where Do They Live?', url: 'game/where-do-they-live.html', image: 'where-do-they-live-icon.svg', age: '4+' },
  { id: 'finger-painting', name: 'Finger Painting', url: 'game/finger-painting.html', image: 'finger-painting-icon.svg', age: '1+' },
  { id: 'bubble-wrap-pop', name: 'Bubble Wrap Pop', url: 'game/bubble-wrap-pop.html', image: 'bubble-wrap-pop-icon.svg', age: '1+' },
  { id: 'connect-the-dots', name: 'Connect the Dots', url: 'game/connect-the-dots.html', image: 'connect-the-dots-icon.svg', age: '2+' },
  { id: 'pattern-maker', name: 'Pattern Maker', url: 'game/pattern-maker.html', image: 'pattern-maker-icon.svg', age: '3+' },
  { id: 'size-sorter', name: 'Size Sorter', url: 'game/size-sorter.html', image: 'size-sorter-icon.svg', age: '2+' },
  { id: 'catch-treats', name: 'Catch the Treats', url: 'game/catch-treats.html', image: 'catch-treats-icon.svg', age: '2+' },
  { id: 'bouncing-buddy', name: 'Bouncing Buddy', url: 'game/bouncing-buddy.html', image: 'bouncing-buddy-icon.svg', age: '1+' },
  { id: 'emotion-explorer', name: 'Emotion Explorer', url: 'game/emotion-explorer.html', image: 'emotion-explorer-icon.svg', age: '2+' },
  { id: 'hot-cold-sorter', name: 'Hot & Cold Sorter', url: 'game/hot-cold-sorter.html', image: 'hot-cold-sorter-icon.svg', age: '3+' },
  { id: 'land-sea-air', name: 'Land, Sea, or Air', url: 'game/land-sea-air.html', image: 'land-sea-air-icon.svg', age: '3+' },
  { id: 'emoji-xylophone', name: 'Emoji Xylophone', url: 'game/emoji-xylophone.html', image: 'emoji-xylophone-icon.svg', age: '1+' },
  { id: 'animal-beatbox', name: 'Animal Beatbox', url: 'game/animal-beatbox.html', image: 'animal-beatbox-icon.svg', age: '2+' },
  { id: 'breathing-bubble', name: 'Breathing Bubble', url: 'game/breathing-bubble.html', image: 'breathing-bubble-icon.svg', age: '1+' },
  { id: 'magic-sand', name: 'Magic Sand', url: 'game/magic-sand.html', image: 'magic-sand-icon.svg', age: '1+' },
  { id: 'trace-path', name: 'Trace the Path', url: 'game/trace-path.html', image: 'trace-path-icon.svg', age: '2+' },
  { id: 'count-with-me', name: 'Count with Me', url: 'game/count-with-me.html', image: 'count-with-me-icon.svg', age: '2+' },
  { id: 'who-makes-sound', name: 'Who Makes This Sound?', url: 'game/who-makes-sound.html', image: 'who-makes-sound-icon.svg', age: '2+' },
  { id: 'selective-bubble-pop', name: 'Selective Bubble Pop', url: 'game/selective-bubble-pop.html', image: 'selective-bubble-pop-icon.svg', age: '3+' },
  { id: 'bake-a-cake', name: 'Bake a Cake', url: 'game/bake-a-cake.html', image: 'bake-a-cake-icon.svg', age: '3+' },
  { id: 'flashlight-explorer', name: 'Flashlight Explorer', url: 'game/flashlight-explorer.html', image: 'flashlight-explorer-icon.svg', age: '3+' },
  { id: 'egg-hatching', name: 'Egg Hatching', url: 'game/egg-hatching.html', image: 'egg-hatching-icon.svg', age: '1+' }
];

// Global list of all stories for navigation, age badges, and stats
const ALL_STORIES = [
  // 1. Pet Animal Stories
  { id: 'rabbit', name: 'Rabbit', url: 'story/rabbit-story.html', age: '2+', category: 'pet-animals' },
  { id: 'dog', name: 'Dog', url: 'story/dog-story.html', age: '1+', category: 'pet-animals' },
  { id: 'cat', name: 'Cat', url: 'story/cat-story.html', age: '1+', category: 'pet-animals' },
  { id: 'duck', name: 'Duck', url: 'story/duck-story.html', age: '1+', category: 'pet-animals' },
  { id: 'cow', name: 'Cow', url: 'story/cow-story.html', age: '1+', category: 'pet-animals' },
  { id: 'horse', name: 'Horse', url: 'story/horse-story.html', age: '2+', category: 'pet-animals' },
  { id: 'pig', name: 'Pig', url: 'story/pig-story.html', age: '1+', category: 'pet-animals' },
  { id: 'sheep', name: 'Sheep', url: 'story/sheep-story.html', age: '1+', category: 'pet-animals' },
  { id: 'turtle', name: 'Turtle', url: 'story/turtle-story.html', age: '1+', category: 'pet-animals' },

  // 2. Wild Animal Stories
  { id: 'elephant', name: 'Elephant', url: 'story/elephant-story.html', age: '2+', category: 'wild-animals' },
  { id: 'lion', name: 'Lion', url: 'story/lion-story.html', age: '3+', category: 'wild-animals' },
  { id: 'monkey', name: 'Monkey', url: 'story/monkey-story.html', age: '2+', category: 'wild-animals' },
  { id: 'bear', name: 'Bear', url: 'story/bear-story.html', age: '2+', category: 'wild-animals' },
  { id: 'tiger', name: 'Tiger', url: 'story/tiger-story.html', age: '3+', category: 'wild-animals' },
  { id: 'giraffe', name: 'Giraffe', url: 'story/giraffe-story.html', age: '2+', category: 'wild-animals' },
  { id: 'zebra', name: 'Zebra', url: 'story/zebra-story.html', age: '2+', category: 'wild-animals' },
  { id: 'panda', name: 'Panda', url: 'story/panda-story.html', age: '2+', category: 'wild-animals' },
  { id: 'fox', name: 'Fox', url: 'story/fox-story.html', age: '3+', category: 'wild-animals' },
  { id: 'kangaroo', name: 'Kangaroo', url: 'story/kangaroo-story.html', age: '2+', category: 'wild-animals' },
  { id: 'penguin', name: 'Penguin', url: 'story/penguin-story.html', age: '2+', category: 'wild-animals' },

  // 3. Daily Routines & Self-Care
  { id: 'toothpaste-train', name: 'The Toothpaste Train', url: 'story/brush-teeth-toothpaste-train.html', age: '2+', category: 'daily-routines' },
  { id: 'bubble-bath', name: 'Splish-Splash Bubble Bath', url: 'story/splish-splash-bubble-bath.html', age: '1+', category: 'daily-routines' },
  { id: 'toy-cleanup', name: 'Where Do the Toys Sleep?', url: 'story/where-do-toys-sleep-cleanup.html', age: '2+', category: 'daily-routines' },
  { id: 'big-kid-bed', name: 'The Big Kid Bed', url: 'story/big-kid-bed-sleep-story.html', age: '3+', category: 'daily-routines' },
  { id: 'shoes-and-clothes', name: 'Left Shoe, Right Shoe', url: 'story/left-shoe-right-shoe.html', age: '3+', category: 'daily-routines' },
  { id: 'hand-washing', name: 'The Bubble Monster', url: 'story/bubble-monster-wash-hands.html', age: '1+', category: 'daily-routines' },
  { id: 'hair-nail-trim', name: 'The Gentle Hair & Nail Trim', url: 'story/gentle-hair-nail-trim.html', age: '1+', category: 'daily-routines' },

  // 4. Potty Training & Body Cues
  { id: 'tummy-bell', name: 'Listen to the Tummy Bell', url: 'story/listen-to-tummy-bell.html', age: '2+', category: 'potty-training' },
  { id: 'potty-crown', name: 'The Potty Crown', url: 'story/the-potty-crown.html', age: '2+', category: 'potty-training' },
  { id: 'big-kid-underwear', name: 'Big Kid Underwear Day', url: 'story/big-kid-underwear-day.html', age: '2+', category: 'potty-training' },
  { id: 'wipe-flush-cheer', name: 'Wipe, Flush, and Cheer!', url: 'story/wipe-flush-and-cheer.html', age: '3+', category: 'potty-training' },
  { id: 'oops-its-okay', name: "Oops, It's Okay!", url: 'story/oops-its-okay-potty.html', age: '2+', category: 'potty-training' },

  // 5. Healthy Eating & Table Manners
  { id: 'rainbow-plate', name: 'The Rainbow Plate Adventure', url: 'story/rainbow-plate-adventure.html', age: '2+', category: 'healthy-eating' },
  { id: 'table-astronaut', name: 'The Table Astronaut', url: 'story/table-astronaut-manners.html', age: '2+', category: 'healthy-eating' },
  { id: 'water-sipper', name: 'The Mighty Water Sipper', url: 'story/mighty-water-sipper.html', age: '1+', category: 'healthy-eating' },
  { id: 'spoon-fork-explorer', name: 'Spoon & Fork Explorers', url: 'story/spoon-and-fork-explorers.html', age: '2+', category: 'healthy-eating' },
  { id: 'little-chef-soup', name: "The Little Chef's Soup", url: 'story/little-chefs-soup.html', age: '3+', category: 'healthy-eating' },

  // 6. Play School & Big Steps
  { id: 'pocket-kiss', name: 'The Magic Pocket Kiss', url: 'story/magic-pocket-kiss-goodbye.html', age: '2+', category: 'play-school' },
  { id: 'hello-new-friend', name: 'Hi, My Name Is Sam!', url: 'story/hi-my-name-is-sam.html', age: '3+', category: 'play-school' },
  { id: 'circle-time', name: 'Circle Time Sunshine', url: 'story/circle-time-sunshine.html', age: '3+', category: 'play-school' },
  { id: 'sharing-timer', name: 'The Sharing Timer', url: 'story/the-sharing-timer.html', age: '2+', category: 'play-school' },
  { id: 'super-backpack', name: 'Pack My Super Backpack', url: 'story/pack-my-super-backpack.html', age: '3+', category: 'play-school' },

  // 7. Big Feelings & Calming Down
  { id: 'blow-the-candle', name: 'Blowing Out the Candle', url: 'story/blowing-out-the-candle.html', age: '2+', category: 'big-feelings' },
  { id: 'talking-voice', name: 'Use Your Talking Voice', url: 'story/use-your-talking-voice.html', age: '2+', category: 'big-feelings' },
  { id: 'broken-crayon', name: 'The Broken Crayon', url: 'story/the-broken-crayon.html', age: '3+', category: 'big-feelings' },
  { id: 'apology-hug', name: 'The Warm Apology Hug', url: 'story/warm-apology-hug.html', age: '3+', category: 'big-feelings' },
  { id: 'big-sibling-helper', name: 'Big Sibling Helper', url: 'story/big-sibling-helper.html', age: '2+', category: 'big-feelings' },

  // 8. Outdoor Play & Movement
  { id: 'slide-line', name: 'The Gentle Slide Line', url: 'story/gentle-slide-line.html', age: '2+', category: 'outdoor-play' },
  { id: 'pass-the-ball', name: 'Pass the Ball to Me!', url: 'story/pass-the-ball-to-me.html', age: '3+', category: 'outdoor-play' },
  { id: 'bug-safari', name: 'The Backyard Bug Safari', url: 'story/backyard-bug-safari.html', age: '2+', category: 'outdoor-play' },
  { id: 'helmet-on', name: 'Helmet On, Wheels Roll!', url: 'story/helmet-on-wheels-roll.html', age: '3+', category: 'outdoor-play' },
  { id: 'five-minutes-warning', name: 'Five More Minutes Warning', url: 'story/five-more-minutes-warning.html', age: '2+', category: 'outdoor-play' },

  // 9. Brave Little Hero
  { id: 'dr-bear-stethoscope', name: "Dr. Bear's Stethoscope", url: 'story/dr-bear-stethoscope.html', age: '2+', category: 'brave-hero' },
  { id: 'counting-pearly-whites', name: 'Counting Pearly Whites', url: 'story/counting-pearly-whites-dentist.html', age: '3+', category: 'brave-hero' },
  { id: 'cape-of-courage', name: 'The Cape of Courage', url: 'story/the-cape-of-courage-haircut.html', age: '2+', category: 'brave-hero' },
  { id: 'magic-bandage', name: 'The Magic Bandage', url: 'story/the-magic-bandage.html', age: '1+', category: 'brave-hero' },

  // 10. Safety First & Important Rules
  { id: 'parking-lot-hold', name: 'The Parking Lot Super-Hold', url: 'story/parking-lot-super-hold.html', age: '1+', category: 'safety-first' },
  { id: 'cart-helper', name: 'The Cart Helper', url: 'story/the-cart-helper-supermarket.html', age: '2+', category: 'safety-first' },
  { id: 'click-clack-seat', name: 'Click-Clack, Safe & Snug', url: 'story/click-clack-safe-and-snug.html', age: '1+', category: 'safety-first' },
  { id: 'freeze-feet-kitchen', name: 'Hot Stove, Freeze Feet!', url: 'story/hot-stove-freeze-feet.html', age: '2+', category: 'safety-first' }
];

// Check if the current device is a handheld device (phone/tablet)
const isHandheldDevice = /Mobi|Android|iPhone|iPad|iPod|Windows Phone/i.test(navigator.userAgent) || 
                         (navigator.maxTouchPoints > 0 && /Macintosh/.test(navigator.userAgent));

/**
 * True when running installed (PWA standalone, fullscreen, iOS home-screen, or Android TWA).
 */
function isStandaloneMode() {
  return window.matchMedia('(display-mode: standalone)').matches ||
         window.matchMedia('(display-mode: fullscreen)').matches ||
         window.navigator.standalone ||
         document.referrer.includes('android-app://');
}

/**
 * Sets the current year in footer elements
 */
function setCurrentYear() {
  const yearElements = document.querySelectorAll('#year');
  const currentYear = new Date().getFullYear();
  yearElements.forEach(element => {
    element.textContent = currentYear;
  });
}

/**
 * Dynamically adds Parental Stats link to footer if not present
 */
function initializeFooterStatsLink() {
  const footerNavs = document.querySelectorAll('.footer-nav');
  footerNavs.forEach(nav => {
    // Check if Stats link already exists
    if (nav.querySelector('a[href*="parental-stats.html"]')) return;

    // Determine correct path based on folder depth
    const path = window.location.pathname;
    let statsUrl = 'pages/parental-stats.html';

    // If we are in /game/ or /story/ or /pages/ or /blog/ or /question/
    if (path.includes('/game/') || path.includes('/story/') || path.includes('/pages/') || path.includes('/blog/') || path.includes('/question/')) {
      statsUrl = 'parental-stats.html'; // In pages/ it's local
      if (path.includes('/game/') || path.includes('/story/') || path.includes('/blog/') || path.includes('/question/')) {
        statsUrl = '../pages/parental-stats.html';
      }
    }

    const statsLink = document.createElement('a');
    statsLink.href = statsUrl;
    statsLink.textContent = 'Stats';
    statsLink.style.color = '#ffeb3b';
    statsLink.style.fontWeight = 'bold';
    nav.appendChild(statsLink);
  });
}

/**
 * Initialize common functionality when DOM is loaded
 */
document.addEventListener('DOMContentLoaded', function() {
  // Set current year in footer
  setCurrentYear();

  // Track page view
  trackPageView();

  // Initialize common event listeners if needed
  initializeCommonEvents();

  // Register Service Worker
  registerServiceWorker();

  // Initialize PWA install tracking
  initializePWAInstallTracking();

  // Initialize Share Widget
  initializeShareWidget();

  // Handle game-specific navigation (back button trapping)
  handleGameNavigation();

  // Initialize Footer Stats Link (Global)
  initializeFooterStatsLink();

  // Initialize Recently Played (Homepage only)
  if (typeof loadRecentGames === 'function') {
    loadRecentGames();
  }

  // Warm up Speech Synthesis
  warmUpSpeechSynthesis();
});

/**
 * Initialize and render the "Top Trending Today" section on the homepage.
/**
 * Handle game-specific navigation:
 * 1. Trap back button/gesture on game pages.
 * 2. Make game title link back to home.
 * 3. Add Next/Prev navigation buttons.
 * 4. Apply toddler-friendly behaviors (Evening Mode, No-Scroll Zones).
 */
function handleGameNavigation() {
  // Apply evening mode globally
  applyEveningMode();

  const path = window.location.pathname;
  const isGamePage = path.includes('/game/');
  const isStoryPage = path.includes('/story/');
  
  // Don't apply game-page restrictions to the menus
  const isGameMenu = path.endsWith('/game/') || path.endsWith('/game/index.html');
  const isStoryMenu = path.endsWith('/story/') || path.endsWith('/story/index.html');
  
  if (!isGamePage && !isStoryPage) return;
  if (isGameMenu || isStoryMenu) return;

  // Specific check for games that MUST allow scrolling (like emoji-scroll)
  const isScrollGame = path.includes('emoji-scroll.html');
  
  if (!isScrollGame) {
    // Add class to html to apply immersive-page base styles (like disabling pull-to-refresh)
    document.documentElement.classList.add('game-page');
    // Disable pull-to-refresh and system scrolling on non-scroll game pages
    document.body.classList.add('no-scroll-zone');
  }

  // Prevent accidental multi-touch zoom/gestures on all game pages
  document.addEventListener('touchstart', (e) => {
    if (e.touches.length > 1 && !isScrollGame) {
      e.preventDefault();
    }
  }, { passive: false });

  // Trap back button/gesture ONLY in PWA/TWA standalone mode
  const isStandalone = isStandaloneMode();

  if (isStandalone) {
    // Block visual browser swipe-to-go-back gesture (does not affect vertical scroll)
    document.body.style.overscrollBehaviorX = 'none';

    // Push multiple dummy states to reinforce the trap against rapid swiping
    window.history.pushState(null, null, window.location.href);
    window.history.pushState(null, null, window.location.href);
    window.history.pushState(null, null, window.location.href);
    
    // When back button/gesture is used, popstate fires. We replenish the trap.
    window.addEventListener('popstate', function(event) {
      window.history.pushState(null, null, window.location.href);
    });
  }
}

/**
 * Register Service Worker with update notification
 */
function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    // Determine SW path - absolute path is more reliable for root registration
    const swUrl = '/service-worker.js';
    
    navigator.serviceWorker.register(swUrl)
      .then(registration => {
        
        // Check for updates
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              const toast = document.createElement('div');
              toast.id = 'update-toast';
              toast.innerHTML = '🚀 Update ready! Tap to restart.';
              document.body.appendChild(toast);
              
              setTimeout(() => toast.classList.add('show'), 100);
              
              toast.addEventListener('click', () => {
                toast.classList.remove('show');
                newWorker.postMessage({ type: 'SKIP_WAITING' });
              });
            }
          });
        });
      })
      .catch(error => {
        console.error('SW registration failed:', error);
      });

    // Handle controller change (only reload if an existing SW was updated, not on fresh install)
    const hadControllerOnLoad = !!navigator.serviceWorker.controller;
    let refreshing = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (hadControllerOnLoad && !refreshing) {
        refreshing = true;
        window.location.reload();
      }
    });
  }
}

/**
 * Initialize PWA install tracking
 */
async function initializePWAInstallTracking() {
  // Check if browser natively detects app is installed
  if ('getInstalledRelatedApps' in navigator) {
    try {
      const relatedApps = await navigator.getInstalledRelatedApps();
      if (relatedApps.length > 0) {
        localStorage.setItem('kids_scroll_installed', 'true');
        return;
      }
    } catch (e) {
      console.warn('Failed to get installed related apps', e);
    }
  }

  const isAndroid = /Android/i.test(navigator.userAgent);
  const isStandalone = isStandaloneMode();

  if (!isStandalone) {
    if (isAndroid) {
      // Show Android promotion immediately
      showInstallPromotion(true);
      if (window.location.pathname.includes('/blog/')) {
        showInlineInstallBanner(true);
      }
    } else {
      // Show PWA promotion immediately for non-Android devices (iOS, Windows, etc)
      showInstallPromotion(false);
      if (window.location.pathname.includes('/blog/')) {
        showInlineInstallBanner(false);
      }
    }
  }

  window.addEventListener('beforeinstallprompt', (e) => {
    // Stash the event so it can be triggered later
    deferredPrompt = e;
    e.preventDefault();

    // Send install prompt event to Google Analytics
    if (typeof gtag !== 'undefined') {
      gtag('event', 'install_prompt_shown', {
        'event_category': 'PWA',
        'event_label': 'Install Prompt Shown'
      });
    }
  });

  window.addEventListener('appinstalled', () => {
    // Mark as installed to prevent showing again
    localStorage.setItem('kids_scroll_installed', 'true');
    
    // Clear the deferredPrompt and hide promotion
    deferredPrompt = null;
    hideInstallPromotion();
    hideInlineInstallBanner();
    
    // Send install success event to Google Analytics
    if (typeof gtag !== 'undefined') {
      gtag('event', 'pwa_installed', {
        'event_category': 'PWA',
        'event_label': 'PWA Installed Successfully'
      });
    }
  });
}

/**
 * Show custom install promotion banner (Sticky top version)
 */
function showInstallPromotion(isAndroidStore = false) {
  // Only show on key landing pages for best experience
  const keyPages = ['/', '/index.html', '/game/', '/game/index.html', '/story/', '/story/index.html', '/blog/', '/blog/index.html', '/pages/about.html', '/pages/contact.html'];
  const currentPath = window.location.pathname;
  if (!keyPages.includes(currentPath) && !keyPages.some(p => currentPath.endsWith(p))) return;
  
  // Don't show if already exists
  if (document.getElementById('install-banner')) return;

  const banner = document.createElement('div');
  banner.id = 'install-banner';
  
  // 2-liner layout
  banner.style.cssText = `
    background: #6a11cb;
    background: linear-gradient(to right, #6a11cb, #2575fc);
    color: white;
    padding: 12px 15px;
    font-family: inherit;
    position: sticky;
    top: 0;
    z-index: 9999;
    box-shadow: 0 2px 10px rgba(0,0,0,0.2);
    display: flex;
    flex-direction: row;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
  `;

  const titleText = 'Play Offline & Ad-Free!';
  const descriptionText = '50+ learning games & read-aloud stories.';
  const buttonText = isAndroidStore ? 'Get App' : 'Install';

  banner.innerHTML = `
    <div style="display: flex; align-items: center; gap: 10px; flex: 1;">
      <div style="font-size: 24px;">📱</div>
      <div>
        <div style="font-size: 14px; font-weight: bold; margin-bottom: 2px;">${titleText}</div>
        <div style="font-size: 12px; opacity: 0.9;">${descriptionText}</div>
      </div>
    </div>
    <button id="install-button" style="
      background: white;
      color: #6a11cb;
      border: none;
      padding: 8px 16px;
      border-radius: 20px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      font-size: 14px;
      white-space: nowrap;
    ">${buttonText}</button>
  `;

  document.body.prepend(banner);

  document.getElementById('install-button').addEventListener('click', async () => {
    if (isAndroidStore) {
      if (typeof gtag !== 'undefined') {
        gtag('event', 'play_store_clicked', {
          'event_category': 'App Promotion',
          'event_label': 'Main Banner Play Store Clicked'
        });
      }
      hideInstallPromotion();
      window.location.href = 'https://play.google.com/store/apps/details?id=com.kidsscroll.www.twa';
      return;
    }

    if (deferredPrompt) {
      // Track click event
      if (typeof gtag !== 'undefined') {
        gtag('event', 'install_clicked', {
          'event_category': 'PWA',
          'event_label': 'Main Banner Install Clicked'
        });
      }

      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      deferredPrompt = null;
      hideInstallPromotion();
    } else {
      // iOS or fallback manual installation
      if (typeof gtag !== 'undefined') {
        gtag('event', 'install_clicked', {
          'event_category': 'PWA',
          'event_label': 'Main Banner Install Clicked (Manual)'
        });
      }
      showIOSInstallModal();
    }
  });
}

/**
 * Hide custom install promotion banner
 */
function hideInstallPromotion() {
  const banner = document.getElementById('install-banner');
  if (banner) {
    banner.remove();
  }
}

/**
 * Show inline install banner (for blogs)
 */
function showInlineInstallBanner(isAndroidStore = false) {
  // Check if we have a placeholder for it
  const container = document.getElementById('inline-install-banner');
  if (!container) return;

  const descriptionText = '50+ learning games & read-aloud stories.';
    
  const buttonText = isAndroidStore ? 'Get App' : 'Install Kids Scroll';

  container.style.display = 'block';
  container.innerHTML = `
    <div style="
      background: linear-gradient(135deg, #f6f9ff 0%, #eef2ff 100%);
      border: 1px solid #6a11cb;
      border-radius: 10px;
      padding: 15px;
      margin: 1.5rem 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 15px;
      box-shadow: 0 2px 8px rgba(106, 17, 203, 0.1);
    ">
      <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
        <div style="font-size: 2rem;">📱</div>
        <div>
          <h3 style="color: #6a11cb; margin: 0 0 4px 0; font-size: 16px;">Play Offline & Ad-Free!</h3>
          <p style="color: #444; margin: 0; font-size: 14px; line-height: 1.3;">${descriptionText}</p>
        </div>
      </div>
      <button id="inline-install-button" style="
        background: #6a11cb;
        color: white;
        border: none;
        padding: 8px 18px;
        border-radius: 20px;
        font-weight: bold;
        cursor: pointer;
        font-size: 14px;
        transition: transform 0.2s;
        white-space: nowrap;
      ">${buttonText}</button>
    </div>
  `;

  const btn = document.getElementById('inline-install-button');
  if (btn) {
    btn.onclick = async () => {
      if (isAndroidStore) {
        if (typeof gtag !== 'undefined') {
          gtag('event', 'play_store_clicked', {
            'event_category': 'App Promotion',
            'event_label': 'Inline Blog Play Store Clicked'
          });
        }
        hideInlineInstallBanner();
        window.location.href = 'https://play.google.com/store/apps/details?id=com.kidsscroll.www.twa';
        return;
      }

      if (deferredPrompt) {
        // Track click event
        if (typeof gtag !== 'undefined') {
          gtag('event', 'install_clicked', {
            'event_category': 'PWA',
            'event_label': 'Inline Blog Install Clicked'
          });
        }

        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        deferredPrompt = null;
        hideInlineInstallBanner();
      } else {
        // iOS or manual fallback
        if (typeof gtag !== 'undefined') {
          gtag('event', 'install_clicked', {
            'event_category': 'PWA',
            'event_label': 'Inline Blog Install Clicked (Manual)'
          });
        }
        showIOSInstallModal();
      }
    };
    
    btn.onmouseover = () => btn.style.transform = 'scale(1.05)';
    btn.onmouseout = () => btn.style.transform = 'scale(1)';
  }
}

/**
 * Hide inline install banner
 */
function hideInlineInstallBanner() {
  const banner = document.getElementById('inline-install-banner');
  if (banner) {
    banner.style.display = 'none';
    banner.innerHTML = '';
  }
}

/**
 * Show iOS/Manual PWA Installation modal
 */
function showIOSInstallModal() {
  const existingModal = document.getElementById('ios-install-modal');
  if (existingModal) existingModal.remove();

  // 1. Lock background scrolling while modal is open
  const prevDocOverflow = document.documentElement.style.overflow;
  const prevBodyOverflow = document.body.style.overflow;
  document.documentElement.style.overflow = 'hidden';
  document.body.style.overflow = 'hidden';

  const modal = document.createElement('div');
  modal.id = 'ios-install-modal';
  modal.style.cssText = `
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    width: 100vw;
    height: 100vh;
    height: 100dvh;
    background: rgba(0,0,0,0.65);
    z-index: 99999;
    display: flex;
    justify-content: center;
    align-items: center; /* Centered in visible viewport */
    padding: 20px;
    box-sizing: border-box;
    cursor: pointer;
    backdrop-filter: blur(2px);
    -webkit-backdrop-filter: blur(2px);
    font-family: 'Fredoka', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  `;
  modal.innerHTML = `
    <div id="ios-install-card" style="background: white; width: 100%; max-width: 380px; border-radius: 20px; padding: 24px; text-align: center; box-shadow: 0 15px 35px rgba(0,0,0,0.3); position: relative; animation: popIn 0.25s cubic-bezier(0.34, 1.56, 0.64, 1); cursor: default; box-sizing: border-box; font-family: 'Fredoka', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
      <button id="ios-install-close-btn" style="position: absolute; top: 12px; right: 15px; background: none; border: none; font-size: 24px; color: #666; cursor: pointer; padding: 5px; line-height: 1;">&times;</button>
      <div style="font-size: 40px; margin-bottom: 12px;">📲</div>
      <h3 style="margin: 0 0 10px 0; color: #6a11cb; font-size: 1.3rem;">Install Kids Scroll</h3>
      <p style="margin: 0 0 18px 0; color: #444; font-size: 15px; line-height: 1.4;">Install the app on your device to play offline instantly!</p>
      <div style="background: #f5f7fa; padding: 15px; border-radius: 12px; text-align: left; font-size: 14px; color: #333;">
        <ol style="margin: 0; padding-left: 20px;">
          <li style="margin-bottom: 10px;">Tap the <strong>Share</strong> icon <svg style="display:inline; vertical-align:middle;" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path><polyline points="16 6 12 2 8 6"></polyline><line x1="12" y1="2" x2="12" y2="15"></line></svg> at the bottom of your screen.</li>
          <li>Scroll down and tap <strong>Add to Home Screen</strong> <svg style="display:inline; vertical-align:middle;" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="12" y1="8" x2="12" y2="16"></line><line x1="8" y1="12" x2="16" y2="12"></line></svg>.</li>
        </ol>
      </div>
    </div>
  `;
  document.documentElement.appendChild(modal);

  const cleanup = () => {
    document.removeEventListener('keydown', onKeyDown);
    document.documentElement.style.overflow = prevDocOverflow;
    document.body.style.overflow = prevBodyOverflow;
    if (modal.parentNode) {
      modal.remove();
    }
  };

  const onKeyDown = (e) => {
    if (e.key === 'Escape') {
      cleanup();
    }
  };
  document.addEventListener('keydown', onKeyDown);

  // Close when clicking outside of the card (on backdrop)
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      cleanup();
    }
  });

  // Close button click
  const closeBtn = document.getElementById('ios-install-close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      cleanup();
    });
  }

  // Add animation style if not present
  if (!document.getElementById('ios-modal-styles')) {
    const style = document.createElement('style');
    style.id = 'ios-modal-styles';
    style.innerHTML = `@keyframes popIn { from { transform: scale(0.92); opacity: 0; } to { transform: scale(1); opacity: 1; } }`;
    document.head.appendChild(style);
  }
}

/**
 * Initialize the floating share widget
 */
function initializeShareWidget() {
  // Never show share widget in installed PWA or Android TWA mode
  if (typeof isPWAOrTWA === 'function' && isPWAOrTWA()) return;
  if (typeof isStandaloneMode === 'function' && isStandaloneMode()) return;

  const currentPath = window.location.pathname;
  const isGameHub = currentPath.endsWith('/game/') || currentPath.endsWith('/game/index.html') || currentPath === '/game';
  const isIndividualGame = currentPath.includes('/game/') && !isGameHub;
  const isStoryHub = currentPath.endsWith('/story/') || currentPath.endsWith('/story/index.html') || currentPath === '/story';
  const isIndividualStory = currentPath.includes('/story/') && !isStoryHub;
  const isStoryPageClass = document.documentElement.classList.contains('story-page') || document.body.classList.contains('story-page');
  const isLauncher = currentPath.includes('/launch/');

  if (isIndividualGame || isIndividualStory || isStoryPageClass || isLauncher) return;

  const widget = document.createElement('div');
  widget.className = 'share-widget';
  widget.innerHTML = `
    <button class="share-btn" id="shareBtn" title="Share with friends">
      <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92zM18 4c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zM6 13c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm12 7.02c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/>
      </svg>
    </button>
  `;

  document.documentElement.appendChild(widget);

  const isBlogPost = currentPath.includes('/blog/') && !currentPath.endsWith('/blog/') && !currentPath.endsWith('/blog/index.html');

  const shareBtn = document.getElementById('shareBtn');
  shareBtn.addEventListener('click', async () => {
    let shareData = {
      title: 'Kids Scroll - Safe Offline Games for Toddlers',
      text: 'Check out these fun, safe, and educational offline games for toddlers and kids!',
      url: 'https://www.offlinekidsgames.com'
    };

    if (isStoryHub) {
      shareData = {
        title: 'Kids Scroll Stories - Free Read-Aloud Tales for Toddlers',
        text: 'Explore gentle, ad-free offline read-aloud stories and bedtime fables for toddlers!',
        url: 'https://www.offlinekidsgames.com/story/'
      };
    } else if (isBlogPost) {
      const metaDesc = document.querySelector('meta[name="description"]');
      shareData = {
        title: document.title,
        text: (metaDesc && metaDesc.content) || 'Read this interesting blog post on Kids Scroll!',
        url: window.location.href
      };
    }

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        // Fallback to copy link
        await navigator.clipboard.writeText(shareData.url);
        alert('Link copied to clipboard! 📋');
      }
    } catch (err) {
      console.error('Error sharing:', err);
    }
  });
}

/**
 * Track page view in Google Analytics
 */
function trackPageView() {
  if (typeof gtag !== 'undefined') {
    gtag('event', 'page_view', {
      'page_title': document.title,
      'page_location': window.location.href
    });
  }
}

/**
 * Initialize common events across the application
 */
function initializeCommonEvents() {
  preventZooming();
  initializeArrowKeyNavigation();
}

/**
 * Lets the header's prev/next links (games and story reader alike) be
 * triggered with the keyboard's left/right arrow keys, not just tap/click.
 */
function initializeArrowKeyNavigation() {
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    const tag = document.activeElement && document.activeElement.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    const selector = e.key === 'ArrowLeft' ? '.nav-arrow.prev-arrow' : '.nav-arrow.next-arrow';
    const link = document.querySelector(selector);
    if (link && link.href) window.location.href = link.href;
  });
}

/**
 * Trigger a celebration with confetti, sound and a popup message
 * @param {boolean} withSound - Whether to play the celebration sound
 * @param {number} delay - Delay in ms before playing the sound
 */
function triggerCelebration(withSound = true, delay = 0, showPopup = true) {
  // Play celebration voice if requested
  if (withSound) {
    if (delay > 0) {
      setTimeout(playCelebrationSound, delay);
    } else {
      playCelebrationSound();
    }
  }

  let message = null;

  // Create popup message (Superior UX: Vertical rectangle with stars)
  if (showPopup) {
    message = document.createElement('div');
    message.className = 'celebration-message-global';
    message.innerHTML = `
      <div class="celebration-star">🌟</div>
      <div class="celebration-text">Good Job!</div>
      <div class="celebration-star">🌟</div>
    `;
    document.body.appendChild(message);
  }

  // Confetti
  const container = document.createElement('div');
  container.className = 'confetti-container';
  document.body.appendChild(container);

  const colors = ['#f44336', '#e91e63', '#9c27b0', '#673ab7', '#3f51b5', '#2196f3', '#03a9f4', '#00bcd4', '#009688', '#4caf50', '#8bc34a', '#cddc39', '#ffeb3b', '#ffc107', '#ff9800', '#ff5722'];

  for (let i = 0; i < 100; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.top = -Math.random() * 20 + 'vh';
    container.appendChild(piece);

    piece.animate([
      { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
      { transform: `translateY(110vh) rotate(${Math.random() * 720}deg)`, opacity: 0 }
    ], {
      duration: Math.random() * 2000 + 2000,
      easing: 'cubic-bezier(0, 0.9, 0.57, 1)',
      fill: 'forwards'
    });
  }

  // Remove container and message after animation
  setTimeout(() => {
    container.remove();
    if (message) {
      message.classList.add('fade-out');
      setTimeout(() => message.remove(), 500);
    }
  }, 3500);
}

/**
 * Prevent zooming on mobile devices
 */
function preventZooming() {
  let lastTouchEnd = 0;
  document.addEventListener('touchend', function (event) {
    const now = (new Date()).getTime();
    if (now - lastTouchEnd <= 300) {
      if (event.target.tagName !== 'A' && event.target.tagName !== 'BUTTON' && !event.target.closest('a') && !event.target.closest('button')) {
        event.preventDefault();
      }
    }
    lastTouchEnd = now;
  }, false);

  document.addEventListener('gesturestart', function (e) {
    e.preventDefault();
  });
}

// Keep a global reference to prevent garbage collection on Android Webview
window.__speechUtterances = window.__speechUtterances || [];

// Fallback removed as it causes CORS/403 errors and cannot bypass Autoplay policies anyway.

/**
 * Strip emojis and unicode pictographs from text for natural, toddler-friendly speech synthesis.
 * Prevents TTS engines from speaking out emoji names like "rocket", "cat face", "dog face", etc.
 * @param {string} str
 * @returns {string}
 */
function stripEmojisForSpeech(str) {
  if (!str) return '';
  return str
    .replace(/[\p{Extended_Pictographic}\uFE0F\u200D\u20E3]/gu, '')
    .replace(/\s+([.,!?:;])/g, '$1')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

/**
 * Speak text using Web Speech API
 * @param {string} text The text to speak
 * @param {function} onEndCallback Optional callback to run after speech finishes
 */
function speakText(text, onEndCallback = null) {

  if ('speechSynthesis' in window) {
    // Only cancel if actually speaking to prevent Safari/Android queue freezing
    if (window.speechSynthesis.speaking || window.speechSynthesis.pending) {
        window.speechSynthesis.cancel();
    }
    
    // Attempt to resume the engine in case it's stuck in a paused state
    window.speechSynthesis.resume();

    const cleanText = stripEmojisForSpeech(text);
    if (!cleanText) {
      if (onEndCallback) onEndCallback();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 0.9; // Slightly slower for kids
    utterance.pitch = 1.1; // Slightly higher/cuter
    // Intentionally omitting utterance.lang to let Android pick its default engine voice
    
    // Store reference to prevent GC bug where audio cuts out or fails to start
    window.__speechUtterances.push(utterance);
    
    utterance.onstart = () => {
      backgroundMusicManager.duck();
      if (pendingStartupInstruction === text) {
        pendingStartupInstruction = null;
      }
    };
    
    utterance.onend = () => {
      backgroundMusicManager.unduck();
      const idx = window.__speechUtterances.indexOf(utterance);
      if (idx > -1) window.__speechUtterances.splice(idx, 1);
      if (onEndCallback) {
        onEndCallback();
      }
    };
    utterance.onerror = (e) => {
      backgroundMusicManager.unduck();
      utterance.onend();
      // If blocked by autoplay policy, save it to play on next user interaction
      if (e.error === 'not-allowed' || e.error === 'interrupted') {
          // Only re-pend if it's the startup instruction
          if (text.includes("!")) { 
              pendingStartupInstruction = text;
          }
      }
    };
    
    window.speechSynthesis.speak(utterance);
  } else {
    // Web Speech API not supported
    if (onEndCallback) onEndCallback();
  }
}

/**
 * Play a random encouragement phrase
 */
function playEncouragement() {
  const phrases = [
    "So smart!",
    "You're doing great!",
    "Amazing!",
    "Keep going!",
    "You're a superstar!",
    "I love it!",
    "Fantastic!",
    "Wow!",
    "Good job!"
  ];
  const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
  speakText(randomPhrase);
}

/**
 * Vibrate the device for success
 */
function vibrateSuccess() {
  if (isHandheldDevice && navigator.vibrate) {
    navigator.vibrate(50);
  }
}

/**
 * Vibrate the device for scrubbing (throttled)
 */
let lastScrubVibrate = 0;
function vibrateScrub() {
  const now = Date.now();
  if (now - lastScrubVibrate > 100) {
    if (isHandheldDevice && navigator.vibrate) {
      navigator.vibrate(10);
    }
    lastScrubVibrate = now;
  }
}

/**
 * GhostHand class for visual guidance
 */
class GhostHand {
  constructor() {
    this.element = null;
    this.timer = null;
    this.repeatCount = 0;
    this.maxRepeats = 5;
    this.showTime = 0;
    this._handleInteraction = this._handleInteraction.bind(this);
  }

  _handleInteraction(e) {
    // Ignore events if shown less than 500ms ago (grace period)
    // This prevents immediate dismissal from programmatic scrolls or lingering touches
    if (Date.now() - this.showTime < 500) return;
    
    this.stop();
  }

  show(animationType, startX = '50%', startY = '50%', endX = '50%', endY = '50%') {
    if (this.element) return;
    this.showTime = Date.now();

    // Add listeners to stop guide on ANY user interaction
    window.addEventListener('mousedown', this._handleInteraction, { capture: true });
    window.addEventListener('touchstart', this._handleInteraction, { capture: true });
    window.addEventListener('pointerdown', this._handleInteraction, { capture: true });
    window.addEventListener('keydown', this._handleInteraction, { capture: true });
    window.addEventListener('wheel', this._handleInteraction, { capture: true });

    this.element = document.createElement('div');
    this.element.className = `ghost-hand ${animationType}`;
    this.element.innerHTML = '👆';
    this.element.style.left = startX;
    this.element.style.top = startY;
    
    if (animationType === 'ghost-trace' || animationType === 'ghost-swipe' || animationType === 'ghost-pair-tap') {
      this.element.style.setProperty('--start-x', startX);
      this.element.style.setProperty('--start-y', startY);
      this.element.style.setProperty('--end-x', endX);
      this.element.style.setProperty('--end-y', endY);
    }

    document.body.appendChild(this.element);

    this.element.addEventListener('animationiteration', () => {
      this.repeatCount++;
      if (this.repeatCount >= this.maxRepeats) {
        this.stop();
      }
    });

    // Fallback if animationiteration doesn't fire as expected
    const duration = (animationType === 'ghost-tap') ? 1000 : (animationType === 'ghost-pair-tap' ? 3000 : 2000);
    this.timer = setTimeout(() => {
      if (this.repeatCount < this.maxRepeats) {
        // Continue if not yet reached max repeats
      } else {
        this.stop();
      }
    }, duration * this.maxRepeats);
  }

  stop() {
    // Clean up interaction listeners
    window.removeEventListener('mousedown', this._handleInteraction, true);
    window.removeEventListener('touchstart', this._handleInteraction, true);
    window.removeEventListener('pointerdown', this._handleInteraction, true);
    window.removeEventListener('keydown', this._handleInteraction, true);
    window.removeEventListener('wheel', this._handleInteraction, true);

    if (this.element) {
      this.element.remove();
      this.element = null;
    }
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.repeatCount = 0;
  }
}

const ghostHand = new GhostHand();

let hasPlayedStartupGuide = false;

/**
 * Initialize startup guide and instructions for a game
 * @param {string} instruction Text to speak
 * @param {object} guideConfig Configuration for ghost hand
 */
function showStartupGuide(instruction, guideConfig) {
  if (hasPlayedStartupGuide) return;
  hasPlayedStartupGuide = true;

  // Wait for a short delay after load (1s to allow settle time)
  setTimeout(() => {
    // Attempt to play instructions immediately (at once)
    pendingStartupInstruction = instruction;
    speakText(instruction);

    if (guideConfig) {
      ghostHand.show(
        guideConfig.type, 
        guideConfig.startX, 
        guideConfig.startY, 
        guideConfig.endX, 
        guideConfig.endY
      );
    }
  }, 500);

  // Stop visual guide on navigation. Browser natively halts SpeechSynthesis.
  window.addEventListener('beforeunload', () => {
    ghostHand.stop();
  });
}

/**
 * Apply evening mode if it's late (gentle on eyes)
 */
function applyEveningMode() {
  const now = new Date();
  const hour = now.getHours();
  if (hour >= 19 || hour < 7) {
    document.body.style.filter = 'sepia(0.3) brightness(0.9)';
  }
}

function playCelebrationSound() {
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();

    const phrases = [
      "Yippee! You did it!",
      "Hooray! Great job!",
      "You are so smart!",
      "Woo-hoo! Amazing!",
      "Awesome! You won!",
      "Yay! You did so well!"
    ];

    // Pick a random phrase
    const randomPhrase = phrases[Math.floor(Math.random() * phrases.length)];
    const celebration = new SpeechSynthesisUtterance(randomPhrase);

    // 2. Set the pitch slightly higher for a happy tone (range is 0 to 2)
    celebration.pitch = 1.3; 
    celebration.rate = 0.85;

    // 4. Increase the volume
    celebration.volume = 1;

    // 5. Speak with ducking!
    backgroundMusicManager.duck();
    celebration.onend = () => backgroundMusicManager.unduck();
    celebration.onerror = () => backgroundMusicManager.unduck();
    window.speechSynthesis.speak(celebration);
  }
}

/**
 * Pre-load Speech Synthesis voices and initialize the engine
 * on the first user interaction to prevent "cold start" delays.
 */
function warmUpSpeechSynthesis() {
  if (!('speechSynthesis' in window)) return;

  // 1. Calling getVoices() early helps some browsers start loading them
  window.speechSynthesis.getVoices();
  
  // 2. Some browsers need voiceschanged event to be active
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();
  }

  // 3. Play pending instruction and warm up audio engine on first interaction
  const warmUp = () => {
    userHasInteracted = true;
    
    // Unlock and warm up Web Audio Animal Sprite engine
    animalSpriteManager.initAudioContext();
    animalSpriteManager.resume();
    animalSpriteManager.loadAnimalSprite();

    // Attempt to unpause SpeechSynthesis engine
    if (window.speechSynthesis) window.speechSynthesis.resume();
    
    if (pendingStartupInstruction) {
      speakText(pendingStartupInstruction);
      pendingStartupInstruction = null;
    }
    
    // Remove listeners after first use
    window.removeEventListener('touchstart', warmUp, true);
    window.removeEventListener('mousedown', warmUp, true);
  };

  window.addEventListener('touchstart', warmUp, { once: true, capture: true });
  window.addEventListener('mousedown', warmUp, { once: true, capture: true });
}

/**
 * Recently Played and Stats Logic
 */
const STORAGE_RECENT = 'kids_scroll_recent_games';
const STORAGE_STATS = 'kids_scroll_parental_stats';

// Safe localStorage wrappers to prevent crashes in restricted WebViews
function safeStorageGet(key, defaultValue) {
  try {
    return localStorage.getItem(key) || defaultValue;
  } catch (e) {
    console.warn('localStorage not available', e);
    return defaultValue;
  }
}

function safeStorageSet(key, value) {
  try {
    localStorage.setItem(key, value);
  } catch (e) {
    console.warn('localStorage not available', e);
  }
}

/**
 * Record game statistics for parental dashboard
 * @param {string} gameId - The ID of the game played
 * @param {number} duration - Time spent in seconds (optional)
 * @param {object} metrics - Specific performance metrics e.g. { avgTime: 5.2 } (optional)
 */
window.recordGameStats = function(gameId, duration = 0, metrics = null) {
  const now = new Date();
  // Use local date string (YYYY-MM-DD)
  const dateStr = now.getFullYear() + '-' + 
                  String(now.getMonth() + 1).padStart(2, '0') + '-' + 
                  String(now.getDate()).padStart(2, '0');
  
  let stats = JSON.parse(safeStorageGet(STORAGE_STATS, '{}'));
  
  if (!stats[dateStr]) {
    stats[dateStr] = {};
  }
  
  if (!stats[dateStr][gameId]) {
    stats[dateStr][gameId] = {
      plays: 0,
      timeSpent: 0,
      metrics: []
    };
  }
  
  stats[dateStr][gameId].plays++;
  stats[dateStr][gameId].timeSpent += duration;
  
  if (metrics) {
    stats[dateStr][gameId].metrics.push({
      timestamp: now.getTime(),
      ...metrics
    });
  }
  
  // Cleanup old stats (keep last 30 days to save space)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const cutoff = thirtyDaysAgo.toISOString().split('T')[0];
  
  Object.keys(stats).forEach(date => {
    if (date < cutoff) delete stats[date];
  });
  
  safeStorageSet(STORAGE_STATS, JSON.stringify(stats));
};

/**
 * Save a game to the "Recently Played" list and track progress for stickers
 */
window.saveToRecent = function(gameId) {
  // 1. Update Recently Played
  let recentGames = JSON.parse(safeStorageGet(STORAGE_RECENT, '[]'));
  recentGames = recentGames.filter(id => id !== gameId);
  recentGames.unshift(gameId);
  recentGames = recentGames.slice(0, 5);
  safeStorageSet(STORAGE_RECENT, JSON.stringify(recentGames));

  // 2. Record basic play stat
  window.recordGameStats(gameId);
};

/**
 * Load and render the "Recently Played" section on the homepage
 */
function loadRecentGames() {
  const recentlyPlayedScroll = document.getElementById('recently-played-scroll');
  const recentlyPlayedSection = document.getElementById('recently-played-section');
  if (!recentlyPlayedScroll || !recentlyPlayedSection) return;

  const recentGames = JSON.parse(safeStorageGet(STORAGE_RECENT, '[]'));
  if (recentGames.length === 0) {
    recentlyPlayedSection.style.display = 'none';
    return;
  }

  document.documentElement.classList.add('has-recently-played');
  recentlyPlayedScroll.innerHTML = '';

  recentGames.forEach(gameId => {
    const originalItem = document.querySelector(`.trending-item[data-game-id="${gameId}"]`);
    if (originalItem) {
      const clone = originalItem.cloneNode(true);
      clone.addEventListener('click', () => window.saveToRecent(gameId));
      recentlyPlayedScroll.appendChild(clone);
    }
  });
  
  recentlyPlayedSection.style.display = 'block';
}

/**
 * JoyMeter: A centralized floating progress bar (happiness meter)
 */
class JoyMeter {
  constructor(containerId = 'game-container', options = {}) {
    this.container = typeof containerId === 'string' ? document.getElementById(containerId) : containerId;
    if (!this.container) return;

    this.options = {
      color1: options.color1 || '#FFD700',
      color2: options.color2 || '#FFA500',
      width: options.width || '80%',
      maxWidth: options.maxWidth || '400px',
      top: options.top || '10px'
    };

    this.createDOM();
  }

  createDOM() {
    this.wrapper = document.createElement('div');
    this.wrapper.className = 'global-joy-meter-wrapper';
    this.wrapper.style.top = this.options.top;
    this.wrapper.style.width = this.options.width;
    this.wrapper.style.maxWidth = this.options.maxWidth;

    this.meterContainer = document.createElement('div');
    this.meterContainer.className = 'joy-meter-container';

    this.meterFill = document.createElement('div');
    this.meterFill.className = 'joy-meter-fill';
    this.meterFill.style.background = `linear-gradient(to right, ${this.options.color1}, ${this.options.color2})`;

    this.meterContainer.appendChild(this.meterFill);
    this.wrapper.appendChild(this.meterContainer);
    this.container.appendChild(this.wrapper);
  }

  setProgress(percentage) {
    if (this.meterFill) {
      this.meterFill.style.width = Math.min(Math.max(percentage, 0), 100) + '%';
    }
  }

  reset() {
    if (this.meterFill) {
      this.meterFill.style.width = '0%';
    }
  }
}

/**
 * Centralized Game Controls Locking
 * Disables download and refresh buttons until user interacts with the game
 */
function unlockGameControls() {
    const controls = document.querySelectorAll('.download-btn, .floating-restart-btn, .floating-refresh-btn, #restartBtn, #downloadCanvas');
    controls.forEach(btn => btn.classList.remove('control-locked'));
}

window.unlockGameControls = unlockGameControls;

function initializeGameControls() {
    const controls = document.querySelectorAll('.download-btn, .floating-restart-btn, .floating-refresh-btn, #restartBtn, #downloadCanvas');
    
    if (controls.length > 0) {
        // Lock controls by default
        controls.forEach(btn => {
            btn.classList.add('control-locked');
            
            // Intercept clicks in capture phase
            btn.addEventListener('click', function(e) {
                if (btn.classList.contains('control-locked')) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    
                    // Play error sound
                    if (typeof soundGenerator !== 'undefined' && typeof soundGenerator.playWrongSound === 'function') {
                        soundGenerator.playWrongSound();
                    }
                    
                    // Trigger shake animation
                    btn.classList.remove('shake-error');
                    void btn.offsetWidth; // force reflow
                    btn.classList.add('shake-error');
                }
            }, true);
        });

        // Global unlock on first touch/click in the game area
        const unlockHandler = function(e) {
            // Ignore if tapped on the control buttons or header
            if (!e.target.closest('.download-btn, .floating-restart-btn, .floating-refresh-btn, #restartBtn, #downloadCanvas, .header-nav-container')) {
                unlockGameControls();
                document.body.removeEventListener('pointerdown', unlockHandler, true);
                document.body.removeEventListener('click', unlockHandler, true);
            }
        };

        // Attach listeners (capture phase to ensure we catch it early)
        document.body.addEventListener('pointerdown', unlockHandler, true);
        document.body.addEventListener('click', unlockHandler, true);
    }
}

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeGameControls);
} else {
    initializeGameControls();
}

/**
 * Background Music Auto-activation
 * Active across ALL game pages (/game/*.html), Games Hub (/game/index.html), and Stories Hub (/story/index.html).
 * Excludes individual story reading pages (/story/*.html) so narrated stories remain crystal clear.
 */
(function autoStartBackgroundMusic() {
  if (typeof window === 'undefined') return;
  const path = window.location.pathname.toLowerCase();
  
  // All games and game hub
  const isGame = path.includes('/game/') || path === '/game' || path.endsWith('/game.html');
  
  // Stories hub landing page ONLY (not individual story readers)
  const isStoryHub = path.endsWith('/story/') || path.endsWith('/story/index.html') || path === '/story' || path.endsWith('/story.html');

  // Question & Wonder hub landing page ONLY (not individual question readers or ask chat)
  const isQuestionHub = path.endsWith('/question/') || path.endsWith('/question/index.html') || path === '/question' || path.endsWith('/question.html');

  if (isGame || isStoryHub || isQuestionHub) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => backgroundMusicManager.play());
    } else {
      backgroundMusicManager.play();
    }
  }
})();