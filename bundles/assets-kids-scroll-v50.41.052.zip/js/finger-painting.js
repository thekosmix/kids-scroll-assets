/**
 * Finger Painting - Game Logic
 */

class FingerPainting {
    constructor() {
        this.canvas = document.getElementById('paintCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.controlsArea = document.getElementById('controlsArea');
        this.isDrawing = false;
        
        // Extended color pool for the scrollable palette
        this.colorPool = [
            { hex: '#FF0000', name: 'Red' },
            { hex: '#FF7F00', name: 'Orange' },
            { hex: '#FFFF00', name: 'Yellow' },
            { hex: '#00FF00', name: 'Green' },
            { hex: '#0000FF', name: 'Blue' },
            { hex: '#4B0082', name: 'Indigo' },
            { hex: '#8B00FF', name: 'Violet' },
            { hex: '#FF00FF', name: 'Pink' },
            { hex: '#00FFFF', name: 'Cyan' },
            { hex: '#FF1493', name: 'Deep Pink' },
            { hex: '#ADFF2F', name: 'Lime' },
            { hex: '#FFD700', name: 'Gold' },
            { hex: '#00FA9A', name: 'Medium Spring Green' },
            { hex: '#000000', name: 'Black' },
            { hex: '#8B4513', name: 'Brown' }
        ];
        
        this.currentColor = '#FF0000';
        this.lineWidth = 20;
        
        this.init();
    }

    init() {
        this.generateBuckets();
        this.resizeCanvas();
        this.setupEventListeners();
        
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
    }

    generateBuckets() {
        // Clear existing buckets
        this.controlsArea.innerHTML = '';
        
        this.colorPool.forEach((colorObj, index) => {
            const bucket = document.createElement('div');
            bucket.className = 'color-bucket';
            bucket.style.backgroundColor = colorObj.hex;
            bucket.dataset.color = colorObj.hex;
            bucket.dataset.name = colorObj.name;
            
            if (colorObj.hex === this.currentColor) {
                bucket.classList.add('active');
            }

            bucket.onclick = () => {
                this.currentColor = bucket.dataset.color;
                const colorName = bucket.dataset.name;
                
                document.querySelectorAll('.color-bucket').forEach(b => b.classList.remove('active'));
                bucket.classList.add('active');
                
                if (typeof soundGenerator !== 'undefined') {
                    soundGenerator.playTapSound();
                }

                if (typeof speakText === 'function') {
                    speakText(`Now painting with ${colorName}`);
                }
            };
            
            this.controlsArea.appendChild(bucket);
        });
    }

    resizeCanvas() {
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
        
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        this.ctx.lineWidth = this.lineWidth;
    }

    setupEventListeners() {
        window.addEventListener('resize', () => this.resizeCanvas());

        // Mouse Events
        this.canvas.addEventListener('mousedown', (e) => this.startDrawing(e));
        this.canvas.addEventListener('mousemove', (e) => this.draw(e));
        this.canvas.addEventListener('mouseup', () => this.stopDrawing());
        this.canvas.addEventListener('mouseout', () => this.stopDrawing());

        // Touch Events
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            this.startDrawing(e.touches[0]);
        }, { passive: false });
        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            this.draw(e.touches[0]);
        }, { passive: false });
        this.canvas.addEventListener('touchend', () => this.stopDrawing());
        this.canvas.addEventListener('touchcancel', () => this.stopDrawing());

        const downloadBtn = document.getElementById('downloadBtn');
        downloadBtn.addEventListener('click', () => this.handleDownloadAndClear());

        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                if (typeof ghostHand !== 'undefined') ghostHand.stop();
                this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
                if (typeof soundGenerator !== 'undefined') {
                    soundGenerator.playTapSound();
                }
            });
        }

        // Startup guide
        if (typeof showStartupGuide === 'function') {
            setTimeout(() => {
                const firstBucket = document.querySelector('.color-bucket');
                if (firstBucket) {
                    const rect = firstBucket.getBoundingClientRect();
                    showStartupGuide("tap a color and paint with you finger", {
                        type: 'ghost-tap',
                        startX: (rect.left + rect.width/2) + 'px',
                        startY: (rect.top + rect.height/2) + 'px'
                    });
                }
            }, 500);
        }
    }

    getCoordinates(e) {
        const rect = this.canvas.getBoundingClientRect();
        return {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
        };
    }

    startDrawing(e) {
        if (typeof ghostHand !== 'undefined') ghostHand.stop();
        this.isDrawing = true;
        const coords = this.getCoordinates(e);
        this.ctx.beginPath();
        this.ctx.moveTo(coords.x, coords.y);
    }

    draw(e) {
        if (!this.isDrawing) return;
        
        const coords = this.getCoordinates(e);
        this.ctx.strokeStyle = this.currentColor;
        this.ctx.lineWidth = this.lineWidth;
        this.ctx.lineTo(coords.x, coords.y);
        this.ctx.stroke();
    }

    stopDrawing() {
        this.isDrawing = false;
        this.ctx.closePath();
    }

    handleDownloadAndClear() {
        if (typeof ghostHand !== 'undefined') ghostHand.stop();
        // 1. Download the painting
        const link = document.createElement('a');
        const imageData = this.canvas.toDataURL('image/png');
        link.href = imageData;
        
        const timestamp = new Date().getTime();
        link.download = `my-painting-${timestamp}.png`;
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // 2. Clear the canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        if (typeof triggerCelebration === 'function') {
            triggerCelebration();
        }
    }
}

// Start game
document.addEventListener('DOMContentLoaded', () => {
    window.fingerPainting = new FingerPainting();
});
