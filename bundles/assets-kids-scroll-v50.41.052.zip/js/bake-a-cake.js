/**
 * Bake a Cake Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const shelf = document.getElementById('shelf');
    const bowl = document.getElementById('bowl');
    const bowlContainer = document.getElementById('bowl-container');
    const mixingIndicator = document.getElementById('mixing-indicator');
    const oven = document.getElementById('oven');
    const finalCake = document.getElementById('final-cake');
    const dragClone = document.getElementById('drag-clone');

    const dishes = [
        { name: 'cake', emoji: '🎂', ingredients: [{e:'🥚',n:'eggs'}, {e:'🥛',n:'milk'}, {e:'🌾',n:'flour'}] },
        { name: 'soup', emoji: '🍲', ingredients: [{e:'🥕',n:'carrots'}, {e:'🧅',n:'onions'}, {e:'🥦',n:'broccoli'}] },
        { name: 'pizza', emoji: '🍕', ingredients: [{e:'🧀',n:'cheese'}, {e:'🍅',n:'tomatoes'}, {e:'🌾',n:'flour'}] },
        { name: 'pie', emoji: '🥧', ingredients: [{e:'🍎',n:'apples'}, {e:'🍯',n:'honey'}, {e:'🌾',n:'flour'}] }
    ];
    let currentDish = null;

    let state = 'ADDING'; // ADDING, MIXING, BAKING, DONE
    let itemsAdded = 0;
    
    let activeDragElement = null;
    let isDragging = false;
    
    let mixProgress = 0;
    let lastMixAngle = null;

    function initGame() {
        state = 'ADDING';
        itemsAdded = 0;
        mixProgress = 0;
        
        shelf.innerHTML = '';
        currentDish = dishes[Math.floor(Math.random() * dishes.length)];
        currentDish.ingredients.forEach(ing => {
            const div = document.createElement('div');
            div.className = 'ingredient';
            div.dataset.item = ing.e;
            div.dataset.name = ing.n;
            div.textContent = ing.e;
            shelf.appendChild(div);
        });

        oven.classList.remove('show', 'baking');
        finalCake.classList.remove('show');
        finalCake.textContent = currentDish.emoji;
        mixingIndicator.style.display = 'none';
        
        bowl.textContent = '🥣';
        bowlContainer.classList.remove('on-oven');
        bowlContainer.style.display = 'flex';
        shelf.style.display = 'flex';

        showStartupGuide("Mix the items to make a dish!", {
            type: 'ghost-swipe', // approximate
            startX: '50%',
            startY: '30%',
            endX: '50%',
            endY: '60%'
        });

        if(typeof saveToRecent === 'function') saveToRecent('bake-a-cake');
    }

    // --- Drag and Drop Logic ---
    function handleStart(e) {
        if(state !== 'ADDING') {
            // If in mixing state, start mixing
            if(state === 'MIXING' && e.target.closest('#bowl-container')) {
                const rect = bowl.getBoundingClientRect();
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                const clientX = e.touches ? e.touches[0].clientX : e.clientX;
                const clientY = e.touches ? e.touches[0].clientY : e.clientY;
                lastMixAngle = Math.atan2(clientY - centerY, clientX - centerX);
            }
            return;
        }

        const target = e.target.closest('.ingredient');
        if(!target || target.classList.contains('used')) return;

        isDragging = true;
        activeDragElement = target;
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        dragClone.textContent = target.dataset.item;
        dragClone.style.display = 'block';
        dragClone.style.left = clientX + 'px';
        dragClone.style.top = clientY + 'px';
        
        activeDragElement.style.opacity = '0'; // Hide original
        e.preventDefault();
    }

    function handleMove(e) {
        if(state === 'MIXING') {
            handleMixing(e);
            return;
        }

        if(!isDragging || !activeDragElement) return;
        e.preventDefault();

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        dragClone.style.left = clientX + 'px';
        dragClone.style.top = clientY + 'px';
    }

    function handleEnd(e) {
        if(state === 'MIXING') {
            lastMixAngle = null;
            return;
        }

        if(!isDragging || !activeDragElement) return;
        isDragging = false;
        
        const clientX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
        const clientY = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;

        const bowlRect = bowl.getBoundingClientRect();
        
        // Simple collision detection (center of clone vs bowl rect)
        if (clientX > bowlRect.left && clientX < bowlRect.right && 
            clientY > bowlRect.top && clientY < bowlRect.bottom) {
            
            // Success drop: animate out and remove from shelf
            const elemToRemove = activeDragElement;
            elemToRemove.style.transition = 'all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
            elemToRemove.style.transform = 'scale(0)';
            elemToRemove.style.opacity = '0';
            setTimeout(() => {
                if (elemToRemove && elemToRemove.parentNode) {
                    elemToRemove.parentNode.removeChild(elemToRemove);
                }
            }, 250);
            
            bowl.classList.remove('wobble');
            void bowl.offsetWidth; // trigger reflow
            bowl.classList.add('wobble');
            
            if(typeof vibrateSuccess === 'function') vibrateSuccess();

            itemsAdded++;
            if(itemsAdded >= 3) {
                let hasTransitioned = false;
                const transitionToMixing = () => {
                    if (hasTransitioned) return;
                    hasTransitioned = true;
                    startMixingPhase();
                };
                speakText("Now mixing " + elemToRemove.dataset.name, transitionToMixing);
                // Safety fallback in case speech callback is delayed or blocked
                setTimeout(transitionToMixing, 2400);
            } else {
                speakText("Now mixing " + elemToRemove.dataset.name);
            }
        } else {
            // Return to start
            activeDragElement.style.opacity = '1';
        }

        dragClone.style.display = 'none';
        activeDragElement = null;
    }

    // --- Mixing Logic ---
    function startMixingPhase() {
        state = 'MIXING';
        shelf.style.display = 'none';
        mixingIndicator.style.display = 'block';
        speakText("Stir the bowl!");
    }

    function handleMixing(e) {
        if(lastMixAngle === null) return;
        e.preventDefault();

        const rect = bowl.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        const currentAngle = Math.atan2(clientY - centerY, clientX - centerX);
        
        // Calculate angle difference
        let diff = currentAngle - lastMixAngle;
        if(diff > Math.PI) diff -= Math.PI * 2;
        if(diff < -Math.PI) diff += Math.PI * 2;
        
        mixProgress += Math.abs(diff);
        lastMixAngle = currentAngle;

        // Vibrate slightly while mixing
        if(mixProgress % 2 > 1.8 && typeof vibrateScrub === 'function') vibrateScrub();

        if(mixProgress > 15) { // Arbitrary threshold (about 2.5 full circles)
            startBakingPhase();
        }
    }

    // --- Baking Logic ---
    function startBakingPhase() {
        if(state === 'BAKING') return;
        state = 'BAKING';
        lastMixAngle = null;
        
        mixingIndicator.style.display = 'none';
        bowl.textContent = '🥣'; // Could change to batter emoji if exists, but bowl is fine
        
        setTimeout(() => {
            bowlContainer.classList.add('on-oven');
            oven.classList.add('show');
            speakText("Tap the oven to bake!");
        }, 500);
    }

    oven.addEventListener('pointerdown', () => {
        if(state !== 'BAKING') return;
        state = 'DONE';
        
        oven.classList.add('baking');
        speakText("Ding!");
        
        setTimeout(() => {
            oven.classList.remove('show');
            bowlContainer.style.display = 'none';
            finalCake.classList.add('show');
            
            speakText(`You made a delicious ${currentDish.name}!`);
            
            setTimeout(() => {
                triggerCelebration(true, 500);
                setTimeout(() => {
                    initGame();
                }, 4000);
            }, 5000);
        }, 1500);
    });

    document.addEventListener('touchstart', handleStart, {passive: false});
    document.addEventListener('touchmove', handleMove, {passive: false});
    document.addEventListener('touchend', handleEnd);
    document.addEventListener('touchcancel', handleEnd);
    
    document.addEventListener('mousedown', handleStart);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);

    initGame();
});
