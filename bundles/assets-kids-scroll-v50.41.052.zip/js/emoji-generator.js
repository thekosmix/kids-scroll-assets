/**
 * Emoji Generator for Kids Scroll
 * Generates emojis from specific categories: faces, animals, food, games, and vehicles
 */

/**
 * Gets a random emoji from the specified category using Unicode ranges
 * @param {string} category - The category to pick from (faces, animals, food, games, vehicles)
 * @returns {string} A random emoji from the specified category
 */
function getRandomEmojiFromCategory(category) {
  const ranges = {
    faces: [0x1F600, 0x1F64F],  // Emoticons range
    animals: [0x1F400, 0x1F44F], // Animal range (partially)
    food: [0x1F300, 0x1F37F],    // Food and drink range
    games: [0x1F380, 0x1F3FF],   // Games and activities range
    vehicles: [0x1F680, 0x1F6FF] // Transport and map symbols range
  };

  // Check if category exists
  if (!ranges[category]) {
    console.error(`Invalid emoji category: ${category}`);
    return '❓'; // Default fallback emoji
  }

  const [start, end] = ranges[category];
  
  // Pick a random whole number between the start and end
  const randomCode = Math.floor(Math.random() * (end - start + 1)) + start;
  
  // Return the emoji using String.fromCodePoint
  return String.fromCodePoint(randomCode);
}

/**
 * Gets a random emoji from any category
 * @returns {string} A random emoji from any category
 */
function getRandomEmoji() {
  const categories = ['faces', 'animals', 'food', 'games', 'vehicles'];
  const randomCategory = categories[Math.floor(Math.random() * categories.length)];
  return getRandomEmojiFromCategory(randomCategory);
}

/**
 * Generates an emoji SVG representation
 * @param {string} emoji - The emoji to convert to SVG
 * @returns {string} SVG string representing the emoji
 */
function generateEmojiSvg(emoji) {
  // Create a large, centered emoji in an SVG container
  return `
    <svg width="100%" height="100%" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle"
            font-size="60" font-family="Apple Color Emoji, Segoe UI Emoji, Noto Color Emoji"
            fill="black" style="pointer-events: none;">
        ${emoji}
      </text>
    </svg>
  `;
}

/**
 * Generates a random emoji SVG
 * @returns {string} SVG string representing a random emoji
 */
function generateRandomEmojiSvg() {
  const emoji = getRandomEmoji();
  return generateEmojiSvg(emoji);
}

/**
 * Gets a random emoji category
 * @returns {string} A random category name
 */
function getRandomCategory() {
  const categories = ['faces', 'animals', 'food', 'games', 'vehicles'];
  return categories[Math.floor(Math.random() * categories.length)];
}

/**
 * Gets an emoji SVG from the emoji generator
 * @param {string} category The emoji category to use (faces, animals, food, games, vehicles)
 * @param {string} seed The seed for generating the emoji (not used in emoji generation)
 * @returns {Promise<string>} Promise that resolves to the SVG string
 */
async function getAvatar(category, seed) {
  return new Promise((resolve) => {
    // Generate a random emoji
    const emoji = getRandomEmojiFromCategory(category || getRandomStyle());
    const svg = generateEmojiSvg(emoji);
    resolve(svg);
  });
}

/**
 * Gets a random emoji category
 * @returns {string} Random emoji category
 */
function getRandomStyle() {
  const categories = ['faces', 'animals', 'food', 'games', 'vehicles'];
  return categories[Math.floor(Math.random() * categories.length)];
}

// Make functions globally available
window.getAvatar = getAvatar;
window.getRandomEmojiFromCategory = getRandomEmojiFromCategory;
window.generateEmojiSvg = generateEmojiSvg;
window.getRandomEmoji = getRandomEmoji;
window.getRandomStyle = getRandomStyle;
window.getRandomCategory = getRandomCategory;