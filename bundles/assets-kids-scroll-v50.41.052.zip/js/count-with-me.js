/**
 * Count with Me Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('items-container');
    const finalNumber = document.getElementById('final-number');
    
    let totalItems = 0;
    let currentCount = 0;
    let startTime;
    
    const objects = [
        { emoji: '🐶', name: 'dogs' },
        { emoji: '🐱', name: 'cats' },
        { emoji: '🦊', name: 'foxes' },
        { emoji: '🐻', name: 'bears' },
        { emoji: '🐸', name: 'frogs' },
        { emoji: '🐧', name: 'penguins' },
        { emoji: '🐢', name: 'turtles' },
        { emoji: '🦆', name: 'ducks' },
        { emoji: '🐰', name: 'bunnies' },
        { emoji: '🦁', name: 'lions' }
    ];

    function initGame() {
        container.innerHTML = '';
        finalNumber.className = '';
        finalNumber.textContent = '';
        
        // Random number between 3 and 10
        totalItems = Math.floor(Math.random() * 8) + 3;
        currentCount = 0;
        
        const animal = objects[Math.floor(Math.random() * objects.length)];
        const emoji = animal.emoji;
        
        for(let i=0; i<totalItems; i++) {
            const el = document.createElement('div');
            el.className = 'count-item';
            el.innerHTML = `
                ${emoji}
                <div class="number-badge"></div>
            `;
            el.addEventListener('pointerdown', () => handleTap(el));
            container.appendChild(el);
        }
        
        startTime = Date.now();

        // Guide hand on the first item
        const firstItem = container.firstChild;
        if(firstItem) {
            const rect = firstItem.getBoundingClientRect();
            showStartupGuide(`Tap to count the ${animal.name}!`, {
                type: 'ghost-tap',
                startX: `${rect.left + rect.width/2}px`,
                startY: `${rect.top + rect.height/2}px`
            });
        }

        if(typeof saveToRecent === 'function') saveToRecent('count-with-me');
    }

    function handleTap(el) {
        if(el.classList.contains('counted')) return;
        
        currentCount++;
        el.classList.add('counted');
        el.querySelector('.number-badge').textContent = currentCount;
        
        // Vibrate and speak
        if(typeof vibrateSuccess === 'function') vibrateSuccess();
        speakText(currentCount.toString());
        
        if(currentCount === totalItems) {
            winGame();
        }
    }

    function winGame() {
        setTimeout(() => {
            container.style.opacity = '0.3';
            finalNumber.textContent = totalItems;
            finalNumber.classList.add('show');
            
            triggerCelebration(true, 500);
            
            const duration = Math.floor((Date.now() - startTime) / 1000);
            if(typeof recordGameStats === 'function') {
                // Tracking average time per count
                recordGameStats('count-with-me', duration, { avgTime: duration / totalItems });
            }

            setTimeout(() => {
                container.style.opacity = '1';
                initGame();
            }, 3500);
        }, 1000); // Wait a second before showing final celebration to let the last number sound play
    }

    initGame();
});
