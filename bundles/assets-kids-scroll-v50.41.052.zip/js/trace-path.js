/**
 * Trace the Path Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const gameContainer = document.getElementById('game-container');
    const draggable = document.getElementById('draggable-emoji');
    const target = document.getElementById('target-emoji');
    const trackPath = document.getElementById('track-path');
    const progressPath = document.getElementById('progress-path');
    
    let isDragging = false;
    let pathPoints = [];
    let currentPointIndex = 0;
    const SNAP_DISTANCE = 60;
    
    const pairs = [
        { obj: '🚗', target: '🏠' },
        { obj: '🐛', target: '🍃' },
        { obj: '🐝', target: '🌻' },
        { obj: '🐠', target: '🌊' },
        { obj: '🚂', target: '🚉' },
        { obj: '🚀', target: '🌙' },
        { obj: '🐒', target: '🍌' },
        { obj: '⛵', target: '🏝️' },
        { obj: '🐦', target: '🌳' },
        { obj: '🐸', target: '🪷' },
        { obj: '🚜', target: '🌾' },
        { obj: '🕷️', target: '🕸️' },
        { obj: '🐻', target: '🍯' },
        { obj: '🐭', target: '🧀' },
        { obj: '🐰', target: '🥕' }
    ];
    
    let startTime;

    function initGame() {
        const pair = pairs[Math.floor(Math.random() * pairs.length)];
        draggable.textContent = pair.obj;
        target.textContent = pair.target;

        const rect = gameContainer.getBoundingClientRect();
        const w = rect.width || window.innerWidth;
        const h = rect.height || (window.innerHeight - 70);

        // Safe margins (accounting for 40px stroke width + 60px emoji size + padding)
        const padX = Math.max(55, w * 0.08);
        const padY = Math.max(50, h * 0.14);
        const minY = padY;
        const maxY = h - padY;
        const minX = padX;
        const maxX = w - padX;

        // Generate a random path shape
        const pathType = Math.floor(Math.random() * 4);
        let pathD = '';
        let startX = minX;
        let startY = minY + Math.random() * (maxY - minY);
        let endX = maxX;
        let endY = minY + Math.random() * (maxY - minY);

        if (pathType === 0) {
            // Simple curve
            const cp1X = minX + (maxX - minX) * 0.35;
            const cp1Y = Math.random() > 0.5 ? minY : maxY;
            const cp2X = minX + (maxX - minX) * 0.65;
            const cp2Y = Math.random() > 0.5 ? minY : maxY;
            pathD = `M ${startX} ${startY} C ${cp1X} ${cp1Y}, ${cp2X} ${cp2Y}, ${endX} ${endY}`;
        } else if (pathType === 1) {
            // Double wave (Snake)
            const midX = (minX + maxX) / 2;
            const midY = (minY + maxY) / 2;
            const isUpFirst = Math.random() > 0.5;
            const wave1Y = isUpFirst ? minY : maxY;
            const wave2Y = isUpFirst ? maxY : minY;
            pathD = `M ${startX} ${startY} Q ${minX + (midX - minX) * 0.5} ${wave1Y}, ${midX} ${midY} T ${endX} ${endY}`;
        } else if (pathType === 2) {
            // Big Loop
            const loopUp = Math.random() > 0.5;
            const loopY1 = loopUp ? minY : maxY;
            const loopY2 = loopUp ? maxY : minY;
            const cp1X = maxX - (maxX - minX) * 0.15;
            const cp2X = minX + (maxX - minX) * 0.15;
            pathD = `M ${startX} ${startY} C ${cp1X} ${loopY1}, ${cp2X} ${loopY2}, ${endX} ${endY}`;
        } else {
            // Spiral inwards to center
            endX = (minX + maxX) / 2;
            endY = (minY + maxY) / 2;
            const topY = minY;
            const botY = maxY;
            const innerLeftX = minX + (maxX - minX) * 0.25;
            const innerTopY = minY + (maxY - minY) * 0.35;
            pathD = `M ${startX} ${startY} 
                     C ${minX} ${topY}, ${maxX} ${topY}, ${maxX} ${botY} 
                     C ${maxX} ${botY}, ${innerLeftX} ${botY}, ${innerLeftX} ${endY}
                     C ${innerLeftX} ${innerTopY}, ${endX} ${innerTopY}, ${endX} ${endY}`;
        }
        
        trackPath.setAttribute('d', pathD);
        
        // Setup positions
        draggable.style.left = startX + 'px';
        draggable.style.top = startY + 'px';
        target.style.left = endX + 'px';
        target.style.top = endY + 'px';

        // Pre-calculate path points for snap/progress
        const pathLength = trackPath.getTotalLength();
        const numPoints = Math.floor(pathLength / 10); // Checkpoint every 10px
        pathPoints = [];
        for(let i=0; i<=numPoints; i++) {
            const pt = trackPath.getPointAtLength(i * 10);
            pathPoints.push({x: pt.x, y: pt.y, distance: i * 10});
        }
        
        currentPointIndex = 0;
        updateProgressPath();
        startTime = Date.now();

        showStartupGuide("Follow the path to go home!", {
            type: 'ghost-trace',
            startX: `${startX}px`,
            startY: `${startY}px`,
            endX: `${endX}px`,
            endY: `${endY}px`
        });
        
        if(typeof saveToRecent === 'function') saveToRecent('trace-path');
    }

    function handleStart(e) {
        if(e.target === draggable) {
            isDragging = true;
            e.preventDefault();
        }
    }

    function handleMove(e) {
        if(!isDragging) return;
        e.preventDefault();

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        const containerRect = gameContainer.getBoundingClientRect();
        const posX = clientX - containerRect.left;
        const posY = clientY - containerRect.top;

        // Find nearest point on the path ahead
        let nearestIdx = currentPointIndex;
        let minDis = Infinity;
        
        // Only allow moving forward along the path (within a window of points)
        const windowSize = 30; // approx 300px ahead max
        const endIdx = Math.min(pathPoints.length, currentPointIndex + windowSize);
        
        for(let i = currentPointIndex; i < endIdx; i++) {
            const pt = pathPoints[i];
            const dx = pt.x - posX;
            const dy = pt.y - posY;
            const dis = Math.sqrt(dx*dx + dy*dy);
            if(dis < minDis) {
                minDis = dis;
                nearestIdx = i;
            }
        }

        // If the finger is within snap distance of the path, move the emoji
        if(minDis < SNAP_DISTANCE) {
            currentPointIndex = nearestIdx;
            const snapPt = pathPoints[currentPointIndex];
            draggable.style.left = snapPt.x + 'px';
            draggable.style.top = snapPt.y + 'px';
            updateProgressPath();

            // Check win
            if(currentPointIndex >= pathPoints.length - 2) { // Allow slight forgiveness
                isDragging = false;
                winGame();
            }
        }
    }

    function handleEnd() {
        isDragging = false;
    }

    function updateProgressPath() {
        if(currentPointIndex === 0) {
            progressPath.setAttribute('d', '');
            return;
        }
        
        // Generate partial path
        const startPt = pathPoints[0];
        let d = `M ${startPt.x} ${startPt.y}`;
        // Add a few points to make it smooth, don't need every single one but it's fine for SVG
        for(let i=1; i<=currentPointIndex; i+=5) {
            d += ` L ${pathPoints[i].x} ${pathPoints[i].y}`;
        }
        d += ` L ${pathPoints[currentPointIndex].x} ${pathPoints[currentPointIndex].y}`;
        progressPath.setAttribute('d', d);
    }

    function winGame() {
        // Snap to exact center of target
        draggable.style.left = target.style.left;
        draggable.style.top = target.style.top;
        
        triggerCelebration(true, 100);
        
        const duration = Math.floor((Date.now() - startTime) / 1000);
        if(typeof recordGameStats === 'function') {
            recordGameStats('trace-path', duration, { avgTime: duration });
        }

        setTimeout(() => {
            initGame();
        }, 3500);
    }

    document.addEventListener('touchstart', handleStart, {passive: false});
    document.addEventListener('touchmove', handleMove, {passive: false});
    document.addEventListener('touchend', handleEnd);
    document.addEventListener('touchcancel', handleEnd);
    
    document.addEventListener('mousedown', handleStart);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleEnd);

    initGame();

    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(initGame, 250);
    });
});
