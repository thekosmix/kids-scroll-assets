document.addEventListener('DOMContentLoaded', () => {
    const gameContainer = document.getElementById('game-container');
    const labelEl = document.getElementById('emotion-label');
    
    const allEmotions = [
        { emoji: '😀', name: 'Happy', color: '#FFF59D' },
        { emoji: '😭', name: 'Sad', color: '#BBDEFB' },
        { emoji: '😡', name: 'Angry', color: '#FFCDD2' },
        { emoji: '😴', name: 'Sleepy', color: '#D1C4E9' },
        { emoji: '😲', name: 'Surprised', color: '#FFE082' },
        { emoji: '😋', name: 'Hungry', color: '#FFCC80' },
        { emoji: '🙄', name: 'Bored', color: '#CFD8DC' },
        { emoji: '🤒', name: 'Sick', color: '#C8E6C9' },
        { emoji: '😱', name: 'Scared', color: '#E1BEE7' },
        { emoji: '🤪', name: 'Silly', color: '#F8BBD0' }
    ];

    let currentEmotions = [];
    let tappedCards = new Set();
    let startTime = Date.now();

    function initGame() {
        gameContainer.innerHTML = '';
        tappedCards.clear();
        labelEl.classList.remove('show');
        startTime = Date.now();

        // Pick 6 random emotions
        const shuffled = [...allEmotions].sort(() => Math.random() - 0.5);
        currentEmotions = shuffled.slice(0, 6);

        currentEmotions.forEach((emotion, index) => {
            const card = document.createElement('div');
            card.className = 'emotion-card';
            card.textContent = emotion.emoji;
            card.id = `emotion-${index}`;
            
            const interact = (e) => {
                e.preventDefault();
                handleEmotionClick(emotion, card, index);
            };
            
            card.addEventListener('mousedown', interact);
            card.addEventListener('touchstart', interact, { passive: false });
            
            gameContainer.appendChild(card);
        });

        // Setup guide
        setTimeout(() => {
            const firstCard = document.getElementById('emotion-0');
            if (firstCard && typeof showStartupGuide === 'function') {
                const rect = firstCard.getBoundingClientRect();
                showStartupGuide("How are you feeling today?", {
                    type: 'ghost-tap',
                    startX: (rect.left + rect.width / 2) + 'px',
                    startY: (rect.top + rect.height / 2) + 'px'
                });
            }
        }, 500);
    }

    function handleEmotionClick(emotion, cardElement, index) {
        if (typeof ghostHand !== 'undefined') ghostHand.stop();

        cardElement.classList.remove('animating');
        void cardElement.offsetWidth;
        cardElement.classList.add('animating');

        document.body.style.backgroundColor = emotion.color;

        if (typeof speakText === 'function') {
            speakText(emotion.name);
        }

        labelEl.textContent = emotion.name;
        labelEl.classList.remove('show');
        void labelEl.offsetWidth;
        
        const rect = cardElement.getBoundingClientRect();
        labelEl.style.left = `${rect.left + rect.width / 2}px`;
        labelEl.style.top = `${rect.top}px`;
        labelEl.classList.add('show');

        tappedCards.add(index);

        if (tappedCards.size === 6) {
            setTimeout(() => {
                if (typeof triggerCelebration === 'function') triggerCelebration(true);
                if (typeof recordGameStats === 'function') {
                    recordGameStats('emotion-explorer', Math.round((Date.now() - startTime)/1000), { explored: 6 });
                }
                setTimeout(initGame, 3000);
            }, 1000);
        }
    }

    initGame();
});
