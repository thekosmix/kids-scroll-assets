// Color mixing game functionality
document.addEventListener('DOMContentLoaded', function() {
  // Define color palette
  const colorPalette = [
    { name: "Red", hex: "#FF0000", rgb: [255, 0, 0] },
    { name: "Green", hex: "#00FF00", rgb: [0, 255, 0] },
    { name: "Blue", hex: "#0000FF", rgb: [0, 0, 255] },
    { name: "Yellow", hex: "#FFFF00", rgb: [255, 255, 0] },
    { name: "Purple", hex: "#800080", rgb: [128, 0, 128] },
    { name: "Orange", hex: "#FFA500", rgb: [255, 165, 0] },
    { name: "Pink", hex: "#FFC0CB", rgb: [255, 192, 203] },
    { name: "White", hex: "#FFFFFF", rgb: [255, 255, 255] },
    { name: "Black", hex: "#000000", rgb: [0, 0, 0] }
  ];

  // Common color mixing combinations
  const COLOR_MIXES = {
    'Blue+Red': { name: 'Purple', hex: '#800080' },
    'Red+Yellow': { name: 'Orange', hex: '#FFA500' },
    'Blue+Yellow': { name: 'Green', hex: '#008000' },
    'Black+White': { name: 'Gray', hex: '#808080' },
    'Red+White': { name: 'Pink', hex: '#FFC0CB' },
    'Blue+White': { name: 'Light Blue', hex: '#ADD8E6' },
    'Green+White': { name: 'Light Green', hex: '#90EE90' },
    'Orange+White': { name: 'Peach', hex: '#FFDAB9' },
    'Purple+White': { name: 'Lavender', hex: '#E6E6FA' },
    'White+Yellow': { name: 'Light Yellow', hex: '#FFFFE0' },
    'Pink+White': { name: 'Light Pink', hex: '#FFB6C1' },
    'Black+Red': { name: 'Dark Red', hex: '#8B0000' },
    'Black+Blue': { name: 'Dark Blue', hex: '#00008B' },
    'Black+Green': { name: 'Dark Green', hex: '#006400' },
    'Black+Yellow': { name: 'Olive', hex: '#808000' },
    'Black+Purple': { name: 'Dark Purple', hex: '#4B0082' },
    'Black+Orange': { name: 'Brown', hex: '#8B4513' },
    'Black+Pink': { name: 'Dark Pink', hex: '#E75480' },
    'Blue+Green': { name: 'Teal', hex: '#008080' },
    'Green+Yellow': { name: 'Lime Green', hex: '#32CD32' },
    'Orange+Red': { name: 'Red-Orange', hex: '#FF4500' },
    'Orange+Yellow': { name: 'Amber', hex: '#FFBF00' },
    'Pink+Red': { name: 'Hot Pink', hex: '#FF69B4' },
    'Pink+Purple': { name: 'Lilac', hex: '#C8A2C8' },
    'Green+Red': { name: 'Brown', hex: '#8B4513' },
    'Blue+Orange': { name: 'Brown', hex: '#8B4513' },
    'Green+Purple': { name: 'Dark Purple', hex: '#4B0082' },
    'Orange+Purple': { name: 'Brown', hex: '#8B4513' },
    'Orange+Green': { name: 'Brown', hex: '#8B4513' },
    'Pink+Blue': { name: 'Lavender', hex: '#E6E6FA' },
    'Pink+Yellow': { name: 'Peach', hex: '#FFDAB9' },
    'Green+Pink': { name: 'Gray', hex: '#808080' },
    'Purple+Yellow': { name: 'Brown', hex: '#8B4513' },
    'Blue+Purple': { name: 'Indigo', hex: '#4B0082' },
    'Purple+Red': { name: 'Magenta', hex: '#FF00FF' },
    'Blue+Pink': { name: 'Lavender', hex: '#E6E6FA' },
    'Green+Orange': { name: 'Brown', hex: '#8B4513' },
    'Pink+Orange': { name: 'Peach', hex: '#FFDAB9' }
  };

  // DOM elements
  const colorGrid = document.getElementById('colorGrid');
  const colorPlaceholder1 = document.getElementById('color1');
  const colorPlaceholder2 = document.getElementById('color2');
  const resultElement = document.getElementById('result');
  const restartBtn = document.getElementById('restartBtn');

  // State variables
  let selectedColor1 = null;
  let selectedColor2 = null;
  let autoRefreshTimeout = null;

  // Initialize the color grid
  function initColorGrid() {
    colorGrid.innerHTML = '';

    colorPalette.forEach(color => {
      const tile = document.createElement('div');
      tile.className = 'color-tile';
      tile.style.backgroundColor = color.hex;
      
      // Add color name
      const nameDiv = document.createElement('div');
      nameDiv.className = 'color-name';
      nameDiv.textContent = color.name;
      tile.appendChild(nameDiv);

      // Store color data
      tile.dataset.name = color.name;
      tile.dataset.hex = color.hex;
      tile.dataset.r = color.rgb[0];
      tile.dataset.g = color.rgb[1];
      tile.dataset.b = color.rgb[2];

      // Add click event listener instead of drag
      tile.addEventListener('click', handleColorClick);

      colorGrid.appendChild(tile);
    });
  }

  // Handle color tile click
  function handleColorClick() {
    if (selectedColor1 && selectedColor2) return; // Wait for mix to finish

    const colorData = {
      name: this.dataset.name,
      hex: this.dataset.hex,
      r: parseInt(this.dataset.r),
      g: parseInt(this.dataset.g),
      b: parseInt(this.dataset.b)
    };

    // Play click sound
    if (typeof soundGenerator !== 'undefined') {
        soundGenerator.playTapSound();
    }
    
    // Speak color name
    if (typeof speakText === 'function') {
        speakText(colorData.name);
    }

    if (!selectedColor1) {
      selectedColor1 = colorData;
      updateColorPlaceholder(colorPlaceholder1, colorData);
    } else if (!selectedColor2) {
      selectedColor2 = colorData;
      updateColorPlaceholder(colorPlaceholder2, colorData);
      // Mix colors if both are selected
      mixColors();
    }
  }

  // Update color placeholder with selected color
  function updateColorPlaceholder(element, colorData) {
    element.style.backgroundColor = colorData.hex;
    element.textContent = colorData.name;
    element.classList.add('filled');
    element.dataset.color = colorData.name;
  }

  // Mix two colors
  function mixColors() {
    if (autoRefreshTimeout) {
      clearTimeout(autoRefreshTimeout);
    }

    const color1 = selectedColor1.name;
    const color2 = selectedColor2.name;
    const combo = [color1, color2].sort().join('+');
    
    let mixedName, mixedHex;

    if (color1 === color2) {
      mixedName = color1;
      mixedHex = selectedColor1.hex;
    } else if (COLOR_MIXES[combo]) {
      mixedName = COLOR_MIXES[combo].name;
      mixedHex = COLOR_MIXES[combo].hex;
    } else {
      // Fallback: RGB averaging
      const r = Math.round((selectedColor1.r + selectedColor2.r) / 2);
      const g = Math.round((selectedColor1.g + selectedColor2.g) / 2);
      const b = Math.round((selectedColor1.b + selectedColor2.b) / 2);
      mixedHex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
      
      const avgBrightness = (getBrightness(selectedColor1) + getBrightness(selectedColor2)) / 2;
      mixedName = avgBrightness > 180 ? 'Light Mix' : (avgBrightness < 70 ? 'Dark Mix' : 'Mix');
    }

    // Add swirl animation to the placeholders to show they are mixing
    colorPlaceholder1.classList.add('swirl-animation');
    colorPlaceholder2.classList.add('swirl-animation');

    // Short delay to show the second color being filled before showing result
    setTimeout(() => {
        // Remove swirl from placeholders
        colorPlaceholder1.classList.remove('swirl-animation');
        colorPlaceholder2.classList.remove('swirl-animation');

        // Update the result element
        resultElement.style.backgroundColor = mixedHex;
        resultElement.textContent = mixedName;
        
        // Add swirl animation to result
        resultElement.classList.add('swirl-animation');
        setTimeout(() => resultElement.classList.remove('swirl-animation'), 1000);

        // Trigger celebration (message only, no sound)
        if (typeof triggerCelebration === 'function') {
            triggerCelebration(false);
        }

        // Speak the result in a full sentence
        if (typeof speakText === 'function') {
          const sentence = `${mixedName} color is formed when ${color1} and ${color2} colors are mixed`;
          // Delay speaking the sentence slightly so it doesn't overlap with the last color name
          setTimeout(() => speakText(sentence), 500);
        }

        resultElement.classList.add('mixing-complete');
        setTimeout(() => {
          resultElement.classList.remove('mixing-complete');
        }, 500);

        // Auto-refresh after 6 seconds to allow for the longer sentence
        autoRefreshTimeout = setTimeout(() => {
          clearSelections();
        }, 6000);
    }, 1000); // Increased delay for mixing feel
  }

  // Helper function to calculate brightness of a color
  function getBrightness(color) {
    return (color.r * 299 + color.g * 587 + color.b * 114) / 1000;
  }

  // Clear all selections
  function clearSelections() {
    if (autoRefreshTimeout) {
      clearTimeout(autoRefreshTimeout);
      autoRefreshTimeout = null;
    }

    selectedColor1 = null;
    selectedColor2 = null;

    colorPlaceholder1.style.backgroundColor = '';
    colorPlaceholder1.textContent = 'Tap a color';
    colorPlaceholder1.classList.remove('filled');
    colorPlaceholder1.dataset.color = '';

    colorPlaceholder2.style.backgroundColor = '';
    colorPlaceholder2.textContent = 'Tap a color';
    colorPlaceholder2.classList.remove('filled');
    colorPlaceholder2.dataset.color = '';

    resultElement.style.backgroundColor = '';
    resultElement.textContent = '?';
  }

  // Refresh colors with animation
  function refreshColors() {
    if (typeof ghostHand !== 'undefined') ghostHand.stop();
    restartBtn.classList.add('rotating');
    setTimeout(() => {
      clearSelections();
      restartBtn.classList.remove('rotating');
    }, 250);
  }

  initColorGrid();
  
  // Show startup guide
  if (typeof showStartupGuide === 'function') {
    setTimeout(() => {
      const tiles = document.querySelectorAll('.color-tile');
      if (tiles.length >= 2) {
        const rect1 = tiles[0].getBoundingClientRect();
        const rect2 = tiles[1].getBoundingClientRect();
        
        showStartupGuide("Tap 2 colors to see what new color is formed", {
          type: 'ghost-pair-tap',
          startX: (rect1.left + rect1.width/2) + 'px',
          startY: (rect1.top + rect1.height/2) + 'px',
          endX: (rect2.left + rect2.width/2) + 'px',
          endY: (rect2.top + rect2.height/2) + 'px'
        });
      }
    }, 500);
  }

  if (restartBtn) {
      restartBtn.addEventListener('click', refreshColors);
  }
});
