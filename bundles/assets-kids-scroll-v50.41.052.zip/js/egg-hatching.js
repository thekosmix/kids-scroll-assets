/**
 * Egg Hatching Game Logic
 */
document.addEventListener('DOMContentLoaded', () => {
    const egg = document.getElementById('egg');
    const cracksContainer = document.getElementById('cracks');

    const animals = ['🐥', '🦖', '🐢', '🐍', '🐧', '🐉'];
    
    function getAnimalName(emoji) {
        switch(emoji) {
            case '🐥': return 'chick';
            case '🦖': return 'dinosaur';
            case '🐢': return 'turtle';
            case '🐍': return 'snake';
            case '🐧': return 'penguin';
            case '🐉': return 'dragon';
            default: return 'animal';
        }
    }
    const MAX_TAPS = 5;
    let taps = 0;
    let isHatched = false;
    let startTime;

    function initGame() {
        taps = 0;
        isHatched = false;
        egg.textContent = '🥚';
        egg.style.transform = 'scale(1)';
        cracksContainer.innerHTML = '';
        cracksContainer.style.opacity = '0';
        
        startTime = Date.now();
        
        showStartupGuide("Tap the egg!", {
            type: 'ghost-tap',
            startX: '50%',
            startY: '50%'
        });

        if(typeof saveToRecent === 'function') saveToRecent('egg-hatching');
    }

    egg.addEventListener('pointerdown', () => {
        if(isHatched) return;
        
        taps++;
        
        // Remove and re-add animation to re-trigger it
        egg.classList.remove('shake');
        void egg.offsetWidth; 
        egg.classList.add('shake');
        
        if(typeof vibrateSuccess === 'function') vibrateSuccess(); // Mild feedback per tap
        speakText(["Crack", "Tap", "Knock", "Thump"][Math.floor(Math.random()*4)]);
        
        drawCrack(taps);

        if(taps >= MAX_TAPS) {
            hatch();
        }
    });

    function drawCrack(tapLevel) {
        cracksContainer.style.opacity = '1';
        
        const crack = document.createElement('div');
        crack.className = 'crack-line';
        
        // Random length and angle based on tap level
        const length = 20 + (tapLevel * 10);
        const angle = Math.random() * 360;
        
        crack.style.width = length + 'px';
        crack.style.transform = `rotate(${angle}deg)`;
        crack.style.top = (40 + Math.random() * 20) + '%';
        crack.style.left = (40 + Math.random() * 20) + '%';
        
        cracksContainer.appendChild(crack);
    }

    function hatch() {
        isHatched = true;
        cracksContainer.style.opacity = '0';
        
        // Pick random animal
        const animal = animals[Math.floor(Math.random() * animals.length)];
        
        egg.textContent = animal;
        egg.style.transform = 'scale(1.2)';
        
        const animalName = getAnimalName(animal);
        if (typeof playAnimalSound === 'function' && typeof ANIMAL_SOUNDS !== 'undefined' && ANIMAL_SOUNDS[animal]) {
            playAnimalSound(animal);
        }
        speakText(`You found a baby ${animalName}!`);
        
        setTimeout(() => {
            triggerCelebration(true, 100);
            
            setTimeout(() => {
                initGame();
            }, 4000);
        }, 5000);
    }

    initGame();
});
