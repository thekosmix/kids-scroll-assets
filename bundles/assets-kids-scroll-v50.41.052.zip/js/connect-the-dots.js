document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    const container = document.getElementById('game-container');
    
    let points = [];
    let currentPoint = 0;
    let maxPoints = 0;
    let startTime = Date.now();
    let currentLevel = 1; // Starts at 1, goes to 4
    let gameActive = true;
    
    let isDragging = false;
    let pointerPos = null;

    function resize() {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        if (points.length > 0) draw();
    }
    window.addEventListener('resize', resize);

    function initGame() {
        resize();
        points = [];
        currentPoint = 0;
        isDragging = false;
        pointerPos = null;
        gameActive = true;
        startTime = Date.now();
        
        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        const r = Math.min(cx, cy) * 0.6;
        
        // Generate Level (up to 14 levels)
        maxPoints = 2 + currentLevel;
        if (maxPoints > 15) maxPoints = 15;
        
        const offsetAngle = -Math.PI / 2; // Start from top
        
        for (let i = 0; i < maxPoints; i++) {
            let angle = offsetAngle + (i * 2 * Math.PI) / maxPoints;
            
            let currentRadius = r;
            // Every alternate level from 4 makes a star shape by changing inner radius
            if (currentLevel >= 4 && currentLevel % 2 === 0 && i % 2 !== 0) {
                currentRadius = r * 0.5;
            }
            
            points[i] = {
                id: i + 1,
                x: cx + Math.cos(angle) * currentRadius,
                y: cy + Math.sin(angle) * currentRadius
            };
        }
        
        draw();
        
        if (typeof showStartupGuide === 'function') {
            const rect = canvas.getBoundingClientRect();
            showStartupGuide("Connect the dots in order!", {
                type: 'ghost-swipe',
                startX: (rect.left + points[0].x) + 'px',
                startY: (rect.top + points[0].y) + 'px',
                endX: (rect.left + points[1].x) + 'px',
                endY: (rect.top + points[1].y) + 'px'
            });
        }
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw connected lines
        if (currentPoint > 0) {
            ctx.beginPath();
            ctx.moveTo(points[0].x, points[0].y);
            const limit = Math.min(currentPoint, maxPoints);
            for (let i = 1; i < limit; i++) {
                ctx.lineTo(points[i].x, points[i].y);
            }
            
            // Draw line to pointer if dragging
            if (isDragging && pointerPos && currentPoint <= maxPoints) {
                ctx.lineTo(pointerPos.x, pointerPos.y);
            }
            
            // Connect last to first if fully finished
            if (currentPoint > maxPoints) {
                ctx.lineTo(points[0].x, points[0].y);
            }
            
            ctx.strokeStyle = '#FFB74D';
            ctx.lineWidth = 10;
            ctx.lineJoin = 'round';
            ctx.lineCap = 'round';
            ctx.stroke();
        }

        // Draw points while game is active
        if (currentPoint <= maxPoints) {
            points.forEach((p, idx) => {
                ctx.font = '50px Arial';
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.fillText('⭐', p.x, p.y - 10);
                
                ctx.fillStyle = '#333';
                ctx.font = 'bold 30px "Comic Sans MS", cursive';
                ctx.fillText(p.id, p.x, p.y + 30);
            });
        }
    }

    function playSynth(freq) {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            const audioCtx = new AudioContext();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.frequency.value = freq;
            osc.type = 'sine';
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.1);
        } catch(e){}
    }
    
    function getPointerPos(e) {
        const rect = canvas.getBoundingClientRect();
        // Support touch and mouse
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    }

    function handlePointerDown(e) {
        if (!gameActive || currentPoint > maxPoints) return;
        const pos = getPointerPos(e);
        const targetIndex = currentPoint === 0 ? 0 : currentPoint - 1;
        const target = points[targetIndex];
        const dist = Math.hypot(pos.x - target.x, pos.y - target.y);
        
        // Start dragging if touching the active point
        if (dist < 80) {
            isDragging = true;
            pointerPos = pos;
            if (typeof ghostHand !== 'undefined') ghostHand.stop();
            
            // If it's the very first point, we just activate dragging
            if (currentPoint === 0) {
                playSynth(400);
                currentPoint = 1;
                draw();
            }
        }
    }

    function handlePointerMove(e) {
        if (!isDragging || !gameActive) return;
        e.preventDefault(); // Prevent scrolling
        pointerPos = getPointerPos(e);
        
        if (currentPoint <= maxPoints) {
            // Target is next point, or points[0] if we reached the last point
            const target = currentPoint === maxPoints ? points[0] : points[currentPoint];
            const dist = Math.hypot(pointerPos.x - target.x, pointerPos.y - target.y);
            
            if (dist < 80) { // Reached the next point or closing point
                playSynth(400 + currentPoint * 100);
                currentPoint++;
                
                if (currentPoint > maxPoints) {
                    isDragging = false;
                    finishGame();
                }
            }
        }
        draw();
    }

    function handlePointerUp() {
        if (isDragging) {
            isDragging = false;
            pointerPos = null;
            // If they didn't connect, they must restart dragging from the last connected point
            draw();
        }
    }
    
    function finishGame() {
        gameActive = false;
        draw();
        setTimeout(() => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.font = '150px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            const emojis = ['🦄','🦖','🚀','🐱','🐶','🐼','🐸','🚗'];
            const emoji = emojis[Math.floor(Math.random()*emojis.length)];
            ctx.fillText(emoji, canvas.width/2, canvas.height/2);
            
            if (typeof triggerCelebration === 'function') triggerCelebration(true);
            
            try {
                if (typeof window.recordGameStats === 'function') {
                    window.recordGameStats('connect-the-dots', Math.round((Date.now() - startTime)/1000), { completed: 1, level: currentLevel });
                } else if (typeof recordGameStats === 'function') {
                    recordGameStats('connect-the-dots', Math.round((Date.now() - startTime)/1000), { completed: 1, level: currentLevel });
                }
            } catch(e) {}
            
            currentLevel++;
            if (currentLevel > 14) currentLevel = 1;
            
            setTimeout(initGame, 3000);
        }, 500);
    }

    // Attach listeners
    canvas.addEventListener('mousedown', handlePointerDown);
    canvas.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    
    canvas.addEventListener('touchstart', handlePointerDown, {passive: false});
    canvas.addEventListener('touchmove', handlePointerMove, {passive: false});
    window.addEventListener('touchend', handlePointerUp);
    window.addEventListener('touchcancel', handlePointerUp);

    // Start game
    setTimeout(initGame, 100);
});
