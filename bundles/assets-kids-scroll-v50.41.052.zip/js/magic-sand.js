const canvas = document.getElementById('sand-canvas');
const ctx = canvas.getContext('2d', { alpha: false }); // Optimize for no transparency background

let width, height;
let particles = [];
let isDrawing = false;
let hue = 0;
let lastX = 0;
let lastY = 0;

class Particle {
    constructor(x, y, h) {
        this.x = x;
        this.y = y;
        this.size = Math.random() * 4 + 2;
        this.speedX = Math.random() * 6 - 3;
        this.speedY = Math.random() * 6 - 3;
        this.color = `hsl(${h}, 100%, 60%)`;
        this.life = 1.0;
        this.decay = Math.random() * 0.02 + 0.01;
    }
    
    update() {
        this.x += this.speedX;
        this.y += this.speedY;
        
        // Add a bit of gravity and drag
        this.speedY += 0.1;
        this.speedX *= 0.99;
        
        this.life -= this.decay;
    }
    
    draw() {
        ctx.fillStyle = this.color;
        ctx.globalAlpha = this.life;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
    }
}

function resizeCanvas() {
    width = canvas.clientWidth;
    height = canvas.clientHeight;
    canvas.width = width;
    canvas.height = height;
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, width, height);
}

function initGame() {
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    // Event listeners for drawing
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);
    
    canvas.addEventListener('touchstart', handleTouchStart, {passive: false});
    canvas.addEventListener('touchmove', handleTouchMove, {passive: false});
    canvas.addEventListener('touchend', stopDrawing);
    canvas.addEventListener('touchcancel', stopDrawing);
    

    // Ghost hand guide
    if (typeof showStartupGuide === 'function' && !window.hasSpokenIntro) {
        window.hasSpokenIntro = true;
        showStartupGuide("Draw with the magic sand!", {
            type: 'ghost-scrub',
            startX: '50%',
            startY: '50%'
        });
    }
    
    // Start loop
    requestAnimationFrame(animate);
}

function handleTouchStart(e) {
    e.preventDefault();
    const touch = e.touches[0];
    const rect = canvas.getBoundingClientRect();
    lastX = touch.clientX - rect.left;
    lastY = touch.clientY - rect.top;
    isDrawing = true;
    addParticles(lastX, lastY);
}

function handleTouchMove(e) {
    e.preventDefault();
    if (!isDrawing) return;
    
    for (let i=0; i<e.touches.length; i++) {
        const touch = e.touches[i];
        const rect = canvas.getBoundingClientRect();
        const x = touch.clientX - rect.left;
        const y = touch.clientY - rect.top;
        
        addParticles(x, y);
    }
}

function startDrawing(e) {
    isDrawing = true;
    lastX = e.offsetX;
    lastY = e.offsetY;
    addParticles(lastX, lastY);
}

function draw(e) {
    if (!isDrawing) return;
    addParticles(e.offsetX, e.offsetY);
}

function stopDrawing() {
    isDrawing = false;
    // Record game usage when they finish a stroke
    if (typeof saveToRecent === 'function') {
        saveToRecent('magic-sand');
    }
}

function addParticles(x, y) {
    // Determine how many particles based on distance from last point (if we wanted to interpolate)
    // For simplicity, just add a bunch
    for(let i=0; i<5; i++) {
        particles.push(new Particle(x, y, hue));
    }
    hue += 2;
    if (hue > 360) hue = 0;
    
    // Optional: add sound effect randomly or continuously? 
    // Toddlers love sound, but continuous might be annoying.
    // Let's do a tiny vibration if possible
    if (Math.random() > 0.8 && typeof vibrateScrub === 'function') {
        vibrateScrub();
    }
}

function animate() {
    // Draw semi-transparent black to create trailing effect
    ctx.globalCompositeOperation = 'source-over';
    ctx.globalAlpha = 0.2;
    ctx.fillStyle = '#111';
    ctx.fillRect(0, 0, width, height);
    
    // Draw particles
    ctx.globalCompositeOperation = 'lighter';
    
    for (let i = 0; i < particles.length; i++) {
        particles[i].update();
        particles[i].draw();
    }
    
    // Remove dead particles
    particles = particles.filter(p => p.life > 0);
    
    // Limit max particles for performance
    if (particles.length > 1000) {
        particles.splice(0, particles.length - 1000);
    }
    
    requestAnimationFrame(animate);
}

window.onload = initGame;
