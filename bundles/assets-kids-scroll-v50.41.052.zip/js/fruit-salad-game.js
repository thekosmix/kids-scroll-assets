/**
 * Make Fruit Salad Game
 * A Fruit Ninja style game for toddlers.
 */

class FruitSaladGame {
    constructor() {
        this.canvas = document.getElementById('game-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.fruits = [];
        this.slicedFruits = [];
        this.particles = [];
        this.score = 0;
        this.joyMeter = new JoyMeter('game-container', { top: '20px', color1: '#FF4500', color2: '#FF8C00' });
        this.isGameOver = false;
        this.lastTime = 0;
        this.spawnTimer = 0;
        this.spawnInterval = 1800; // Slower start for toddlers
        this.streak = 0;
        this.isFirstLoad = true;
        this.startTime = Date.now();
        
        this.slashPoints = [];
        this.isSlashing = false;
        
        this.fruitEmojis = ['🍎', '🍌', '🍉', '🍇', '🍓', '🍍', '🥝', '🍑', '🍐', '🍊', '🥭', '🍒', '🍋', '🥑', '🥥', '🫐', '🍈', '🍏', '🍅', '🌽'];
        this.fruitColors = {
            '🍎': '#ff0000', '🍌': '#ffff00', '🍉': '#ff3333', '🍇': '#800080', '🍓': '#ff0000',
            '🍍': '#ffd700', '🥝': '#32cd32', '🍑': '#ffdab9', '🍐': '#adff2f', '🍊': '#ffa500',
            '🥭': '#ffcc00', '🍒': '#ff0000', '🍋': '#ffff00', '🥑': '#556b2f', '🥥': '#f5f5f5',
            '🫐': '#0000ff', '🍈': '#90ee90', '🍏': '#32cd32', '🍅': '#ff6347', '🌽': '#ffff00'
        };
        this.fruitNames = {
            '🍎': 'Apple', '🍌': 'Banana', '🍉': 'Watermelon', '🍇': 'Grapes', '🍓': 'Strawberry',
            '🍍': 'Pineapple', '🥝': 'Kiwi', '🍑': 'Peach', '🍐': 'Pear', '🍊': 'Orange',
            '🥭': 'Mango', '🍒': 'Cherries', '🍋': 'Lemon', '🥑': 'Avocado', '🥥': 'Coconut',
            '🫐': 'Blueberries', '🍈': 'Melon', '🍏': 'Green Apple', '🍅': 'Tomato', '🌽': 'Corn'
        };
        
        this.init();
    }

    init() {
        this.resize();
        window.addEventListener('resize', () => this.resize());
        
        this.canvas.addEventListener('mousedown', (e) => this.startSlash(e));
        this.canvas.addEventListener('mousemove', (e) => this.continueSlash(e));
        this.canvas.addEventListener('mouseup', () => this.endSlash());
        
        this.canvas.addEventListener('touchstart', (e) => this.startSlash(e), { passive: false });
        this.canvas.addEventListener('touchmove', (e) => this.continueSlash(e), { passive: false });
        this.canvas.addEventListener('touchend', () => this.endSlash());
        this.canvas.addEventListener('touchcancel', () => this.endSlash());

        requestAnimationFrame((time) => this.update(time));

        // Startup guide
        if (this.isFirstLoad && typeof showStartupGuide === 'function') {
            this.isFirstLoad = false;
            showStartupGuide("Cut the fruits to make a yummy fruit salad!", {
                type: 'ghost-swipe',
                startX: '10vw',
                startY: '80vh',
                endX: '90vw',
                endY: '20vh'
            });
        }
    }

    resize() {
        const header = document.querySelector('header');
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight - (header ? header.offsetHeight : 0);
    }

    startSlash(e) {
        if (typeof ghostHand !== 'undefined') ghostHand.stop();
        if (e.cancelable) e.preventDefault();
        this.isSlashing = true;
        this.slashPoints = [this.getPos(e)];
    }

    continueSlash(e) {
        if (!this.isSlashing) return;
        if (e.cancelable) e.preventDefault();
        const pos = this.getPos(e);
        this.slashPoints.push(pos);
        if (this.slashPoints.length > 10) this.slashPoints.shift();
        this.checkCollisions(this.slashPoints[this.slashPoints.length - 2], pos);
    }

    endSlash() {
        this.isSlashing = false;
        this.slashPoints = [];
    }

    getPos(e) {
        const rect = this.canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return { x: clientX - rect.left, y: clientY - rect.top };
    }

    checkCollisions(p1, p2) {
        if (!p1 || !p2) return;
        for (let i = this.fruits.length - 1; i >= 0; i--) {
            const fruit = this.fruits[i];
            const dist = this.distToSegment(fruit, p1, p2);
            if (dist < fruit.radius * 1.5) { // Forgiving hitbox
                this.sliceFruit(fruit, i);
            }
        }
    }

    distToSegment(p, v, w) {
        const l2 = Math.pow(v.x - w.x, 2) + Math.pow(v.y - w.y, 2);
        if (l2 === 0) return Math.sqrt(Math.pow(p.x - v.x, 2) + Math.pow(p.y - v.y, 2));
        let t = ((p.x - v.x) * (w.x - v.x) + (p.y - v.y) * (w.y - v.y)) / l2;
        t = Math.max(0, Math.min(1, t));
        return Math.sqrt(Math.pow(p.x - (v.x + t * (w.x - v.x)), 2) + Math.pow(p.y - (v.y + t * (w.y - v.y)), 2));
    }

    sliceFruit(fruit, index) {
        this.fruits.splice(index, 1);
        this.score++;
        this.streak++;
        this.joyMeter.setProgress((this.score / 15) * 100);
        if (typeof vibrateSuccess === 'function') vibrateSuccess();
        
        // Juice droplets
        const color = this.fruitColors[fruit.emoji] || '#ffffff';
        for(let i=0; i<8; i++) {
            this.particles.push({
                x: fruit.x, y: fruit.y,
                vx: (Math.random()-0.5)*10, vy: (Math.random()-0.5)*10,
                radius: Math.random()*4 + 2, color: color, opacity: 1, gravity: 0.3
            });
        }

        this.slicedFruits.push({
            x: fruit.x, y: fruit.y, vx: fruit.vx - 3, vy: fruit.vy,
            emoji: fruit.emoji, angle: fruit.angle, rotation: -0.15,
            gravity: 0.25, opacity: 1, side: 'left'
        });
        this.slicedFruits.push({
            x: fruit.x, y: fruit.y, vx: fruit.vx + 3, vy: fruit.vy,
            emoji: fruit.emoji, angle: fruit.angle, rotation: 0.15,
            gravity: 0.25, opacity: 1, side: 'right'
        });

        if (window.soundGenerator) window.soundGenerator.playPopSound();
        if (typeof speakText === 'function') speakText(this.fruitNames[fruit.emoji]);
        
        // Adaptive speed
        this.spawnInterval = Math.max(500, this.spawnInterval - 30);

        if (this.score >= 15 && !this.isGameOver) this.win();
    }

    spawnFruit() {
        const radius = 45;
        const x = Math.random() * (this.canvas.width - radius * 2) + radius;
        const y = this.canvas.height + radius;
        const vx = (Math.random() - 0.5) * 5;
        const vy = -(Math.random() * 6 + 12);
        const emoji = this.fruitEmojis[Math.floor(Math.random() * this.fruitEmojis.length)];
        this.fruits.push({ x, y, vx, vy, radius, emoji, angle: 0, rotation: (Math.random()-0.5)*0.15, gravity: 0.18 });
    }

    win() {
        this.isGameOver = true;
        const duration = (Date.now() - this.startTime) / 1000;
        if (typeof recordGameStats === 'function') {
            recordGameStats('make_fruit_salad', duration, { avgTime: duration / 15 });
        }

        if (typeof triggerCelebration === 'function') triggerCelebration();

        const bowl = document.getElementById('salad-bowl');
        bowl.style.display = 'block';
        bowl.style.bottom = '-300px';
        let pos = -300;
        const anim = setInterval(() => {
            if (pos >= 100) {
                clearInterval(anim);
                setTimeout(() => this.restart(), 4000);
            } else {
                pos += 6;
                bowl.style.bottom = pos + 'px';
            }
        }, 20);
    }

    restart() {
        const bowl = document.getElementById('salad-bowl');
        if (bowl) bowl.style.display = 'none';
        this.score = 0;
        this.joyMeter.reset();
        this.streak = 0;
        this.fruits = [];
        this.slicedFruits = [];
        this.particles = [];
        this.isGameOver = false;
        this.spawnInterval = 1800;
        this.startTime = Date.now();
    }

    update(time) {
        const deltaTime = time - this.lastTime;
        this.lastTime = time;
        if (!this.isGameOver) {
            this.spawnTimer += deltaTime;
            if (this.spawnTimer > this.spawnInterval) {
                this.spawnFruit();
                this.spawnTimer = 0;
            }
        }
        this.draw();
        requestAnimationFrame((t) => this.update(t));
    }

    draw() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        // Slash
        if (this.slashPoints.length > 1) {
            this.ctx.beginPath();
            this.ctx.moveTo(this.slashPoints[0].x, this.slashPoints[0].y);
            for (let i = 1; i < this.slashPoints.length; i++) this.ctx.lineTo(this.slashPoints[i].x, this.slashPoints[i].y);
            this.ctx.strokeStyle = '#fff';
            this.ctx.lineWidth = 8;
            this.ctx.lineCap = 'round';
            this.ctx.stroke();
        }

        // Particles (Juice)
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const p = this.particles[i];
            p.x += p.vx; p.y += p.vy; p.vy += p.gravity; p.opacity -= 0.02;
            this.ctx.globalAlpha = p.opacity;
            this.ctx.fillStyle = p.color;
            this.ctx.beginPath(); this.ctx.arc(p.x, p.y, p.radius, 0, Math.PI*2); this.ctx.fill();
            if (p.opacity <= 0) this.particles.splice(i, 1);
        }
        this.ctx.globalAlpha = 1;

        // Fruits
        for (let i = this.fruits.length - 1; i >= 0; i--) {
            const f = this.fruits[i];
            f.x += f.vx; f.y += f.vy; f.vy += f.gravity; f.angle += f.rotation;
            this.ctx.save();
            this.ctx.translate(f.x, f.y);
            this.ctx.rotate(f.angle);
            this.ctx.font = `${f.radius * 2}px Arial`;
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.fillText(f.emoji, 0, 0);
            this.ctx.restore();
            if (f.y > this.canvas.height + 100) {
                this.fruits.splice(i, 1);
                this.spawnInterval = Math.min(2000, this.spawnInterval + 50); // Slow down if missed
            }
        }

        // Sliced halves
        for (let i = this.slicedFruits.length - 1; i >= 0; i--) {
            const s = this.slicedFruits[i];
            s.x += s.vx; s.y += s.vy; s.vy += s.gravity; s.angle += s.rotation; s.opacity -= 0.015;
            this.ctx.save();
            this.ctx.translate(s.x, s.y);
            this.ctx.rotate(s.angle);
            this.ctx.font = `80px Arial`;
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            this.ctx.globalAlpha = Math.max(0, s.opacity);
            this.ctx.beginPath();
            if (s.side === 'left') this.ctx.rect(-100, -100, 100, 200);
            else this.ctx.rect(0, -100, 100, 200);
            this.ctx.clip();
            this.ctx.fillText(s.emoji, 0, 0);
            this.ctx.restore();
            if (s.y > this.canvas.height + 100 || s.opacity <= 0) this.slicedFruits.splice(i, 1);
        }
        this.ctx.globalAlpha = 1;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if (typeof SoundGenerator !== 'undefined' && !window.soundGenerator) window.soundGenerator = new SoundGenerator();
    new FruitSaladGame();
});
