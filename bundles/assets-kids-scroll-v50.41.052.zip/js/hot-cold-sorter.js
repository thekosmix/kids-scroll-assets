document.addEventListener('DOMContentLoaded', () => {
    const dock = document.getElementById('dock');
    const zoneHot = document.getElementById('zone-hot');
    const zoneCold = document.getElementById('zone-cold');
    const zones = [zoneHot, zoneCold];
    
    let currentItem = null;
    let touchClone = null;
    let isDragging = false;
    let startX, startY, initialX, initialY;
    let hasInteracted = false;
    
    // Stats tracking
    let itemsSorted = 0;
    let startTime = Date.now();
    let itemStartTime = Date.now();

    const items = [
        { emoji: '☕', type: 'hot', name: 'Hot Coffee' },
        { emoji: '🥞', type: 'hot', name: 'Hot Pancakes' },
        { emoji: '🌶️', type: 'hot', name: 'Spicy Pepper' },
        { emoji: '☀️', type: 'hot', name: 'Sun' },
        { emoji: '🔥', type: 'hot', name: 'Fire' },
        { emoji: '🥣', type: 'hot', name: 'Hot Soup' },
        { emoji: '🍵', type: 'hot', name: 'Hot Tea' },
        { emoji: '🌋', type: 'hot', name: 'Volcano' },
        { emoji: '🕯️', type: 'hot', name: 'Candle' },
        { emoji: '🍕', type: 'hot', name: 'Hot Pizza' },
        { emoji: '🍟', type: 'hot', name: 'Hot Fries' },
        { emoji: '🍞', type: 'hot', name: 'Toast' },
        { emoji: '🍦', type: 'cold', name: 'Ice Cream' },
        { emoji: '🧊', type: 'cold', name: 'Ice Cube' },
        { emoji: '☃️', type: 'cold', name: 'Snowman' },
        { emoji: '🐧', type: 'cold', name: 'Penguin' },
        { emoji: '❄️', type: 'cold', name: 'Snowflake' },
        { emoji: '🍧', type: 'cold', name: 'Shaved Ice' },
        { emoji: '🍨', type: 'cold', name: 'Ice Cream Bowl' },
        { emoji: '🐻‍❄️', type: 'cold', name: 'Polar Bear' },
        { emoji: '🥤', type: 'cold', name: 'Iced Drink' },
        { emoji: '🍉', type: 'cold', name: 'Cold Watermelon' },
        { emoji: '🦭', type: 'cold', name: 'Seal' },
        { emoji: '🥦', type: 'cold', name: 'Broccoli' }
    ];

    let remainingItems = [];

    function initGame() {
        if (window.saveToRecent) {
            window.saveToRecent('hot-cold-sorter');
        }
        resetItems();
        spawnItems();

        setTimeout(() => {
            if (!hasInteracted && typeof showStartupGuide === 'function') {
                const firstEl = document.querySelector('.draggable');
                if (firstEl) {
                    const rect = firstEl.getBoundingClientRect();
                    const targetZone = firstEl.dataset.type === 'hot' ? zoneHot : zoneCold;
                    const targetRect = targetZone.getBoundingClientRect();
                    
                    showStartupGuide("Sort hot and cold items", {
                        type: 'ghost-swipe',
                        startX: rect.left + rect.width/2 + 'px',
                        startY: rect.top + rect.height/2 + 'px',
                        endX: targetRect.left + targetRect.width/2 + 'px',
                        endY: targetRect.top + targetRect.height/2 + 'px'
                    });
                }
            }
        }, 500);
    }

    function resetItems() {
        remainingItems = [...items].sort(() => Math.random() - 0.5);
        itemsSorted = 0;
        startTime = Date.now();
    }

    function spawnItems() {
        dock.innerHTML = '';
        const allShuffled = [...items].sort(() => Math.random() - 0.5);
        const roundItems = allShuffled.slice(0, 4); // Pick 4 items
        
        roundItems.forEach((itemData) => {
            const el = document.createElement('div');
            el.className = 'draggable';
            el.textContent = itemData.emoji;
            el.dataset.type = itemData.type;
            el.dataset.name = itemData.name;
            
            el.style.position = 'relative'; // Since we are using flex in dock
            
            el.addEventListener('mousedown', dragStart);
            el.addEventListener('touchstart', dragStart, { passive: false });
            dock.appendChild(el);
        });

        itemStartTime = Date.now();
        
        if (!window.hasSpokenIntro) {
            window.hasSpokenIntro = true;
        }
    }

    function dragStart(e) {
        if (e.type === 'touchstart') e.preventDefault();
        
        if (!hasInteracted) {
            hasInteracted = true;
            if (typeof ghostHand !== 'undefined') ghostHand.stop();
        }

        isDragging = true;
        currentItem = e.target;
        
        const rect = currentItem.getBoundingClientRect();
        initialX = rect.left;
        initialY = rect.top;
        
        if (e.type === 'touchstart') {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        } else {
            startX = e.clientX;
            startY = e.clientY;
        }
        
        currentItem.style.opacity = '0'; // Hide original
        
        touchClone = currentItem.cloneNode(true);
        touchClone.classList.add('dragging');
        touchClone.style.opacity = '0.9';
        touchClone.style.position = 'fixed';
        touchClone.style.zIndex = '1000';
        touchClone.style.pointerEvents = 'none';
        touchClone.style.margin = '0';
        touchClone.style.left = initialX + 'px';
        touchClone.style.top = initialY + 'px';
        touchClone.style.transform = 'scale(1.2)';
        
        document.body.appendChild(touchClone);
        
        if (window.speakText) window.speakText(currentItem.dataset.name);
        
        document.addEventListener('mousemove', dragMove);
        document.addEventListener('touchmove', dragMove, { passive: false });
        document.addEventListener('mouseup', dragEnd);
        document.addEventListener('touchend', dragEnd);
        document.addEventListener('touchcancel', dragEnd);
    }

    function dragMove(e) {
        if (!isDragging || !touchClone) return;
        e.preventDefault();
        
        let clientX, clientY;
        if (e.type === 'touchmove') {
            clientX = e.touches[0].clientX;
            clientY = e.touches[0].clientY;
        } else {
            clientX = e.clientX;
            clientY = e.clientY;
        }
        
        const dx = clientX - startX;
        const dy = clientY - startY;
        
        touchClone.style.left = `${initialX + dx}px`;
        touchClone.style.top = `${initialY + dy}px`;
        
        checkIntersections(clientX, clientY);
    }

    function checkIntersections(x, y) {
        zones.forEach(zone => zone.classList.remove('highlight'));
        const target = getZoneAtPosition(x, y);
        if (target) target.classList.add('highlight');
    }

    function getZoneAtPosition(x, y) {
        for (let i = 0; i < zones.length; i++) {
            const rect = zones[i].getBoundingClientRect();
            if (x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom) {
                return zones[i];
            }
        }
        return null;
    }

    function dragEnd(e) {
        if (!isDragging) return;
        isDragging = false;
        
        document.removeEventListener('mousemove', dragMove);
        document.removeEventListener('touchmove', dragMove);
        document.removeEventListener('mouseup', dragEnd);
        document.removeEventListener('touchend', dragEnd);
        document.removeEventListener('touchcancel', dragEnd);
        
        if (touchClone) touchClone.style.transform = 'scale(1)';
        
        let clientX, clientY;
        if (e.type === 'touchend') {
            clientX = e.changedTouches[0].clientX;
            clientY = e.changedTouches[0].clientY;
        } else {
            clientX = e.clientX;
            clientY = e.clientY;
        }
        
        zones.forEach(zone => zone.classList.remove('highlight'));
        
        const targetZone = getZoneAtPosition(clientX, clientY);
        const itemType = currentItem.dataset.type;
        
        // Add magnetic pull check via center point if not directly dropped inside
        let isCorrect = false;
        let actualZone = targetZone;
        
        if (!actualZone) {
            const itemRect = (touchClone || currentItem).getBoundingClientRect();
            const itemCenter = { x: itemRect.left + itemRect.width/2, y: itemRect.top + itemRect.height/2 };
            
            // Magnetic pull ~80px
            const hotRect = zoneHot.getBoundingClientRect();
            const coldRect = zoneCold.getBoundingClientRect();
            
            if (Math.hypot(itemCenter.x - (hotRect.left + hotRect.width/2), itemCenter.y - (hotRect.top + hotRect.height/2)) < 150) {
                actualZone = zoneHot;
            } else if (Math.hypot(itemCenter.x - (coldRect.left + coldRect.width/2), itemCenter.y - (coldRect.top + coldRect.height/2)) < 150) {
                actualZone = zoneCold;
            }
        }
        
        if (actualZone && actualZone.dataset.type === itemType) {
            handleCorrectDrop(actualZone);
        } else {
            if (actualZone && window.speakText) {
                window.speakText("Oops! Try the other side.");
            }
            returnToStart();
        }
    }

    function returnToStart() {
        if (touchClone) {
            touchClone.style.transition = 'all 0.3s ease';
            touchClone.style.left = initialX + 'px';
            touchClone.style.top = initialY + 'px';
            
            setTimeout(() => {
                if (touchClone) {
                    touchClone.remove();
                    touchClone = null;
                }
                if (currentItem) {
                    currentItem.style.opacity = '1';
                }
            }, 300);
        } else if (currentItem) {
            currentItem.style.opacity = '1';
        }
    }

    function handleCorrectDrop(zone) {
        const dropped = document.createElement('div');
        dropped.className = 'dropped-item';
        dropped.textContent = currentItem.textContent;
        
        const itemsContainer = zone.querySelector('.zone-items');
        itemsContainer.appendChild(dropped);
        
        if (window.speakText) window.speakText("Good!");
        
        if (touchClone) {
            touchClone.remove();
            touchClone = null;
        }
        if (currentItem) {
            currentItem.remove();
            currentItem = null;
        }
        itemsSorted++;
        
        if (itemsSorted >= 4) {
            if (window.triggerCelebration) window.triggerCelebration(true);
            if (window.recordGameStats) {
                const totalTime = (Date.now() - startTime) / 1000;
                window.recordGameStats('hot-cold-sorter', totalTime, { avgTimePerItem: totalTime / 4 });
            }
            setTimeout(() => {
                document.querySelectorAll('.dropped-item').forEach(el => el.remove());
                resetItems();
                spawnItems();
            }, 3000);
        }
    }

    initGame();
});
