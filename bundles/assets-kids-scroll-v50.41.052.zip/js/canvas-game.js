// Canvas drawing functionality
function initCanvasGame() {
  // Canvas setup
  const canvas = document.getElementById('drawingCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  // Set canvas size to match container
  function resizeCanvas() {
    const container = canvas.parentElement;
    canvas.width = container.clientWidth;
    canvas.height = container.clientHeight;

    // Set drawing properties
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 5;
  }

  // Initialize canvas size
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  // VIBGYOR color spectrum (Violet to Red)
  const VIBGYOR_COLORS = [
    '#9400D3', // Violet
    '#4B0082', // Indigo
    '#0000FF', // Blue
    '#00FF00', // Green
    '#FFFF00', // Yellow
    '#FF7F00', // Orange
    '#FF0000'  // Red
  ];

  // Variables for drawing
  let isDrawing = false;
  let lastX = 0;
  let lastY = 0;
  let hue = 0; // Will cycle through colors
  let totalDistance = 0; // Total distance traveled for color calculation
  let isFirstLoad = true;

  // Touch/mouse events
  canvas.addEventListener('mousedown', startDrawing);
  canvas.addEventListener('mousemove', draw);
  canvas.addEventListener('mouseup', stopDrawing);
  canvas.addEventListener('mouseout', stopDrawing);

  // Touch events for mobile
  canvas.addEventListener('touchstart', handleTouchStart, { passive: false });
  canvas.addEventListener('touchmove', handleTouchMove, { passive: false });
  canvas.addEventListener('touchend', stopDrawing, { passive: false });
  canvas.addEventListener('touchcancel', stopDrawing, { passive: false });

  // Show guide after a short delay
  if (isFirstLoad && typeof showStartupGuide === 'function') {
    isFirstLoad = false;
    setTimeout(() => {
        const rect = canvas.getBoundingClientRect();
        showStartupGuide("Draw with your finger", {
          type: 'ghost-swipe',
          startX: (rect.left + rect.width * 0.2) + 'px',
          startY: (rect.top + rect.height * 0.3) + 'px',
          endX: (rect.left + rect.width * 0.8) + 'px',
          endY: (rect.top + rect.height * 0.7) + 'px'
        });
    }, 200);
  }

  // Download button
  const downloadBtn = document.getElementById('downloadCanvas');
  downloadBtn.addEventListener('click', () => {
    // Stop guide if active
    if (typeof ghostHand !== 'undefined') ghostHand.stop();
    
    // Track download event
        // Create a temporary link element
    const link = document.createElement('a');

    // Convert canvas to data URL
    const imageData = canvas.toDataURL('image/png');

    // Set the href to the image data
    link.href = imageData;

    // Set the download filename with timestamp
    const now = new Date();
    const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}-${String(now.getMinutes()).padStart(2, '0')}-${String(now.getSeconds()).padStart(2, '0')}`;
    link.download = `kids-drawing-${timestamp}.png`;

    // Trigger the download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Clear the canvas after download
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  });

  // Refresh button
  const refreshBtn = document.getElementById('restartBtn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      if (typeof ghostHand !== 'undefined') ghostHand.stop();
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Play tap sound
      if (typeof soundGenerator !== 'undefined' && typeof soundGenerator.playTapSound === 'function') {
        soundGenerator.playTapSound();
      }
    });
  }

  // Drawing functions
  function startDrawing(e) {
    isDrawing = true;
    [lastX, lastY] = getCoordinates(e);
    totalDistance = 0; // Reset distance when starting a new stroke
  }

  function draw(e) {
    if (!isDrawing) return;

    const [currentX, currentY] = getCoordinates(e);
    const dx = currentX - lastX;
    const dy = currentY - lastY;
    const distance = Math.sqrt(dx * dx + dy * dy);
    totalDistance += distance;

    // Calculate hue based on total distance traveled (for VIBGYOR gradient)
    // Cycle through the full color spectrum every 500 pixels
    hue = (totalDistance / 500) * 360;

    // Set the stroke style with the calculated hue
    ctx.strokeStyle = `hsl(${hue % 360}, 100%, 50%)`;

    // Draw line
    ctx.beginPath();
    ctx.moveTo(lastX, lastY);
    ctx.lineTo(currentX, currentY);
    ctx.stroke();

    // Increment draw count
    if (typeof window.drawCount !== 'undefined') {
      window.drawCount++;
    } else {
      window.drawCount = 1;
    }

    [lastX, lastY] = [currentX, currentY];
  }

  function stopDrawing() {
    isDrawing = false;
    
    // Track drawing activity when user stops drawing
    if (window.drawCount > 0 && typeof gtag !== 'undefined') {
      
      
      // Reset draw count after tracking
      window.drawCount = 0;
    }
  }

  // Touch event handlers
  function handleTouchStart(e) {
    e.preventDefault();
    const touch = e.touches[0] || e.changedTouches[0];
    const mouseEvent = new MouseEvent('mousedown', {
      clientX: touch.clientX,
      clientY: touch.clientY
    });
    canvas.dispatchEvent(mouseEvent);
  }

  function handleTouchMove(e) {
    e.preventDefault();
    const touch = e.touches[0] || e.changedTouches[0];
    const mouseEvent = new MouseEvent('mousemove', {
      clientX: touch.clientX,
      clientY: touch.clientY
    });
    canvas.dispatchEvent(mouseEvent);
  }

  // Helper function to get coordinates from mouse or touch events
  function getCoordinates(e) {
    let clientX, clientY;

    if (e.type.includes('touch')) {
      const touch = e.touches[0] || e.changedTouches[0];
      clientX = touch.clientX;
      clientY = touch.clientY;
    } else {
      clientX = e.clientX;
      clientY = e.clientY;
    }

    // Calculate position relative to canvas
    const rect = canvas.getBoundingClientRect();
    return [
      clientX - rect.left,
      clientY - rect.top
    ];
  }

}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initCanvasGame);
} else {
  initCanvasGame();
}