// Two-word combinations: adjective-noun or noun-noun
const adjectives = [
  'big', 'happy', 'ripe', 'bright', 'fast', 'slow', 'soft', 'hard',
  'small', 'sad', 'green', 'red', 'blue', 'tall', 'short', 'round',
  'square', 'fluffy', 'smooth', 'rough', 'warm', 'cold', 'light', 'heavy',
  'loud', 'quiet', 'strong', 'weak', 'young', 'old', 'clean', 'dirty',
  'full', 'empty', 'hot', 'cool', 'sweet', 'sour', 'bitter', 'salty',
  'bright', 'dark', 'clear', 'cloudy', 'windy', 'calm', 'busy', 'free',
  'rich', 'poor', 'thick', 'thin', 'wide', 'narrow', 'deep', 'shallow',
  'smooth', 'bumpy', 'sharp', 'dull', 'clean', 'messy', 'tidy', 'neat',
  'wild', 'tame', 'fresh', 'stale', 'dry', 'wet', 'loose', 'tight',
  'lovely', 'ugly', 'pretty', 'plain', 'fancy', 'simple', 'complex', 'easy',
  'difficult', 'fun', 'boring', 'exciting', 'boring', 'amazing', 'terrible', 'fantastic'
];
const nouns = [
  'car', 'cat', 'mango', 'truck', 'fire', 'tree', 'house', 'dog',
  'bird', 'fish', 'book', 'chair', 'table', 'phone', 'computer', 'lamp',
  'window', 'door', 'wall', 'floor', 'ceiling', 'roof', 'garden', 'flower',
  'grass', 'river', 'mountain', 'ocean', 'sky', 'star', 'moon', 'sun',
  'cloud', 'rain', 'snow', 'wind', 'storm', 'bridge', 'road', 'path',
  'city', 'village', 'town', 'country', 'planet', 'space', 'rocket', 'ship',
  'plane', 'train', 'bicycle', 'wheel', 'engine', 'key', 'lock', 'bag',
  'hat', 'coat', 'shirt', 'pants', 'shoes', 'socks', 'gloves', 'scarf',
  'apple', 'banana', 'orange', 'grape', 'lemon', 'lime', 'cherry', 'berry',
  'bread', 'milk', 'water', 'juice', 'coffee', 'tea', 'sugar', 'salt',
  'fork', 'spoon', 'knife', 'plate', 'cup', 'bowl', 'pot', 'pan'
];

/**
 * Generates a random seed string combining an adjective and a noun
 * @returns {string} Random seed in the format "adjective-noun"
 */
function generateSeed() {
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  return `${adj}-${noun}`;
}

/**
 * Debounces a function to prevent it from being called too frequently
 * @param {Function} func The function to debounce
 * @param {number} wait Time to wait in milliseconds
 * @returns {Function} Debounced function
 */
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}