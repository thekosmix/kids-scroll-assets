document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('game-container');
    const basket = document.getElementById('basket');
    const joyMeter = new JoyMeter('game-container', { top: '20px' });
    
    let treats = [];
    let score = 0;
    const maxScore = 10;
    let gameLoopId;
    let spawnId;
    let isPlaying = false;
    let guide = null;
    let startTime = Date.now();
    
    const treatEmojis = [
        { emoji: '🍎', name: 'Apple' },
        { emoji: '🍌', name: 'Banana' },
        { emoji: '🍇', name: 'Grapes' },
        { emoji: '🍓', name: 'Strawberry' },
        { emoji: '🍉', name: 'Watermelon' },
        { emoji: '🍒', name: 'Cherries' },
        { emoji: '🍭', name: 'Lollipop' },
        { emoji: '🍬', name: 'Candy' },
        { emoji: '🍪', name: 'Cookie' }
    ];

    function initGame() {
        score = 0;
        updateJoyMeter();
        treats.forEach(t => t.el.remove());
        treats = [];
        isPlaying = true;
        startTime = Date.now();
        basket.style.left = '50%';
        
        if (typeof speakText === 'function') {
            speakText("Catch the treats in the basket!");
        }

        if (typeof GhostHand !== 'undefined') {
            if (!guide) guide = new GhostHand();
            setTimeout(() => {
                const basketRect = basket.getBoundingClientRect();
                guide.show('ghost-swipe', 
                    `${basketRect.left + basketRect.width/2}px`, 
                    `${basketRect.top + basketRect.height/2}px`,
                    `${container.clientWidth * 0.8}px`,
                    `${basketRect.top + basketRect.height/2}px`
                );
            }, 100);
        }

        spawnId = setInterval(spawnTreat, 1500);
        gameLoopId = requestAnimationFrame(update);
    }

    function spawnTreat() {
        if (!isPlaying) return;
        const el = document.createElement('div');
        el.className = 'treat';
        const treatData = treatEmojis[Math.floor(Math.random() * treatEmojis.length)];
        el.textContent = treatData.emoji;
        const x = Math.random() * (container.clientWidth - 50);
        el.style.left = `${x}px`;
        el.style.top = `-50px`;
        container.appendChild(el);
        
        treats.push({ el, y: -50, x, speed: 2 + Math.random() * 2, name: treatData.name });
    }

    function update() {
        if (!isPlaying) return;
        
        const basketRect = basket.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();

        for (let i = treats.length - 1; i >= 0; i--) {
            const t = treats[i];
            t.y += t.speed;
            t.el.style.top = `${t.y}px`;
            
            const treatRect = t.el.getBoundingClientRect();
            
            // Check collision with basket
            if (isIntersecting(treatRect, basketRect)) {
                catchTreat(i);
            } 
            // Check out of bounds
            else if (t.y > containerRect.height) {
                t.el.remove();
                treats.splice(i, 1);
            }
        }
        
        gameLoopId = requestAnimationFrame(update);
    }

    function catchTreat(index) {
        if (guide) guide.stop();
        playSynth(800 + score * 50);
        
        const t = treats[index];
        if (typeof speakText === 'function') {
            speakText(t.name);
        }
        t.el.style.transition = 'transform 0.2s, opacity 0.2s';
        t.el.style.transform = 'scale(0)';
        t.el.style.opacity = '0';
        
        setTimeout(() => t.el.remove(), 200);
        treats.splice(index, 1);
        
        score++;
        updateJoyMeter();
        
        // animate basket
        basket.style.transform = 'translateX(-50%) scale(1.2)';
        setTimeout(() => basket.style.transform = 'translateX(-50%) scale(1)', 100);

        if (score >= maxScore) {
            endGame();
        }
    }
    
    function updateJoyMeter() {
        const percentage = Math.min(100, (score / maxScore) * 100);
        joyMeter.setProgress(percentage);
    }

    function endGame() {
        isPlaying = false;
        clearInterval(spawnId);
        cancelAnimationFrame(gameLoopId);
        
        if (typeof triggerCelebration === 'function') triggerCelebration(true);
        if (typeof recordGameStats === 'function') {
            recordGameStats('catch-treats', Math.round((Date.now() - startTime)/1000), { caught: score });
        }
        
        setTimeout(initGame, 4000);
    }

    function isIntersecting(r1, r2) {
        // give basket a smaller hit box for fairness
        const hitZone = {
            left: r2.left + 10,
            right: r2.right - 10,
            top: r2.top + 10,
            bottom: r2.top + 30 // only top edge
        };
        return !(hitZone.left > r1.right || hitZone.right < r1.left || hitZone.top > r1.bottom || hitZone.bottom < r1.top);
    }

    // Basket movement via touch/mouse
    let isDragging = false;

    container.addEventListener('pointerdown', (e) => {
        isDragging = true;
        moveBasket(e);
        if (guide) guide.stop();
    });

    container.addEventListener('pointermove', (e) => {
        if (isDragging) moveBasket(e);
    });

    container.addEventListener('pointerup', () => isDragging = false);
    container.addEventListener('pointerleave', () => isDragging = false);

    function moveBasket(e) {
        const rect = container.getBoundingClientRect();
        let x = e.clientX - rect.left;
        
        // Clamp to screen bounds
        const halfWidth = basket.offsetWidth / 2;
        if (x < halfWidth) x = halfWidth;
        if (x > rect.width - halfWidth) x = rect.width - halfWidth;
        
        basket.style.left = `${x}px`;
    }

    function playSynth(freq) {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            const audioCtx = new AudioContext();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.frequency.value = freq;
            osc.type = 'sine';
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.1);
        } catch(e){}
    }

    initGame();
});
