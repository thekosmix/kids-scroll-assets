const bubble = document.getElementById('bubble');
const container = document.getElementById('game-container');

let isBreathing = false;
let cycleCount = 0;
const MAX_CYCLES = 5;
let breatheTimer;

function initGame() {
    setInterval(createMagicParticle, 2000);
    
    // Auto-start instructions and loop
    setTimeout(() => {
        if (typeof speakText === 'function') {
            speakText("Breathe in to make the bubble grow, breathe out to make it small.");
        }
        
        setTimeout(startBreathingSequence, 4000);
    }, 1000);
}

function startBreathingSequence() {
    isBreathing = true;
    cycleCount = 0;
    breatheIn();
}

function breatheIn() {
    if (cycleCount >= MAX_CYCLES) {
        finishBreathing();
        return;
    }
    
    // Play sound every cycle except the very first one where we play the long instruction
    if (cycleCount > 0 || !window.firstBreathDone) {
        window.firstBreathDone = true;
        if (typeof speakText === 'function') speakText("Breathe in...");
    }
    
    bubble.style.transform = "scale(2.5)";
    breatheTimer = setTimeout(breatheOut, 4000);
}

function breatheOut() {
    if (typeof speakText === 'function') speakText("Breathe out...");
    
    bubble.style.transform = "scale(1)";
    cycleCount++;
    
    breatheTimer = setTimeout(breatheIn, 4000);
}

function finishBreathing() {
    isBreathing = false;
    
    if (typeof speakText === 'function') speakText("Great job! You are so calm.");
    if (typeof triggerCelebration === 'function') triggerCelebration(false);
    if (typeof saveToRecent === 'function') saveToRecent('breathing-bubble');
    
    setTimeout(startBreathingSequence, 4000);
}

function createMagicParticle() {
    const p = document.createElement('div');
    p.className = 'magic-particle';
    
    const x = Math.random() * window.innerWidth;
    const y = window.innerHeight + 10;
    
    p.style.left = x + 'px';
    p.style.top = y + 'px';
    
    container.appendChild(p);
    
    const duration = 5000 + Math.random() * 5000;
    const targetY = -50;
    const targetX = x + (Math.random() - 0.5) * 100;
    
    p.animate([
        { transform: `translate(0, 0)`, opacity: 0 },
        { opacity: 0.8, offset: 0.2 },
        { transform: `translate(${targetX - x}px, ${targetY - y}px)`, opacity: 0 }
    ], {
        duration: duration,
        easing: 'linear',
        fill: 'forwards'
    });
    
    setTimeout(() => {
        if (p.parentNode) p.remove();
    }, duration);
}

window.onload = initGame;
