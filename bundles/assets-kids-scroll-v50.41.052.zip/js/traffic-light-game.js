/**
 * Traffic Light Game
 * Control the traffic light and watch vehicles move through the intersection
 */

document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');

    // Vehicle emoji options
    const VEHICLE_EMOJIS = ['🚗', '🚕', '🚙', '🚌', '🚎', '🏎️', '🚓', '🚑', '🚒', '🚐', '🚚', '🚛', '🚜', '🛴', '🏍️'];

    // Traffic light states
    const LIGHT_STATES = {
        RED: 'red',
        YELLOW: 'yellow',
        GREEN: 'green'
    };

    // Speeds for different light states
    const SPEEDS = {
        STOPPED: 0,
        YELLOW: 1,
        GREEN: 4
    };

    // Game state
    let currentLight = LIGHT_STATES.RED;
    let roadLights = {
        top: LIGHT_STATES.RED,
        right: LIGHT_STATES.RED,
        bottom: LIGHT_STATES.RED,
        left: LIGHT_STATES.RED
    };
    let activeRoadIndex = -1; // -1: none, 0: top, 1: right, 2: bottom, 3: left

    let vehicles = [];
    let lastSpawnTime = 0;
    const SPAWN_INTERVAL = 1500; // 1.5 seconds for more traffic
    let ambientInterval = null;

    // Directions: top, right, bottom, left
    let DIRECTIONS = {
        TOP: { dx: 0, dy: 1, name: 'top' },      // Coming from top, moving down
        RIGHT: { dx: -1, dy: 0, name: 'right' },  // Coming from right, moving left
        BOTTOM: { dx: 0, dy: -1, name: 'bottom' }, // Coming from bottom, moving up
        LEFT: { dx: 1, dy: 0, name: 'left' }      // Coming from left, moving right
    };

    let roadWidth = 0;
    let laneWidth = 0;
    let centerX = 0;
    let centerY = 0;

    // Resize canvas to fit container
    function resizeCanvas() {
        const container = canvas.parentElement;
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        
        centerX = canvas.width / 2;
        centerY = canvas.height / 2;
        roadWidth = Math.min(canvas.width, canvas.height) * 0.4;
        laneWidth = roadWidth / 2;
    }

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('load', resizeCanvas);

    // Vehicle class
    class Vehicle {
        constructor(direction) {
            this.emoji = VEHICLE_EMOJIS[Math.floor(Math.random() * VEHICLE_EMOJIS.length)];
            this.direction = direction;
            this.size = Math.min(canvas.width, canvas.height) * 0.096;
            this.speed = SPEEDS.GREEN;
            this.stoppedByLight = false;
            this.stoppedByVehicle = false;
            
            // Assign random action (40% straight, 30% left, 30% right)
            const rand = Math.random();
            this.action = rand < 0.4 ? 'straight' : (rand < 0.7 ? 'left' : 'right');
            this.state = 'approaching'; // 'approaching', 'turning', 'exiting'
            
            this.setInitialPosition();
        }

        setInitialPosition() {
            const offset = laneWidth / 2;
            switch(this.direction.name) {
                case 'top':
                    this.x = centerX - offset - this.size / 2;
                    this.y = -this.size - 20;
                    this.rotation = Math.PI / 2; // Moving down
                    break;
                case 'right':
                    this.x = canvas.width + 20;
                    this.y = centerY - offset - this.size / 2;
                    this.rotation = Math.PI; // Moving left
                    break;
                case 'bottom':
                    this.x = centerX + offset - this.size / 2;
                    this.y = canvas.height + 20;
                    this.rotation = -Math.PI / 2; // Moving up
                    break;
                case 'left':
                    this.x = -this.size - 20;
                    this.y = centerY + offset - this.size / 2;
                    this.rotation = 0; // Moving right
                    break;
            }
        }

        setupBezierPoints() {
            const W = roadWidth / 2;
            const O = laneWidth / 2;
            
            this.p0 = { x: 0, y: 0 };
            this.p1 = { x: 0, y: 0 };
            this.p2 = { x: 0, y: 0 };
            
            switch(this.direction.name) {
                case 'top':
                    this.p0 = { x: centerX - O, y: centerY - W };
                    if (this.action === 'straight') {
                        this.p2 = { x: centerX - O, y: centerY + W };
                        this.p1 = { x: centerX - O, y: centerY };
                        this.targetDirection = DIRECTIONS.TOP;
                    } else if (this.action === 'right') {
                        this.p2 = { x: centerX - W, y: centerY - O };
                        this.p1 = { x: centerX - O, y: centerY - O };
                        this.targetDirection = DIRECTIONS.RIGHT;
                    } else if (this.action === 'left') {
                        this.p2 = { x: centerX + W, y: centerY + O };
                        this.p1 = { x: centerX - O, y: centerY + O };
                        this.targetDirection = DIRECTIONS.LEFT;
                    }
                    break;
                case 'bottom':
                    this.p0 = { x: centerX + O, y: centerY + W };
                    if (this.action === 'straight') {
                        this.p2 = { x: centerX + O, y: centerY - W };
                        this.p1 = { x: centerX + O, y: centerY };
                        this.targetDirection = DIRECTIONS.BOTTOM;
                    } else if (this.action === 'right') {
                        this.p2 = { x: centerX + W, y: centerY + O };
                        this.p1 = { x: centerX + O, y: centerY + O };
                        this.targetDirection = DIRECTIONS.LEFT;
                    } else if (this.action === 'left') {
                        this.p2 = { x: centerX - W, y: centerY - O };
                        this.p1 = { x: centerX + O, y: centerY - O };
                        this.targetDirection = DIRECTIONS.RIGHT;
                    }
                    break;
                case 'left':
                    this.p0 = { x: centerX - W, y: centerY + O };
                    if (this.action === 'straight') {
                        this.p2 = { x: centerX + W, y: centerY + O };
                        this.p1 = { x: centerX, y: centerY + O };
                        this.targetDirection = DIRECTIONS.LEFT;
                    } else if (this.action === 'right') {
                        this.p2 = { x: centerX - O, y: centerY + W };
                        this.p1 = { x: centerX - O, y: centerY + O };
                        this.targetDirection = DIRECTIONS.TOP;
                    } else if (this.action === 'left') {
                        this.p2 = { x: centerX + O, y: centerY - W };
                        this.p1 = { x: centerX + O, y: centerY + O };
                        this.targetDirection = DIRECTIONS.BOTTOM;
                    }
                    break;
                case 'right':
                    this.p0 = { x: centerX + W, y: centerY - O };
                    if (this.action === 'straight') {
                        this.p2 = { x: centerX - W, y: centerY - O };
                        this.p1 = { x: centerX, y: centerY - O };
                        this.targetDirection = DIRECTIONS.RIGHT;
                    } else if (this.action === 'right') {
                        this.p2 = { x: centerX + O, y: centerY - W };
                        this.p1 = { x: centerX + O, y: centerY - O };
                        this.targetDirection = DIRECTIONS.BOTTOM;
                    } else if (this.action === 'left') {
                        this.p2 = { x: centerX - O, y: centerY + W };
                        this.p1 = { x: centerX - O, y: centerY - O };
                        this.targetDirection = DIRECTIONS.TOP;
                    }
                    break;
            }
        }

        update(frontVehicle) {
            if (this.state === 'approaching') {
                this.checkTrafficLight();
                this.checkCollision(frontVehicle);

                if (this.stoppedByLight || this.stoppedByVehicle) {
                    this.speed = SPEEDS.STOPPED;
                } else {
                    const roadLight = roadLights[this.direction.name];
                    if (roadLight === LIGHT_STATES.YELLOW) {
                        this.speed = SPEEDS.YELLOW;
                    } else {
                        this.speed = SPEEDS.GREEN;
                    }
                }

                this.x += this.direction.dx * this.speed;
                this.y += this.direction.dy * this.speed;

                // Check crossing stop line
                const stopLine = roadWidth / 2;
                let crossed = false;
                if (this.direction.name === 'top' && (this.y + this.size >= centerY - stopLine)) crossed = true;
                else if (this.direction.name === 'right' && (this.x <= centerX + stopLine)) crossed = true;
                else if (this.direction.name === 'bottom' && (this.y <= centerY + stopLine)) crossed = true;
                else if (this.direction.name === 'left' && (this.x + this.size >= centerX - stopLine)) crossed = true;

                if (crossed) {
                    this.state = 'turning';
                    this.turnT = 0;
                    this.setupBezierPoints();
                }
            } else if (this.state === 'turning') {
                const roadLight = roadLights[this.direction.name];
                this.speed = (roadLight === LIGHT_STATES.YELLOW) ? SPEEDS.YELLOW : SPEEDS.GREEN;
                
                const L = Math.hypot(this.p2.x - this.p0.x, this.p2.y - this.p0.y);
                const turnLength = (this.action === 'straight') ? L : (1.2 * L);
                this.turnT += this.speed / turnLength;

                if (this.turnT >= 1) {
                    this.turnT = 1;
                    this.state = 'exiting';
                    this.direction = this.targetDirection;
                    this.x = this.p2.x - this.size / 2;
                    this.y = this.p2.y - this.size / 2;
                    this.rotation = Math.atan2(this.direction.dy, this.direction.dx);
                } else {
                    const t = this.turnT;
                    const mt = 1 - t;
                    const px = mt*mt*this.p0.x + 2*mt*t*this.p1.x + t*t*this.p2.x;
                    const py = mt*mt*this.p0.y + 2*mt*t*this.p1.y + t*t*this.p2.y;
                    this.x = px - this.size / 2;
                    this.y = py - this.size / 2;

                    const tx = 2*mt*(this.p1.x - this.p0.x) + 2*t*(this.p2.x - this.p1.x);
                    const ty = 2*mt*(this.p1.y - this.p0.y) + 2*t*(this.p2.y - this.p1.y);
                    this.rotation = Math.atan2(ty, tx);
                }
            } else if (this.state === 'exiting') {
                this.speed = SPEEDS.GREEN;
                this.x += this.direction.dx * this.speed;
                this.y += this.direction.dy * this.speed;
            }
        }

        checkTrafficLight() {
            const roadLight = roadLights[this.direction.name];
            if (roadLight !== LIGHT_STATES.RED) {
                this.stoppedByLight = false;
                return;
            }
            if (this.stoppedByLight) return;
            const stopLine = roadWidth / 2 + 10;
            switch(this.direction.name) {
                case 'top':
                    if (this.y + this.size <= centerY - stopLine && this.y + this.size + SPEEDS.GREEN > centerY - stopLine) {
                        this.stoppedByLight = true;
                        this.y = centerY - stopLine - this.size;
                    }
                    break;
                case 'right':
                    if (this.x >= centerX + stopLine && this.x - SPEEDS.GREEN < centerX + stopLine) {
                        this.stoppedByLight = true;
                        this.x = centerX + stopLine;
                    }
                    break;
                case 'bottom':
                    if (this.y >= centerY + stopLine && this.y - SPEEDS.GREEN < centerY + stopLine) {
                        this.stoppedByLight = true;
                        this.y = centerY + stopLine;
                    }
                    break;
                case 'left':
                    if (this.x + this.size <= centerX - stopLine && this.x + this.size + SPEEDS.GREEN > centerX - stopLine) {
                        this.stoppedByLight = true;
                        this.x = centerX - stopLine - this.size;
                    }
                    break;
            }
        }

        checkCollision(frontVehicle) {
            this.stoppedByVehicle = false;
            if (!frontVehicle || frontVehicle.state !== 'approaching') return;
            
            const minDistance = this.size * 1.15;
            const dist = this.getDistanceTo(frontVehicle);
            if (dist < minDistance + 2) {
                this.stoppedByVehicle = true;
                switch(this.direction.name) {
                    case 'top': this.y = frontVehicle.y - minDistance; break;
                    case 'right': this.x = frontVehicle.x + minDistance; break;
                    case 'bottom': this.y = frontVehicle.y + minDistance; break;
                    case 'left': this.x = frontVehicle.x - minDistance; break;
                }
            }
        }

        getDistanceTo(other) {
            return Math.sqrt(
                Math.pow((other.x + other.size / 2) - (this.x + this.size / 2), 2) +
                Math.pow((other.y + other.size / 2) - (this.y + this.size / 2), 2)
            );
        }

        draw() {
            ctx.font = `${this.size}px Arial`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.save();
            ctx.translate(this.x + this.size / 2, this.y + this.size / 2);
            ctx.rotate(this.rotation + Math.PI);
            ctx.fillText(this.emoji, 0, 0);
            ctx.restore();
        }

        isOffScreen() {
            const buffer = 100;
            return (this.x < -buffer || this.x > canvas.width + buffer || this.y < -buffer || this.y > canvas.height + buffer);
        }
    }

    function drawIntersection() {
        ctx.fillStyle = '#7ec850';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = '#999999';
        ctx.fillRect(centerX - roadWidth / 2, 0, roadWidth, canvas.height);
        ctx.fillRect(0, centerY - roadWidth / 2, canvas.width, roadWidth);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 4;
        ctx.setLineDash([20, 20]);
        ctx.beginPath();
        ctx.moveTo(centerX, 0); ctx.lineTo(centerX, canvas.height); ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, centerY); ctx.lineTo(canvas.width, centerY); ctx.stroke();
        ctx.setLineDash([]);

        // Draw individual stop lines colored by active light
        const stopDist = roadWidth / 2 + 5;
        const directions = ['top', 'right', 'bottom', 'left'];
        
        directions.forEach(dir => {
            const light = roadLights[dir];
            ctx.strokeStyle = light === LIGHT_STATES.RED ? '#ff0000' : (light === LIGHT_STATES.YELLOW ? '#ffff00' : '#00ff00');
            ctx.lineWidth = 8;
            ctx.beginPath();
            if (dir === 'top') {
                ctx.moveTo(centerX - roadWidth / 2, centerY - stopDist);
                ctx.lineTo(centerX, centerY - stopDist);
            } else if (dir === 'right') {
                ctx.moveTo(centerX + stopDist, centerY - roadWidth / 2);
                ctx.lineTo(centerX + stopDist, centerY);
            } else if (dir === 'bottom') {
                ctx.moveTo(centerX, centerY + stopDist);
                ctx.lineTo(centerX + roadWidth / 2, centerY + stopDist);
            } else if (dir === 'left') {
                ctx.moveTo(centerX - stopDist, centerY);
                ctx.lineTo(centerX - stopDist, centerY + roadWidth / 2);
            }
            ctx.stroke();
        });

        drawTrees(centerX, centerY, roadWidth);
    }

    function drawTrees(centerX, centerY, roadWidth) {
        const treePositions = [
            { x: centerX - roadWidth - 60, y: centerY - roadWidth - 60, size: 50 },
            { x: centerX - roadWidth - 30, y: centerY - roadWidth - 30, size: 40 },
            { x: centerX + roadWidth + 60, y: centerY - roadWidth - 60, size: 50 },
            { x: centerX + roadWidth + 30, y: centerY - roadWidth - 30, size: 40 },
            { x: centerX - roadWidth - 60, y: centerY + roadWidth + 60, size: 50 },
            { x: centerX - roadWidth - 30, y: centerY + roadWidth + 30, size: 40 },
            { x: centerX + roadWidth + 60, y: centerY + roadWidth + 60, size: 50 },
            { x: centerX + roadWidth + 30, y: centerY + roadWidth + 30, size: 40 }
        ];
        treePositions.forEach(pos => drawTree(pos.x, pos.y, pos.size));
    }

    function drawTree(x, y, size) {
        const foliageColor = '#228B22';
        const darkerGreen = '#1a6b1a';
        ctx.fillStyle = foliageColor;
        ctx.beginPath(); ctx.arc(x, y, size, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = darkerGreen;
        ctx.beginPath(); ctx.arc(x - size * 0.3, y + size * 0.2, size * 0.4, 0, Math.PI * 2); ctx.fill();
    }

    function spawnVehicle() {
        const directions = Object.values(DIRECTIONS);
        const randomDirection = directions[Math.floor(Math.random() * directions.length)];
        vehicles.push(new Vehicle(randomDirection));
    }

    function setTrafficLight(light) {
        currentLight = light;
        if (typeof vibrateSuccess === 'function') vibrateSuccess();
        
        document.querySelectorAll('.traffic-light-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.light === light) btn.classList.add('active');
        });

        // Update road lights
        if (light === LIGHT_STATES.RED) {
            roadLights.top = LIGHT_STATES.RED;
            roadLights.right = LIGHT_STATES.RED;
            roadLights.bottom = LIGHT_STATES.RED;
            roadLights.left = LIGHT_STATES.RED;
        } else if (light === LIGHT_STATES.GREEN) {
            activeRoadIndex = (activeRoadIndex + 1) % 4;
            const directions = ['top', 'right', 'bottom', 'left'];
            directions.forEach((dir, idx) => {
                roadLights[dir] = (idx === activeRoadIndex) ? LIGHT_STATES.GREEN : LIGHT_STATES.RED;
            });
        } else if (light === LIGHT_STATES.YELLOW) {
            activeRoadIndex = (activeRoadIndex + 1) % 4;
            const directions = ['top', 'right', 'bottom', 'left'];
            directions.forEach((dir, idx) => {
                roadLights[dir] = (idx === activeRoadIndex) ? LIGHT_STATES.YELLOW : LIGHT_STATES.RED;
            });
        }

        if (typeof speakText === 'function') {
            const directions = ['top', 'right', 'bottom', 'left'];
            const roadName = activeRoadIndex >= 0 ? directions[activeRoadIndex].toUpperCase() : 'ALL';
            switch(light) {
                case LIGHT_STATES.RED: speakText("Red light, all stop"); break;
                case LIGHT_STATES.YELLOW: speakText(`${roadName} road yellow, go slow`); break;
                case LIGHT_STATES.GREEN: speakText(`${roadName} road green, go`); break;
            }
        }
        updateAmbientSounds();
    }

    function updateAmbientSounds() {
        clearInterval(ambientInterval);
        if (currentLight === LIGHT_STATES.RED) {
            ambientInterval = setInterval(() => {
                if (window.soundGenerator) soundGenerator.playTone(800 + Math.random()*400, 0.05, 'sine');
            }, 3000);
        } else if (currentLight === LIGHT_STATES.GREEN) {
            ambientInterval = setInterval(() => {
                if (window.soundGenerator) soundGenerator.playTone(100 + Math.random()*50, 0.1, 'triangle');
            }, 500);
        }
    }

    function gameLoop(timestamp) {
        if (canvas.width === 0 || canvas.height === 0) {
            resizeCanvas();
        }
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawIntersection();
        if (timestamp - lastSpawnTime > SPAWN_INTERVAL) {
            spawnVehicle();
            lastSpawnTime = timestamp;
        }

        // Group approaching vehicles by direction for stable collision queueing
        const lanes = { top: [], right: [], bottom: [], left: [] };
        vehicles.forEach(v => {
            if (v.state === 'approaching') {
                lanes[v.direction.name].push(v);
            }
        });

        // Sort lanes front-to-back
        lanes.top.sort((a, b) => b.y - a.y);
        lanes.right.sort((a, b) => a.x - b.x);
        lanes.bottom.sort((a, b) => a.y - b.y);
        lanes.left.sort((a, b) => b.x - a.x);

        for (let i = vehicles.length - 1; i >= 0; i--) {
            const vehicle = vehicles[i];
            
            let frontVehicle = null;
            if (vehicle.state === 'approaching') {
                const lane = lanes[vehicle.direction.name];
                const idx = lane.indexOf(vehicle);
                if (idx > 0) {
                    frontVehicle = lane[idx - 1];
                }
            }

            vehicle.update(frontVehicle);
            vehicle.draw();
            if (vehicle.isOffScreen()) vehicles.splice(i, 1);
        }
        requestAnimationFrame(gameLoop);
    }

    function createRipple(x, y) {
        const ripple = document.createElement('div');
        ripple.className = 'ripple-effect';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.style.width = '20px';
        ripple.style.height = '20px';
        document.body.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);
    }

    document.querySelectorAll('.traffic-light-btn').forEach(btn => {
        const handler = function(e) {
            if (typeof ghostHand !== 'undefined') ghostHand.stop();
            const rect = e.target.getBoundingClientRect();
            const x = e.clientX || (e.touches ? e.touches[0].clientX : rect.left + rect.width/2);
            const y = e.clientY || (e.touches ? e.touches[0].clientY : rect.top + rect.height/2);
            createRipple(x, y);
            const light = this.dataset.light;
            setTrafficLight(light);
        };
        btn.addEventListener('click', handler);
        btn.addEventListener('touchstart', (e) => { e.preventDefault(); handler.call(btn, e); });
    });

    requestAnimationFrame(gameLoop);
    updateAmbientSounds();
});
