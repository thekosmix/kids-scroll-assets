document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('game-container');
    const buddy = document.getElementById('buddy');
    
    let x = 50, y = 50;
    let vx = 3, vy = 3;
    let size = 120;
    let isPlaying = true;
    let tapCount = 0;
    let guide = null;
    let startTime = Date.now();
    
    const buddies = [
        { emoji: '🐶', name: 'Dog' },
        { emoji: '🐱', name: 'Cat' },
        { emoji: '🐭', name: 'Mouse' },
        { emoji: '🐹', name: 'Hamster' },
        { emoji: '🐰', name: 'Rabbit' },
        { emoji: '🦊', name: 'Fox' },
        { emoji: '🐻', name: 'Bear' },
        { emoji: '🐼', name: 'Panda' },
        { emoji: '🐨', name: 'Koala' },
        { emoji: '🐯', name: 'Tiger' },
        { emoji: '🦁', name: 'Lion' },
        { emoji: '🐮', name: 'Cow' },
        { emoji: '🐷', name: 'Pig' },
        { emoji: '🐸', name: 'Frog' },
        { emoji: '🐵', name: 'Monkey' },
        { emoji: '🐘', name: 'Elephant' },
        { emoji: '🦓', name: 'Zebra' },
        { emoji: '🦒', name: 'Giraffe' },
        { emoji: '🦘', name: 'Kangaroo' },
        { emoji: '🦛', name: 'Hippo' },
        { emoji: '🦏', name: 'Rhino' },
        { emoji: '🦍', name: 'Gorilla' },
        { emoji: '🦥', name: 'Sloth' },
        { emoji: '🦦', name: 'Otter' },
        { emoji: '🦨', name: 'Skunk' },
        { emoji: '🦡', name: 'Badger' },
        { emoji: '🦇', name: 'Bat' },
        { emoji: '🦉', name: 'Owl' },
        { emoji: '🦄', name: 'Unicorn' }
    ];

    function initGame() {
        x = container.clientWidth / 2 - size / 2;
        y = container.clientHeight / 2 - size / 2;
        
        vx = (Math.random() > 0.5 ? 3 : -3);
        vy = (Math.random() > 0.5 ? 3 : -3);
        
        const buddyData = buddies[Math.floor(Math.random() * buddies.length)];
        buddy.textContent = buddyData.emoji;
        
        if (typeof playAnimalSound === 'function') {
            playAnimalSound(buddyData.emoji);
        }

        if (typeof speakText === 'function') {
            speakText("Tap the bouncing buddy!");
        }

        if (typeof GhostHand !== 'undefined') {
            if (!guide) guide = new GhostHand();
        }

        requestAnimationFrame(update);
    }

    function update() {
        if (!isPlaying) return;
        
        x += vx;
        y += vy;
        
        const w = container.clientWidth;
        const h = container.clientHeight;
        
        // Bounce off walls
        if (x <= 0) { x = 0; vx *= -1; playBoing(); }
        if (x + size >= w) { x = w - size; vx *= -1; playBoing(); }
        if (y <= 0) { y = 0; vy *= -1; playBoing(); }
        if (y + size >= h) { y = h - size; vy *= -1; playBoing(); }
        
        buddy.style.transform = `translate(${x}px, ${y}px)`;
        
        if (guide && tapCount === 0) {
            if (!guide.isVisible) {
                guide.show('ghost-tap', '50%', '50%', 'Tap it!');
                guide.isVisible = true; // custom flag
            }
        }

        requestAnimationFrame(update);
    }

    buddy.addEventListener('pointerdown', (e) => {
        if (e.cancelable) e.preventDefault();
        
        if (guide) {
            guide.stop();
            guide = null; // hide forever after first tap
        }
        
        tapCount++;
        const newBuddy = buddies[Math.floor(Math.random() * buddies.length)];
        buddy.textContent = newBuddy.emoji;
        
        if (typeof playAnimalSound === 'function') {
            playAnimalSound(newBuddy.emoji);
        }
        if (typeof speakText === 'function') {
            speakText(newBuddy.name);
        }
        
        // Speed up slightly and change direction randomly
        vx = (Math.random() > 0.5 ? 1 : -1) * (3 + Math.random() * 2);
        vy = (Math.random() > 0.5 ? 1 : -1) * (3 + Math.random() * 2);
        
        playFunnySynth();
        
        // Bubble effect
        buddy.style.transition = 'transform 0.1s';
        buddy.style.transform = `translate(${x}px, ${y}px) scale(1.3)`;
        setTimeout(() => {
            buddy.style.transition = 'none';
        }, 100);

        if (tapCount % 5 === 0) {
            if (typeof triggerCelebration === 'function') triggerCelebration(false);
        }
        
        if (tapCount === 10 && typeof recordGameStats === 'function') {
            recordGameStats('bouncing-buddy', Math.round((Date.now() - startTime)/1000), { taps: tapCount });
        }
    });

    function playBoing() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            const audioCtx = new AudioContext();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.frequency.value = 150;
            osc.type = 'triangle';
            gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.1);
        } catch(e){}
    }

    function playFunnySynth() {
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (!AudioContext) return;
            const audioCtx = new AudioContext();
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            
            // Funny pitch sweep
            osc.frequency.setValueAtTime(200, audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(800, audioCtx.currentTime + 0.1);
            osc.type = 'square';
            
            gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.2);
            
            osc.start();
            osc.stop(audioCtx.currentTime + 0.2);
        } catch(e){}
    }

    initGame();
});
