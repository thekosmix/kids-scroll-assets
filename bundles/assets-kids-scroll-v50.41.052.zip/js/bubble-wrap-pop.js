document.addEventListener('DOMContentLoaded', () => {
    const grid = document.getElementById('bubbleGrid');
    
    // Bubble properties
    const bubbleSize = 60; // Size of bubble (adjust to fit container)
    const containerSize = 320;
    const center = containerSize / 2 - bubbleSize / 2;
    
    let totalBubbles = 0;
    let poppedCount = 0;
    let currentFormationIdx = -1;
    
    // Formations
    const formations = [
        // 0: Grid (4x4)
        () => {
            const coords = [];
            const offset = 20;
            const step = (containerSize - offset*2 - bubbleSize) / 3;
            for(let r=0; r<4; r++){
                for(let c=0; c<4; c++){
                    coords.push({x: offset + c*step, y: offset + r*step});
                }
            }
            return coords;
        },
        // 1: Circle
        () => {
            const coords = [];
            const num = 12;
            const radius = 100;
            for(let i=0; i<num; i++){
                const angle = (i/num) * Math.PI * 2;
                coords.push({
                    x: center + radius * Math.cos(angle),
                    y: center + radius * Math.sin(angle)
                });
            }
            coords.push({x: center, y: center}); // center bubble
            return coords;
        },
        // 2: Cross (+)
        () => {
            const coords = [];
            const step = 60;
            for(let i=-2; i<=2; i++){
                coords.push({x: center + i*step, y: center});
                if(i !== 0) coords.push({x: center, y: center + i*step});
            }
            return coords;
        },
        // 3: X Shape
        () => {
            const coords = [];
            const step = 45;
            for(let i=-2; i<=2; i++){
                coords.push({x: center + i*step, y: center + i*step});
                if(i !== 0) coords.push({x: center + i*step, y: center - i*step});
            }
            return coords;
        },
        // 4: Triangle
        () => {
            const coords = [];
            let yOffset = 20;
            let step = 60;
            for(let row=0; row<4; row++){
                let numCols = row + 1;
                let startX = center - ((numCols-1) * step)/2;
                for(let col=0; col<numCols; col++){
                    coords.push({x: startX + col*step, y: yOffset + row*step});
                }
            }
            return coords;
        },
        // 5: Diamond
        () => {
            const coords = [];
            let step = 50;
            let rows = [1, 2, 3, 2, 1];
            let yOffset = 40;
            for(let r=0; r<rows.length; r++){
                let numCols = rows[r];
                let startX = center - ((numCols-1) * step)/2;
                for(let c=0; c<numCols; c++){
                    coords.push({x: startX + c*step, y: yOffset + r*step});
                }
            }
            return coords;
        },
        // 6: Checkerboard
        () => {
            const coords = [];
            const offset = 30;
            const step = 65;
            for(let r=0; r<4; r++){
                for(let c=0; c<4; c++){
                    if ((r+c)%2 === 0) {
                        coords.push({x: offset + c*step, y: offset + r*step});
                    }
                }
            }
            return coords;
        },
        // 7: Square Border
        () => {
            const coords = [];
            const offset = 20;
            const step = (containerSize - offset*2 - bubbleSize) / 3;
            for(let r=0; r<4; r++){
                for(let c=0; c<4; c++){
                    if (r === 0 || r === 3 || c === 0 || c === 3) {
                        coords.push({x: offset + c*step, y: offset + r*step});
                    }
                }
            }
            return coords;
        },
        // 8: Horizontal Lines
        () => {
            const coords = [];
            const offset = 30;
            const stepX = 70;
            const stepY = 80;
            for(let r=0; r<3; r++){
                for(let c=0; c<4; c++){
                    coords.push({x: offset + c*stepX, y: offset + r*stepY + 20});
                }
            }
            return coords;
        },
        // 9: Random Scatter
        () => {
            const coords = [];
            for(let i=0; i<12; i++){
                coords.push({
                    x: Math.random() * (containerSize - bubbleSize),
                    y: Math.random() * (containerSize - bubbleSize)
                });
            }
            return coords;
        }
    ];
    
    // Initialize Game
    function initGame() {
        grid.innerHTML = '';
        poppedCount = 0;
        
        // Pick next formation
        currentFormationIdx = (currentFormationIdx + 1) % formations.length;
        const coords = formations[currentFormationIdx]();
        totalBubbles = coords.length;
        
        coords.forEach((pos, idx) => {
            const bubble = document.createElement('div');
            bubble.classList.add('bubble');
            bubble.style.width = bubbleSize + 'px';
            bubble.style.height = bubbleSize + 'px';
            bubble.style.left = pos.x + 'px';
            bubble.style.top = pos.y + 'px';
            
            const popHandler = (e) => {
                e.preventDefault(); 
                if (!bubble.classList.contains('popped')) {
                    popBubble(bubble);
                }
            };
            
            bubble.addEventListener('mousedown', popHandler);
            bubble.addEventListener('touchstart', popHandler, { passive: false });
            
            grid.appendChild(bubble);
        });
        
        // Wait a small delay
        setTimeout(() => {
            if (typeof showStartupGuide === 'function') {
                showStartupGuide("Pop the bubbles!", {
                    type: 'ghost-tap',
                    startX: (grid.getBoundingClientRect().left + coords[0].x + bubbleSize/2) + 'px',
                    startY: (grid.getBoundingClientRect().top + coords[0].y + bubbleSize/2) + 'px'
                });
            }
        }, 500);
    }
    
    // Pop a bubble
    function popBubble(bubble) {
        bubble.classList.add('popped');
        bubble.innerHTML = '💥';
        
        playPopSound();
        poppedCount++;
        
        if (poppedCount >= totalBubbles) {
            setTimeout(() => {
                try {
                    if (typeof triggerCelebration === 'function') {
                        triggerCelebration();
                    }
                    if (typeof speakText === 'function') {
                        speakText("All popped! Great job!");
                    }
                } catch(e) {}
                // Auto restart after 3 seconds
                setTimeout(initGame, 3000);
            }, 500);
        }
    }
    
    let audioCtx;
    function playPopSound() {
        try {
            if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
            if (audioCtx.state === 'suspended') audioCtx.resume();
            
            const oscillator = audioCtx.createOscillator();
            const gainNode = audioCtx.createGain();
            
            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(800, audioCtx.currentTime);
            oscillator.frequency.exponentialRampToValueAtTime(100, audioCtx.currentTime + 0.1);
            
            gainNode.gain.setValueAtTime(1, audioCtx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
            
            oscillator.connect(gainNode);
            gainNode.connect(audioCtx.destination);
            
            oscillator.start();
            oscillator.stop(audioCtx.currentTime + 0.1);
        } catch (e) {
            console.warn("Audio play failed", e);
        }
    }
    
    initGame();
});
