// Import in-memory ZIP decompression library
try {
  importScripts('/assets/vendor/fflate.min.js');
} catch (e) {
  console.warn('fflate import failed:', e);
}

// CACHE_NAME versioning logic: Major.Minor.Patch
// Major = Number of games in /game folder
// Minor = Number of blogs in /blog folder
// Patch = Number of edits/updates (content, SEO, bug fixes)
const CACHE_NAME = 'kids-scroll-v50.41.052';
const OFFLINE_URL = '/';
const ZIP_BUNDLE_URL = `https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/bundles/assets-${CACHE_NAME}.zip`;

const urlsToCache = [
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/assets/jsons/story-and-rhymes.json',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/assets/jsons/wonders-and-facts.json',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/assets/sounds/animal-sprite.mp3',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/assets/sounds/kids-scroll-background-music.mp3',
  // Core & Config
  '/',
  '/favicon.ico',
  '/manifest.json',
  '/service-worker.js',
  '/assets/vendor/fflate.min.js',
  '/launch/index.html',
  // Pages
  '/pages/about.html',
  '/pages/contact.html',
  '/pages/parental-stats.html',
  '/pages/privacy-policy.html',
  '/pages/research.html',
  '/pages/terms-conditions.html',
  // Blogs
  '/blog/index.html',
  // Questions & Wonder (Hub & 76 Canonical Topic Pages)
  '/question/index.html',
  '/question/cat.html',
  '/question/dog.html',
  '/question/rabbit.html',
  '/question/duck.html',
  '/question/cow.html',
  '/question/horse.html',
  '/question/pig.html',
  '/question/sheep.html',
  '/question/turtle.html',
  '/question/elephant.html',
  '/question/lion.html',
  '/question/monkey.html',
  '/question/bear.html',
  '/question/tiger.html',
  '/question/giraffe.html',
  '/question/zebra.html',
  '/question/panda.html',
  '/question/fox.html',
  '/question/kangaroo.html',
  '/question/penguin.html',
  '/question/bird.html',
  '/question/frog.html',
  '/question/bee.html',
  '/question/car.html',
  '/question/bus.html',
  '/question/train.html',
  '/question/airplane.html',
  '/question/rocket.html',
  '/question/boat.html',
  '/question/bicycle.html',
  '/question/bike.html',
  '/question/fire-truck.html',
  '/question/home.html',
  '/question/school.html',
  '/question/playground.html',
  '/question/park.html',
  '/question/supermarket.html',
  '/question/mall.html',
  '/question/library.html',
  '/question/beach.html',
  '/question/farm.html',
  '/question/rain.html',
  '/question/rainbow.html',
  '/question/snow.html',
  '/question/thunder.html',
  '/question/wind.html',
  '/question/sea.html',
  '/question/sun.html',
  '/question/river.html',
  '/question/seasons.html',
  '/question/clock.html',
  '/question/mirror.html',
  '/question/magnet.html',
  '/question/ball.html',
  '/question/blocks.html',
  '/question/shoes.html',
  '/question/bed.html',
  '/question/umbrella.html',
  '/question/apple.html',
  '/question/banana.html',
  '/question/carrot.html',
  '/question/tree.html',
  '/question/flower.html',
  '/question/milk.html',
  '/question/bread.html',
  '/question/honey.html',
  '/question/moon.html',
  '/question/star.html',
  '/question/cloud.html',
  '/question/planet-earth.html',
  '/question/heart.html',
  '/question/eyes.html',
  '/question/hands.html',
  '/question/teeth.html',
  '/question/sleep.html',
  '/question/hiccup.html',
  // Stories (HTML)
  '/story/index.html',
  '/story/read.html',
  '/story/rabbit-story.html',
  '/story/elephant-story.html',
  '/story/lion-story.html',
  '/story/monkey-story.html',
  '/story/dog-story.html',
  '/story/cat-story.html',
  '/story/bear-story.html',
  '/story/duck-story.html',
  '/story/cow-story.html',
  '/story/tiger-story.html',
  '/story/giraffe-story.html',
  '/story/zebra-story.html',
  '/story/horse-story.html',
  '/story/panda-story.html',
  '/story/fox-story.html',
  '/story/pig-story.html',
  '/story/sheep-story.html',
  '/story/kangaroo-story.html',
  '/story/turtle-story.html',
  '/story/penguin-story.html',
  '/story/brush-teeth-toothpaste-train.html',
  '/story/splish-splash-bubble-bath.html',
  '/story/where-do-toys-sleep-cleanup.html',
  '/story/big-kid-bed-sleep-story.html',
  '/story/left-shoe-right-shoe.html',
  '/story/bubble-monster-wash-hands.html',
  '/story/gentle-hair-nail-trim.html',
  '/story/listen-to-tummy-bell.html',
  '/story/the-potty-crown.html',
  '/story/big-kid-underwear-day.html',
  '/story/wipe-flush-and-cheer.html',
  '/story/oops-its-okay-potty.html',
  '/story/rainbow-plate-adventure.html',
  '/story/table-astronaut-manners.html',
  '/story/mighty-water-sipper.html',
  '/story/spoon-and-fork-explorers.html',
  '/story/little-chefs-soup.html',
  '/story/magic-pocket-kiss-goodbye.html',
  '/story/hi-my-name-is-sam.html',
  '/story/circle-time-sunshine.html',
  '/story/the-sharing-timer.html',
  '/story/pack-my-super-backpack.html',
  '/story/blowing-out-the-candle.html',
  '/story/use-your-talking-voice.html',
  '/story/the-broken-crayon.html',
  '/story/warm-apology-hug.html',
  '/story/big-sibling-helper.html',
  '/story/gentle-slide-line.html',
  '/story/pass-the-ball-to-me.html',
  '/story/backyard-bug-safari.html',
  '/story/helmet-on-wheels-roll.html',
  '/story/five-more-minutes-warning.html',
  '/story/dr-bear-stethoscope.html',
  '/story/counting-pearly-whites-dentist.html',
  '/story/the-cape-of-courage-haircut.html',
  '/story/the-magic-bandage.html',
  '/story/parking-lot-super-hold.html',
  '/story/the-cart-helper-supermarket.html',
  '/story/click-clack-safe-and-snug.html',
  '/story/hot-stove-freeze-feet.html',
// Games (HTML)
  '/game/animal-beatbox.html',
  '/game/animal-fight.html',
  '/game/balloon-pop.html',
  '/game/bouncing-buddy.html',
  '/game/breathing-bubble.html',
  '/game/bubble-wrap-pop.html',
  '/game/build-a-face.html',
  '/game/build-the-zoo.html',
  '/game/catch-treats.html',
  '/game/color-mixture.html',
  '/game/color-train.html',
  '/game/connect-the-dots.html',
  '/game/day-and-night.html',
  '/game/drawing-canvas.html',
  '/game/emoji-jigsaw.html',
  '/game/emoji-scroll.html',
  '/game/emoji-xylophone.html',
  '/game/emotion-explorer.html',
  '/game/feed-animals.html',
  '/game/find-the-hidden-friend.html',
  '/game/finger-painting.html',
  '/game/garden-growing.html',
  '/game/guess-the-time.html',
  '/game/hot-cold-sorter.html',
  '/game/index.html',
  '/game/land-sea-air.html',
  '/game/learn-letters.html',
  '/game/learn-numbers.html',
  '/game/magic-sand.html',
  '/game/make-fruit-salad.html',
  '/game/musical-instruments.html',
  '/game/odd-one-out.html',
  '/game/pattern-maker.html',
  '/game/rocket-burst.html',
  '/game/scrub-the-mud.html',
  '/game/shadow-match.html',
  '/game/shape-sorter.html',
  '/game/size-sorter.html',
  '/game/sort-the-groceries.html',
  '/game/spot-the-pair.html',
  '/game/traffic-light.html',
  '/game/whack-a-mole.html',
  '/game/where-do-they-live.html',
  '/game/who-is-it.html',
  '/game/trace-path.html',
  '/game/count-with-me.html',
  '/game/who-makes-sound.html',
  '/game/selective-bubble-pop.html',
  '/game/bake-a-cake.html',
  '/game/flashlight-explorer.html',
  '/game/egg-hatching.html',
  // Fonts
  '/assets/fonts/fredoka-variable.woff2',
  // CSS
  '/css/styles.css',
  '/css/styles.css?v=3',
  '/css/story.css?v=13',
  // JavaScript
  '/js/alphabet-game.js?v=1.0.0',
  '/js/animal-beatbox.js?v=1.1.0',
  '/js/animal.js?v=1.0.0',
  '/js/app.js?v=1.0.1',
  '/js/bouncing-buddy.js?v=1.0.1',
  '/js/breathing-bubble.js?v=1.0.0',
  '/js/bubble-wrap-pop.js?v=1.0.0',
  '/js/canvas-game.js?v=1.0.1',
  '/js/catch-treats.js?v=1.0.0',
  '/js/color-game.js?v=1.0.0',
  '/js/common-utils.js?v=1.2.9',
  '/js/animal-manifest.js?v=1.0.0',
  '/js/connect-the-dots.js?v=1.0.1',
  '/js/emoji-generator.js?v=1.0.0',
  '/js/emoji-xylophone.js?v=1.0.1',
  '/js/emotion-explorer.js?v=1.0.0',
  '/js/finger-painting.js?v=1.0.0',
  '/js/fruit-salad-game.js?v=1.0.0',
  '/js/hot-cold-sorter.js?v=1.0.1',
  '/js/land-sea-air.js?v=1.0.0',
  '/js/magic-sand.js?v=1.0.0',
  '/js/numbers-game.js?v=1.0.0',
  '/js/pattern-maker.js?v=1.0.1',
  '/js/rocket-game.js?v=1.0.0',
  '/js/size-sorter.js?v=1.0.0',
  '/js/sound-generator.js?v=1.0.0',
  '/js/traffic-light-game.js?v=1.0.3',
  '/js/utils.js?v=1.0.0',
  '/js/whack-a-mole.js?v=1.0.2',
  '/js/where-do-they-live.js?v=1.0.0',
  '/js/trace-path.js?v=1.0.2',
  '/js/count-with-me.js?v=1.0.1',
  '/js/who-makes-sound.js?v=1.0.3',
  '/js/selective-bubble-pop.js?v=1.0.6',
  '/js/bake-a-cake.js?v=1.0.2',
  '/js/flashlight-explorer.js?v=1.0.3',
  '/js/egg-hatching.js?v=1.0.2',
  '/js/standalone-nav.js?v=5',
  '/js/vendor/html2canvas.min.js?v=1.4.1',
  // Story JavaScript (model/wasm intentionally excluded, see note above)
  '/js/story/app.js?v=7',
  '/js/story/story-page.js?v=13',
  '/js/story/catalog.js',
  '/js/story/routine-stories.js',
  '/js/story/animals.js',
  '/js/story/classic-tales.js',
  '/js/story/content-filter.js',
  '/js/story/data-fetcher.js',
  '/js/story/db.js',
  '/js/story/flags.js',
  '/js/story/playground.js',
  '/js/story/scene-parser.js',
  '/js/story/stats.js',
  '/js/story/storage.js',
  '/js/story/story-engine.js',
  '/js/story/title-generator.js',
  '/js/story/tts.js',
  // Question & Wonder Modules
  '/js/question/catalog.js',
  '/js/question/data-fetcher.js',
  '/js/question/app.js?v=1',
  '/js/question/topic-page.js?v=7',
  // App Icons
  '/assets/icons/icon-128x128.png',
  '/assets/icons/icon-144x144.png',
  '/assets/icons/icon-152x152.png',
  '/assets/icons/icon-192x192.png',
  '/assets/icons/icon-384x384.png',
  '/assets/icons/icon-512x512.png',
  '/assets/icons/icon-72x72.png',
  '/assets/icons/icon-96x96.png',
  // Game SVG Icons
  '/assets/images/games/animal-beatbox-icon.svg',
  '/assets/images/games/animal-fight-icon.svg',
  '/assets/images/games/avatar-scroll-icon.svg',
  '/assets/images/games/balloon-pop-icon.svg',
  '/assets/images/games/bouncing-buddy-icon.svg',
  '/assets/images/games/breathing-bubble-icon.svg',
  '/assets/images/games/bubble-wrap-pop-icon.svg',
  '/assets/images/games/build-a-face-icon.svg',
  '/assets/images/games/build-the-zoo-icon.svg',
  '/assets/images/games/catch-treats-icon.svg',
  '/assets/images/games/color-mixture-icon.svg',
  '/assets/images/games/color-train-icon.svg',
  '/assets/images/games/connect-the-dots-icon.svg',
  '/assets/images/games/day-and-night-icon.svg',
  '/assets/images/games/drawing-canvas-icon.svg',
  '/assets/images/games/emoji-jigsaw-icon.svg',
  '/assets/images/games/emoji-xylophone-icon.svg',
  '/assets/images/games/emotion-explorer-icon.svg',
  '/assets/images/games/feed-the-animals-icon.svg',
  '/assets/images/games/find-the-hidden-friend-icon.svg',
  '/assets/images/games/finger-painting-icon.svg',
  '/assets/images/games/garden-growing-icon.svg',
  '/assets/images/games/guess-the-time-icon.svg',
  '/assets/images/games/hot-cold-sorter-icon.svg',
  '/assets/images/games/land-sea-air-icon.svg',
  '/assets/images/games/learn-letters-icon.svg',
  '/assets/images/games/learn-numbers-icon.svg',
  '/assets/images/games/magic-sand-icon.svg',
  '/assets/images/games/make-fruit-salad-icon.svg',
  '/assets/images/games/music-note-icon.svg',
  '/assets/images/games/odd-one-out-icon.svg',
  '/assets/images/games/pattern-maker-icon.svg',
  '/assets/images/games/rocket-burst-icon.svg',
  '/assets/images/games/scrub-the-mud-icon.svg',
  '/assets/images/games/shadow-match-icon.svg',
  '/assets/images/games/shape-sorter-icon.svg',
  '/assets/images/games/size-sorter-icon.svg',
  '/assets/images/games/sort-the-groceries-icon.svg',
  '/assets/images/games/spot-the-pair-icon.svg',
  '/assets/images/games/traffic-light-icon.svg',
  '/assets/images/games/whack-a-mole-icon.svg',
  '/assets/images/games/where-do-they-live-icon.svg',
  '/assets/images/games/who-is-it-icon.svg',
  '/assets/images/games/trace-path-icon.svg',
  '/assets/images/games/count-with-me-icon.svg',
  '/assets/images/games/who-makes-sound-icon.svg',
  '/assets/images/games/selective-bubble-pop-icon.svg',
  '/assets/images/games/bake-a-cake-icon.svg',
  '/assets/images/games/flashlight-explorer-icon.svg',
  '/assets/images/games/egg-hatching-icon.svg',
  '/assets/images/games/wonders-icon.svg',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/ks-traffic.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/ga-visit.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/ga-page-time.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/country-list.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/Teacher-Approved-1.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/Teacher-Approved-2.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/Teacher-Approved-3.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/parents/Teacher-Approved-4.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/youtube/nyt-meta-youtube.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/youtube/guardian-meta-youtube.webp',
  'https://cdn.jsdelivr.net/gh/thekosmix/kids-scroll-assets@main/media/campaigns/youtube/cnn-meta-youtube.webp',
  '/assets/images/others/google-play-badge.svg',
  '/assets/images/others/amazon-appstore-badge.svg',
  '/assets/images/others/pwa-install-prompt.webp',
  '/assets/images/others/pwa-chrome-menu.webp',
];

// MIME type mapping for in-memory Response generation from ZIP archive
const MIME_TYPES = {
  html: 'text/html; charset=utf-8',
  js: 'application/javascript; charset=utf-8',
  css: 'text/css; charset=utf-8',
  json: 'application/json; charset=utf-8',
  svg: 'image/svg+xml',
  png: 'image/png',
  webp: 'image/webp',
  ico: 'image/x-icon',
  woff2: 'font/woff2',
  mp3: 'audio/mpeg'
};

function getMimeType(filePath) {
  const ext = filePath.split('.').pop().split('?')[0].toLowerCase();
  return MIME_TYPES[ext] || 'application/octet-stream';
}

// Helper to cache assets using atomic ZIP extraction with graceful file-by-file fallback
let isCachingInProgress = false;

async function cacheAssetPack(targetUrls, isInstall = false) {
  if (isCachingInProgress && !isInstall) return;
  isCachingInProgress = true;

  try {
    const cache = await caches.open(CACHE_NAME);
    const total = targetUrls.length;

    const broadcastProgress = (loaded, maxTotal = total) => {
      self.clients.matchAll({ includeUncontrolled: true, type: 'window' }).then(clients => {
        clients.forEach(client => {
          client.postMessage({
            type: 'CACHE_PROGRESS',
            loaded,
            total: maxTotal
          });
        });
      });
    };

    const broadcastComplete = (maxTotal = total) => {
      self.clients.matchAll({ includeUncontrolled: true, type: 'window' }).then(clients => {
        clients.forEach(client => {
          client.postMessage({
            type: 'CACHE_COMPLETE',
            total: maxTotal
          });
        });
      });
    };

    // 1. ATTEMPT FAST ZIP EXTRACTION (1 request, 0 bytes Firebase egress)
    if (typeof fflate !== 'undefined' && fflate.unzipSync) {
      try {
        console.log(`[SW] Attempting fast ZIP bundle extraction from: ${ZIP_BUNDLE_URL}`);
        const zipResponse = await fetch(ZIP_BUNDLE_URL, { cache: 'reload' });
        if (zipResponse && zipResponse.ok) {
          const zipBuffer = new Uint8Array(await zipResponse.arrayBuffer());
          const unzipped = fflate.unzipSync(zipBuffer);
          const fileNames = Object.keys(unzipped);
          const zipTotal = fileNames.length;

          if (zipTotal > 0) {
            console.log(`[SW] Decompressed ${zipTotal} files from ZIP. Populating CacheStorage...`);
            for (let i = 0; i < zipTotal; i++) {
              const rawPath = fileNames[i];
              const fileBytes = unzipped[rawPath];
              const urlPath = '/' + rawPath.replace(/^[\/\\]+/, '');
              const contentType = getMimeType(urlPath);

              const cachedResponse = new Response(fileBytes, {
                headers: {
                  'Content-Type': contentType,
                  'Content-Length': fileBytes.length.toString()
                }
              });

              await cache.put(urlPath, cachedResponse.clone());
              if (urlPath === '/index.html') {
                await cache.put('/', cachedResponse.clone());
              }

              if (i % 15 === 0 || i === zipTotal - 1) {
                broadcastProgress(i + 1, zipTotal);
              }
            }

            // Also fetch remaining external CDN assets (e.g. mp3, campaign images) not in zip
            const externalUrls = targetUrls.filter(u => u.startsWith('http://') || u.startsWith('https://'));
            if (externalUrls.length > 0) {
              await Promise.all(
                externalUrls.map(async url => {
                  try {
                    const extRes = await fetch(new Request(url, { cache: 'reload' }));
                    if (extRes && extRes.ok) {
                      await cache.put(url, extRes);
                    }
                  } catch (e) {
                    console.warn(`[SW] Could not cache external asset ${url}:`, e);
                  }
                })
              );
            }

            console.log(`[SW] ✅ Atomic ZIP extraction and caching completed successfully!`);
            broadcastComplete(zipTotal);
            if (isInstall) await self.skipWaiting();
            return;
          }
        }
      } catch (zipErr) {
        console.warn('[SW] Fast ZIP bundle fetch/extraction failed, falling back to individual file caching:', zipErr);
      }
    }

    // 2. FALLBACK: INDIVIDUAL FILE FETCHING (If ZIP is missing or failed)
    const existingKeys = await cache.keys();
    const existingUrlSet = new Set(existingKeys.map(k => k.url));

    let loaded = 0;
    for (const u of targetUrls) {
      const fullUrl = u.startsWith('http') ? u : new URL(u, self.location.origin).href;
      if (existingUrlSet.has(fullUrl)) {
        loaded++;
      }
    }

    broadcastProgress(loaded, total);

    if (loaded >= total) {
      broadcastComplete(total);
      if (isInstall) await self.skipWaiting();
      return;
    }

    // Filter missing URLs to avoid re-downloading already cached files
    const missingUrls = targetUrls.filter(u => {
      const fullUrl = u.startsWith('http') ? u : new URL(u, self.location.origin).href;
      return !existingUrlSet.has(fullUrl);
    });

    // Process in batches of 5 to avoid network congestion
    const batchSize = 5;
    for (let i = 0; i < missingUrls.length; i += batchSize) {
      const batch = missingUrls.slice(i, i + batchSize);
      await Promise.all(
        batch.map(async url => {
          try {
            const response = await fetch(new Request(url, { cache: 'reload' }));
            if (response.ok) {
              await cache.put(url, response);
            } else {
              console.warn(`Failed to cache ${url}: ${response.status}`);
            }
          } catch (err) {
            console.error(`Network error caching ${url}:`, err);
          } finally {
            loaded++;
            broadcastProgress(loaded, total);
          }
        })
      );
    }

    broadcastComplete(total);
    if (isInstall) {
      await self.skipWaiting();
    }
  } finally {
    isCachingInProgress = false;
  }
}

// Message event for skip waiting and on-demand offline downloads
self.addEventListener('message', event => {
  if (!event.data) return;
  if (event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  } else if (event.data.type === 'START_OFFLINE_DOWNLOAD' || event.data.type === 'DOWNLOAD_ASSETS') {
    event.waitUntil(cacheAssetPack(urlsToCache, false));
  }
});

// Install event - robust individual caching with progress
self.addEventListener('install', event => {
  // Do NOT skipWaiting automatically until download completes
  event.waitUntil(cacheAssetPack(urlsToCache, true));
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event
self.addEventListener('fetch', event => {
  const isExternalAsset = event.request.url.startsWith('https://cdn.jsdelivr.net/');
  if (!event.request.url.startsWith(self.location.origin) && !isExternalAsset) return;

  const url = new URL(event.request.url);
  
  // 1. Normalize HTML directory paths for cache matching
  // This ensures query params on HTML (e.g. ?animal=cow) are safely ignored
  // and fixes the issue where offline links to "/game/" couldn't find "/game/index.html".
  let matchUrl = url.origin + url.pathname;
  if (url.pathname !== '/' && url.pathname.endsWith('/')) {
    matchUrl += 'index.html';
  }

  // 2. Determine Strategy
  const isHtml = url.pathname === '/' || url.pathname.endsWith('/') || url.pathname.endsWith('.html') || url.pathname.endsWith('manifest.json') || url.pathname.endsWith('service-worker.js');
  // Story JS is plain unversioned ES modules (import './x.js' has no cache-busting
  // query string), so it needs network-first too, or a stale cached module could
  // stick around indefinitely across deploys.
  const isStoryModule = url.pathname.startsWith('/js/story/') || url.pathname.startsWith('/js/question/');

  if (isHtml || isStoryModule) {
    // NETWORK-FIRST for HTML (and story JS modules) to ensure users always get the latest layout and versions.
    // If the network succeeds with 2xx, we update cache and return it.
    // If the network fails (offline) OR returns a non-2xx status (e.g. 402 Quota Exceeded, 429, 500, 502, 503, 504, 509),
    // we seamlessly fall back to the cached offline version.
    event.respondWith(
      fetch(event.request)
        .then(networkResponse => {
          if (networkResponse && networkResponse.ok) {
            const responseClone = networkResponse.clone();
            caches.open(CACHE_NAME).then(cache => {
              cache.put(event.request, responseClone);
            });
            return networkResponse;
          }
          // Server returned an error status (e.g. 402 Quota Exceeded, 429, 5xx)
          return caches.match(matchUrl, { ignoreSearch: true })
            .then(cachedResponse => {
              if (cachedResponse) return cachedResponse;
              if (event.request.mode === 'navigate') {
                if (url.pathname === '/' || url.pathname === '/index.html') {
                  return caches.match(OFFLINE_URL, { ignoreSearch: true });
                }
                return getOfflineFallbackPage();
              }
              return networkResponse;
            });
        })
        .catch(() => {
          return caches.match(matchUrl, { ignoreSearch: true })
            .then(cachedResponse => {
              if (cachedResponse) return cachedResponse;
              if (event.request.mode === 'navigate') {
                if (url.pathname === '/' || url.pathname === '/index.html') {
                  return caches.match(OFFLINE_URL, { ignoreSearch: true });
                }
                return getOfflineFallbackPage();
              }
              return new Response('', { status: 408, statusText: 'Request Timeout' });
            });
        })
    );
  } else {
    // STALE-WHILE-REVALIDATE Strategy for Assets (JS, CSS, SVGs, MP3s)
    // We try an exact match first (event.request) so cache-busting (?v=x) works properly.
    event.respondWith(
      caches.match(event.request)
        .then(cachedResponse => {
          const fetchPromise = fetch(event.request).then(networkResponse => {
            if (networkResponse && networkResponse.ok) {
              const responseClone = networkResponse.clone();
              caches.open(CACHE_NAME).then(cache => {
                cache.put(event.request, responseClone);
              });
              return networkResponse;
            }
            // If network returned an error status (402, 5xx), return cache if available
            return cachedResponse || caches.match(matchUrl, { ignoreSearch: true }) || networkResponse || new Response('', { status: 404 });
          }).catch(() => {
             // Network failed (offline). If we didn't have an exact cache hit
             // (e.g. because HTML requested ?v=2 but cache had ?v=1), we rescue it
             // by ignoring the search string so the app still works offline!
             return cachedResponse || caches.match(matchUrl, { ignoreSearch: true }) || new Response('', { status: 408, statusText: 'Request Timeout' });
          });

          return cachedResponse || fetchPromise;
        })
    );
  }
});

function getOfflineFallbackPage() {
  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>Offline</title>
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      height: 100vh; height: 100dvh; margin: 0; padding: 1.5rem; text-align: center;
      background: #f0f7f4; color: #2d2d2d; box-sizing: border-box;
    }
    .icon { font-size: 4rem; margin-bottom: 1rem; }
    h1 { font-size: 1.6rem; margin: 0 0 0.5rem; color: #6a11cb; }
    p { font-size: 1.15rem; color: #555; max-width: 340px; line-height: 1.5; margin: 0 0 2rem; }
    .btn {
      background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
      color: white; border: none; padding: 14px 28px; border-radius: 30px;
      font-size: 1.1rem; font-weight: bold; cursor: pointer; text-decoration: none;
      box-shadow: 0 4px 15px rgba(0,0,0,0.25);
    }
  </style>
</head>
<body>
  <div class="icon">📡</div>
  <h1>Download Required</h1>
  <p>Please connect to the internet to download and play this activity!</p>
  <a href="javascript:history.back()" class="btn">⬅️ Go Back</a>
</body>
</html>`;
  return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
}

