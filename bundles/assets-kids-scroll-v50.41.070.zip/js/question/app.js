const STORAGE_RECENT = 'kids_scroll_recent_wonders';

function loadRecentWonders() {
  const recentSection = document.getElementById('recently-explored-section');
  const recentScroll = document.getElementById('recently-explored-scroll');
  if (!recentSection || !recentScroll) return;

  try {
    const recentIds = JSON.parse(localStorage.getItem(STORAGE_RECENT) || '[]');
    if (!Array.isArray(recentIds) || recentIds.length === 0) {
      recentSection.style.display = 'none';
      return;
    }

    recentScroll.innerHTML = '';
    let addedCount = 0;

    recentIds.forEach(id => {
      const originalNode = document.querySelector(`.category-section:not(#recently-explored-section) .card-item[data-topic-id="${id}"]`);
      if (originalNode) {
        recentScroll.appendChild(originalNode.cloneNode(true));
        addedCount++;
      }
    });

    recentSection.style.display = addedCount > 0 ? 'block' : 'none';
  } catch (e) {
    recentSection.style.display = 'none';
  }
}

function setupFilters() {
  const ageFilter = document.getElementById('age-filter');
  const searchInput = document.getElementById('wonder-search');

  function getActiveAgeFilter() {
    if (typeof isPWAOrTWA === 'function' && isPWAOrTWA()) {
      try {
        const saved = localStorage.getItem('kids_scroll_selected_age');
        if (saved) return saved;
      } catch (e) {}
    }
    return ageFilter ? ageFilter.value : 'all';
  }

  function filterWonders(mode) {
    const selectedAge = getActiveAgeFilter();
    const searchQuery = searchInput ? searchInput.value.toLowerCase().trim() : '';

    const allItems = document.querySelectorAll('.category-section:not(#recently-explored-section) .card-item');

    allItems.forEach((item) => {
      let shouldShow = true;
      const itemAge = item.getAttribute('data-age');

      if (mode === 'age' && selectedAge !== 'all' && itemAge) {
        if (selectedAge === 'toddler') {
          shouldShow = ['1+', '2+', '3+'].includes(itemAge);
        } else if (selectedAge === 'preschool') {
          shouldShow = ['3+', '4+', '5+'].includes(itemAge);
        } else {
          const selectedAgeNum = parseInt(selectedAge, 10);
          const itemAgeNum = parseInt(itemAge, 10);
          if (isNaN(itemAgeNum) || itemAgeNum < selectedAgeNum) {
            shouldShow = false;
          }
        }
      } else if (mode === 'search' && searchQuery) {
        const title = item.querySelector('h3')?.textContent.toLowerCase() || '';
        if (!title.includes(searchQuery)) {
          shouldShow = false;
        }
      }

      item.style.display = shouldShow ? '' : 'none';
    });

    // Hide empty category sections
    document.querySelectorAll('.category-section:not(#recently-explored-section)').forEach((section) => {
      const items = section.querySelectorAll('.card-item');
      if (items.length === 0) return;

      let hasVisible = false;
      items.forEach((item) => {
        if (item.style.display !== 'none') hasVisible = true;
      });

      section.style.display = hasVisible ? 'block' : 'none';
    });
  }

  if (ageFilter) {
    ageFilter.addEventListener('change', (e) => {
      e.target.blur();
      if (searchInput) searchInput.value = '';
      filterWonders('age');
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      if (ageFilter) ageFilter.value = 'all';
      filterWonders('search');
    });
  }

  // In PWA/TWA standalone mode, initialize with the launch page age selection
  if (typeof isPWAOrTWA === 'function' && isPWAOrTWA()) {
    const savedAge = localStorage.getItem('kids_scroll_selected_age') || 'all';
    if (ageFilter) {
      if (ageFilter.querySelector(`option[value="${savedAge}"]`)) {
        ageFilter.value = savedAge;
      }
    }
    if (savedAge !== 'all') {
      filterWonders('age');
    }
  }
}

function init() {
  loadRecentWonders();
  setupFilters();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

window.addEventListener('pageshow', (event) => {
  if (event.persisted) {
    loadRecentWonders();
  }
});
