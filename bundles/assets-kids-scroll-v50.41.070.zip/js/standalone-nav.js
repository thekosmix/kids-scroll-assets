/**
 * Standalone-only nav: hides the marketing footer (blog/contact/social links
 * a kid could tap out to), hides the search/age-filters on hubs, injects a launcher
 * return button on the header left (🚀), and a static hub switcher button on the header right:
 * Play & Learn (🎮) -> Stories & Rhymes (📖) -> Wonders & Facts (💡) -> Play & Learn (🎮)
 * strictly when running installed (PWA/TWA). No-op in a regular browser tab.
 */
(function () {
  var isStandalone = (typeof isStandaloneMode === 'function' && isStandaloneMode()) ||
                     (typeof isPWAOrTWA === 'function' && isPWAOrTWA());
  if (!isStandalone) return;

  var path = window.location.pathname;
  var isGameMenu = path.endsWith('/game/') || path.endsWith('/game/index.html');
  var isStoryMenu = path.endsWith('/story/') || path.endsWith('/story/index.html');
  var isQuestionMenu = path.endsWith('/question/') || path.endsWith('/question/index.html');
  if (!isGameMenu && !isStoryMenu && !isQuestionMenu) return;

  // Mark <html> element as standalone
  if (document.documentElement) {
    document.documentElement.classList.add('is-pwa-standalone');
  }

  // Hide the marketing footer
  var footer = document.querySelector('footer');
  if (footer) footer.style.display = 'none';

  // Circular Mode Destination: Games -> Stories -> Questions -> Games
  var nextMode = isGameMenu
    ? { key: 'story', emoji: '📖', label: 'Stories & Rhymes', url: '/story/index.html', bg: 'linear-gradient(135deg, #ffb347 0%, #ffcc33 100%)', shadow: 'rgba(255, 179, 71, 0.45)' }
    : isStoryMenu
    ? { key: 'question', emoji: '💡', label: 'Wonders & Facts', url: '/question/index.html', bg: 'linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%)', shadow: 'rgba(251, 194, 235, 0.45)' }
    : { key: 'game', emoji: '🎮', label: 'Play & Learn', url: '/game/index.html', bg: 'linear-gradient(135deg, #00C9FF 0%, #92FE9D 100%)', shadow: 'rgba(0, 201, 255, 0.45)' };

  // Inject PWA/TWA hub styles (hide filters container & style header launcher / switcher buttons)
  if (!document.getElementById('pwa-standalone-hub-styles')) {
    var hubStyle = document.createElement('style');
    hubStyle.id = 'pwa-standalone-hub-styles';
    hubStyle.innerHTML = [
      '.is-pwa-standalone .filters-container { display: none !important; }',
      '.hub-launcher-btn, .hub-switcher-btn {',
      '  position: absolute;',
      '  top: 50%;',
      '  transform: translateY(-50%);',
      '  width: 44px;',
      '  height: 44px;',
      '  border-radius: 50%;',
      '  display: flex;',
      '  align-items: center;',
      '  justify-content: center;',
      '  font-size: 1.45rem;',
      '  text-decoration: none;',
      '  z-index: 101;',
      '  border: 2px solid rgba(255, 255, 255, 0.9);',
      '  cursor: pointer;',
      '  transition: transform 0.15s cubic-bezier(0.34, 1.56, 0.64, 1);',
      '  -webkit-tap-highlight-color: transparent;',
      '  user-select: none;',
      '  -webkit-user-select: none;',
      '  -webkit-touch-callout: none;',
      '}',
      '.hub-launcher-btn {',
      '  left: 12px;',
      '  background: #ffffff;',
      '  box-shadow: 0 4px 12px rgba(0,0,0,0.18);',
      '}',
      '.hub-switcher-btn {',
      '  right: 12px;',
      '  background: ' + nextMode.bg + ';',
      '  box-shadow: 0 4px 12px ' + nextMode.shadow + ';',
      '  border: 2px solid rgba(255, 255, 255, 0.9);',
      '  padding: 0;',
      '}',
      '.hub-launcher-btn:active, .hub-switcher-btn:active { transform: translateY(-50%) scale(0.9) !important; }',
      '@media (orientation: landscape) {',
      '  .hub-launcher-btn, .hub-switcher-btn { width: 38px; height: 38px; font-size: 1.25rem; }',
      '}'
    ].join('\n');
    document.head.appendChild(hubStyle);
  }

  // Inject Launcher button (left) and Mode Switcher (right) on the header of hub pages
  function injectHeaderButtons() {
    var header = document.querySelector('header');
    if (!header) return;
    header.style.position = 'relative';

    if (!document.getElementById('hub-launcher-btn')) {
      var launcherBtn = document.createElement('a');
      launcherBtn.id = 'hub-launcher-btn';
      launcherBtn.href = '/launch/index.html';
      launcherBtn.className = 'hub-launcher-btn';
      launcherBtn.setAttribute('aria-label', 'Return to Launch Page');
      launcherBtn.title = 'Choose Mode 🚀';
      launcherBtn.innerHTML = '🚀';
      header.appendChild(launcherBtn);
    }

    if (!document.getElementById('hub-switcher-btn')) {
      var switcherBtn = document.createElement('button');
      switcherBtn.id = 'hub-switcher-btn';
      switcherBtn.type = 'button';
      switcherBtn.className = 'hub-switcher-btn';
      switcherBtn.setAttribute('aria-label', 'Switch to ' + nextMode.label);
      switcherBtn.title = 'Switch to ' + nextMode.label;
      switcherBtn.innerHTML = '<span style="font-size: 1.45rem; line-height: 1; pointer-events: none;">' + nextMode.emoji + '</span>';
      switcherBtn.addEventListener('click', function () {
        switcherBtn.style.transform = 'translateY(-50%) scale(0.9)';
        try {
          localStorage.setItem('kids_scroll_last_mode', nextMode.key);
        } catch (e) {}
        setTimeout(function() {
          window.location.href = nextMode.url;
        }, 120);
      });
      header.appendChild(switcherBtn);
    }
  }

  // Automatically apply the saved age filter from the launch page
  function applySavedAgeFilter() {
    try {
      var savedAge = localStorage.getItem('kids_scroll_selected_age') || 'all';
      var ageSelect = document.getElementById('age-filter');
      if (ageSelect) {
        if (ageSelect.querySelector('option[value="' + savedAge + '"]')) {
          ageSelect.value = savedAge;
        }
        ageSelect.dispatchEvent(new Event('change'));
      }
    } catch (e) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      injectHeaderButtons();
      applySavedAgeFilter();
    });
  } else {
    injectHeaderButtons();
    applySavedAgeFilter();
  }
})();
