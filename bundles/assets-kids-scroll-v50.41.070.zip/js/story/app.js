const STORAGE_RECENT = 'kids_scroll_recent_stories';

function loadRecentStories() {
  const recentSection = document.getElementById('recently-listened-section');
  const recentScroll = document.getElementById('recently-listened-scroll');
  if (!recentSection || !recentScroll) return;

  try {
    const recentIds = JSON.parse(localStorage.getItem(STORAGE_RECENT) || '[]');
    if (!Array.isArray(recentIds) || recentIds.length === 0) {
      recentSection.style.display = 'none';
      return;
    }

    recentScroll.innerHTML = '';
    let addedCount = 0;

    recentIds.forEach(id => {
      // Find the first matching menu-item in the document
      const originalNode = document.querySelector(`.category-section:not(#recently-listened-section) .card-item[data-story-id="${id}"]`);
      if (originalNode) {
        recentScroll.appendChild(originalNode.cloneNode(true));
        addedCount++;
      }
    });

    recentSection.style.display = addedCount > 0 ? 'block' : 'none';
  } catch (e) {
    recentSection.style.display = 'none';
  }
}

function setupFilters() {
  const ageFilter = document.getElementById('age-filter');
  const searchInput = document.getElementById('story-search');

  function getActiveAgeFilter() {
    if (typeof isPWAOrTWA === 'function' && isPWAOrTWA()) {
      try {
        const saved = localStorage.getItem('kids_scroll_selected_age');
        if (saved) return saved;
      } catch (e) {}
    }
    return ageFilter ? ageFilter.value : 'all';
  }

  function filterStories(mode) {
    const selectedAge = getActiveAgeFilter();
    const searchQuery = searchInput ? searchInput.value.toLowerCase().trim() : '';
    
    // We only filter items inside main category sections (skip recent)
    const allItems = document.querySelectorAll('.category-section:not(#recently-listened-section) .card-item');

    allItems.forEach((item) => {
      let shouldShow = true;
      const storyAge = item.getAttribute('data-age');

      if (mode === 'age' && selectedAge !== 'all' && storyAge) {
        if (selectedAge === 'toddler') {
          shouldShow = ['1+', '2+', '3+'].includes(storyAge);
        } else if (selectedAge === 'preschool') {
          shouldShow = ['3+', '4+', '5+'].includes(storyAge);
        } else {
          const selectedAgeNum = parseInt(selectedAge, 10);
          const storyAgeNum = parseInt(storyAge, 10);
          if (isNaN(storyAgeNum) || storyAgeNum < selectedAgeNum) {
            shouldShow = false;
          }
        }
      } else if (mode === 'search' && searchQuery) {
        const title = item.querySelector('h2')?.textContent.toLowerCase() || '';
        if (!title.includes(searchQuery)) {
          shouldShow = false;
        }
      }

      item.style.display = shouldShow ? '' : 'none';
    });

    // Hide empty category sections
    document.querySelectorAll('.category-section:not(#recently-listened-section)').forEach((section) => {
      const items = section.querySelectorAll('.card-item');
      if (items.length === 0) return;

      let hasVisible = false;
      items.forEach((item) => {
        if (item.style.display !== 'none') hasVisible = true;
      });

      section.style.display = hasVisible ? 'block' : 'none';
    });
  }

  if (ageFilter) {
    ageFilter.addEventListener('change', (e) => {
      e.target.blur();
      if (searchInput) searchInput.value = '';
      filterStories('age');
    });
  }

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      if (ageFilter) ageFilter.value = 'all';
      filterStories('search');
    });
  }

  // In PWA/TWA standalone mode, initialize with the launch page age selection
  if (typeof isPWAOrTWA === 'function' && isPWAOrTWA()) {
    const savedAge = localStorage.getItem('kids_scroll_selected_age') || 'all';
    if (ageFilter) {
      if (ageFilter.querySelector(`option[value="${savedAge}"]`)) {
        ageFilter.value = savedAge;
      }
    }
    if (savedAge !== 'all') {
      filterStories('age');
    }
  }
}

function init() {
  loadRecentStories();
  setupFilters();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
